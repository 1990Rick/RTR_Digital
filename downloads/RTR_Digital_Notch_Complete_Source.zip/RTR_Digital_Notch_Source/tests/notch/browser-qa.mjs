import { chromium } from '@playwright/test';
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '../..');
const baseURL = process.env.NOTCH_BASE_URL || 'http://127.0.0.1:5173';
const outputDir = path.resolve(root, 'docs/previews');
const reportFile = path.resolve(root, 'tests/notch/qa-report.json');
const routes = [
  ['home', '/'],
  ['about', '/about'],
  ['academics', '/academics'],
  ['crime', '/crime-thrillers'],
  ['fiction', '/fiction'],
  ['nonfiction', '/non-fiction'],
  ['literature', '/literature'],
  ['magazines', '/magazines'],
  ['newsletters', '/newsletters'],
];
const report = {
  baseURL,
  started: new Date().toISOString(),
  browser: 'Chromium',
  routes: [],
  journeys: [],
  consoleErrors: [],
  failedRequests: [],
  issues: [],
};
const interactionsOnly = process.argv.includes('--interactions-only');
if (interactionsOnly) {
  const previous = JSON.parse(await fs.readFile(reportFile, 'utf8'));
  report.routes = previous.routes;
  report.journeys = previous.journeys.filter(journey => journey.name.includes('renders and refreshes'));
  report.routeAuditReusedFrom = previous.completed;
}

await fs.mkdir(outputDir, { recursive: true });
const browser = await chromium.launch({
  executablePath: process.env.PLAYWRIGHT_CHROMIUM_EXECUTABLE || '/usr/bin/chromium',
  headless: true,
  args: ['--no-sandbox'],
});

async function check(name, fn) {
  try {
    const details = await fn();
    report.journeys.push({ name, status: 'passed', ...(details || {}) });
    console.log(`PASS ${name}`);
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error);
    report.journeys.push({ name, status: 'failed', message });
    report.issues.push({ name, message });
    console.log(`FAIL ${name}: ${message}`);
  }
}

function observe(page, viewport) {
  page.on('pageerror', error => report.consoleErrors.push({ viewport, url: page.url(), message: error.message }));
  page.on('console', message => {
    if (message.type() === 'error') report.consoleErrors.push({ viewport, url: page.url(), message: message.text() });
  });
  page.on('requestfailed', request => {
    if (request.failure()?.errorText !== 'net::ERR_ABORTED') {
      report.failedRequests.push({ viewport, url: request.url(), error: request.failure()?.errorText });
    }
  });
}

async function settleAndReveal(page) {
  await page.waitForLoadState('networkidle');
  await page.evaluate(async () => {
    const wait = ms => new Promise(resolve => setTimeout(resolve, ms));
    const step = Math.max(350, Math.round(window.innerHeight * 0.8));
    const height = Math.min(document.documentElement.scrollHeight, 20000);
    for (let y = 0; y < height; y += step) {
      window.scrollTo(0, y);
      await wait(85);
    }
    window.scrollTo(0, 0);
  });
  await page.waitForTimeout(300);
}

for (const [viewportName, viewport] of (interactionsOnly ? [] : [
  ['desktop', { width: 1440, height: 1000 }],
  ['mobile', { width: 390, height: 844 }],
])) {
  const context = await browser.newContext({ viewport, reducedMotion: 'reduce' });
  const page = await context.newPage();
  observe(page, viewportName);
  for (const [slug, route] of routes) {
    await check(`${viewportName}: ${route} renders and refreshes`, async () => {
      const response = await page.goto(baseURL + route);
      assert(response?.ok(), `Route returned HTTP ${response?.status()}`);
      await settleAndReveal(page);
      const heading = (await page.locator('main h1, main [role="heading"][aria-level="1"]').first().textContent())?.trim();
      assert(heading && heading.length > 8, `Missing primary heading: ${heading}`);
      assert.equal(await page.locator('main h1').count(), 1, 'A page should have one primary h1');
      assert.equal(await page.locator('main').count(), 1, 'A page should have one main landmark');
      const layout = await page.evaluate(() => ({
        width: document.documentElement.clientWidth,
        scrollWidth: document.documentElement.scrollWidth,
        bodyWidth: document.body.scrollWidth,
        brokenImages: [...document.images].filter(image => image.complete && image.naturalWidth === 0).map(image => image.src),
      }));
      assert(layout.scrollWidth <= layout.width + 1 && layout.bodyWidth <= layout.width + 1,
        `Horizontal overflow: viewport ${layout.width}, document ${layout.scrollWidth}, body ${layout.bodyWidth}`);
      assert.deepEqual(layout.brokenImages, [], 'Broken images');
      const publicNavText = (await page.locator('header').innerText()).toLowerCase();
      for (const forbidden of ['admin workspace', 'administrator', 'publishing studio', 'commerce office', 'demo account']) {
        assert(!publicNavText.includes(forbidden), `Public navigation exposes ${forbidden}`);
      }
      assert.equal(await page.locator('header a[href^="/admin"], footer a[href^="/admin"], header a[href^="/publisher"], header a[href^="/operations"]').count(), 0);
      const screenshot = `notch-${slug}-${viewportName}.png`;
      await page.screenshot({ path: path.join(outputDir, screenshot), fullPage: true });
      await page.reload({ waitUntil: 'networkidle' });
      assert.equal(new URL(page.url()).pathname, route);
      assert((await page.locator('main h1').innerText()).trim().length > 0);
      report.routes.push({ viewport: viewportName, route, heading, screenshot, ...layout });
    });
  }
  await context.close();
}

const context = await browser.newContext({ viewport: { width: 1440, height: 1000 }, reducedMotion: 'reduce' });
const page = await context.newPage();
observe(page, 'journeys');
await page.goto(baseURL);
await page.waitForLoadState('networkidle');

await check('Customer frontend bundle excludes administrator interface', async () => {
  const scripts = await page.locator('script[src]').evaluateAll(nodes => nodes.map(node => node.src));
  let bytes = 0;
  for (const script of scripts.filter(url => new URL(url).origin === new URL(baseURL).origin)) {
    const response = await context.request.get(script);
    assert(response.ok(), `Script unavailable: ${script}`);
    const text = await response.text();
    bytes += Buffer.byteLength(text);
    for (const forbidden of ['Current administrator password', 'Shared development demo', 'Save payment settings', 'Admin workspace']) {
      assert(!text.includes(forbidden), `Administrator UI string in public entry script: ${forbidden}`);
    }
  }
  const builtAssets = path.join(root, 'dist/frontend/assets');
  let productionAssets = [];
  try {
    productionAssets = (await fs.readdir(builtAssets)).filter(file => file.endsWith('.js'));
  } catch { /* A development-only check may run before the first build. */ }
  for (const file of productionAssets) {
    const text = await fs.readFile(path.join(builtAssets, file), 'utf8');
    for (const forbidden of ['Current administrator password', 'Shared development demo', 'Save payment settings', 'Admin workspace']) {
      assert(!text.includes(forbidden), `Administrator interface leaked into production asset: ${file}`);
    }
  }
  return { entryScriptCount: scripts.length, entryScriptBytes: bytes, productionAssets, productionAssetsChecked: productionAssets.length > 0 };
});

await check('Header navigation and browser Back preserve route', async () => {
  const about = page.locator('header a[href="/about"]').first();
  await about.click();
  await page.waitForURL('**/about');
  await page.goBack();
  await page.waitForURL(baseURL + '/');
  return { route: new URL(page.url()).pathname };
});

await check('Search works by keyboard, handles no results and restores focus', async () => {
  const launch = page.getByRole('button', { name: 'Search the reading collection', exact: true });
  await launch.click();
  const dialog = page.getByRole('dialog', { name: 'Find your next read', exact: true });
  await dialog.waitFor({ state: 'visible' });
  const input = page.getByRole('searchbox', { name: 'Search titles, topics and stories' });
  assert(await input.evaluate(element => element === document.activeElement), 'Search input should receive focus');
  await input.fill('not-a-real-editorial-title-123');
  assert(await page.getByText('No pages found. Try a different word.', { exact: true }).isVisible());
  await page.getByRole('button', { name: 'Explore the selections' }).click();
  assert.equal(await input.inputValue(), '');
  await input.fill('academics');
  assert(await dialog.locator('.nr-search-results > button').count() > 0, 'Category search should find entries');
  for (let index = 0; index < 10; index += 1) {
    await page.keyboard.press('Tab');
    assert(await dialog.evaluate(element => element.contains(document.activeElement)), 'Keyboard focus escaped the modal');
  }
  await page.keyboard.press('Escape');
  await dialog.waitFor({ state: 'hidden' });
  assert(await launch.evaluate(element => element === document.activeElement), 'Closing search should restore its trigger');
  await page.keyboard.press('Control+k');
  await dialog.waitFor({ state: 'visible' });
  await page.keyboard.press('Escape');
  await dialog.waitFor({ state: 'hidden' });
});

await check('Category topic filters, sorting and empty saved view work', async () => {
  await page.goto(baseURL + '/academics');
  await page.waitForLoadState('networkidle');
  const cards = page.locator('.nc-book-card');
  const initialCount = await cards.count();
  assert(initialCount >= 3, 'Expected several sample selections');
  await page.locator('.nc-topics button').nth(1).click();
  assert(await cards.count() < initialCount && await cards.count() > 0, 'Topic should filter the shelf');
  await page.getByRole('button', { name: 'All selections', exact: true }).click();
  assert.equal(await cards.count(), initialCount);
  await page.getByRole('combobox', { name: 'Sort selections' }).selectOption('shortest');
  const times = await cards.locator('.nc-book-bottom > span').allTextContents();
  const minutes = times.map(value => Number.parseInt(value, 10));
  assert.deepEqual(minutes, [...minutes].sort((a, b) => a - b));
  await page.getByRole('button', { name: 'Saved', exact: true }).click();
  assert.equal(await cards.count(), 0);
  assert(await page.getByRole('heading', { name: 'A little room for discovery.' }).isVisible());
  await page.getByRole('button', { name: 'Show all selections' }).click();
  assert.equal(await cards.count(), initialCount);
  return { initialCount, shortestFirst: minutes };
});

await check('Saving a selection survives refresh and the saved filter', async () => {
  const save = page.getByRole('button', { name: /^Save .* to your reading list$/ }).first();
  const originalLabel = await save.getAttribute('aria-label');
  await save.click();
  await page.waitForFunction(() => JSON.parse(localStorage.getItem('rtr-notch-reading-list') || '[]').length > 0);
  const before = await page.evaluate(() => JSON.parse(localStorage.getItem('rtr-notch-reading-list') || '[]'));
  await page.reload({ waitUntil: 'networkidle' });
  const after = await page.evaluate(() => JSON.parse(localStorage.getItem('rtr-notch-reading-list') || '[]'));
  assert.deepEqual(after, before);
  await page.getByRole('button', { name: 'Saved', exact: true }).click();
  assert.equal(await page.locator('.nc-book-card').count(), 1);
  const remove = originalLabel.replace(/^Save /, 'Remove ').replace(/ to your reading list$/, ' from your reading list');
  assert(await page.getByRole('button', { name: remove, exact: true }).first().isVisible());
  await page.getByRole('button', { name: 'Saved', exact: true }).click();
  return { savedCount: after.length };
});

await check('Read sample dialog supports Escape and returns focus', async () => {
  const trigger = page.getByRole('button', { name: /^Read a sample of / }).first();
  const label = await trigger.getAttribute('aria-label');
  await trigger.click();
  const dialog = page.getByRole('dialog');
  await dialog.waitFor({ state: 'visible' });
  assert((await dialog.innerText()).length > 150, 'Sample contains readable prose');
  await page.keyboard.press('Escape');
  await dialog.waitFor({ state: 'hidden' });
  assert.equal(await page.evaluate(() => document.activeElement?.getAttribute('aria-label')), label);
  assert.notEqual(await page.evaluate(() => document.body.style.overflow), 'hidden');
});

await check('Magazine issue controls change the featured selection', async () => {
  await page.goto(baseURL + '/magazines');
  await page.waitForLoadState('networkidle');
  const initial = await page.locator('#nc-feature-title').innerText();
  await page.getByRole('button', { name: 'Next featured issue' }).click();
  const next = await page.locator('#nc-feature-title').innerText();
  assert.notEqual(next, initial);
  await page.getByRole('button', { name: 'Previous featured issue' }).click();
  assert.equal(await page.locator('#nc-feature-title').innerText(), initial);
  return { initial, next };
});

await check('Home featured read controls change and restore the editorial spotlight', async () => {
  await page.goto(baseURL);
  await page.waitForLoadState('networkidle');
  const initial = await page.locator('#nh-feature-title').innerText();
  await page.getByRole('button', { name: 'Next featured read' }).click();
  const next = await page.locator('#nh-feature-title').innerText();
  assert.notEqual(next, initial);
  await page.getByRole('button', { name: 'Previous featured read' }).click();
  assert.equal(await page.locator('#nh-feature-title').innerText(), initial);
  assert(await page.getByRole('button', { name: 'Play featured reads' }).isDisabled(), 'Reduced-motion mode should disable automatic playback');
  return { initial, next, reducedMotionAutoplayDisabled: true };
});

await check('Newsletter previews and consented signup store a real request', async () => {
  await page.goto(baseURL + '/newsletters');
  await page.waitForLoadState('networkidle');
  const initial = await page.locator('.ne-letter-preview h3').innerText();
  await page.getByRole('button', { name: 'Between the Lines' }).click();
  assert.notEqual(await page.locator('.ne-letter-preview h3').innerText(), initial);
  const email = `notch-browser-${Date.now()}@example.test`;
  await page.getByLabel('Your email address', { exact: true }).fill(email);
  let posts = 0;
  const listener = request => { if (request.method() === 'POST' && request.url().includes('/api/subscribe.php')) posts += 1; };
  page.on('request', listener);
  await page.getByRole('button', { name: 'Keep me curious' }).click();
  await page.waitForTimeout(250);
  assert.equal(posts, 0, 'Missing consent must not submit newsletter details');
  await page.getByRole('checkbox').check();
  const saved = page.waitForResponse(response => response.url().includes('/api/subscribe.php') && response.request().method() === 'POST');
  await page.getByRole('button', { name: 'Keep me curious' }).click();
  const response = await saved;
  assert(response.ok(), `Newsletter API returned HTTP ${response.status()}`);
  const result = await response.json();
  assert.equal(result.ok, true);
  await page.getByRole('heading', { name: 'You’re on the list.' }).waitFor({ state: 'visible' });
  page.off('request', listener);
  return { httpStatus: response.status(), storedRequest: true, emailDeliveryTested: false };
});

await context.close();
const mobileContext = await browser.newContext({ viewport: { width: 390, height: 844 }, reducedMotion: 'reduce' });
const mobilePage = await mobileContext.newPage();
observe(mobilePage, 'mobile-navigation');
await check('Mobile navigation opens, closes with Escape and follows a selected page', async () => {
  await mobilePage.goto(baseURL);
  await mobilePage.waitForLoadState('networkidle');
  await mobilePage.getByRole('button', { name: 'Open navigation menu' }).click();
  const nav = mobilePage.getByRole('navigation', { name: 'Mobile navigation' });
  await nav.waitFor({ state: 'visible' });
  assert.equal(await nav.getByRole('link').count(), 9);
  assert.equal(await mobilePage.evaluate(() => document.body.style.overflow), 'hidden');
  await mobilePage.screenshot({ path: path.join(outputDir, 'notch-navigation-mobile.png'), fullPage: false });
  await mobilePage.keyboard.press('Escape');
  await nav.waitFor({ state: 'hidden' });
  assert.notEqual(await mobilePage.evaluate(() => document.body.style.overflow), 'hidden');
  await mobilePage.getByRole('button', { name: 'Open navigation menu' }).click();
  await nav.locator('a[href="/fiction"]').click();
  await mobilePage.waitForURL('**/fiction');
  await nav.waitFor({ state: 'hidden' });
  assert.notEqual(await mobilePage.evaluate(() => document.body.style.overflow), 'hidden');
  assert.equal(await mobilePage.evaluate(() => document.activeElement?.id), 'main-content');
});
await mobileContext.close();
await browser.close();
report.completed = new Date().toISOString();
report.status = report.issues.length || report.consoleErrors.length || report.failedRequests.length ? 'needs-review' : 'passed';
await fs.writeFile(reportFile, JSON.stringify(report, null, 2) + '\n');
console.log(JSON.stringify({ status: report.status, routes: report.routes.length, journeys: report.journeys.length,
  issues: report.issues.length, consoleErrors: report.consoleErrors.length, failedRequests: report.failedRequests.length,
  reportFile }, null, 2));
if (report.issues.length) process.exitCode = 1;
