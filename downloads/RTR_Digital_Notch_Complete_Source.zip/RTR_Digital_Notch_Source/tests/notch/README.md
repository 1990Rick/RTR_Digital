# RTR Digital editorial browser checks

Start the new public frontend and its separate PHP content service first. Then run:

```sh
node tests/notch/browser-qa.mjs
```

The default address is `http://127.0.0.1:5173`. Set `NOTCH_BASE_URL` to test another running environment. Chromium defaults to `/usr/bin/chromium`; set `PLAYWRIGHT_CHROMIUM_EXECUTABLE` when needed.

The runner checks all nine routes at desktop and mobile sizes, hard refreshes, the absence of administrator links in public navigation, script separation, image loading and horizontal overflow. It captures full-page screenshots in `docs/previews/notch-*` and writes its evidence to `tests/notch/qa-report.json`.

After a change confined to an interaction, `node tests/notch/browser-qa.mjs --interactions-only` reruns the ten interactive journeys while retaining the earlier successful route evidence and its timestamp. Run the full command again for route, layout or artwork changes.

These browser checks establish observed local behavior. They do not claim that a hosting account, production PHP configuration, newsletter delivery service or live commerce integration is configured.
