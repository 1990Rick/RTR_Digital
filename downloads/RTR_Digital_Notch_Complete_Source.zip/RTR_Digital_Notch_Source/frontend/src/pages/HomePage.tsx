import { useEffect, useMemo, useRef, useState } from "react";
import type { CSSProperties } from "react";
import {
  ArrowDown,
  ArrowDownRight,
  ArrowLeft,
  ArrowRight,
  ArrowUpRight,
  Bookmark,
  BookOpen,
  Check,
  ChevronRight,
  Pause,
  Play,
  Sparkle,
} from "lucide-react";
import type {
  EditorialContent,
  EditorialEntry,
  SectionId,
} from "../lib/content";
import "./home.css";

type HomePageProps = {
  content: EditorialContent;
  onNavigate: (id: SectionId) => void;
  onRead: (entry: EditorialEntry) => void;
  onSave: (id: string) => void;
  savedIds: string[];
};

const genres: { id: SectionId; label: string; note: string }[] = [
  { id: "academics", label: "Academics", note: "Go a little deeper" },
  {
    id: "crime-thrillers",
    label: "Crime & thrillers",
    note: "Expect the unexpected",
  },
  { id: "fiction", label: "Fiction", note: "Somewhere else awaits" },
  { id: "non-fiction", label: "Non-fiction", note: "See things differently" },
  { id: "literature", label: "Literature", note: "Words that stay with you" },
  { id: "magazines", label: "Magazines", note: "A fresh point of view" },
  { id: "newsletters", label: "Newsletters", note: "A good kind of inbox" },
];

const categoryNames: Record<string, string> = {
  academics: "Academics",
  "crime-thrillers": "Crime & thrillers",
  fiction: "Fiction",
  "non-fiction": "Non-fiction",
  literature: "Literature",
  magazines: "Magazines",
  newsletters: "Newsletters",
};

const shelfFilters = [
  { id: "all", label: "The full edit" },
  { id: "stories", label: "Lose yourself" },
  { id: "ideas", label: "Find a new idea" },
];

function Asterisk() {
  return (
    <svg viewBox="0 0 100 100" aria-hidden="true">
      {[0, 45, 90, 135].map((angle) => (
        <rect
          key={angle}
          x="46"
          y="6"
          width="8"
          height="88"
          rx="4"
          fill="currentColor"
          transform={`rotate(${angle} 50 50)`}
        />
      ))}
    </svg>
  );
}

function useEntrance() {
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    const root = ref.current;
    if (
      !root ||
      !("IntersectionObserver" in window) ||
      window.matchMedia("(prefers-reduced-motion: reduce)").matches
    )
      return;
    const elements = root.querySelectorAll<HTMLElement>("[data-nh-reveal]");
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            (entry.target as HTMLElement).dataset.nhVisible = "true";
            observer.unobserve(entry.target);
          }
        });
      },
      { threshold: 0.08, rootMargin: "0px 0px 35px 0px" },
    );
    elements.forEach((element) => {
      element.dataset.nhReady = "true";
      observer.observe(element);
    });
    return () => observer.disconnect();
  }, []);
  return ref;
}

function Cover({
  entry,
  index = 0,
}: {
  entry: EditorialEntry;
  index?: number;
}) {
  const label = categoryNames[entry.category] || "The RTR edit";
  return (
    <div
      className={`nh-cover nh-cover-${entry.category}`}
      style={{ "--nh-cover-turn": `${index % 2 ? 2 : -2}deg` } as CSSProperties}
    >
      <div className="nh-cover-content">
        <span className="nh-cover-imprint">
          RTR DIGITAL <i>THE READING EDIT</i>
        </span>
        <span className="nh-cover-graphic" aria-hidden="true">
          <i />
          <i />
          <i />
        </span>
        <span className="nh-cover-title">{entry.title}</span>
        <span className="nh-cover-rule" />
        <span className="nh-cover-category">
          {label} <ArrowUpRight size={16} />
        </span>
      </div>
      <span className="nh-cover-spine" aria-hidden="true" />
    </div>
  );
}

function editorialMix(entries: EditorialEntry[]) {
  const groups = [...new Set(entries.map((entry) => entry.category))].map(
    (category) => entries.filter((entry) => entry.category === category),
  );
  const mixed: EditorialEntry[] = [];
  for (let row = 0; groups.some((group) => group.length > row); row += 1) {
    groups.forEach((group) => {
      if (group[row]) mixed.push(group[row]);
    });
  }
  return mixed;
}

export function HomePage({
  content,
  onNavigate,
  onRead,
  onSave,
  savedIds,
}: HomePageProps) {
  const rootRef = useEntrance();
  const homePage = content.pages.find((page) => page.id === "notch");
  const [shelfFilter, setShelfFilter] = useState("all");
  const [featureIndex, setFeatureIndex] = useState(0);
  const [playing, setPlaying] = useState(
    () => !window.matchMedia("(prefers-reduced-motion: reduce)").matches,
  );
  const [featureHover, setFeatureHover] = useState(false);
  const [featureFocus, setFeatureFocus] = useState(false);
  const [documentVisible, setDocumentVisible] = useState(
    () => !document.hidden,
  );
  const [reducedMotion, setReducedMotion] = useState(
    () => window.matchMedia("(prefers-reduced-motion: reduce)").matches,
  );
  const features = useMemo(
    () => editorialMix(content.entries).slice(0, 4),
    [content.entries],
  );
  const feature = features[featureIndex % Math.max(1, features.length)];
  const shelf = useMemo(() => {
    let list = content.entries;
    if (shelfFilter === "stories")
      list = list.filter((entry) =>
        ["fiction", "crime-thrillers", "literature"].includes(entry.category),
      );
    if (shelfFilter === "ideas")
      list = list.filter((entry) =>
        ["academics", "non-fiction", "magazines"].includes(entry.category),
      );
    return editorialMix(list).slice(0, 4);
  }, [content.entries, shelfFilter]);

  useEffect(() => {
    const preference = window.matchMedia("(prefers-reduced-motion: reduce)");
    const onPreference = () => {
      setReducedMotion(preference.matches);
      if (preference.matches) setPlaying(false);
    };
    const onVisibility = () => setDocumentVisible(!document.hidden);
    preference.addEventListener("change", onPreference);
    document.addEventListener("visibilitychange", onVisibility);
    return () => {
      preference.removeEventListener("change", onPreference);
      document.removeEventListener("visibilitychange", onVisibility);
    };
  }, []);

  useEffect(() => {
    if (
      !playing ||
      reducedMotion ||
      featureHover ||
      featureFocus ||
      !documentVisible ||
      features.length < 2
    )
      return;
    const timer = window.setInterval(
      () => setFeatureIndex((value) => (value + 1) % features.length),
      8000,
    );
    return () => window.clearInterval(timer);
  }, [
    playing,
    reducedMotion,
    featureHover,
    featureFocus,
    documentVisible,
    features.length,
  ]);

  function stepFeature(direction: number) {
    setPlaying(false);
    setFeatureIndex(
      (value) =>
        (value + direction + features.length) % Math.max(1, features.length),
    );
  }

  return (
    <div className="notch-home" ref={rootRef}>
      <section className="nh-hero nh-wrap" aria-labelledby="notch-title">
        <div className="nh-hero-copy">
          <div className="nh-eyebrow">
            <span className="nh-live-dot" /> RTR’S NOTCH{" "}
            <span className="nh-eyebrow-line" />
            <span>{homePage?.eyebrow || "A NEW CHAPTER"}</span>
          </div>
          <h1 id="notch-title">
            {homePage?.title || "For the love"}
            <br />
            <span className="nh-hero-italic">
              {homePage?.emphasis || "of what’s next."}
            </span>
          </h1>
          <p className="nh-hero-description">
            {homePage?.description ||
              "A different world. A fresh perspective. A sentence you can’t stop thinking about. Your next great read starts here."}
          </p>
          <div className="nh-hero-actions">
            <button
              className="nh-button nh-button-dark"
              onClick={() =>
                document
                  .getElementById("notch-shelf")
                  ?.scrollIntoView({
                    behavior: reducedMotion ? "instant" : "smooth",
                    block: "start",
                  })
              }
            >
              Find your next read <ArrowUpRight size={18} />
            </button>
            <button
              className="nh-text-button"
              onClick={() => onNavigate("about")}
            >
              Meet RTR Digital <ArrowRight size={17} />
            </button>
          </div>
          <div className="nh-hero-footnote">
            <span className="nh-hero-footnote-line" />
            <BookOpen size={17} strokeWidth={1.5} />
            <span>Made for the endlessly curious.</span>
          </div>
        </div>
        <div className="nh-hero-art">
          <span className="nh-art-topline">
            MANY WORLDS. <span>ONE NOTCH ABOVE.</span>
          </span>
          <div className="nh-hero-image-frame">
            <img
              src="/images/rtr-digital-notch-hero.webp"
              alt="Books and an open volume beneath a sculptural arch in warm light"
              fetchPriority="high"
              width="1920"
              height="1080"
            />
          </div>
          <span className="nh-orbit-label">
            <span>
              GOOD THINGS
              <br />
              BETWEEN
              <br />
              <em>the covers.</em>
            </span>
            <Sparkle aria-hidden="true" size={18} />
          </span>
          <span className="nh-image-index">
            FIG. 01 <span>THE POSSIBILITIES ARE OPEN.</span>
          </span>
          <ArrowDownRight
            className="nh-art-arrow"
            size={62}
            strokeWidth={1}
            aria-hidden="true"
          />
        </div>
      </section>

      <div className="nh-under-hero nh-wrap">
        <span>INDEPENDENT SPIRIT. INFINITE CURIOSITY.</span>
        <button
          onClick={() =>
            document
              .getElementById("notch-worlds")
              ?.scrollIntoView({
                behavior: reducedMotion ? "instant" : "smooth",
              })
          }
        >
          A world to discover <ArrowDown size={15} />
        </button>
        <span>READ SOMETHING THAT MOVES YOU.</span>
      </div>

      <section
        className="nh-worlds nh-wrap"
        id="notch-worlds"
        aria-labelledby="nh-worlds-title"
        data-nh-reveal
      >
        <div className="nh-section-heading nh-worlds-heading">
          <div>
            <span className="nh-eyebrow">FOLLOW YOUR CURIOSITY</span>
            <h2 id="nh-worlds-title">
              Find your kind of <em>different.</em>
            </h2>
          </div>
          <span className="nh-section-note">
            Seven ways in.
            <br />
            Where will you go?
          </span>
        </div>
        <div className="nh-genre-grid">
          {genres.map((genre, index) => (
            <button
              className="nh-genre"
              key={genre.id}
              onClick={() => onNavigate(genre.id)}
            >
              <span className="nh-genre-number">
                0{index + 1}
                <ArrowUpRight size={17} />
              </span>
              <span className="nh-genre-name">{genre.label}</span>
              <span className="nh-genre-note">{genre.note}</span>
            </button>
          ))}
        </div>
      </section>

      <section
        className="nh-shelf nh-wrap"
        id="notch-shelf"
        aria-labelledby="nh-shelf-title"
        data-nh-reveal
      >
        <div className="nh-section-heading">
          <div>
            <span className="nh-eyebrow">
              A LITTLE SOMETHING FOR YOUR READING LIST
            </span>
            <h2 id="nh-shelf-title">
              The editors’ <em>shelf.</em>
            </h2>
          </div>
          <button
            className="nh-text-button"
            onClick={() => onNavigate("fiction")}
          >
            Explore the stories <ArrowUpRight size={17} />
          </button>
        </div>
        <div className="nh-shelf-toolbar">
          <div
            className="nh-filter-tabs"
            role="group"
            aria-label="Filter the editors’ shelf"
          >
            {shelfFilters.map((filter) => (
              <button
                key={filter.id}
                aria-pressed={filter.id === shelfFilter}
                className={filter.id === shelfFilter ? "is-active" : ""}
                onClick={() => setShelfFilter(filter.id)}
              >
                {filter.label}
              </button>
            ))}
          </div>
          <span>
            THE RTR EDIT{" "}
            <span className="nh-small-star">
              <Asterisk />
            </span>{" "}
            SELECTED WITH CURIOSITY
          </span>
        </div>
        <div className="nh-books-grid" aria-live="polite">
          {shelf.map((entry, index) => (
            <article className="nh-book-card" key={entry.id}>
              <div className="nh-book-stage">
                <button
                  className="nh-cover-open"
                  onClick={() => onRead(entry)}
                  aria-label={`Read an excerpt from ${entry.title}`}
                >
                  <Cover entry={entry} index={index} />
                </button>
                <button
                  className={`nh-save-button ${savedIds.includes(entry.id) ? "is-saved" : ""}`}
                  aria-pressed={savedIds.includes(entry.id)}
                  aria-label={`${savedIds.includes(entry.id) ? "Remove" : "Save"} ${entry.title}${savedIds.includes(entry.id) ? " from" : " to"} your reading list`}
                  onClick={() => onSave(entry.id)}
                >
                  {savedIds.includes(entry.id) ? (
                    <Check size={17} />
                  ) : (
                    <Bookmark size={17} />
                  )}
                </button>
              </div>
              <div className="nh-book-meta">
                <span>{categoryNames[entry.category] || entry.topic}</span>
                <span>{entry.readTime} MIN READ</span>
              </div>
              <button className="nh-book-title" onClick={() => onRead(entry)}>
                {entry.title}
                <ArrowUpRight size={18} />
              </button>
              <p className="nh-book-subtitle">
                {entry.subtitle || entry.description}
              </p>
            </article>
          ))}
        </div>
        <p className="nh-sample-note">
          A preview of what’s possible. These sample reads set the scene for the
          full RTR Digital collection.
        </p>
      </section>

      {feature && (
        <section
          className="nh-feature"
          aria-labelledby="nh-feature-title"
          onMouseEnter={() => setFeatureHover(true)}
          onMouseLeave={() => setFeatureHover(false)}
          onFocusCapture={() => setFeatureFocus(true)}
          onBlurCapture={(event) => {
            if (
              !event.currentTarget.contains(event.relatedTarget as Node | null)
            )
              setFeatureFocus(false);
          }}
        >
          <div className="nh-feature-inner nh-wrap">
            <div className="nh-feature-visual" key={`art-${feature.id}`}>
              <span className="nh-feature-issue">
                THE SLOW READ{" "}
                <span>
                  0{(featureIndex % features.length) + 1} / 0{features.length}
                </span>
              </span>
              <div className="nh-feature-book">
                <Cover entry={feature} index={featureIndex} />
              </div>
              <span className="nh-feature-side">
                A MOMENT TO GET LOST IN SOMETHING GOOD.
              </span>
              <span className="nh-feature-spark" aria-hidden="true">
                <Asterisk />
              </span>
            </div>
            <div className="nh-feature-copy">
              <span className="nh-eyebrow">
                TURN THE PAGE. CHANGE THE PERSPECTIVE.
              </span>
              <h2 id="nh-feature-title" key={`title-${feature.id}`}>
                {feature.title}
              </h2>
              <p key={`description-${feature.id}`}>{feature.description}</p>
              <button
                className="nh-button nh-button-light"
                onClick={() => onRead(feature)}
              >
                Step inside the story <ArrowUpRight size={18} />
              </button>
              <div className="nh-feature-controls">
                <div className="nh-feature-step">
                  <button
                    onClick={() => stepFeature(-1)}
                    aria-label="Previous featured read"
                  >
                    <ArrowLeft size={19} />
                  </button>
                  <button
                    onClick={() => stepFeature(1)}
                    aria-label="Next featured read"
                  >
                    <ArrowRight size={19} />
                  </button>
                  <button
                    aria-label={
                      playing ? "Pause featured reads" : "Play featured reads"
                    }
                    aria-pressed={playing}
                    onClick={() => setPlaying((value) => !value)}
                    disabled={reducedMotion || features.length < 2}
                  >
                    {playing ? <Pause size={14} /> : <Play size={14} />}
                  </button>
                </div>
                <div
                  className="nh-feature-dots"
                  aria-label="Featured read selection"
                >
                  {features.map((entry, index) => (
                    <button
                      key={entry.id}
                      aria-label={`Show featured read ${index + 1}: ${entry.title}`}
                      aria-pressed={index === featureIndex % features.length}
                      onClick={() => {
                        setFeatureIndex(index);
                        setPlaying(false);
                      }}
                    >
                      <span />
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </section>
      )}

      <section
        className="nh-manifesto nh-wrap"
        aria-labelledby="nh-manifesto-title"
        data-nh-reveal
      >
        <div className="nh-manifesto-label">
          <span className="nh-eyebrow">MORE THAN A COLLECTION</span>
          <span className="nh-manifesto-star" aria-hidden="true">
            <Asterisk />
          </span>
        </div>
        <div>
          <h2 id="nh-manifesto-title">
            Some things deserve
            <br />
            your <em>undivided attention.</em>
          </h2>
          <div className="nh-manifesto-bottom">
            <p>
              We believe in the quiet power of a good read. In ideas that
              challenge, stories that transport, and words that make the
              ordinary feel extraordinary.
            </p>
            <button
              className="nh-round-link"
              aria-label="Read about RTR Digital"
              onClick={() => onNavigate("about")}
            >
              <ArrowUpRight size={28} strokeWidth={1.5} />
            </button>
          </div>
        </div>
      </section>

      <section
        className="nh-newsletter nh-wrap"
        aria-labelledby="nh-newsletter-title"
        data-nh-reveal
      >
        <div className="nh-newsletter-line" />
        <div className="nh-newsletter-icon" aria-hidden="true">
          <span>R</span>
          <i />
        </div>
        <div className="nh-newsletter-copy">
          <span className="nh-eyebrow">LET’S KEEP IN TOUCH</span>
          <h2 id="nh-newsletter-title">
            Something worth
            <br />
            <em>opening.</em>
          </h2>
          <p>
            A considered note. A new discovery. A reason to pause.
            <br />
            Make a little room in your inbox for RTR.
          </p>
        </div>
        <button
          className="nh-button nh-button-dark"
          onClick={() => onNavigate("newsletters")}
        >
          Discover our newsletters <ChevronRight size={18} />
        </button>
      </section>
    </div>
  );
}

export default HomePage;
