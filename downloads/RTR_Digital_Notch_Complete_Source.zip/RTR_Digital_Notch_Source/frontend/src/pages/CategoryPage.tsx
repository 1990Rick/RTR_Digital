import { useEffect, useMemo, useRef, useState } from "react";
import type { CSSProperties } from "react";
import {
  ArrowDown,
  ArrowLeft,
  ArrowRight,
  ArrowUpRight,
  Bookmark,
  Check,
  ChevronLeft,
  ChevronRight,
  Clock3,
  SearchX,
} from "lucide-react";
import BookCover from "../components/BookCover";
import type { EditorialEntry, EditorialPage, SectionId } from "../lib/content";
import "./category.css";

type CategoryPageProps = {
  page: EditorialPage;
  entries: EditorialEntry[];
  onRead: (entry: EditorialEntry) => void;
  onSave: (id: string) => void;
  savedIds: string[];
  onNavigate: (id: SectionId) => void;
};

type CategoryStyle = {
  number: string;
  word: string;
  image: string;
  note: string;
  shelf: string;
  intro: string;
  interlude: string;
  next: SectionId;
  nextLabel: string;
};

const categoryStyles: Record<string, CategoryStyle> = {
  academics: {
    number: "01",
    word: "DISCOVER",
    image: "academics",
    note: "A question is a rather good beginning.",
    shelf: "Make room for a new idea.",
    intro:
      "Follow a question a little further. Explore thoughtful introductions, fresh perspectives and the small discoveries that make a subject come alive.",
    interlude: "Stay curious. The world is still full of things to learn.",
    next: "crime-thrillers",
    nextLabel: "Crime Thrillers / Novels",
  },
  "crime-thrillers": {
    number: "02",
    word: "SUSPENSE",
    image: "crime",
    note: "The truth is rarely where you left it.",
    shelf: "Follow the loose thread.",
    intro:
      "A missing detail. An unreliable memory. A quiet street with a story to tell. Enter imagined mysteries built for one more page.",
    interlude: "Some stories follow you long after the last page.",
    next: "fiction",
    nextLabel: "Fiction",
  },
  fiction: {
    number: "03",
    word: "IMAGINE",
    image: "fiction",
    note: "Ordinary days. Extraordinary possibilities.",
    shelf: "Somewhere you haven't been.",
    intro:
      "Step sideways into another life. Meet unexpected characters, wander unfamiliar places and discover how much a made-up world can make you feel.",
    interlude: "A different world is only a sentence away.",
    next: "non-fiction",
    nextLabel: "Non-Fiction",
  },
  "non-fiction": {
    number: "04",
    word: "UNDERSTAND",
    image: "nonfiction",
    note: "Real questions. Room to think.",
    shelf: "A clearer way of seeing.",
    intro:
      "Explore the everyday through a different lens. These sample essays follow ideas about attention, nature, work and the way we live together.",
    interlude: "Pay attention. There is a story in the everyday.",
    next: "literature",
    nextLabel: "Literature",
  },
  literature: {
    number: "05",
    word: "LINGER",
    image: "literature",
    note: "For the love of a well-placed word.",
    shelf: "Words worth staying with.",
    intro:
      "Poetry, short prose and reflections on the art of language. A small collection for slower reading, second thoughts and the pleasure of a sentence.",
    interlude: "Read slowly. Some words deserve a little more of your time.",
    next: "magazines",
    nextLabel: "Magazines",
  },
  magazines: {
    number: "06",
    word: "PERSPECTIVE",
    image: "magazines",
    note: "An eclectic mix. A fresh point of view.",
    shelf: "The magazine shelf.",
    intro:
      "Culture, creativity and the overlooked details of modern life. Browse imagined issues, discover their opening stories and find an idea to take with you.",
    interlude: "A little culture. A little curiosity. A new perspective.",
    next: "newsletters",
    nextLabel: "Newsletters",
  },
};

function SaveButton({
  entry,
  saved,
  onSave,
  label = false,
}: {
  entry: EditorialEntry;
  saved: boolean;
  onSave: (id: string) => void;
  label?: boolean;
}) {
  return (
    <button
      type="button"
      className={`nc-save ${saved ? "nc-saved" : ""} ${label ? "nc-save-with-label" : ""}`}
      aria-label={`${saved ? "Remove" : "Save"} ${entry.title}${saved ? " from" : " to"} your reading list`}
      aria-pressed={saved}
      onClick={() => onSave(entry.id)}
    >
      {saved ? <Check size={17} /> : <Bookmark size={17} />}
      {label && (
        <span>{saved ? "On your reading list" : "Save for later"}</span>
      )}
    </button>
  );
}

export function CategoryPage({
  page,
  entries,
  onRead,
  onSave,
  savedIds,
  onNavigate,
}: CategoryPageProps) {
  const genre = categoryStyles[page.id] ?? categoryStyles.academics;
  const [topic, setTopic] = useState("All selections");
  const [sort, setSort] = useState("edit");
  const [savedOnly, setSavedOnly] = useState(false);
  const [issueIndex, setIssueIndex] = useState(0);
  const root = useRef<HTMLDivElement>(null);
  const collection = useRef<HTMLElement>(null);
  const genreEntries = useMemo(
    () => entries.filter((entry) => entry.category === page.id),
    [entries, page.id],
  );
  const topics = useMemo(
    () => [
      "All selections",
      ...new Set(genreEntries.map((entry) => entry.topic)),
    ],
    [genreEntries],
  );
  const visibleEntries = useMemo(() => {
    let result = genreEntries.filter(
      (entry) =>
        (topic === "All selections" || entry.topic === topic) &&
        (!savedOnly || savedIds.includes(entry.id)),
    );
    if (sort === "shortest") {
      result = [...result].sort((a, b) => a.readTime - b.readTime);
    } else if (sort === "title") {
      result = [...result].sort((a, b) => a.title.localeCompare(b.title));
    }
    return result;
  }, [genreEntries, topic, savedOnly, savedIds, sort]);
  const featured = genreEntries[issueIndex % Math.max(genreEntries.length, 1)];
  const isMagazine = page.id === "magazines";

  useEffect(() => {
    setTopic("All selections");
    setSort("edit");
    setSavedOnly(false);
    setIssueIndex(0);
  }, [page.id]);

  useEffect(() => {
    if (
      !root.current ||
      !window.IntersectionObserver ||
      window.matchMedia("(prefers-reduced-motion: reduce)").matches
    ) {
      return;
    }
    const nodes =
      root.current.querySelectorAll<HTMLElement>("[data-nc-reveal]");
    const observer = new IntersectionObserver(
      (items) => {
        items.forEach((item) => {
          if (item.isIntersecting) {
            (item.target as HTMLElement).dataset.ncVisible = "true";
            observer.unobserve(item.target);
          }
        });
      },
      { threshold: 0.06, rootMargin: "0px 0px 30px 0px" },
    );
    nodes.forEach((node) => {
      node.dataset.ncReady = "true";
      observer.observe(node);
    });
    return () => observer.disconnect();
  }, [page.id]);

  function browse() {
    collection.current?.scrollIntoView({
      behavior: window.matchMedia("(prefers-reduced-motion: reduce)").matches
        ? "auto"
        : "smooth",
      block: "start",
    });
  }

  function resetFilters() {
    setTopic("All selections");
    setSavedOnly(false);
    setSort("edit");
  }

  return (
    <div
      ref={root}
      className={`notch-category cat-${page.id}`}
      style={{ "--nc-accent": page.accent } as CSSProperties}
    >
      <section className="nc-hero" aria-labelledby="nc-page-title">
        <div className="nc-hero-inner">
          <div className="nc-breadcrumb">
            <button type="button" onClick={() => onNavigate("notch")}>
              RTR&apos;s Notch
            </button>
            <span aria-hidden="true">/</span>
            <span>{page.label}</span>
          </div>
          <div className="nc-hero-grid">
            <div className="nc-hero-copy">
              <p className="nc-eyebrow">
                <span className="nc-tiny-square" aria-hidden="true" />
                {page.eyebrow}
              </p>
              <h1 id="nc-page-title">
                {page.title}
                {page.emphasis && <em>{page.emphasis}</em>}
              </h1>
              <p className="nc-hero-description">{page.description}</p>
              <button type="button" className="nc-hero-cta" onClick={browse}>
                {isMagazine ? "Explore the issues" : "Find your next read"}
                <ArrowDown size={17} aria-hidden="true" />
              </button>
              <div className="nc-hero-footnote">
                <span>{genre.number}</span>
                <p>{genre.note}</p>
              </div>
            </div>
            <div className="nc-hero-art" aria-hidden="true">
              <div className="nc-art-ring nc-art-ring-one" />
              <div className="nc-art-ring nc-art-ring-two" />
              <span className="nc-art-overscript">{genre.word}</span>
              <div className="nc-image-mat">
                <img
                  src={`/images/rtr-digital-notch-${genre.image}.webp`}
                  alt=""
                  width="800"
                  height="600"
                  onError={(event) => {
                    event.currentTarget.style.visibility = "hidden";
                  }}
                />
                <div className="nc-art-fallback">
                  <span className="nc-fallback-book nc-fallback-book-one" />
                  <span className="nc-fallback-book nc-fallback-book-two" />
                  <span className="nc-fallback-sphere" />
                </div>
              </div>
              <div className="nc-art-caption">
                <span>THE RTR READING ROOM</span>
                <span>{genre.number} / 06</span>
              </div>
              <div className="nc-art-seal">
                <span>OPEN A BOOK</span>
                <ArrowUpRight size={31} strokeWidth={1.1} />
                <span>OPEN YOUR WORLD</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="nc-intro nc-wrap" data-nc-reveal>
        <span className="nc-section-label">
          THE {page.label.toUpperCase()} EDIT
        </span>
        <h2>{genre.shelf}</h2>
        <p>{genre.intro}</p>
      </section>

      {featured && (
        <section
          className={`nc-feature nc-wrap ${isMagazine ? "nc-feature-issue" : ""}`}
          data-nc-reveal
          aria-labelledby="nc-feature-title"
        >
          <div className="nc-feature-art">
            <span className="nc-feature-topline">
              {isMagazine ? "FROM THE EDITOR'S DESK" : "AN INVITATION TO READ"}
            </span>
            <button
              type="button"
              className="nc-feature-cover"
              aria-label={`Read a sample of ${featured.title}`}
              onClick={() => onRead(featured)}
            >
              <BookCover entry={featured} large />
            </button>
            <span className="nc-feature-art-caption">
              {isMagazine
                ? "A DIGITAL MAGAZINE, REIMAGINED."
                : "A DIFFERENT PERSPECTIVE, ONE PAGE AT A TIME."}
            </span>
          </div>
          <div className="nc-feature-copy" key={featured.id}>
            <p className="nc-eyebrow">
              <span className="nc-feature-dash" />
              {isMagazine ? "THE ISSUE SPOTLIGHT" : "A GOOD PLACE TO BEGIN"}
            </p>
            <p className="nc-feature-topic">{featured.topic}</p>
            <h2 id="nc-feature-title">{featured.title}</h2>
            <p className="nc-feature-subtitle">{featured.subtitle}</p>
            <p className="nc-feature-description">{featured.description}</p>
            <div className="nc-feature-meta">
              <span>
                <Clock3 size={14} /> {featured.readTime} min sample
              </span>
              <span>RTR Editorial</span>
            </div>
            <div className="nc-feature-actions">
              <button
                type="button"
                className="nc-read-button"
                onClick={() => onRead(featured)}
              >
                Read a sample <ArrowUpRight size={17} />
              </button>
              <SaveButton
                entry={featured}
                saved={savedIds.includes(featured.id)}
                onSave={onSave}
                label
              />
            </div>
            {isMagazine && genreEntries.length > 1 && (
              <div
                className="nc-issue-navigation"
                aria-label="Featured magazine issue"
              >
                <button
                  type="button"
                  aria-label="Previous featured issue"
                  onClick={() =>
                    setIssueIndex(
                      (current) =>
                        (current - 1 + genreEntries.length) %
                        genreEntries.length,
                    )
                  }
                >
                  <ChevronLeft size={18} />
                </button>
                <span aria-live="polite">
                  {String(issueIndex + 1).padStart(2, "0")} <i>/</i>{" "}
                  {String(genreEntries.length).padStart(2, "0")}
                </span>
                <button
                  type="button"
                  aria-label="Next featured issue"
                  onClick={() =>
                    setIssueIndex(
                      (current) => (current + 1) % genreEntries.length,
                    )
                  }
                >
                  <ChevronRight size={18} />
                </button>
              </div>
            )}
          </div>
        </section>
      )}

      <section
        className="nc-collection nc-wrap"
        ref={collection}
        aria-labelledby="nc-collection-title"
        data-nc-reveal
      >
        <div className="nc-collection-heading">
          <div>
            <p className="nc-section-label">TAKE YOUR TIME. FIND YOUR THING.</p>
            <h2 id="nc-collection-title">
              {isMagazine
                ? "A shelf of fresh perspectives."
                : "Your next chapter starts here."}
            </h2>
          </div>
          <span className="nc-selection-count">
            {String(genreEntries.length).padStart(2, "0")} selections
          </span>
        </div>
        <div className="nc-filterbar">
          <div
            className="nc-topics"
            role="group"
            aria-label={`Filter ${page.label} by topic`}
          >
            {topics.map((name) => (
              <button
                key={name}
                type="button"
                className={topic === name ? "nc-topic-active" : ""}
                aria-pressed={topic === name}
                onClick={() => setTopic(name)}
              >
                {name}
              </button>
            ))}
          </div>
          <div className="nc-filter-tools">
            <button
              type="button"
              className={`nc-list-filter ${savedOnly ? "nc-list-filter-active" : ""}`}
              aria-pressed={savedOnly}
              onClick={() => setSavedOnly((current) => !current)}
            >
              <Bookmark size={14} /> Saved
            </button>
            <label className="nc-sort">
              <span className="nc-visually-hidden">Sort selections</span>
              <select
                value={sort}
                onChange={(event) => setSort(event.target.value)}
              >
                <option value="edit">The editorial edit</option>
                <option value="shortest">Shortest sample first</option>
                <option value="title">Title: A–Z</option>
              </select>
            </label>
          </div>
        </div>
        <p className="nc-results-status" role="status">
          {visibleEntries.length}{" "}
          {visibleEntries.length === 1 ? "selection" : "selections"}
          {topic !== "All selections" ? ` in ${topic}` : " in this edit"}
          {savedOnly ? " from your reading list" : ""}
        </p>
        {visibleEntries.length > 0 ? (
          <div className="nc-book-grid">
            {visibleEntries.map((entry, index) => (
              <article className="nc-book-card" key={entry.id}>
                <div className="nc-book-art">
                  <button
                    type="button"
                    className="nc-book-cover-button"
                    onClick={() => onRead(entry)}
                    aria-label={`Read a sample of ${entry.title}`}
                  >
                    <BookCover entry={entry} />
                  </button>
                  <span className="nc-book-index">
                    {String(index + 1).padStart(2, "0")}
                  </span>
                  <SaveButton
                    entry={entry}
                    saved={savedIds.includes(entry.id)}
                    onSave={onSave}
                  />
                </div>
                <div className="nc-book-text">
                  <p className="nc-book-topic">{entry.topic}</p>
                  <h3>
                    <button type="button" onClick={() => onRead(entry)}>
                      {entry.title}
                    </button>
                  </h3>
                  <p className="nc-book-description">{entry.subtitle}</p>
                  <div className="nc-book-bottom">
                    <span>{entry.readTime} min sample</span>
                    <button
                      type="button"
                      onClick={() => onRead(entry)}
                      aria-label={`Open ${entry.title}`}
                    >
                      Discover <ArrowUpRight size={14} />
                    </button>
                  </div>
                </div>
              </article>
            ))}
          </div>
        ) : (
          <div className="nc-empty">
            <SearchX size={32} strokeWidth={1.2} />
            <h3>A little room for discovery.</h3>
            <p>
              {savedOnly
                ? "Save a selection using its bookmark, or clear this filter to explore the full edit."
                : "There are no selections in this combination. Try another topic or start again."}
            </p>
            <button type="button" onClick={resetFilters}>
              Show all selections <ArrowRight size={15} />
            </button>
          </div>
        )}
      </section>

      <section className="nc-interlude" data-nc-reveal>
        <span className="nc-interlude-mark" aria-hidden="true">
          “
        </span>
        <p>{genre.interlude}</p>
        <span className="nc-interlude-credit">A NOTE FROM RTR DIGITAL</span>
      </section>

      <section className="nc-next nc-wrap" data-nc-reveal>
        <button
          type="button"
          className="nc-back-link"
          onClick={() => onNavigate("notch")}
        >
          <ArrowLeft size={16} /> Back to RTR&apos;s Notch
        </button>
        <button
          type="button"
          className="nc-next-link"
          onClick={() => onNavigate(genre.next)}
        >
          <span>
            <small>KEEP YOUR CURIOSITY GOING</small>
            <strong>{genre.nextLabel}</strong>
          </span>
          <span className="nc-next-arrow">
            <ArrowUpRight size={28} strokeWidth={1.3} />
          </span>
        </button>
      </section>
    </div>
  );
}
