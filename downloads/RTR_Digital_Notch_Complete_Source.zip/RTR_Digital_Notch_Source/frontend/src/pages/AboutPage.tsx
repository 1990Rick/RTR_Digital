import {
  ArrowDown,
  ArrowUpRight,
  Asterisk,
  BookOpen,
  Compass,
  Fingerprint,
} from "lucide-react";
import type { EditorialPage, SectionId } from "../lib/content";
import "./editorial.css";

export function AboutPage({
  page,
  onNavigate,
}: {
  page: EditorialPage;
  onNavigate: (id: SectionId) => void;
}) {
  return (
    <div className="notch-about">
      <section className="ne-about-hero nr-wrap">
        <span className="nr-eyebrow">{page.eyebrow}</span>
        <div className="ne-about-heading">
          <h1>
            {page.title}
            <br />
            <em>{page.emphasis}</em>
          </h1>
          <span className="ne-about-stamp">
            <Asterisk size={39} strokeWidth={1.1} />
            <span>
              CURIOUS
              <br />
              BY NATURE.
            </span>
          </span>
        </div>
        <div className="ne-about-intro">
          <span>OUR STORY, SO FAR.</span>
          <p>{page.description}</p>
          <ArrowDown size={26} strokeWidth={1} />
        </div>
      </section>
      <section className="ne-about-story nr-wrap">
        <div className="ne-about-art">
          <img
            src="/images/rtr-digital-notch-literature.webp"
            width="800"
            height="600"
            alt="Sculptural paper folds and a dark ribbon in soft afternoon light"
          />
          <span>THERE IS ALWAYS MORE BETWEEN THE LINES.</span>
        </div>
        <div className="ne-about-prose">
          <span className="nr-eyebrow">WHY WE’RE HERE</span>
          <h2>
            More than a page.
            <br />
            <em>A place to begin.</em>
          </h2>
          <p>
            Some things deserve our undivided attention. A story that makes the
            journey home feel shorter. A question that changes a conversation. A
            line of poetry that finds us at exactly the right moment.
          </p>
          <p>
            RTR Digital is a growing home for those discoveries. We bring
            together different kinds of reading, from academic ideas to
            imaginative fiction, with an independent spirit and a belief that
            curiosity makes life richer.
          </p>
          <p>
            RTR’s Notch is our front door. Come in with a question, leave with a
            new perspective, and feel free to stay a while.
          </p>
          <button
            className="nr-text-link"
            onClick={() => onNavigate("literature")}
          >
            Find words that stay with you <ArrowUpRight size={18} />
          </button>
        </div>
      </section>
      <section className="ne-values">
        <div className="nr-wrap">
          <div className="ne-values-head">
            <span className="nr-eyebrow">A FEW THINGS WE BELIEVE</span>
            <h2>
              Independent spirit.
              <br />
              <em>Open horizons.</em>
            </h2>
          </div>
          <div className="ne-values-grid">
            {[
              {
                icon: Compass,
                title: "Follow the interesting.",
                copy: "The best discoveries rarely happen in a straight line. We make room for the unexpected, the unfamiliar, and the wonderfully hard to categorise.",
              },
              {
                icon: BookOpen,
                title: "Make time for depth.",
                copy: "There is more to a story than its headline. We value considered words, thoughtful questions, and the pleasure of reading at your own pace.",
              },
              {
                icon: Fingerprint,
                title: "Keep a point of view.",
                copy: "Good reading has character. We celebrate distinct voices and the human choices that make a piece of work worth spending time with.",
              },
            ].map(({ icon: Icon, title, copy }, index) => (
              <article key={title}>
                <div>
                  <Icon size={29} strokeWidth={1.2} />
                  <span>0{index + 1}</span>
                </div>
                <h3>{title}</h3>
                <p>{copy}</p>
              </article>
            ))}
          </div>
        </div>
      </section>
      <section className="ne-next nr-wrap">
        <span className="nr-eyebrow">THE NEXT CHAPTER IS OPEN</span>
        <h2>
          What will you
          <br />
          <em>discover next?</em>
        </h2>
        <p>A new world is usually just a good question away.</p>
        <button
          className="nr-button nr-button-dark"
          onClick={() => onNavigate("notch")}
        >
          Back to RTR’s Notch <ArrowUpRight size={18} />
        </button>
      </section>
    </div>
  );
}
