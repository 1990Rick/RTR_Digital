import { useId, useState } from "react";
import type { FormEvent } from "react";
import {
  ArrowDown,
  ArrowRight,
  ArrowUpRight,
  Check,
  CheckCircle2,
  LoaderCircle,
  Mail,
  Plus,
  X,
} from "lucide-react";
import type { EditorialContent, EditorialPage } from "../lib/content";
import "./editorial.css";

export function NewsletterPage({
  page,
  content,
}: {
  page: EditorialPage;
  content: EditorialContent;
}) {
  const [topics, setTopics] = useState<string[]>(["literature", "fiction"]);
  const [email, setEmail] = useState("");
  const [consent, setConsent] = useState(false);
  const [status, setStatus] = useState<
    "idle" | "sending" | "success" | "error"
  >("idle");
  const [message, setMessage] = useState("");
  const [letter, setLetter] = useState(0);
  const [openQuestion, setOpenQuestion] = useState<number | null>(0);
  const formId = useId();
  const choices = content.pages.filter(
    (p) => !["notch", "about", "newsletters"].includes(p.id),
  );
  const letters = [
    {
      label: "The Sunday Notch",
      eyebrow: "A LITTLE PERSPECTIVE / LETTER 01",
      greeting: "Dear curious reader,",
      title: "What did you notice today?",
      text: "Perhaps the light fell differently across a familiar room. Perhaps a sentence made you stop. This week, we’re making a small case for paying attention—to the world outside, to the ideas around us, and to the stories waiting in plain sight.",
      note: "This is a sample of the editorial tone. Future issues will be shaped by the content you choose to publish.",
    },
    {
      label: "Between the Lines",
      eyebrow: "READING NOTES / LETTER 02",
      greeting: "A note for your next quiet hour,",
      title: "Some books keep good company.",
      text: "There are stories we race through and stories we return to. This week’s reading note is about the second kind: a poem in a coat pocket, a paragraph marked with a pencil, a novel that feels a little different each time we open it.",
      note: "Sample newsletter preview. Signing up saves your preferences; it does not trigger an automatic campaign.",
    },
    {
      label: "The Curious Edit",
      eyebrow: "IDEAS TO SPEND TIME WITH / LETTER 03",
      greeting: "Hello from the other side of the page,",
      title: "Take the interesting way home.",
      text: "An unexpected idea can come from almost anywhere. A conversation about cities becomes a question about belonging. A book about science becomes a lesson in patience. This is a letter for following those connections a little further.",
      note: "Sample newsletter preview. You can explore and change your interests before joining.",
    },
  ];
  const active = letters[letter];
  const questions = [
    [
      "What am I signing up for?",
      "You are saving your email and chosen interests with RTR Digital. Newsletter sending will be configured separately by the owner; this preview does not promise an automated delivery schedule.",
    ],
    [
      "Can I choose what interests me?",
      "Yes. Select one or more topics before joining. Your selections are saved with your email, so future editorial letters can reflect what you want to read.",
    ],
    [
      "How is my email used?",
      "Your email and selected interests are stored privately for the newsletter purpose you consent to. They are not displayed on this site. This form does not create a customer account or place an order.",
    ],
    [
      "What if I change my mind?",
      "Send your request to the business contact the owner publishes with the final site. The administrator can remove your subscription from the private newsletter workspace. Future sent campaigns must include a working unsubscribe option.",
    ],
  ];
  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (status === "sending") return;
    if (!topics.length) {
      setStatus("error");
      setMessage("Choose at least one interest for your reading notes.");
      return;
    }
    if (!consent) {
      setStatus("error");
      setMessage(
        "Please confirm that you want RTR Digital to save your newsletter request.",
      );
      return;
    }
    setStatus("sending");
    setMessage("");
    try {
      const response = await fetch("/api/subscribe.php", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email: email.trim(), topics, consent: true }),
      });
      const result: { ok?: boolean; message?: string; error?: string } =
        await response.json();
      if (!response.ok || !result.ok)
        throw new Error(
          result.error || "Your request could not be saved. Please try again.",
        );
      setStatus("success");
      setMessage(
        result.message ||
          "Your email and interests have been saved. Thank you for being curious.",
      );
    } catch (error) {
      setStatus("error");
      setMessage(
        error instanceof Error && !error.message.includes("JSON")
          ? error.message
          : "The newsletter service is unavailable. Please try again shortly.",
      );
    }
  }
  return (
    <div className="notch-newsletters">
      <section className="ne-letter-hero nr-wrap">
        <div className="ne-letter-copy">
          <span className="nr-eyebrow">{page.eyebrow}</span>
          <h1>
            {page.title}
            <br />
            <em>{page.emphasis}</em>
          </h1>
          <p>{page.description}</p>
          <a className="nr-button nr-button-dark" href="#join-the-letter">
            Find your kind of letter <ArrowDown size={17} />
          </a>
          <span className="ne-note">
            THOUGHTFUL WORDS. A LITTLE LESS NOISE.
          </span>
        </div>
        <div className="ne-envelope-art" aria-hidden="true">
          <span className="ne-airmail-lines" />
          <div className="ne-paper-letter">
            <span>RTR / LETTERS</span>
            <p>
              Good things
              <br />
              come to
              <br />
              <em>curious minds.</em>
            </p>
            <span className="ne-letter-scribble">
              A little note from us to you.
            </span>
          </div>
          <div className="ne-envelope">
            <span className="ne-envelope-fold" />
            <span className="ne-envelope-monogram">rtr.</span>
          </div>
          <div className="ne-postmark">
            <span>
              OPEN WITH
              <br />
              CURIOSITY
            </span>
            <Mail size={20} strokeWidth={1} />
          </div>
        </div>
      </section>
      <section
        className="ne-sample nr-wrap"
        aria-labelledby="letter-preview-heading"
      >
        <div className="ne-sample-head">
          <span className="nr-eyebrow">A TASTE OF WHAT’S TO COME</span>
          <h2 id="letter-preview-heading">
            Consider this
            <br />
            <em>an open letter.</em>
          </h2>
          <p>A few sample editions to help you find your frequency.</p>
        </div>
        <div className="ne-sample-content">
          <div
            className="ne-letter-tabs"
            role="group"
            aria-label="Choose a sample newsletter"
          >
            {letters.map((item, index) => (
              <button
                key={item.label}
                aria-pressed={index === letter}
                className={index === letter ? "is-active" : ""}
                onClick={() => setLetter(index)}
              >
                {item.label}
                <ArrowUpRight size={15} />
              </button>
            ))}
          </div>
          <article className="ne-letter-preview" key={letter}>
            <span className="nr-eyebrow">{active.eyebrow}</span>
            <p className="ne-sample-greeting">{active.greeting}</p>
            <h3>{active.title}</h3>
            <p>{active.text}</p>
            <span className="ne-letter-signature">
              Until the next page,
              <br />
              <em>RTR Digital</em>
            </span>
            <small>{active.note}</small>
          </article>
        </div>
      </section>
      <section className="ne-join" id="join-the-letter">
        <div className="nr-wrap ne-join-grid">
          <div>
            <span className="nr-eyebrow">MAKE YOURSELF AT HOME</span>
            <h2>
              A good place
              <br />
              <em>to stay curious.</em>
            </h2>
            <p>
              Choose the things that move you.
              <br />
              We’ll keep your reading interests together.
            </p>
            <span className="ne-join-index">
              A LETTER IS A SMALL BEGINNING.{" "}
              <ArrowUpRight size={27} strokeWidth={1} />
            </span>
          </div>
          {status === "success" ? (
            <div className="ne-form-success" role="status">
              <CheckCircle2 size={40} strokeWidth={1.2} />
              <h3>You’re on the list.</h3>
              <p>{message}</p>
              <p className="ne-form-note">
                Your preferences are saved. Sending future letters is managed
                separately by RTR Digital.
              </p>
              <button
                className="nr-text-link"
                onClick={() => {
                  setStatus("idle");
                  setEmail("");
                  setConsent(false);
                }}
              >
                Add another email <ArrowRight size={18} />
              </button>
            </div>
          ) : (
            <form className="ne-signup-form" onSubmit={submit}>
              <label className="ne-field-label" htmlFor={`${formId}-email`}>
                Your email address
              </label>
              <input
                id={`${formId}-email`}
                name="email"
                autoComplete="email"
                type="email"
                maxLength={254}
                required
                placeholder="you@somewhere.com"
                value={email}
                onChange={(event) => setEmail(event.target.value)}
              />
              <fieldset>
                <legend>What catches your curiosity?</legend>
                <div className="ne-topic-options">
                  {choices.map((item) => (
                    <button
                      type="button"
                      key={item.id}
                      aria-pressed={topics.includes(item.id)}
                      className={topics.includes(item.id) ? "is-active" : ""}
                      onClick={() =>
                        setTopics((previous) =>
                          previous.includes(item.id)
                            ? previous.filter((id) => id !== item.id)
                            : [...previous, item.id],
                        )
                      }
                    >
                      {topics.includes(item.id) ? (
                        <Check size={13} />
                      ) : (
                        <Plus size={13} />
                      )}{" "}
                      {item.label}
                    </button>
                  ))}
                </div>
              </fieldset>
              <label className="ne-consent">
                <input
                  type="checkbox"
                  required
                  checked={consent}
                  onChange={(event) => setConsent(event.target.checked)}
                />
                <span>
                  I’d like RTR Digital to save my email and selected interests
                  for future newsletter updates.
                </span>
              </label>
              {status === "error" && (
                <p className="ne-form-error" role="alert">
                  {message}
                </p>
              )}
              <button
                type="submit"
                className="nr-button nr-button-dark ne-submit"
                disabled={status === "sending"}
              >
                {status === "sending" ? (
                  <>
                    <LoaderCircle className="nr-spinning" size={18} /> Saving
                    your place…
                  </>
                ) : (
                  <>
                    Keep me curious <ArrowUpRight size={18} />
                  </>
                )}
              </button>
              <p className="ne-form-note">
                A private sign-up, with your permission. No payment or account
                required.
              </p>
            </form>
          )}
        </div>
      </section>
      <section className="ne-faq nr-wrap">
        <div>
          <span className="nr-eyebrow">A FEW GOOD QUESTIONS</span>
          <h2>
            Before you
            <br />
            <em>turn the page.</em>
          </h2>
        </div>
        <div className="ne-faq-list">
          {questions.map(([question, answer], index) => (
            <div className="ne-faq-item" key={question}>
              <h3>
                <button
                  aria-expanded={index === openQuestion}
                  aria-controls={`${formId}-faq-${index}`}
                  onClick={() =>
                    setOpenQuestion(index === openQuestion ? null : index)
                  }
                >
                  {question}
                  {index === openQuestion ? (
                    <X size={18} />
                  ) : (
                    <Plus size={18} />
                  )}
                </button>
              </h3>
              {index === openQuestion && (
                <p id={`${formId}-faq-${index}`}>{answer}</p>
              )}
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}
