import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import type { MouseEvent } from "react";
import {
  ArrowRight,
  ArrowUpRight,
  Asterisk,
  Bookmark,
  Check,
  ChevronUp,
  Menu,
  Search,
  X,
} from "lucide-react";
import { HomePage } from "./pages/HomePage";
import { CategoryPage } from "./pages/CategoryPage";
import { AboutPage } from "./pages/AboutPage";
import { NewsletterPage } from "./pages/NewsletterPage";
import { Dialog } from "./components/Dialog";
import BookCover from "./components/BookCover";
import {
  initialContent,
  pageForPath,
  readSaved,
  validContent,
} from "./lib/content";
import type {
  EditorialContent,
  EditorialEntry,
  SectionId,
} from "./lib/content";

type Overlay = "search" | "saved" | "privacy" | null;
function Brand({
  onHome,
}: {
  onHome: (event: MouseEvent<HTMLAnchorElement>) => void;
}) {
  return (
    <a
      className="nr-brand"
      href="/"
      aria-label="RTR Digital home"
      onClick={onHome}
    >
      <span className="nr-brand-mark" aria-hidden="true">
        <svg viewBox="0 0 64 64">
          <path d="M18 48V16h16c17 0 18 23 1 24l14 8H34L23 37h10c8 0 8-12 0-12h-5v23Z" />
        </svg>
      </span>
      <span>
        RTR<span className="nr-brand-digital">Digital</span>
        <span className="nr-brand-dot">.</span>
      </span>
    </a>
  );
}

export default function App() {
  const [content, setContent] = useState<EditorialContent>(initialContent);
  const [pageId, setPageId] = useState<SectionId | null>(
    () => pageForPath(location.pathname)?.id || null,
  );
  const [menuOpen, setMenuOpen] = useState(false);
  const [overlay, setOverlay] = useState<Overlay>(null);
  const [query, setQuery] = useState("");
  const [reading, setReading] = useState<EditorialEntry | null>(null);
  const [savedIds, setSavedIds] = useState<string[]>(readSaved);
  const [toast, setToast] = useState("");
  const [announcement, setAnnouncement] = useState(true);
  const mainRef = useRef<HTMLElement>(null);
  const page = content.pages.find((item) => item.id === pageId);
  const saved = content.entries.filter((entry) => savedIds.includes(entry.id));
  const reducedMotion = () =>
    window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  const closeDialog = useCallback(() => {
    setOverlay(null);
    setReading(null);
  }, []);

  useEffect(() => {
    const controller = new AbortController();
    fetch("/api/content.php", { signal: controller.signal, cache: "no-cache" })
      .then((response) => (response.ok ? response.json() : null))
      .then((data: { content?: unknown } | null) => {
        if (validContent(data?.content)) setContent(data.content);
      })
      .catch(() => {
        /* The bundled editorial edition remains usable without a configured content backend. */
      });
    // Retire only the previous RTR service worker; it must not cache a different release over this site.
    if ("serviceWorker" in navigator)
      void navigator.serviceWorker
        .getRegistrations()
        .then((registrations) => {
          for (const registration of registrations)
            if (
              new URL(registration.scope).origin === location.origin &&
              registration.active?.scriptURL.endsWith("/sw.js")
            )
              void registration.unregister();
        })
        .catch(() => {});
    return () => controller.abort();
  }, []);
  useEffect(() => {
    const onBack = () => {
      setPageId(pageForPath(location.pathname)?.id || null);
      setMenuOpen(false);
      closeDialog();
      window.scrollTo({ top: 0, behavior: "instant" });
    };
    const onShortcut = (event: KeyboardEvent) => {
      if ((event.metaKey || event.ctrlKey) && event.key.toLowerCase() === "k") {
        event.preventDefault();
        setReading(null);
        setMenuOpen(false);
        setOverlay((previous) => (previous === "search" ? null : "search"));
      }
      if (event.key === "Escape") setMenuOpen(false);
    };
    window.addEventListener("popstate", onBack);
    window.addEventListener("keydown", onShortcut);
    return () => {
      window.removeEventListener("popstate", onBack);
      window.removeEventListener("keydown", onShortcut);
    };
  }, [closeDialog]);
  useEffect(() => {
    let frame = 0;
    const progress = () => {
      cancelAnimationFrame(frame);
      frame = requestAnimationFrame(() => {
        const distance =
          document.documentElement.scrollHeight - window.innerHeight;
        document.documentElement.style.setProperty(
          "--reading-progress",
          String(distance > 0 ? Math.min(1, window.scrollY / distance) : 0),
        );
        document.documentElement.classList.toggle(
          "nr-scrolled",
          window.scrollY > 24,
        );
      });
    };
    window.addEventListener("scroll", progress, { passive: true });
    window.addEventListener("resize", progress);
    progress();
    return () => {
      cancelAnimationFrame(frame);
      window.removeEventListener("scroll", progress);
      window.removeEventListener("resize", progress);
    };
  }, [pageId]);
  useEffect(() => {
    document.title = `${page?.label || "Page not found"} — RTR Digital`;
    document
      .querySelector('meta[name="description"]')
      ?.setAttribute(
        "content",
        page?.description || "Discover a new perspective with RTR Digital.",
      );
  }, [page]);
  useEffect(() => {
    try {
      localStorage.setItem("rtr-notch-reading-list", JSON.stringify(savedIds));
    } catch {
      /* Session reading list remains available if browser storage is blocked. */
    }
  }, [savedIds]);
  useEffect(() => {
    if (toast) {
      const timer = window.setTimeout(() => setToast(""), 3200);
      return () => window.clearTimeout(timer);
    }
  }, [toast]);
  useEffect(() => {
    if (!menuOpen) return;
    const headerBottom =
      document.querySelector(".nr-header")?.getBoundingClientRect().bottom ||
      72;
    document.documentElement.style.setProperty(
      "--nr-menu-top",
      `${headerBottom}px`,
    );
    const previous = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    const keydown = (event: KeyboardEvent) => {
      const trigger = document.querySelector<HTMLButtonElement>(
        ".nr-mobile-menu-button",
      );
      const links = Array.from(
        document.querySelectorAll<HTMLAnchorElement>("#mobile-navigation a"),
      );
      if (event.key === "Escape") {
        setMenuOpen(false);
        trigger?.focus();
      }
      if (event.key === "Tab" && links.length) {
        if (!event.shiftKey && document.activeElement === trigger) {
          event.preventDefault();
          links[0].focus();
        } else if (
          !event.shiftKey &&
          document.activeElement === links[links.length - 1]
        ) {
          event.preventDefault();
          trigger?.focus();
        } else if (event.shiftKey && document.activeElement === links[0]) {
          event.preventDefault();
          trigger?.focus();
        } else if (event.shiftKey && document.activeElement === trigger) {
          event.preventDefault();
          links[links.length - 1].focus();
        }
      }
    };
    window.addEventListener("keydown", keydown);
    return () => {
      document.body.style.overflow = previous;
      window.removeEventListener("keydown", keydown);
    };
  }, [menuOpen]);

  const navigate = useCallback(
    (id: SectionId) => {
      const target = initialContent.pages.find((item) => item.id === id);
      if (!target) return;
      if (location.pathname !== target.path)
        history.pushState({}, "", target.path);
      setPageId(id);
      setMenuOpen(false);
      closeDialog();
      window.scrollTo({ top: 0, behavior: "instant" });
      requestAnimationFrame(() =>
        mainRef.current?.focus({ preventScroll: true }),
      );
    },
    [closeDialog],
  );
  function routeLink(event: MouseEvent<HTMLAnchorElement>, id: SectionId) {
    if (
      event.button !== 0 ||
      event.metaKey ||
      event.ctrlKey ||
      event.shiftKey ||
      event.altKey
    )
      return;
    event.preventDefault();
    navigate(id);
  }
  function save(id: string) {
    const exists = savedIds.includes(id);
    setSavedIds((previous) =>
      previous.includes(id)
        ? previous.filter((item) => item !== id)
        : [...previous, id],
    );
    setToast(
      exists
        ? "Removed from your reading list."
        : "Saved to your reading list in this browser.",
    );
  }
  function openReading(entry: EditorialEntry) {
    setOverlay(null);
    setReading(entry);
  }
  const results = useMemo(() => {
    const value = query.trim().toLocaleLowerCase();
    if (!value)
      return content.entries.filter((_, index) => index % 4 === 0).slice(0, 6);
    return content.entries.filter((entry) =>
      `${entry.title} ${entry.subtitle} ${entry.topic} ${entry.description} ${content.pages.find((item) => item.id === entry.category)?.label}`
        .toLocaleLowerCase()
        .includes(value),
    );
  }, [content, query]);

  return (
    <>
      <a className="nr-skip" href="#main-content">
        Skip to content
      </a>
      {announcement && (
        <div className="nr-announcement">
          <span>{content.site.announcement}</span>
          <button onClick={() => navigate("about")}>
            Meet your next perspective <ArrowUpRight size={12} />
          </button>
          <button
            className="nr-announcement-close"
            aria-label="Dismiss announcement"
            onClick={() => setAnnouncement(false)}
          >
            <X size={13} />
          </button>
        </div>
      )}
      <header className="nr-header">
        <div className="nr-header-main nr-wrap">
          <Brand onHome={(event) => routeLink(event, "notch")} />
          <span className="nr-brand-caption">
            A HOME FOR
            <br />
            CURIOUS MINDS.
          </span>
          <div className="nr-header-tools">
            <button
              className="nr-search-launch"
              onClick={() => {
                setMenuOpen(false);
                setQuery("");
                setOverlay("search");
              }}
              aria-label="Search the reading collection"
            >
              <Search size={17} strokeWidth={1.7} />
              <span>Find something good</span>
              <kbd>⌘ K</kbd>
            </button>
            <button
              className="nr-icon-button nr-reading-list"
              onClick={() => {
                setMenuOpen(false);
                setOverlay("saved");
              }}
              aria-label={`Your reading list, ${saved.length} saved selections`}
            >
              <Bookmark size={20} strokeWidth={1.5} />
              {saved.length > 0 && <span>{saved.length}</span>}
            </button>
            <a
              className="nr-header-letter"
              href="/newsletters"
              onClick={(event) => routeLink(event, "newsletters")}
            >
              Stay curious <ArrowUpRight size={16} />
            </a>
            <button
              className="nr-mobile-menu-button nr-icon-button"
              aria-label={
                menuOpen ? "Close navigation menu" : "Open navigation menu"
              }
              aria-expanded={menuOpen}
              aria-controls="mobile-navigation"
              onClick={() => setMenuOpen((value) => !value)}
            >
              {menuOpen ? <X size={22} /> : <Menu size={22} />}
            </button>
          </div>
        </div>
        <nav className="nr-desktop-nav nr-wrap" aria-label="Main navigation">
          {content.pages.map((item) => (
            <a
              key={item.id}
              className={item.id === pageId ? "is-current" : ""}
              href={item.path}
              aria-current={item.id === pageId ? "page" : undefined}
              onClick={(event) => routeLink(event, item.id)}
            >
              {item.label}
              {item.id === "notch" && (
                <Asterisk
                  className="nr-nav-asterisk"
                  size={15}
                  aria-hidden="true"
                />
              )}
            </a>
          ))}
          <span className="nr-nav-end">EST. IN CURIOSITY</span>
        </nav>
        <span className="nr-progress" aria-hidden="true" />
      </header>
      {menuOpen && (
        <nav
          id="mobile-navigation"
          className="nr-mobile-navigation"
          aria-label="Mobile navigation"
        >
          <span className="nr-eyebrow">WHERE WILL CURIOSITY TAKE YOU?</span>
          {content.pages.map((item, index) => (
            <a
              key={item.id}
              href={item.path}
              aria-current={item.id === pageId ? "page" : undefined}
              onClick={(event) => routeLink(event, item.id)}
            >
              <span>0{index + 1}</span>
              {item.label}
              <ArrowUpRight size={18} />
            </a>
          ))}
          <span className="nr-mobile-navigation-note">
            Independent spirit. Open horizons.
          </span>
        </nav>
      )}

      <main
        id="main-content"
        ref={mainRef}
        tabIndex={-1}
        inert={menuOpen}
        className="nr-main"
        key={pageId || "404"}
      >
        {pageId === "notch" && (
          <HomePage
            content={content}
            onNavigate={navigate}
            onRead={openReading}
            onSave={save}
            savedIds={savedIds}
          />
        )}
        {pageId === "about" && page && (
          <AboutPage page={page} onNavigate={navigate} />
        )}
        {pageId === "newsletters" && page && (
          <NewsletterPage page={page} content={content} />
        )}
        {page &&
          pageId &&
          !["notch", "about", "newsletters"].includes(pageId) && (
            <CategoryPage
              page={page}
              entries={content.entries.filter(
                (entry) => entry.category === pageId,
              )}
              onRead={openReading}
              onSave={save}
              savedIds={savedIds}
              onNavigate={navigate}
            />
          )}
        {!page && (
          <section className="nr-not-found nr-wrap">
            <span className="nr-eyebrow">A SMALL DETOUR / 404</span>
            <h1>
              Let’s find
              <br />
              <em>a better page.</em>
            </h1>
            <p>
              This chapter hasn’t been written. There’s plenty more to discover
              at RTR’s Notch.
            </p>
            <button
              className="nr-button nr-button-dark"
              onClick={() => navigate("notch")}
            >
              Back to the beginning <ArrowUpRight size={18} />
            </button>
          </section>
        )}
      </main>

      <footer className="nr-footer" inert={menuOpen}>
        <div className="nr-wrap">
          <div className="nr-footer-top">
            <div>
              <Brand onHome={(event) => routeLink(event, "notch")} />
              <p>
                {content.site.tagline}
                <br />A new perspective is always a good idea.
              </p>
              <a
                href="/newsletters"
                onClick={(event) => routeLink(event, "newsletters")}
                className="nr-footer-letter"
              >
                A little letter, now and then <ArrowUpRight size={17} />
              </a>
            </div>
            <div className="nr-footer-nav">
              <span className="nr-eyebrow">MAKE YOURSELF AT HOME</span>
              <div>
                {content.pages.map((item) => (
                  <a
                    key={item.id}
                    href={item.path}
                    onClick={(event) => routeLink(event, item.id)}
                  >
                    {item.label}
                  </a>
                ))}
              </div>
            </div>
            <button
              className="nr-back-top"
              aria-label="Back to top"
              onClick={() =>
                window.scrollTo({
                  top: 0,
                  behavior: reducedMotion() ? "instant" : "smooth",
                })
              }
            >
              <ChevronUp size={23} />
              <span>BACK TO TOP</span>
            </button>
          </div>
          <div className="nr-footer-wordmark" aria-hidden="true">
            Always <em>curious.</em>
            <span>↗</span>
          </div>
          <div className="nr-footer-bottom">
            <span>
              © {new Date().getFullYear()} RTR Digital. All perspectives
              welcome.
            </span>
            <span>PREVIEW EDITION · SAMPLE EDITORIAL SELECTIONS</span>
            <button onClick={() => setOverlay("privacy")}>
              Privacy & your choices <ArrowUpRight size={12} />
            </button>
          </div>
        </div>
      </footer>

      {overlay === "search" && (
        <Dialog
          title="Find your next read"
          onClose={closeDialog}
          className="nr-search-dialog"
        >
          <div className="nr-search-input">
            <Search size={23} />
            <input
              autoFocus
              type="search"
              value={query}
              onChange={(event) => setQuery(event.target.value)}
              placeholder="A title, an idea, a new perspective…"
              aria-label="Search titles, topics and stories"
            />
            <kbd>ESC</kbd>
          </div>
          <div className="nr-search-results">
            <span className="nr-eyebrow">
              {query.trim()
                ? `${results.length} ${results.length === 1 ? "DISCOVERY" : "DISCOVERIES"}`
                : "SOMETHING TO GET YOU STARTED"}
            </span>
            {results.length ? (
              results.map((entry) => (
                <button key={entry.id} onClick={() => openReading(entry)}>
                  <span
                    className={`nr-search-result-mark nr-search-mark-${entry.category}`}
                  />
                  <span>
                    <strong>{entry.title}</strong>
                    <small>
                      {
                        content.pages.find((item) => item.id === entry.category)
                          ?.label
                      }{" "}
                      · {entry.topic}
                    </small>
                  </span>
                  <ArrowUpRight size={19} />
                </button>
              ))
            ) : (
              <div className="nr-empty">
                <p>No pages found. Try a different word.</p>
                <button className="nr-text-link" onClick={() => setQuery("")}>
                  Explore the selections <ArrowRight size={16} />
                </button>
              </div>
            )}
          </div>
        </Dialog>
      )}
      {overlay === "saved" && (
        <Dialog
          title="Your reading list"
          onClose={closeDialog}
          className="nr-saved-dialog"
        >
          <div className="nr-dialog-intro">
            <span className="nr-eyebrow">GOOD THINGS, KEPT CLOSE.</span>
            <h2>
              Your next
              <br />
              <em>quiet hour.</em>
            </h2>
            <p>Saved in this browser, ready when you are.</p>
          </div>
          {saved.length ? (
            <div className="nr-saved-list">
              {saved.map((entry) => (
                <article key={entry.id}>
                  <button
                    className="nr-saved-open"
                    onClick={() => openReading(entry)}
                  >
                    <BookCover entry={entry} />
                    <span>
                      <small>{entry.topic}</small>
                      <strong>{entry.title}</strong>
                      <span>
                        {entry.readTime} min read <ArrowUpRight size={15} />
                      </span>
                    </span>
                  </button>
                  <button
                    className="nr-icon-button"
                    aria-label={`Remove ${entry.title} from reading list`}
                    onClick={() => save(entry.id)}
                  >
                    <X size={18} />
                  </button>
                </article>
              ))}
            </div>
          ) : (
            <div className="nr-empty">
              <Bookmark size={31} strokeWidth={1.2} />
              <p>A good story is worth keeping.</p>
              <span>
                Use the bookmark beside any selection to begin your reading
                list.
              </span>
              <button
                className="nr-button nr-button-dark"
                onClick={() => navigate("notch")}
              >
                Explore the editors’ shelf <ArrowUpRight size={16} />
              </button>
            </div>
          )}
        </Dialog>
      )}
      {reading && (
        <Dialog
          title={`Reading: ${reading.title}`}
          onClose={closeDialog}
          className="nr-reading-dialog"
        >
          <div className="nr-reader">
            <aside>
              <BookCover entry={reading} large />
              <span>SAMPLE READING / THE RTR EDIT</span>
            </aside>
            <article>
              <span className="nr-eyebrow">
                {
                  content.pages.find((item) => item.id === reading.category)
                    ?.label
                }{" "}
                / {reading.topic}
              </span>
              <h2>{reading.title}</h2>
              <p className="nr-reader-subtitle">{reading.subtitle}</p>
              <div className="nr-reader-byline">
                <span>RTR EDITORIAL</span>
                <span>{reading.readTime} MIN READ</span>
              </div>
              {reading.excerpt.map((paragraph, index) => (
                <p className="nr-reader-paragraph" key={index}>
                  {paragraph}
                </p>
              ))}
              <p className="nr-reader-note">
                A sample editorial selection. Final publications and digital
                editions will be introduced in a later phase.
              </p>
              <button
                className="nr-button nr-button-dark"
                onClick={() => save(reading.id)}
              >
                {savedIds.includes(reading.id) ? (
                  <Check size={17} />
                ) : (
                  <Bookmark size={17} />
                )}{" "}
                {savedIds.includes(reading.id)
                  ? "Saved to your reading list"
                  : "Keep this on your reading list"}
              </button>
            </article>
          </div>
        </Dialog>
      )}
      {overlay === "privacy" && (
        <Dialog
          title="Privacy and your choices"
          onClose={closeDialog}
          className="nr-privacy-dialog"
        >
          <div className="nr-dialog-intro">
            <span className="nr-eyebrow">A LITTLE CLARITY</span>
            <h2>
              Your curiosity.
              <br />
              <em>Your choices.</em>
            </h2>
          </div>
          <div className="nr-privacy-copy">
            <h3>Your reading list</h3>
            <p>
              Bookmarked selections stay in this browser’s local storage. They
              are not a customer account and are not synced between devices.
              Clear your list by removing its items or deleting this site’s
              browser data.
            </p>
            <h3>Newsletter requests</h3>
            <p>
              If you explicitly sign up, the content backend privately stores
              your email and chosen interests. This preview saves the request;
              an automatic newsletter delivery service is not connected. The
              owner will publish final contact and privacy details before
              starting campaigns.
            </p>
            <h3>Site operation</h3>
            <p>
              The separate content workspace uses a necessary session cookie for
              its authenticated operator. This public site does not load
              third-party analytics or advertising trackers. Your hosting
              provider may keep normal web-server logs.
            </p>
            <p>
              These are the current preview’s operating details. Final business
              policies, contact details and publication terms will be supplied
              by RTR Digital.
            </p>
          </div>
        </Dialog>
      )}
      {toast && (
        <div className="nr-toast" role="status">
          <Check size={16} />
          {toast}
          <button aria-label="Dismiss message" onClick={() => setToast("")}>
            <X size={14} />
          </button>
        </div>
      )}
    </>
  );
}
