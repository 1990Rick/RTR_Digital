import seed from "../../../shared/editorial-content.json";

export type SectionId =
  | "notch"
  | "about"
  | "academics"
  | "crime-thrillers"
  | "fiction"
  | "non-fiction"
  | "literature"
  | "magazines"
  | "newsletters";
export interface EditorialPage {
  id: SectionId;
  path: string;
  label: string;
  eyebrow: string;
  title: string;
  emphasis: string;
  description: string;
  accent: string;
  theme: string;
}
export interface EditorialEntry {
  id: string;
  category: SectionId;
  title: string;
  subtitle: string;
  description: string;
  excerpt: string[];
  readTime: number;
  topic: string;
  art: string;
  year: string;
}
export interface EditorialContent {
  site: { name: string; tagline: string; announcement: string };
  pages: EditorialPage[];
  entries: EditorialEntry[];
}
export const initialContent = seed as EditorialContent;
export const sectionArt: Partial<Record<SectionId, string>> = {
  academics: "academics",
  "crime-thrillers": "crime",
  fiction: "fiction",
  "non-fiction": "nonfiction",
  literature: "literature",
  magazines: "magazines",
};
export function pageForPath(path: string): EditorialPage | undefined {
  const normal = path.replace(/\/$/, "") || "/";
  return initialContent.pages.find((page) => page.path === normal);
}
export function readSaved(): string[] {
  try {
    const value: unknown = JSON.parse(
      localStorage.getItem("rtr-notch-reading-list") || "[]",
    );
    return Array.isArray(value)
      ? value.filter((v): v is string => typeof v === "string").slice(0, 100)
      : [];
  } catch {
    return [];
  }
}
export function validContent(value: unknown): value is EditorialContent {
  if (!value || typeof value !== "object") return false;
  const candidate = value as EditorialContent;
  return Boolean(
    candidate.site &&
      typeof candidate.site.name === "string" &&
      Array.isArray(candidate.pages) &&
      candidate.pages.length === 9 &&
      initialContent.pages.every((base) =>
        candidate.pages.some(
          (page) =>
            page.id === base.id &&
            page.path === base.path &&
            typeof page.title === "string",
        ),
      ) &&
      Array.isArray(candidate.entries) &&
      candidate.entries.every(
        (entry) =>
          typeof entry.id === "string" &&
          typeof entry.title === "string" &&
          Array.isArray(entry.excerpt),
      ),
  );
}
