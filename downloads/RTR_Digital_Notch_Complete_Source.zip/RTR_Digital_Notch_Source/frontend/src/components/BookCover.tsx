import type { CSSProperties } from "react";
import type { EditorialEntry } from "../lib/content";

export default function BookCover({
  entry,
  large = false,
}: {
  entry: EditorialEntry;
  large?: boolean;
}) {
  const index = entry.title.length % 4;
  return (
    <div
      className={`rtr-book rtr-book-${entry.category} rtr-book-variant-${index}${large ? " rtr-book-large" : ""}`}
      style={{ "--book-rotation": `${index % 2 ? 3 : -3}deg` } as CSSProperties}
      aria-hidden="true"
    >
      <span className="rtr-book-spine" />
      <div className="rtr-book-face">
        <span className="rtr-book-imprint">
          RTR DIGITAL <span>READ SOMETHING DIFFERENT</span>
        </span>
        <span className="rtr-book-shape">
          <i />
          <i />
          <i />
        </span>
        <span className="rtr-book-title">{entry.title}</span>
        <span className="rtr-book-subtitle">{entry.subtitle}</span>
        <span className="rtr-book-bottom">
          THE RTR EDIT <span>↗</span>
        </span>
      </div>
    </div>
  );
}
