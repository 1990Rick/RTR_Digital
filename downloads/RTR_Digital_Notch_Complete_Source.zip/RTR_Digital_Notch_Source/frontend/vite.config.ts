import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
import { fileURLToPath, URL } from "node:url";

export default defineConfig({
  root: fileURLToPath(new URL(".", import.meta.url)),
  plugins: [react()],
  build: { outDir: "../dist/frontend", emptyOutDir: true, assetsDir: "assets" },
  server: {
    host: "0.0.0.0",
    port: 5173,
    strictPort: true,
    fs: {
      allow: [fileURLToPath(new URL("..", import.meta.url))],
      deny: [
        "**/.git/**",
        "**/.env*",
        "**/backend/private/**",
        "**/backend/app/**",
        "**/data/**",
        "**/*.sqlite*",
        "**/*.{pem,key}",
      ],
    },
    proxy: {
      "/api": { target: "http://127.0.0.1:3002", changeOrigin: false },
      "/admin": { target: "http://127.0.0.1:3002", changeOrigin: false },
    },
  },
  preview: { host: "0.0.0.0", port: 4173, strictPort: true },
});
