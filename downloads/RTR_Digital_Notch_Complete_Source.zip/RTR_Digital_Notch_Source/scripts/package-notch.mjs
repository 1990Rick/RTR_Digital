/**
 * Package the Notch editorial release without including customer data or secrets.
 * Run after npm run build: node scripts/package-notch.mjs
 * Requires only Node.js; no system zip utility or Python is needed.
 */
import { existsSync, mkdirSync, readFileSync, readdirSync, statSync, writeFileSync } from "node:fs";
import { dirname, relative, resolve, sep } from "node:path";
import { fileURLToPath } from "node:url";
import { createHash } from "node:crypto";
import { deflateRawSync } from "node:zlib";

const ROOT = resolve(dirname(fileURLToPath(import.meta.url)), "..");
const OUT = resolve(ROOT, "deliverables");
const FRONTEND = resolve(ROOT, "dist/frontend");
const BACKEND = resolve(ROOT, "backend");
const LEGACY = existsSync(resolve(ROOT, "server/index.mjs")) ? ROOT : resolve(ROOT, "legacy-commerce");

const htaccess = `# RTR Digital: public frontend. Keep api/ and admin/ as separate PHP routes.
Options -Indexes
DirectoryIndex index.html index.php
<IfModule mod_rewrite.c>
  RewriteEngine On
  RewriteRule ^(?:rtr-backend|backend|private|app|seed|node_modules|\\.git)(?:/|$) - [F,L,NC]
  RewriteRule (^|/)\\.(?!well-known/) - [F,L]
  RewriteCond %{REQUEST_FILENAME} -f [OR]
  RewriteCond %{REQUEST_FILENAME} -d
  RewriteRule ^ - [L]
  RewriteRule ^(?:api|admin)(?:/|$) - [L]
  RewriteRule ^ index.html [L]
</IfModule>
<IfModule mod_headers.c>
  Header always set X-Content-Type-Options "nosniff"
  Header always set Referrer-Policy "strict-origin-when-cross-origin"
  <FilesMatch "[.]html$">
    Header set Cache-Control "no-cache"
  </FilesMatch>
</IfModule>
`;

const crcTable = Uint32Array.from({ length: 256 }, (_, index) => {
  let value = index;
  for (let bit = 0; bit < 8; bit++) value = value & 1 ? 0xedb88320 ^ (value >>> 1) : value >>> 1;
  return value >>> 0;
});
function crc32(buffer) {
  let crc = 0xffffffff;
  for (const byte of buffer) crc = crcTable[(crc ^ byte) & 255] ^ (crc >>> 8);
  return (crc ^ 0xffffffff) >>> 0;
}
function normalize(path) {
  const value = path.split(sep).join("/");
  if (value.startsWith("/") || value.split("/").includes("..")) throw new Error(`Unsafe archive path: ${path}`);
  return value;
}
function entry(path, data) {
  return { path: normalize(path), data: Buffer.isBuffer(data) ? data : Buffer.from(data) };
}
function walk(folder, prefix = "", accept = () => true) {
  if (!existsSync(folder)) return [];
  const result = [];
  for (const item of readdirSync(folder, { withFileTypes: true }).sort((a, b) => a.name.localeCompare(b.name))) {
    const disk = resolve(folder, item.name);
    const name = prefix ? `${prefix}/${item.name}` : item.name;
    if (!accept(name, item)) continue;
    if (item.isSymbolicLink()) throw new Error(`Symlinks cannot enter a delivery: ${disk}`);
    if (item.isDirectory()) result.push(...walk(disk, name, accept));
    else if (item.isFile()) result.push(entry(name, readFileSync(disk)));
  }
  return result;
}
function zip(filename, entries) {
  const seen = new Set();
  const local = [], central = [];
  let offset = 0;
  // Real release timestamps are important: fixed 1980 timestamps can make an
  // updated index.html look unchanged to an HTTP If-Modified-Since request.
  const releaseTime = new Date();
  const dosTime = (releaseTime.getUTCHours() << 11) | (releaseTime.getUTCMinutes() << 5) | (releaseTime.getUTCSeconds() >> 1);
  const dosDate = ((Math.max(1980, releaseTime.getUTCFullYear()) - 1980) << 9) | ((releaseTime.getUTCMonth() + 1) << 5) | releaseTime.getUTCDate();
  for (const file of entries) {
    if (seen.has(file.path)) throw new Error(`Duplicate archive entry: ${file.path}`);
    seen.add(file.path);
    const name = Buffer.from(file.path, "utf8");
    const data = file.data;
    const compressed = deflateRawSync(data, { level: 9 });
    const crc = crc32(data);
    const header = Buffer.alloc(30);
    header.writeUInt32LE(0x04034b50, 0);
    header.writeUInt16LE(20, 4);
    header.writeUInt16LE(0x800, 6);
    header.writeUInt16LE(8, 8);
    header.writeUInt16LE(dosTime, 10);
    header.writeUInt16LE(dosDate, 12);
    header.writeUInt32LE(crc, 14);
    header.writeUInt32LE(compressed.length, 18);
    header.writeUInt32LE(data.length, 22);
    header.writeUInt16LE(name.length, 26);
    local.push(header, name, compressed);
    const record = Buffer.alloc(46);
    record.writeUInt32LE(0x02014b50, 0);
    record.writeUInt16LE(0x0314, 4);
    record.writeUInt16LE(20, 6);
    record.writeUInt16LE(0x800, 8);
    record.writeUInt16LE(8, 10);
    record.writeUInt16LE(dosTime, 12);
    record.writeUInt16LE(dosDate, 14);
    record.writeUInt32LE(crc, 16);
    record.writeUInt32LE(compressed.length, 20);
    record.writeUInt32LE(data.length, 24);
    record.writeUInt16LE(name.length, 28);
    record.writeUInt32LE((0o100644 << 16) >>> 0, 38);
    record.writeUInt32LE(offset, 42);
    central.push(record, name);
    offset += header.length + name.length + compressed.length;
  }
  const directory = Buffer.concat(central);
  const end = Buffer.alloc(22);
  end.writeUInt32LE(0x06054b50, 0);
  end.writeUInt16LE(entries.length, 8);
  end.writeUInt16LE(entries.length, 10);
  end.writeUInt32LE(directory.length, 12);
  end.writeUInt32LE(offset, 16);
  const contents = Buffer.concat([...local, directory, end]);
  writeFileSync(resolve(OUT, filename), contents);
  return { filename, bytes: contents.length, files: entries.length,
    sha256: createHash("sha256").update(contents).digest("hex") };
}
function requireFile(path) {
  if (!existsSync(path) || !statSync(path).isFile()) throw new Error(`Missing release prerequisite: ${relative(ROOT, path)}`);
}
function noPrivateData(path, item) {
  const parts = normalize(path).split("/");
  if (parts.some(part => ["node_modules", ".git", "data", "storage", "test-results", "playwright-report", "artifacts", "dist", "deliverables"].includes(part))) return false;
  if (parts.at(-1) === "qa-report.json") return false;
  if (parts.some(part => /^\.env(?:\.|$)/.test(part) && part !== ".env.example")) return false;
  if (/\.(?:sqlite(?:-.*)?|log|pem|key|crt|tsbuildinfo)$/i.test(path)) return false;
  if (/^(?:private\/)/.test(path)) return item.isDirectory() || /(?:^|\/)(?:config\.example\.php|README\.md|\.gitignore|\.htaccess)$/.test(path);
  return true;
}

for (const path of ["index.html", "assets"]) {
  if (!existsSync(resolve(FRONTEND, path))) throw new Error("Run the frontend production build before packaging.");
}
for (const path of ["public/api/content.php", "public/api/subscribe.php", "public/admin/index.php", "private/config.example.php"]) requireFile(resolve(BACKEND, path));
requireFile(resolve(ROOT, "shared/editorial-content.json"));
requireFile(resolve(ROOT, "docs/NOTCH_HOSTING_GUIDE.md"));
mkdirSync(OUT, { recursive: true });

const frontend = walk(FRONTEND).filter(file => file.path !== ".htaccess");
frontend.push(entry(".htaccess", htaccess));
for (const file of frontend) {
  if (file.path.startsWith("admin/") || file.path.startsWith("api/") || file.path.endsWith(".php")) throw new Error(`Backend code leaked into frontend: ${file.path}`);
  if (file.path.endsWith(".js") && /demo-admin@rtr|Current administrator password|Publishing studio|Payment connections/.test(file.data.toString())) {
    throw new Error(`Legacy administrator interface leaked into public bundle: ${file.path}`);
  }
}
const backend = [];
for (const file of walk(resolve(BACKEND, "public"), "", noPrivateData)) backend.push(entry(`public_html/${file.path}`, file.data));
for (const name of ["app", "bin", "seed"]) {
  for (const file of walk(resolve(BACKEND, name), "", noPrivateData)) {
    if (name === "seed" && file.path === "editorial-content.json") continue;
    backend.push(entry(`rtr-backend/${name}/${file.path}`, file.data));
  }
}
for (const file of walk(resolve(BACKEND, "private"), "private", noPrivateData)) backend.push(entry(`rtr-backend/${file.path}`, file.data));
backend.push(entry("rtr-backend/seed/editorial-content.json", readFileSync(resolve(ROOT, "shared/editorial-content.json"))));
if (existsSync(resolve(BACKEND, "README.md"))) backend.push(entry("BACKEND_README.md", readFileSync(resolve(BACKEND, "README.md"))));
const guide = entry("UPLOAD_GUIDE.md", readFileSync(resolve(ROOT, "docs/NOTCH_HOSTING_GUIDE.md")));
const delivery = entry("DELIVERY_README.md", readFileSync(resolve(ROOT, "docs/NOTCH_DELIVERY.md")));
const source = [];
for (const name of ["frontend", "backend", "scripts"]) {
  for (const file of walk(resolve(ROOT, name), "", noPrivateData)) source.push(entry(`RTR_Digital_Notch_Source/${name}/${file.path}`, file.data));
}
for (const name of ["package-lock.json", "README.md", "README-commerce.md", ".gitignore", "LICENSE"]) {
  if (existsSync(resolve(ROOT, name))) source.push(entry(`RTR_Digital_Notch_Source/${name}`, readFileSync(resolve(ROOT, name))));
}
const sourcePackage = JSON.parse(readFileSync(resolve(ROOT, "package.json"), "utf8"));
for (const [name, command] of Object.entries(sourcePackage.scripts ?? {})) {
  const legacyTasks = {
    "dev:commerce": "dev", "dev:legacy": "dev", "build:commerce": "build", "build:legacy": "build",
    "start:commerce": "start", "start:legacy": "start", "test:commerce": "test", "test:legacy": "test",
    "test:e2e:legacy": "test:e2e", "test:e2e:commerce": "test:e2e",
  };
  if (legacyTasks[name]) sourcePackage.scripts[name] = `npm --prefix legacy-commerce run ${legacyTasks[name]}`;
  else if (name === "test" && command.includes("server/")) sourcePackage.scripts[name] = "npm --prefix legacy-commerce test";
  else if (name === "test:e2e" && command.includes("tests/e2e")) sourcePackage.scripts[name] = "npm --prefix legacy-commerce run test:e2e";
  else if (name === "check:legacy" || name === "check:commerce") sourcePackage.scripts[name] = "cd legacy-commerce && tsc -b";
}
source.push(entry("RTR_Digital_Notch_Source/package.json", JSON.stringify(sourcePackage, null, 2) + "\n"));
for (const file of walk(resolve(ROOT, "tests/notch"), "", noPrivateData)) source.push(entry(`RTR_Digital_Notch_Source/tests/notch/${file.path}`, file.data));
for (const name of ["NOTCH_HOSTING_GUIDE.md", "NOTCH_DELIVERY.md", "build_notch_guide.py"]) {
  if (existsSync(resolve(ROOT, "docs", name))) source.push(entry(`RTR_Digital_Notch_Source/docs/${name}`, readFileSync(resolve(ROOT, "docs", name))));
}
source.push(entry("RTR_Digital_Notch_Source/shared/editorial-content.json", readFileSync(resolve(ROOT, "shared/editorial-content.json"))));

// Keep the previous commerce application as a separate source reference, never web payload.
for (const name of ["src", "server", "public", "tests"]) {
  for (const file of walk(resolve(LEGACY, name), "", noPrivateData)) {
    if (name === "tests" && file.path.startsWith("notch/")) continue;
    source.push(entry(`RTR_Digital_Notch_Source/legacy-commerce/${name}/${file.path}`, file.data));
  }
}
for (const name of ["index.html", "tsconfig.json", "vite.config.ts", "playwright.config.ts", "Dockerfile", ".dockerignore", ".env.example"]) {
  if (existsSync(resolve(LEGACY, name))) source.push(entry(`RTR_Digital_Notch_Source/legacy-commerce/${name}`, readFileSync(resolve(LEGACY, name))));
}
for (const file of walk(resolve(LEGACY, "shared"), "", noPrivateData).filter(file => file.path !== "editorial-content.json")) source.push(entry(`RTR_Digital_Notch_Source/legacy-commerce/shared/${file.path}`, file.data));
const legacyPackage = existsSync(resolve(ROOT, "package-legacy-snapshot.json")) ? resolve(ROOT, "package-legacy-snapshot.json") : resolve(LEGACY, "package.json");
if (!existsSync(legacyPackage)) throw new Error("Missing the preserved legacy commerce package manifest.");
source.push(entry("RTR_Digital_Notch_Source/legacy-commerce/package.json", readFileSync(legacyPackage)));
const legacyLock = existsSync(resolve(ROOT, "package-lock-legacy-snapshot.json")) ? resolve(ROOT, "package-lock-legacy-snapshot.json") : resolve(LEGACY, "package-lock.json");
source.push(entry("RTR_Digital_Notch_Source/legacy-commerce/package-lock.json", readFileSync(legacyLock)));
source.push(entry("RTR_Digital_Notch_Source/legacy-commerce/README.md", `# Previous commerce application\n\nPreserved from the earlier RTR Digital delivery. This Node/SQLite commerce application is not the active Notch editorial frontend or PHP backend. It requires Node 24.2+ and persistent private storage; it cannot run on a PHP-only shared plan. From this folder use npm ci, npm run dev, npm run build and npm start. Keep its data and merchant secrets private. No live customer data, original uploads or encryption keys are included.\n`));

const outputs = [
  zip("RTR_Digital_Notch_Frontend.zip", frontend),
  zip("RTR_Digital_Notch_Backend.zip", [...backend, guide, delivery]),
  zip("RTR_Digital_Notch_Complete_Source.zip", source),
];
const combined = [
  ...frontend.map(file => entry(`frontend/${file.path}`, file.data)),
  ...backend.map(file => entry(`backend/${file.path}`, file.data)), guide, delivery,
];
const pdf = resolve(OUT, "RTR_Digital_Notch_Upload_Guide.pdf");
if (existsSync(pdf)) combined.push(entry("UPLOAD_GUIDE.pdf", readFileSync(pdf)));
outputs.push(zip("RTR_Digital_Notch_Hosting_Package.zip", combined));
if (existsSync(pdf)) outputs.push({ filename: "RTR_Digital_Notch_Upload_Guide.pdf", bytes: statSync(pdf).size,
  sha256: createHash("sha256").update(readFileSync(pdf)).digest("hex") });
writeFileSync(resolve(OUT, "RTR_Digital_Notch_SHA256SUMS.txt"), outputs.map(file => `${file.sha256}  ${file.filename}`).join("\n") + "\n");
writeFileSync(resolve(OUT, "notch-release-manifest.json"), JSON.stringify({ release: "RTR Digital Notch editorial edition", artifacts: outputs }, null, 2));
console.log(JSON.stringify(outputs, null, 2));
