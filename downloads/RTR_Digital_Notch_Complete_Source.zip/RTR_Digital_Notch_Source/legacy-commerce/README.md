# Previous commerce application

Preserved from the earlier RTR Digital delivery. This Node/SQLite commerce application is not the active Notch editorial frontend or PHP backend. It requires Node 24.2+ and persistent private storage; it cannot run on a PHP-only shared plan. From this folder use npm ci, npm run dev, npm run build and npm start. Keep its data and merchant secrets private. No live customer data, original uploads or encryption keys are included.
