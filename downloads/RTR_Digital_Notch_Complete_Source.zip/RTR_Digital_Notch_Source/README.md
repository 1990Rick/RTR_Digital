# RTR Digital — Notch editorial edition

The current public website is an editorial reading destination with **nine pages**: **RTR's Notch** (home), **About**, **Academics**, **Crime Thrillers/Novels**, **Fiction**, **Non-Fiction**, **Literature**, **Magazines**, and **Newsletters**.

The public frontend and content backend are separate. The frontend contains no administrator workspace, demonstration-admin sign-in or merchant settings. The private content workspace is reached separately at `/admin/` and requires its own owner account. This phase uses relevant sample texts and conceptual artwork for design review; actual publication content can replace those samples later.

## Current architecture

| Part | Source | Production destination |
| --- | --- | --- |
| Public React/Vite frontend | `frontend/` | Compiled `dist/frontend/` contents into the domain's public document root. |
| PHP editorial backend | `backend/` | Public `api`, `admin` and PHP bridge inside the public root; application/configuration/records in sibling private `rtr-backend`. |
| Initial editorial content | `shared/editorial-content.json` | Bundled into the frontend and supplied as the private backend seed. Saved admin edits supersede the initial seed. |
| Previous commerce application | Existing workspace `src/`, `server/`, old `public/`, `shared/catalog.json` | Preserved separately in source deliveries under `legacy-commerce/`; not activated by this PHP hosting package. |

The new PHP backend manages site/page/story copy and stores explicit newsletter-interest requests. It does not send email, process checkout, create customer libraries or connect merchant accounts. The earlier Node/SQLite commerce services remain available as separate source for a later integration; their administrator screens are not imported by the new public frontend.

## Run the current website locally

Use **Node 24 LTS** for project tooling. To run the backend locally, install **PHP 8.2+** or have Docker available for the helper's official PHP image fallback. No MySQL, SQLite or Composer installation is needed for this editorial backend.

```sh
npm ci
npm run dev
```

The combined command starts the PHP backend on **3002** and the new frontend on **5173**. Open `http://localhost:5173`. The Vite proxy forwards `/api` and `/admin` to the separate PHP backend. The first Docker fallback run may need internet access to fetch PHP's official image.

Do not double-click the compiled `index.html` to run the site locally. Browser `file://` module restrictions and the absent PHP server can break that approach. Use `npm run dev` from the complete source, or upload the compiled files as documented.

On PowerShell systems that block `npm.ps1`, use `npm.cmd ci` and `npm.cmd run dev`. Do not weaken the computer's execution policy simply to run the npm command shim.

If you want only the visual frontend, run `npm run dev:frontend`. For separately controlled terminals, use `npm run dev:backend` in one and `npm run dev:frontend` in another **instead of** the combined command. Do not start a second backend on an already occupied port. `npm run preview` serves the built frontend only; it does not start PHP.

### Create your local content administrator

1. The backend helper creates `backend/private/config.php` only when absent, using explicit development mode and a new random installation token. It supplies no account and no default password.
2. Read the token privately in that file. Never post it in screenshots or commit the file.
3. Open `http://localhost:3002/admin/`, enter the token, your email and a unique **12–72-character ASCII password**, and choose **Create administrator**.
4. Sign in with **Enter your workspace**. Setup is locked after the owner record exists.
5. Use **Editorial content** to select **Brand & global copy**, **The nine pages** or **Reading selections**. Edit plain text and choose **Publish changes**; refresh the public website to load the update.
6. **Newsletter requests** lists genuinely stored consented form submissions. **Download CSV** exports them; **Remove** deletes a chosen request after confirmation. No email or campaign is sent.
7. **Account & security** changes the password after verifying the current password. Sign out when finished.

Use a separate fresh configuration and private directory for production. Never upload the generated local development configuration, test owner account or subscriber records as a live installation.

## Build and package

```sh
npm run build
node scripts/package-notch.mjs
```

`npm run build` type-checks and compiles the **new frontend** into `dist/frontend`. The pure-Node packaging script then creates clearly separated delivery ZIPs without private configuration, customer/subscriber records, `node_modules`, encryption keys or Git history.

The optional PDF version of the upload guide is generated with `python docs/build_notch_guide.py` when Python, ReportLab and the documented system fonts are available. Packaging always includes the Markdown guide and includes the PDF in the combined archive when it exists.

| Artifact in `deliverables/` | Use |
| --- | --- |
| `RTR_Digital_Notch_Frontend.zip` | Public-root upload contents only. |
| `RTR_Digital_Notch_Backend.zip` | Public PHP entry points plus the separate private backend tree. |
| `RTR_Digital_Notch_Hosting_Package.zip` | Frontend/backend trees together with upload instructions. |
| `RTR_Digital_Notch_Complete_Source.zip` | Editable current source and separately preserved old commerce source. |
| `RTR_Digital_Notch_Upload_Guide.pdf` | Step-by-step hosting instructions, when generated. |
| `RTR_Digital_Notch_SHA256SUMS.txt` | Hashes for verifying the packaged artifacts. |

The complete source archive preserves the older commerce application under `legacy-commerce/`. Its legacy script wrappers are adjusted for that archive layout. Keep complete source out of your public document root.

## Host on GoDaddy or Hostinger

Use a compatible **Linux PHP 8.2+ plan** with HTTPS, writable private storage outside the public root, and Apache/LiteSpeed rewrite support. No Node process is required on that host for this phase. A static-only or Windows/ASP-only plan is not equivalent to PHP hosting, and plan capabilities must be checked in the actual account.

```text
account-or-domain-home/
├── public_html/                 compiled public frontend
│   ├── index.html
│   ├── .htaccess
│   ├── assets/
│   ├── images/
│   ├── api/
│   ├── admin/
│   └── rtr-bootstrap.php
└── rtr-backend/                 outside the public web root
    ├── app/
    ├── bin/
    ├── seed/
    └── private/
        ├── config.example.php
        └── config.php          owner creates this privately
```

1. Upload/extract the frontend contents directly into the domain's actual `public_html` or equivalent root.
2. Place the backend's public files into that same root and its private `rtr-backend` folder immediately beside the root, not inside it.
3. Copy the private `config.example.php` to `config.php`; supply your own random setup token of at least 32 characters and the final HTTPS `public_url`. Keep production mode and do not enable proxy trust without verification.
4. Open your domain's `/admin/`, create the owner account with that private token, then sign in. The public navigation intentionally supplies no admin link.
5. Test all nine page addresses by refreshing them directly, save a content change, test a consented newsletter submission, and make a protected backup before announcing launch.

Read [the full upload guide](docs/NOTCH_HOSTING_GUIDE.md) for cPanel/hPanel steps, hidden `.htaccess` files, runtime settings, directory mapping, backups and troubleshooting. Read [backend documentation](backend/README.md) for configuration, endpoints, account recovery and security boundaries.

## Editing the current design and copy

- `frontend/src/App.tsx`: public shell, page routing, search, saved reading and excerpt dialogs.
- `frontend/src/pages/`: homepage, category layouts, About and Newsletters.
- `frontend/src/styles.css` and page CSS: typography, responsive layout, motion and visual treatments.
- `frontend/public/images/`: current artwork with descriptions in `ARTWORK.md`.
- `shared/editorial-content.json`: initial sample pages and reading selections.
- `backend/public/admin/`: separate protected content-management screen and its assets.
- `backend/app/`: validated PHP API and private-record handling.

An administrator edit changes stored content without a frontend build. A React/CSS change requires a new build and public-file deployment. Uploading a fresh seed does not intentionally replace installed saved content. Preserve `backend/private` during development and the live private `rtr-backend/private` directory during deployment.

## Verification commands

```sh
npm run build
npm run test:backend
npm run test:notch
```

The backend smoke suite uses an isolated temporary private directory and PHP/Docker. Browser checks require the installed Playwright/Chromium prerequisites and the current test runner's documented environment. These application checks do not establish that your domain, hosting account, email provider or live commerce configuration has been provisioned.

## Earlier commerce work

The previous commerce README is preserved as [README-commerce.md](README-commerce.md) in this workspace. The current workspace's `dev:commerce`, `build:commerce`, `start:commerce` and commerce checks refer to that earlier Node/SQLite application; they are separate from the editorial shared-hosting release. Do not use them to start the current public website. The retained commerce application requires Node 24.2+ and durable private storage and cannot run on PHP-only shared hosting.

No real bank link, live payment, delivery campaign or hosting purchase is created by this source delivery. Sample excerpts and conceptual images demonstrate the design and interactions for the owner's future content.
