"""Render the current Notch hosting guide, requiring reportlab and DejaVu fonts."""
from pathlib import Path
import re
from xml.sax.saxutils import escape

from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import BaseDocTemplate, Frame, KeepTogether, LongTable, PageBreak, PageTemplate, Paragraph, Preformatted, Spacer, TableStyle
from reportlab.platypus.tableofcontents import TableOfContents

ROOT = Path(__file__).resolve().parent.parent
SOURCE = ROOT / "docs/NOTCH_HOSTING_GUIDE.md"
OUTPUT = ROOT / "deliverables/RTR_Digital_Notch_Upload_Guide.pdf"
W, H = A4
M = 49
CW = W - M * 2
INK = colors.HexColor("#20231f")
PAPER = colors.HexColor("#f7f4ec")
RED = colors.HexColor("#d7472f")
GREEN = colors.HexColor("#304b3e")
MUTED = colors.HexColor("#5d665e")
FONTS = Path("/usr/share/fonts/truetype/dejavu")
for name, filename in [("Notch", "DejaVuSans.ttf"), ("NotchBold", "DejaVuSans-Bold.ttf"), ("NotchMono", "DejaVuSansMono.ttf"), ("NotchSerif", "DejaVuSerif.ttf")]:
    pdfmetrics.registerFont(TTFont(name, str(FONTS / filename)))
pdfmetrics.registerFontFamily("Notch", normal="Notch", bold="NotchBold")
S = {
    "body": ParagraphStyle("Body", fontName="Notch", fontSize=9.5, leading=14.7, spaceAfter=9, textColor=INK, allowWidows=0, allowOrphans=0),
    "step": ParagraphStyle("Step", fontName="Notch", fontSize=9.5, leading=14.7, leftIndent=17, firstLineIndent=-17, spaceAfter=7, textColor=INK, allowWidows=0, allowOrphans=0),
    "h1": ParagraphStyle("MainTitle", fontName="NotchBold", fontSize=25, leading=32, spaceAfter=18, textColor=INK, keepWithNext=True),
    "h2": ParagraphStyle("Heading", fontName="NotchBold", fontSize=14.2, leading=19, spaceBefore=17, spaceAfter=10, textColor=GREEN, keepWithNext=True),
    "h3": ParagraphStyle("SmallHeading", fontName="NotchBold", fontSize=10.8, leading=16, spaceBefore=11, spaceAfter=7, textColor=INK, keepWithNext=True),
    "cell": ParagraphStyle("Cell", fontName="Notch", fontSize=8.1, leading=12, textColor=INK),
    "headcell": ParagraphStyle("HeadCell", fontName="NotchBold", fontSize=8.1, leading=12, textColor=INK),
    "code": ParagraphStyle("Code", fontName="NotchMono", fontSize=7.7, leading=11.5, spaceBefore=7, spaceAfter=13, backColor=colors.HexColor("#ecece2"), borderPadding=8, textColor=INK),
    "eyebrow": ParagraphStyle("Eyebrow", fontName="NotchBold", fontSize=8.8, leading=14, textColor=RED, spaceAfter=13),
    "cover": ParagraphStyle("Cover", fontName="NotchSerif", fontSize=37, leading=45, textColor=INK, spaceAfter=22),
    "lead": ParagraphStyle("Lead", fontName="Notch", fontSize=12, leading=19, textColor=MUTED, spaceAfter=16),
}


def inline(text):
    stashed = []
    def code(m):
        stashed.append('<font name="NotchMono" size="8.25">' + escape(m[1]) + '</font>')
        return f"STASH{len(stashed)-1}END"
    text = re.sub(r"`([^`]+)`", code, text)
    text = escape(text)
    text = re.sub(r"\*\*(.+?)\*\*", r"<b>\1</b>", text)
    for i, html in enumerate(stashed):
        text = text.replace(f"STASH{i}END", html)
    return text


class Guide(BaseDocTemplate):
    def __init__(self):
        super().__init__(str(OUTPUT), pagesize=A4, leftMargin=M, rightMargin=M, topMargin=78, bottomMargin=59, title="RTR Digital Notch — Hosting and Upload Guide", author="RTR Digital", subject="Separate public frontend and PHP content backend; GoDaddy and Hostinger deployment")
        self.section = "Hosting and upload guide"
        self.addPageTemplates(PageTemplate(id="guide", frames=[Frame(M, 59, CW, H-137, leftPadding=0, rightPadding=0, topPadding=0, bottomPadding=0)], onPage=self.background, onPageEnd=self.furniture))

    def beforeDocument(self):
        self.section = "Hosting and upload guide"

    def background(self, c, doc):
        c.saveState(); c.setFillColor(PAPER); c.rect(0, 0, W, H, fill=1, stroke=0); c.restoreState()

    def furniture(self, c, doc):
        c.saveState(); c.setFillColor(RED); c.rect(M, H-49, 15, 19, fill=1, stroke=0)
        c.setFont("NotchBold", 10.2); c.setFillColor(INK); c.drawString(M+24, H-43, "RTR Digital")
        c.setFont("Notch", 7.1); c.setFillColor(MUTED); c.drawRightString(W-M, H-43, "NOTCH EDITORIAL EDITION")
        c.setStrokeColor(colors.HexColor("#d8d8ca")); c.line(M, 43, W-M, 43)
        c.setFont("Notch", 7); c.drawString(M, 28, "PUBLIC FRONTEND / PRIVATE CONTENT BACKEND")
        c.drawRightString(W-M, 28, str(doc.page)); c.restoreState()

    def afterFlowable(self, flowable):
        if hasattr(flowable, "_guide_heading"):
            text, key = flowable._guide_heading
            self.canv.bookmarkPage(key, fit="XYZ", left=0, top=min(H-65, self.frame._y+flowable.height+flowable.getSpaceAfter()+4), zoom=0)
            self.canv.addOutlineEntry(text, key, level=0, closed=False)
            self.notify("TOCEntry", (0, escape(text), self.page, key))


def parse(text):
    result, paragraph = [], []
    lines, i, heading = text.splitlines(), 0, 0
    def flush():
        if paragraph:
            result.append(Paragraph(inline(" ".join(paragraph)), S["body"])); paragraph.clear()
    while i < len(lines):
        line = lines[i]; i += 1
        if line.startswith("# "):
            continue
        if line.startswith("```"):
            flush(); code = []
            while i < len(lines) and not lines[i].startswith("```"):
                code.append(lines[i]); i += 1
            i += 1
            result.append(KeepTogether([Preformatted("\n".join(code), S["code"])])); continue
        if line.startswith("|"):
            flush(); rows = [line]
            while i < len(lines) and lines[i].startswith("|"):
                rows.append(lines[i]); i += 1
            data = []
            for row in rows:
                if re.match(r"^\|[\s:|\-]+\|\s*$", row): continue
                data.append([value.strip() for value in row.strip().strip("|").split("|")])
            n = len(data[0]); ratios = [.29, .39, .32] if n == 3 else [.29, .71]
            cells = [[Paragraph(inline(cell), S["headcell"] if j == 0 else S["cell"]) for cell in row] for j, row in enumerate(data)]
            table = LongTable(cells, colWidths=[CW*f for f in ratios], repeatRows=1, hAlign="LEFT")
            table.setStyle(TableStyle([("BACKGROUND",(0,0),(-1,0),colors.HexColor("#dfe7dc")), ("ROWBACKGROUNDS",(0,1),(-1,-1),[PAPER,colors.HexColor("#f0f0e7")]), ("VALIGN",(0,0),(-1,-1),"TOP"), ("LEFTPADDING",(0,0),(-1,-1),7), ("RIGHTPADDING",(0,0),(-1,-1),7), ("TOPPADDING",(0,0),(-1,-1),7), ("BOTTOMPADDING",(0,0),(-1,-1),7)]))
            result.extend([table, Spacer(1,11)]); continue
        if line.startswith("## "):
            flush(); heading += 1; title = line[3:]
            p = Paragraph(inline(title), S["h2"]); p._guide_heading = (title, f"section-{heading}")
            result.append(p); continue
        if line.startswith("### "):
            flush(); result.append(Paragraph(inline(line[4:]), S["h3"])); continue
        if not line.strip(): flush(); continue
        if re.match(r"^\d+\. ", line):
            flush(); result.append(Paragraph(inline(line), S["step"])); continue
        paragraph.append(line.strip())
    flush(); return result


def build():
    OUTPUT.parent.mkdir(exist_ok=True)
    toc = TableOfContents(); toc.levelStyles = [ParagraphStyle("TOC", fontName="Notch", fontSize=9.2, leading=14.2, spaceBefore=5, spaceAfter=5, textColor=INK)]
    story = [Spacer(1,75), Paragraph("YOUR UPLOAD COMPANION", S["eyebrow"]), Paragraph("From files<br/>to your domain.", S["cover"]), Paragraph("A practical guide to publishing RTR Digital’s new editorial website on compatible GoDaddy or Hostinger PHP hosting.", S["lead"]), Spacer(1,22), Paragraph("Frontend. Backend.<br/>Clearly separated.", S["h1"]), Paragraph("Nine public pages, one protected content workspace, and private persistent records outside the public web folder. Includes directory maps, first administrator setup, updates and troubleshooting.", S["body"]), Spacer(1,23), Paragraph("Use this guide for the Notch editorial edition. The previous Node commerce application is preserved separately and is not deployed by this shared-hosting package.", S["body"]), PageBreak(), Paragraph("Find your next step.", S["h1"]), toc, PageBreak()]
    story.extend(parse(SOURCE.read_text()))
    doc = Guide(); doc.multiBuild(story)
    print(f"{OUTPUT} — {doc.page} pages")


if __name__ == "__main__": build()
