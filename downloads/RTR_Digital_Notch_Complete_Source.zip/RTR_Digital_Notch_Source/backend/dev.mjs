import { existsSync, mkdirSync, writeFileSync } from 'node:fs';
import { randomBytes } from 'node:crypto';
import { dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { spawn, spawnSync } from 'node:child_process';

const root = dirname(fileURLToPath(import.meta.url));
const privateDir = resolve(process.env.RTR_PRIVATE_DIR || resolve(root, 'private'));
mkdirSync(privateDir, { recursive: true, mode: 0o700 });
const configFile = resolve(privateDir, 'config.php');
if (!existsSync(configFile)) {
  const token = randomBytes(32).toString('hex');
  writeFileSync(configFile, `<?php\nreturn [\n  'environment' => 'development',\n  'setup_token' => '${token}',\n  'public_url' => 'http://localhost:5173',\n  'trust_proxy_https' => false,\n];\n`, { mode: 0o600, flag: 'wx' });
  console.log('Created a private DEVELOPMENT configuration. Read its setup token in backend/private/config.php when creating your administrator.');
}
const port = process.env.RTR_BACKEND_PORT || '3002';
const native = process.env.PHP_EXECUTABLE || 'php';
const available = spawnSync(native, ['--version'], { stdio: 'ignore' }).status === 0;
let command = native;
let args = ['-S', `0.0.0.0:${port}`, '-t', resolve(root, 'public')];
if (!available) {
  const docker = spawnSync('docker', ['version', '--format', '{{.Server.Version}}'], { stdio: 'ignore' });
  if (docker.status !== 0) {
    console.error('PHP 8.2+ is required. Install PHP and put it on PATH, set PHP_EXECUTABLE, or start Docker. See backend/README.md.');
    process.exit(1);
  }
  command = 'docker';
  args = ['run', '--rm', '--init', '--name', `rtr-editorial-dev-${process.pid}`, '-p', `${port}:3002`,
    '--mount', `type=bind,src=${dirname(root)},dst=/workspace/rtr`,
    '--mount', `type=bind,src=${privateDir},dst=/rtr-private`,
    '-e', 'RTR_ENV=development', '-e', 'RTR_PRIVATE_DIR=/rtr-private',
    '-w', '/workspace/rtr', 'php:8.3-cli-alpine', 'php', '-S', '0.0.0.0:3002', '-t', 'backend/public'];
  if (process.getuid && process.getgid) args.splice(2, 0, '--user', `${process.getuid()}:${process.getgid()}`);
  console.log('Using the PHP 8.3 Docker development fallback. The first run may download the official PHP image.');
}
console.log(`Editorial PHP backend: http://localhost:${port}; private administration: http://localhost:${port}/admin/`);
const child = spawn(command, args, { stdio: 'inherit', env: { ...process.env, RTR_ENV: 'development', RTR_PRIVATE_DIR: privateDir } });
for (const signal of ['SIGINT', 'SIGTERM']) process.on(signal, () => {
  if (command === 'docker') spawnSync('docker', ['stop', '--time', '3', `rtr-editorial-dev-${process.pid}`], { stdio: 'ignore' });
  child.kill(signal);
});
child.on('error', error => { console.error(error.message); process.exitCode = 1; });
child.on('exit', (code, signal) => { if (signal) process.exit(0); process.exit(code ?? 1); });
