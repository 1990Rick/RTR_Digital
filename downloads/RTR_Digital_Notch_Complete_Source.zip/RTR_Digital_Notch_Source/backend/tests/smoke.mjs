import assert from 'node:assert/strict';
import { randomBytes } from 'node:crypto';
import { mkdtempSync, writeFileSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { spawn, spawnSync } from 'node:child_process';

const root = resolve(dirname(fileURLToPath(import.meta.url)), '../..');
const temporary = mkdtempSync(resolve(tmpdir(), 'rtr-php-smoke-'));
const token = randomBytes(32).toString('hex');
const password = randomBytes(24).toString('hex');
const port = 23000 + Math.floor(Math.random()*15000);
const origin = `http://127.0.0.1:${port}`;
writeFileSync(resolve(temporary, 'config.php'), `<?php return ['environment'=>'development','setup_token'=>'${token}','public_url'=>'${origin}'];`, {mode:0o600});
const native = process.env.PHP_EXECUTABLE || 'php';
const havePHP = spawnSync(native, ['--version'], {stdio:'ignore'}).status === 0;
const name = `rtr-php-test-${process.pid}`;
const dockerArgs = ['run','--rm','--name',name,'-p',`${port}:3002`,
  '--mount',`type=bind,src=${root},dst=/app,readonly`,
  '--mount',`type=bind,src=${temporary},dst=/private`,
  '-e','RTR_ENV=development','-e','RTR_PRIVATE_DIR=/private',
  'php:8.3-cli-alpine','php','-S','0.0.0.0:3002','-t','/app/backend/public'];
if (process.getuid && process.getgid) dockerArgs.splice(2,0,'--user',`${process.getuid()}:${process.getgid()}`);
let serverOutput='';
const child = havePHP
  ? spawn(native,['-S',`127.0.0.1:${port}`,'-t',resolve(root,'backend/public')],{env:{...process.env,RTR_ENV:'development',RTR_PRIVATE_DIR:temporary},stdio:['ignore','pipe','pipe']})
  : spawn('docker',dockerArgs,{stdio:['ignore','pipe','pipe']});
child.stdout.on('data',d=>{serverOutput+=d});child.stderr.on('data',d=>{serverOutput+=d});
const cookies=new Map();
async function call(path, {method='GET',body,csrf,withOrigin=true,raw=false}={}) {
  const headers={}; if(body!==undefined)headers['Content-Type']='application/json';
  if(cookies.size)headers.Cookie=[...cookies].map(([k,v])=>`${k}=${v}`).join('; ');
  if(csrf)headers['X-CSRF-Token']=csrf;
  if(method!=='GET'&&withOrigin)headers.Origin=typeof withOrigin==='string'?withOrigin:origin;
  const response=await fetch(origin+path,{method,headers,...(body!==undefined?{body:JSON.stringify(body)}:{})});
  for(const cookie of response.headers.getSetCookie()){
    const pair=cookie.split(';',1)[0];const at=pair.indexOf('=');cookies.set(pair.slice(0,at),pair.slice(at+1));
  }
  return {response,status:response.status,data:raw?await response.text():await response.json()};
}
let count=0;const check=(condition,message)=>{assert.ok(condition,message);count++};
try {
  let ready=false;
  for(let i=0;i<100;i++){
    try{const r=await fetch(origin+'/api/content.php');if(r.status===200){ready=true;break}}catch{}
    await new Promise(r=>setTimeout(r,150));
  }
  assert.ok(ready,'PHP server did not become ready: '+serverOutput.slice(-1800));
  let result=await call('/api/content.php');check(result.status===200&&result.data.content.pages.length===9,'Public content has nine pages');
  check(result.data.content.entries.length===24,'Public content has 24 sample readings');
  result=await call('/admin/api.php?action=content');check(result.status===401,'Unauthenticated content administration blocked');
  result=await call('/admin/api.php?action=session');let csrf=result.data.csrf;
  check(result.data.configured&&!result.data.installed&&!result.data.user,'Private setup state is correct');
  result=await call('/admin/api.php?action=install',{method:'POST',body:{token,email:'editor@example.test',password}});check(result.status===403,'Installer requires CSRF');
  result=await call('/admin/api.php?action=install',{method:'POST',csrf,body:{token:'wrong',email:'editor@example.test',password}});check(result.status===403&&result.data.error.includes('setup token'),'Installer requires private token');
  result=await call('/admin/api.php?action=install',{method:'POST',csrf,body:{token,email:'editor@example.test',password}});check(result.status===200,'Owner setup succeeds with token');
  result=await call('/admin/api.php?action=session');csrf=result.data.csrf;check(result.data.installed&&!result.data.user,'Setup requires explicit sign-in');
  result=await call('/admin/api.php?action=install',{method:'POST',csrf,body:{token,email:'other@example.test',password}});check(result.status===409,'Installer locks after creation');
  result=await call('/admin/api.php?action=login',{method:'POST',csrf,body:{email:'editor@example.test',password:'wrong'}});check(result.status===401,'Wrong password rejected');
  result=await call('/admin/api.php?action=login',{method:'POST',csrf,body:{email:'editor@example.test',password}});check(result.status===200,'Owner login succeeds');
  result=await call('/admin/api.php?action=session');csrf=result.data.csrf;check(result.data.user?.email==='editor@example.test','Authenticated session confirmed');
  result=await call('/admin/api.php?action=content');const original=result.data.content;const revision=result.data.revision;
  const changed=structuredClone(original);changed.pages[0].description='A deliberately changed editorial description for the isolated PHP test.';
  result=await call('/admin/api.php?action=content',{method:'POST',body:{content:changed,revision}});check(result.status===403,'Content mutations require CSRF');
  result=await call('/admin/api.php?action=content',{method:'POST',csrf,withOrigin:'https://evil.example',body:{content:changed,revision}});check(result.status===403,'Foreign origins cannot mutate content');
  const wrongID=structuredClone(changed);wrongID.pages[0].id='attacker-route';
  result=await call('/admin/api.php?action=content',{method:'POST',csrf,body:{content:wrongID,revision}});check(result.status===422,'Immutable content routes validated');
  const html=structuredClone(changed);html.pages[0].title='<script>alert(1)</script>';
  result=await call('/admin/api.php?action=content',{method:'POST',csrf,body:{content:html,revision}});check(result.status===422,'HTML injection rejected');
  result=await call('/admin/api.php?action=content',{method:'POST',csrf,body:{content:changed,revision}});check(result.status===200&&result.data.revision===1,'Content publish increments revision');
  result=await call('/api/content.php');check(result.data.content.pages[0].description===changed.pages[0].description,'Published changes reach public API');
  result=await call('/admin/api.php?action=content',{method:'POST',csrf,body:{content:changed,revision}});check(result.status===409,'Stale updates cannot overwrite newer content');
  result=await call('/api/subscribe.php',{method:'POST',body:{email:'reader@example.test',topics:['literature'],consent:false}});check(result.status===422,'Newsletter consent is required');
  result=await call('/api/subscribe.php',{method:'POST',body:{email:'bad-email',topics:['literature'],consent:true}});check(result.status===422,'Newsletter email validation works');
  result=await call('/api/subscribe.php',{method:'POST',body:{email:'reader@example.test',topics:['literature'],consent:true}});check(result.status===200&&result.data.ok,'Newsletter request is really stored');
  result=await call('/api/subscribe.php',{method:'POST',body:{email:'reader@example.test',topics:['literature'],consent:true}});check(result.status===200,'Duplicate signup has same response');
  result=await call('/admin/api.php?action=subscribers');check(result.data.subscribers.length===1,'Duplicate signup does not duplicate private subscriber');
  result=await call('/admin/api.php?action=export',{method:'POST',csrf,raw:true});check(result.status===200&&result.data.includes('reader@example.test'),'Authenticated CSV export works');
  result=await call('/admin/api.php?action=delete-subscriber',{method:'POST',csrf,body:{email:'reader@example.test'}});check(result.status===200,'Owner can remove newsletter request');
  result=await call('/admin/api.php?action=subscribers');check(result.data.subscribers.length===0,'Removed request no longer appears');
  const newPassword=randomBytes(24).toString('hex');
  result=await call('/admin/api.php?action=password',{method:'POST',csrf,body:{currentPassword:password,password:newPassword}});check(result.status===200,'Password change verifies and updates account');
  result=await call('/admin/api.php?action=logout',{method:'POST',csrf,body:{}});check(result.status===200,'Logout succeeds');
  result=await call('/admin/api.php?action=content');check(result.status===401,'Logout removes private access');
  result=await call('/admin/api.php?action=session');csrf=result.data.csrf;
  result=await call('/admin/api.php?action=login',{method:'POST',csrf,body:{email:'editor@example.test',password}});check(result.status===401,'Old password is invalid after change');
  result=await call('/admin/api.php?action=login',{method:'POST',csrf,body:{email:'editor@example.test',password:newPassword}});check(result.status===200,'New password signs in');
  for(let i=0;i<6;i++)await call('/api/subscribe.php',{method:'POST',body:{email:`reader${i}@example.test`,topics:['fiction'],consent:true}});
  result=await call('/api/subscribe.php',{method:'POST',body:{email:'limited@example.test',topics:['fiction'],consent:true}});check(result.status===429,'Public newsletter requests are rate limited');
  console.log(JSON.stringify({status:'passed',checks:count,php:'native PHP or official PHP 8.3 container',data:'isolated temporary private directory; no real accounts or mail'},null,2));
} finally {
  if(!havePHP)spawnSync('docker',['stop','--time','2',name],{stdio:'ignore'});
  child.kill('SIGTERM');rmSync(temporary,{recursive:true,force:true});
}
