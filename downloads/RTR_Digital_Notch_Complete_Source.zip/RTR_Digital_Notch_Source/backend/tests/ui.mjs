import assert from 'node:assert/strict';
import { randomBytes } from 'node:crypto';
import { mkdtempSync, readFileSync, rmSync, mkdirSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { spawn } from 'node:child_process';
import { chromium } from '@playwright/test';

const root=resolve(dirname(fileURLToPath(import.meta.url)),'../..');
const privateDir=mkdtempSync(resolve(tmpdir(),'rtr-admin-ui-'));
const port=39000+Math.floor(Math.random()*10000);const base=`http://127.0.0.1:${port}`;
const child=spawn(process.execPath,[resolve(root,'backend/dev.mjs')],{cwd:root,env:{...process.env,RTR_PRIVATE_DIR:privateDir,RTR_BACKEND_PORT:String(port)},stdio:['ignore','pipe','pipe']});
let logs='';child.stdout.on('data',d=>{logs+=d});child.stderr.on('data',d=>{logs+=d});
let browser;
try{
  let ready=false;for(let i=0;i<120;i++){try{const r=await fetch(base+'/api/content.php');if(r.status===200){ready=true;break}}catch{}await new Promise(r=>setTimeout(r,150))}
  assert.ok(ready,'PHP UI server failed to start: '+logs.slice(-1600));
  const config=readFileSync(resolve(privateDir,'config.php'),'utf8');const token=config.match(/'setup_token' => '([^']+)'/)[1];
  const password=randomBytes(24).toString('hex');
  browser=await chromium.launch({headless:true,executablePath:process.env.PLAYWRIGHT_CHROMIUM_EXECUTABLE||'/usr/bin/chromium',args:['--no-sandbox']});
  const page=await browser.newPage({viewport:{width:1440,height:1000},acceptDownloads:true});const errors=[];
  page.on('pageerror',e=>errors.push(e.message));
  await page.goto(base+'/admin/');
  await page.getByLabel('Private setup token').fill(token);await page.getByLabel('Administrator email').fill('editor-ui@example.test');await page.getByLabel('Choose a password').fill(password);
  await page.getByRole('button',{name:'Create administrator'}).click();
  await page.getByLabel('Email address',{exact:true}).fill('editor-ui@example.test');await page.getByLabel('Password',{exact:true}).fill(password);
  await page.getByRole('button',{name:'Enter your workspace'}).click();
  await page.getByRole('button',{name:'Publish changes'}).waitFor({state:'visible'});
  await page.getByLabel('WHAT WOULD YOU LIKE TO EDIT?').selectOption('pages');
  await page.getByLabel('Description',{exact:true}).fill('A careful browser-verified change in an isolated editorial backend.');
  await page.getByRole('button',{name:'Publish changes'}).click();
  await page.getByRole('status').filter({hasText:'Your editorial changes are published'}).waitFor();
  const content=await (await fetch(base+'/api/content.php')).json();assert.equal(content.content.pages[0].description,'A careful browser-verified change in an isolated editorial backend.');
  const out=resolve(root,'backend/tests/artifacts');mkdirSync(out,{recursive:true});
  await page.screenshot({path:resolve(out,'rtr-private-editorial-desktop.png'),fullPage:false});
  const signed=await fetch(base+'/api/subscribe.php',{method:'POST',headers:{'Content-Type':'application/json',Origin:base},body:JSON.stringify({email:'consented-reader@example.test',topics:['literature'],consent:true})});assert.equal(signed.status,200);
  await page.getByRole('button',{name:/Newsletter requests/}).click();
  await page.getByRole('cell',{name:'consented-reader@example.test',exact:true}).waitFor();
  const downloaded=page.waitForEvent('download');await page.getByRole('button',{name:'Download CSV'}).click();const download=await downloaded;assert.match(readFileSync(await download.path(),'utf8'),/consented-reader@example\.test/);
  page.once('dialog',d=>d.accept());await page.getByRole('button',{name:'Remove newsletter request for consented-reader@example.test'}).click();
  await page.getByRole('heading',{name:'Every conversation starts somewhere.'}).waitFor();
  await page.setViewportSize({width:390,height:844});await page.getByRole('button',{name:/Editorial content/}).click();
  await page.screenshot({path:resolve(out,'rtr-private-editorial-mobile.png'),fullPage:false});
  const overflow=await page.evaluate(()=>({width:innerWidth,scroll:document.documentElement.scrollWidth,elements:[...document.querySelectorAll('body *')].filter(e=>e.getBoundingClientRect().right>innerWidth+1&&getComputedStyle(e).position!=='fixed').slice(0,8).map(e=>({tag:e.tagName,class:e.className,right:e.getBoundingClientRect().right}))}));
  assert.ok(overflow.scroll<=overflow.width+1,'Backend mobile layout overflows: '+JSON.stringify(overflow));
  await page.getByRole('button',{name:'Sign out'}).click();await page.getByRole('button',{name:'Enter your workspace'}).waitFor();
  assert.deepEqual(errors,[],'Backend JS errors');
  console.log(JSON.stringify({status:'passed',journeys:['private installer','owner login','page editing','publish reaches public API','newsletter review','CSV download','request removal','mobile layout','sign out'],screenshots:2,jsErrors:0},null,2));
}finally{
  if(browser)await browser.close();child.kill('SIGTERM');await new Promise(r=>child.once('exit',r));rmSync(privateDir,{recursive:true,force:true});
}
