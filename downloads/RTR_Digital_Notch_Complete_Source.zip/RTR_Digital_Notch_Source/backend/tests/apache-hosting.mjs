/** Test the REAL delivery ZIPs on PHP/Apache with HTTPS and sibling private storage. */
import assert from 'node:assert/strict';
import { mkdtempSync, readFileSync, writeFileSync, mkdirSync, readdirSync, chmodSync, renameSync, rmSync } from 'node:fs';
import { randomBytes, createHash } from 'node:crypto';
import { tmpdir } from 'node:os';
import { dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { spawn, spawnSync } from 'node:child_process';
import https from 'node:https';
import http from 'node:http';

const root=resolve(dirname(fileURLToPath(import.meta.url)),'../..');
const temp=mkdtempSync(resolve(tmpdir(),'rtr-apache-hosting-'));
const httpsPort=45000+Math.floor(Math.random()*7000),httpPort=httpsPort+7000;
const origin=`https://127.0.0.1:${httpsPort}`;
const name=`rtr-apache-hosting-${process.pid}`;
const token=randomBytes(32).toString('hex'),password=randomBytes(24).toString('hex');
const frontendZip=resolve(root,'deliverables/RTR_Digital_Notch_Frontend.zip');
const backendZip=resolve(root,'deliverables/RTR_Digital_Notch_Backend.zip');
let container,logs='',checks=0;const check=(ok,message)=>{assert.ok(ok,message);checks++};
function run(command,args){const r=spawnSync(command,args,{encoding:'utf8'});if(r.status!==0)throw new Error(`${command} failed: ${r.stderr}`);return r.stdout}
function readable(path){for(const entry of readdirSync(path,{withFileTypes:true})){const p=resolve(path,entry.name);chmodSync(p,entry.isDirectory()?0o755:0o644);if(entry.isDirectory())readable(p)}}
function call(path,{method='GET',body,rawBody,cookies=new Map(),csrf,secure=true,customOrigin}={}){
 return new Promise((done,reject)=>{
  const content=rawBody!==undefined?rawBody:body!==undefined?JSON.stringify(body):undefined;
  const headers={};if(content!==undefined){headers['Content-Type']='application/json';headers['Content-Length']=Buffer.byteLength(content)}
  if(method!=='GET')headers.Origin=customOrigin||origin;if(csrf)headers['X-CSRF-Token']=csrf;
  if(cookies.size)headers.Cookie=[...cookies].map(([k,v])=>`${k}=${v}`).join('; ');
  const client=secure?https:http;
  const req=client.request({hostname:'127.0.0.1',port:secure?httpsPort:httpPort,path,method,headers,...(secure?{rejectUnauthorized:false}:{})},res=>{
   const chunks=[];res.on('data',c=>chunks.push(c));res.on('end',()=>{
    for(const cookie of res.headers['set-cookie']||[]){const pair=cookie.split(';',1)[0],at=pair.indexOf('=');cookies.set(pair.slice(0,at),pair.slice(at+1))}
    const text=Buffer.concat(chunks).toString('utf8');let data;try{data=JSON.parse(text)}catch{}
    done({status:res.statusCode,headers:res.headers,text,data});
   });
  });req.on('error',reject);req.setTimeout(6000,()=>req.destroy(new Error('Local Apache request timed out')));if(content!==undefined)req.write(content);req.end();
 });
}
try{
 mkdirSync(resolve(temp,'public_html'));run('unzip',['-q',frontendZip,'-d',resolve(temp,'public_html')]);
 run('unzip',['-q',backendZip,'-d',temp]);renameSync(resolve(temp,'public_html'),resolve(temp,'html'));
 readable(temp);chmodSync(temp,0o755);const privateDir=resolve(temp,'rtr-backend/private');chmodSync(privateDir,0o700);
 writeFileSync(resolve(privateDir,'config.php'),`<?php return ['environment'=>'production','setup_token'=>'${token}','public_url'=>'${origin}','trust_proxy_https'=>false];`,{mode:0o600});
 mkdirSync(resolve(temp,'tls'));run('openssl',['req','-x509','-newkey','rsa:2048','-nodes','-keyout',resolve(temp,'tls/test.key'),'-out',resolve(temp,'tls/test.crt'),'-days','1','-subj','/CN=localhost','-addext','subjectAltName=IP:127.0.0.1,DNS:localhost']);
 writeFileSync(resolve(temp,'apache.conf'),`<VirtualHost *:443>\nServerName localhost\nDocumentRoot /var/www/html\nSSLEngine on\nSSLCertificateFile /var/www/tls/test.crt\nSSLCertificateKeyFile /var/www/tls/test.key\n<Directory /var/www/html>\nOptions FollowSymLinks\nAllowOverride All\nRequire all granted\n</Directory>\n<Directory /var/www/rtr-backend>\nRequire all denied\n</Directory>\nErrorLog /proc/self/fd/2\nCustomLog /proc/self/fd/1 combined\n</VirtualHost>\n<Directory /var/www/html>\nAllowOverride All\n</Directory>\n`);
 container=spawn('docker',['run','--rm','--name',name,'-p',`${httpsPort}:443`,'-p',`${httpPort}:80`,
  '--mount',`type=bind,src=${temp},dst=/var/www`,
  '--mount',`type=bind,src=${resolve(temp,'apache.conf')},dst=/etc/apache2/sites-enabled/000-rtr-fixture.conf,readonly`,
  'php:8.3-apache','bash','-c','a2enmod rewrite ssl headers >/dev/null && chown -R www-data:www-data /var/www/rtr-backend/private && apache2-foreground'],{stdio:['ignore','pipe','pipe']});
 container.stdout.on('data',d=>{logs+=d});container.stderr.on('data',d=>{logs+=d});
 let ready=false;for(let i=0;i<120;i++){try{if((await call('/api/content.php')).status===200){ready=true;break}}catch{}await new Promise(r=>setTimeout(r,150))}
 check(ready,'Actual Apache HTTPS fixture becomes ready: '+logs.slice(-1500));
 for(const path of ['/','/about','/academics','/crime-thrillers','/fiction','/non-fiction','/literature','/magazines','/newsletters']){
  const r=await call(path);check(r.status===200&&r.headers['content-type'].includes('text/html')&&r.text.includes('id="root"'),`SPA deep route ${path} resolves to the public frontend`);
 }
 let result=await call('/api/content.php');check(result.status===200&&result.data.content.pages.length===9,'Public PHP API returns JSON through the deployed sibling bridge');
 const entry=await call('/');const asset=entry.text.match(/src="([^"]+\.js)"/)[1];result=await call(asset);check(result.status===200&&!result.headers['content-type'].includes('text/html'),'Compiled JS assets do not receive SPA HTML');
 result=await call('/admin/');check(result.status===200&&result.text.includes('Private Editorial Backend')&&!result.text.includes('id="root"'),'Admin DirectoryIndex overrides inherited index.html and remains a separate app');
 check(result.headers['content-security-policy'].includes("frame-ancestors 'none'"),'Private backend CSP is present under Apache');
 check(result.headers['x-robots-tag'].includes('noindex'),'Admin noindex header is present under Apache');
 result=await call('/admin/',{secure:false});check(result.status===426,'Production admin rejects plain HTTP');
 result=await call('/api/subscribe.php',{method:'POST',secure:false,body:{email:'reader@example.test',topics:['fiction'],consent:true}});check(result.status===426,'Production subscription mutations reject plain HTTP');
 for(const path of ['/private/config.php','/backend/private/config.php','/app/bootstrap.php','/seed/editorial-content.json','/.git/config']){
  const r=await call(path);check(r.status===403&&!r.text.includes(token),`Public guessed private path is denied: ${path}`);
 }
 const cookies=new Map();result=await call('/admin/api.php?action=session',{cookies});let csrf=result.data.csrf;
 check(result.headers['set-cookie'].some(c=>/secure/i.test(c)&&/httponly/i.test(c)&&/samesite=strict/i.test(c)),'Production administrator cookie has Secure, HttpOnly and SameSite=Strict');
 result=await call('/admin/api.php?action=content',{cookies});check(result.status===401,'Production private API rejects unauthenticated reads');
 result=await call('/admin/api.php?action=install',{method:'POST',cookies,csrf,body:{token,email:'apache-editor@example.test',password}});check(result.status===200,'Owner installation works with true HTTPS under Apache');
 result=await call('/admin/api.php?action=session',{cookies});csrf=result.data.csrf;
 result=await call('/admin/api.php?action=login',{method:'POST',cookies,csrf,body:{email:'apache-editor@example.test',password}});check(result.status===200,'Owner sign-in works under Apache');
 result=await call('/admin/api.php?action=session',{cookies});csrf=result.data.csrf;
 result=await call('/admin/api.php?action=content',{method:'POST',cookies,csrf,rawBody:'{'});check(result.status===400,'Malformed JSON fails cleanly without a write');
 result=await call('/admin/api.php?action=content',{cookies});const initial=result.data;
 const renamed=structuredClone(initial.content);renamed.site.name='Other Brand';
 result=await call('/admin/api.php?action=content',{method:'POST',cookies,csrf,body:{content:renamed,revision:0}});check(result.status===422,'RTR Digital brand name is immutable on the server');
 const secondCookies=new Map();result=await call('/admin/api.php?action=session',{cookies:secondCookies});let secondCsrf=result.data.csrf;
 result=await call('/admin/api.php?action=login',{method:'POST',cookies:secondCookies,csrf:secondCsrf,body:{email:'apache-editor@example.test',password}});check(result.status===200,'A separate administrator session can sign in');
 result=await call('/admin/api.php?action=session',{cookies:secondCookies});secondCsrf=result.data.csrf;
 const a=structuredClone(initial.content),b=structuredClone(initial.content);a.pages[0].description='Concurrent editor A.';b.pages[0].description='Concurrent editor B.';
 const concurrent=await Promise.all([
  call('/admin/api.php?action=content',{method:'POST',cookies,csrf,body:{content:a,revision:0}}),
  call('/admin/api.php?action=content',{method:'POST',cookies:secondCookies,csrf:secondCsrf,body:{content:b,revision:0}}),
 ]);check(concurrent.map(r=>r.status).sort().join(',')==='200,409','Concurrent editors publish once and reject the stale overwrite');
 const duplicate=await Promise.all(Array.from({length:5},()=>call('/api/subscribe.php',{method:'POST',body:{email:'=1+1@example.test',topics:['literature'],consent:true}})));
 check(duplicate.every(r=>r.status===200),'Concurrent newsletter requests succeed safely');
 result=await call('/admin/api.php?action=subscribers',{cookies});check(result.data.subscribers.length===1,'Concurrent duplicate requests produce exactly one subscriber');
 result=await call('/admin/api.php?action=export',{method:'POST',cookies,csrf});check(result.status===200&&result.text.includes("'=1+1@example.test"),'CSV formula-leading values are escaped');
 result=await call('/api/subscribe.php',{method:'POST',customOrigin:'https://evil.example',body:{email:'attacker@example.test',topics:['fiction'],consent:true}});check(result.status===403,'Production rejects a foreign-origin subscription POST');
 run('docker',['exec',name,'mv','/var/www/rtr-backend/private/config.php','/var/www/rtr-backend/private/config.backup.php']);
 result=await call('/api/subscribe.php',{method:'POST',body:{email:'unconfigured@example.test',topics:['fiction'],consent:true}});check(result.status===503,'An unconfigured backend does not claim to save subscriptions');
 result=await call('/admin/api.php?action=content');check(result.status===401,'An unconfigured backend still denies anonymous private content access');
 result=await call('/admin/api.php?action=session');check(!result.data.configured&&!result.data.user,'Unconfigured backend reveals no private account data');
 run('docker',['exec',name,'mv','/var/www/rtr-backend/private/config.backup.php','/var/www/rtr-backend/private/config.php']);
 const digest=p=>createHash('sha256').update(readFileSync(p)).digest('hex');
 const report={status:'passed',checks,server:'Official PHP 8.3 Apache image, mod_rewrite/SSL/headers, actual extracted ZIPs',layout:'public_html renamed Apache html + sibling rtr-backend; private storage outside document root',https:'Real TLS with isolated self-signed test certificate; no live domain or host account deployed',frontendZipSHA256:digest(frontendZip),backendZipSHA256:digest(backendZip),phpVersion:run('docker',['exec',name,'php','-r','echo PHP_VERSION;']).trim()};
 console.log(JSON.stringify(report,null,2));mkdirSync(resolve(root,'backend/tests/artifacts'),{recursive:true});writeFileSync(resolve(root,'backend/tests/artifacts/apache-validation.json'),JSON.stringify(report,null,2));
}finally{
 if(container){spawnSync('docker',['exec',name,'chown','-R',`${process.getuid?.()||1000}:${process.getgid?.()||1000}`,'/var/www/rtr-backend/private'],{stdio:'ignore'});spawnSync('docker',['stop','--time','2',name],{stdio:'ignore'});container.kill('SIGTERM')}
 rmSync(temp,{recursive:true,force:true});
}
