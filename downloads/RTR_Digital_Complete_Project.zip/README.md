# RTR Digital

RTR Digital is a custom digital-products and subscription application for an **India-based business selling globally in USD**. It includes a customer storefront, private library, membership/team workspace, account security center, publishing studio, and commerce office. React 19, TypeScript, Vite, Express 5, and SQLite power the application. The ribbon-R logo, hero artwork, and digital product cover compositions are original to this project.

The redesigned Signal studio storefront combines an interactive Design/Listen/Build showcase, keyboard search, responsive product discovery, curated edits and transparent membership pricing. Automatic motion has pause/play controls and respects reduced-motion preferences. See [design implementation](docs/DESIGN.md) for the visual system and working interactions.

**RTR Digital is the sole seller and licensor of every product.** Administrator publishing, imports, catalog attribution, license displays and new receipts use this fixed identity. There are no third-party seller accounts, vendor commissions or marketplace payouts. The Creator subscription tier is a customer membership. Business address, tax registration and support details remain configurable; they do not change the RTR Digital brand. Existing financial snapshots remain historical records.

## Run the application

Requires Node.js **24.2+** and npm. Work from this repository directory.

```sh
npm ci
npm run dev
```

The website runs on port 5173; Vite proxies `/api` to Express on port 3001. If the default npm cache is unavailable, use `npm ci --cache /workspace/.cache/npm`.

For the built application with its complete backend:

```sh
npm run build
npm start
```

Express serves the application and API on port 3001. `npm run preview` alone only serves a static preview and does **not** start the API.

Development includes clearly labeled shared customer/admin demo sign-in and no-charge demo checkout. Register a separate customer account to test trials, recovery, MFA, and teams. Development verification/recovery messages appear in the account owner's private mailbox when no email provider is configured. Demo accounts, transactions, and grants are disabled in production.

## Customer and administrator routes

| Route                                  | Working experience                                                                                                                                                             |
| -------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ |
| `/`                                    | Original responsive storefront, featured products, categories and membership introduction                                                                                      |
| `/explore`, `/collections`, `/compare` | Search/filter/sort, saved favorites, curated discovery, persistent comparison of up to three products                                                                          |
| `/products/:id`                        | Shareable product details, public preview, protected originals for entitled users, versions, checksums, license claims, verified reviews and learning notes                    |
| `/membership`                          | Explorer/Creator/Studio plans with monthly/yearly prices and renewal terms                                                                                                     |
| `/library`                             | Entitled products, authenticated downloads, order history, self-service recurring membership management                                                                        |
| `/members`                             | Seven-day trial eligibility, membership activity/reminders, Studio workspace and five-seat invitation management                                                               |
| `/account`                             | Profile, email verification, password changes/recovery, authenticator MFA/recovery codes, sessions, notifications, consent, export and account deletion                        |
| `/billing`                             | Customer order records, private printable payment receipts, refund requests and their status                                                                                   |
| `/admin`                               | Actual store statistics, standard product/cover upload, publication status, orders and support tickets                                                                         |
| `/publisher`                           | Draft-first products, metadata editing, scheduled publication, bulk metadata import, release versions, resumable uploads, public previews, key inventory and review moderation |
| `/operations`                          | Live/demo financial separation, MRR/ARR, promotions, refund decisions, seller details, audit records and CSV exports                                                           |
| `/about`, `/support`, `/policies`      | Brand story, persisted support intake, and transparent preview license/privacy/terms explanations                                                                              |

The account navigation joins these workspaces. Product details, authentication, shopping bag, and checkout use accessible dialogs with keyboard focus handling. The installable web manifest and public-only offline screen do not cache private account pages or media.

## Publishing original digital products

1. Sign in as a development administrator and open **Publishing studio**.
2. Create a new draft with its digital category, description, USD price, and membership eligibility. Drafts without original files cannot be published or sold.
3. Upload an original release, version label and changelog. Standard uploads support 100 MB; larger files use private resumable chunks with SHA-256 verification. The default resumable maximum is **5 GiB**, configurable within available disk capacity.
4. Pause or return later; reselect the same original file to resume. A different file, even with the same name and size, is rejected by its checksum. Sessions expire after 48 hours of inactivity; per-admin and total pending-upload limits apply.
5. Optionally upload a separately designated public preview, product cover, and software license-key inventory. Keys are encrypted at rest and assigned uniquely to entitled customers.
6. Publish or schedule the product. One-time purchases and active eligible memberships grant library access; Studio team membership is checked against its owner's active subscription. Archived releases preserve original bytes.

Supported inline original viewing includes validated PDF, audio/video formats and bounded UTF-8 text. Unsupported formats, archives, HTML/SVG, executables, and oversized text remain download-only. Full original media uses authenticated range delivery; its public preview is a separate administrator-selected asset. Reading/viewing progress, completion, and notes persist per entitled user.

The 12 seeded products, popularity counts and initial ratings are illustrative; every sample is attributed to RTR Digital. Downloads for these seeds are explicitly labeled samples. Real customer review aggregates replace illustrative ratings when available. The production public catalog hides sample products; live checkout refuses sample files and memberships without original published content.

## Subscription behavior

- Explorer: $9 monthly or $84 yearly; Creator: $19 or $180; Studio: $39 or $372. License differences describe personal/commercial/team project usage; redistribution of originals is not included.
- Recurring cancellation takes effect at period end; resumption preserves the current paid period. Demo plan changes explicitly restart a test period without collecting money.
- Live changes use Stripe Billing. Configure allowed provider prices and `STRIPE_PRICE_<STARTER|CREATOR|STUDIO>_<MONTHLY|YEARLY>` mappings. Unknown changed provider prices do not retain Studio team privileges silently.
- Seven-day no-card trials never auto-renew or charge. Production trials are off by default; enable `TRIALS_ENABLED=true` only after publishing original eligible content. They require verified email, are once per account/email, cannot extend themselves through plan changes, and cannot overwrite open Stripe billing records.
- Studio supports five total seats including the owner and pending invitations. Invite links expire, require the invited signed-in email, are single-use, and require email verification in production. Removing a member, ending the owner’s access, or closing the workspace removes shared access. Independently purchased products remain available.
- Signed billing events refresh provider state and record deduplicated renewal/failure activity. In-app reminders are persisted; optional renewal email respects preferences. Invitation links are currently shared by the owner rather than automatically emailed.

## Payments, promotions, receipts and refunds

Checkout quotes and final amounts come from the server. Promotions support scopes, start/end dates, minimum spend, redemption limits, per-account limits and concurrent pending-checkout reservations. Membership discounts apply to the displayed recurring price on every renewal. Demo ordering, promotion redemption, paid fulfillment and refunds are idempotent.

Stripe fulfillment requires a signed event matching a known server-side intent, price, currency and authoritative subscription state. A browser redirect cannot grant access. Configured Stripe Tax calculates applicable tax during hosted checkout; immutable orders preserve the actual charged total, pretax amount, tax and seller snapshot. It is not a locally invented GST or global VAT calculation.

Customers can request a refund from Billing. Administrator approval reverses a demo grant, requests a verified gateway refund, or records an already-cleared bank repayment. Pending/failed provider refunds do not prematurely revoke access, and uncertain repayments require reconciliation before another attempt. Independent purchases of the same product are preserved. Receipts are explicitly **payment receipts, not statutory GST/export tax invoices**; jurisdiction-specific invoicing, export documentation and accounting remain business/provider configuration.

## Payment connections and changeable bank details

Commerce office → **Payment connections** manages PayPal, Razorpay and wire-receiving instructions. Provider credentials are write-only and encrypted; saving sensitive changes requires the current administrator password in production. Blank secret fields preserve saved values, and explicit removal controls disable/remove the saved connection. The bank overview masks account numbers; a password-protected reveal hides again after one minute. Updates affect future payments while pending orders keep their encrypted original account/provider snapshot.

Stripe remains the automatic recurring membership provider, using runtime secrets and its signed webhook. It supports eligible cards, wallets and local methods enabled in the merchant account. PayPal Orders v2 and Razorpay payment links support USD product purchases and a **prepaid, nonrenewing monthly/yearly membership term**. Server-side verification checks the original recipient/payment reference, exact USD amount and captured/settled status. The customer return URL does not unlock content. Production rejects sandbox/test grants even if a development database is reused.

Wire checkout shows private receiving instructions and an order reference. Customer reports do not grant access. The administrator must match cleared funds, exact USD amount, a unique bank reference and the instruction version before confirming. Pending wire instructions last seven days; expired or ambiguous payments require reconciliation. Shared membership checkout locks prevent overlapping pending terms, and a delayed conflicting paid membership is recorded for review without replacing an active purchased term.

Gateway payout bank accounts are changed in the provider's merchant dashboard; the site's wire-receiving account is changed here. This project does not provision merchant accounts or link a real bank automatically. Provider availability, India eligibility, USD acceptance, fees, conversion and bank settlement depend on your approved accounts. Four payment routes are implemented; other payment companies require their own integrations.

PayPal/Razorpay refunds use the original provider connection and preserve access until confirmation. An uncertain Razorpay refund is blocked from automatic resubmission until reconciled in the provider dashboard. Wire refunds must be returned through the bank first, then explicitly recorded with password, exact amount and unique repayment reference. Test payments remain separate from live revenue; prepaid terms are excluded from recurring MRR.

See [payment/bank setup](docs/PAYMENTS_GUIDE.md) and [deployment operations](docs/DEPLOYMENT_GUIDE.md). The distributable guides are also supplied as PDFs.

## Live service configuration

See `.env.example`, [API operations](server/README.md), and [feature coverage](docs/FEATURE_SCOPE.md). No payment or email credentials are bundled.

Configure production secrets securely: `NODE_ENV=production`, persistent `DATA_DIR`, administrator bootstrap credentials, `STRIPE_SECRET_KEY`, `STRIPE_WEBHOOK_SECRET`, HTTPS `PUBLIC_URL`, and optionally `RESEND_API_KEY` / `EMAIL_FROM`. Node can load a local file with `node --env-file=.env server/index.mjs`; `.env` is ignored by Git. Production password recovery/verification refuses unconfigured email delivery or unsafe public origins.

Register Stripe webhooks for checkout completion/async success/expiry, subscription updates/deletion, invoice paid/payment failure/action required, charge refunds and refund updates. Configure Stripe Billing portal plan availability and tax registrations for the merchant's actual India/global business. Provider account eligibility, external delivery, cross-border settlement, taxes, final legal policies, and a public domain must be verified using the operator's own accounts. Local mocks cannot establish those external outcomes.

Uploads use private local storage with capacity checks. Shared object storage/CDN, vendor DRM/activation, malware scanning/quarantine, multi-instance database deployment, outbound marketing campaigns, and independent operational/security/compliance reviews require additional integrations. The site does not promise infinite storage, bandwidth, countries, payment methods, or every conditional feature in the reference atlas.

## Verification

```sh
npm test
npm run build
npm run test:e2e
```

Server tests use isolated SQLite databases and actual HTTP requests, including signed local Stripe test events and provider mocks. The browser runner starts a fresh server/database for each suite on port 3081, keeping bank settings and authentication quotas independent. `/usr/bin/chromium` is used by default; override `PLAYWRIGHT_CHROMIUM_EXECUTABLE` if needed.

The expanded application has been checked through customer/admin journeys, including original-file publication and exact delivery, recovery/MFA, teams, refunds and mobile layouts. An actual **101 MiB** release was paused after an initial chunk, reloaded, rejected a wrong matching-size file, resumed and finalized with its verified checksum. This does not claim that the full configured 5 GiB maximum was uploaded during validation.

## Deployment, privacy and backup

The included Dockerfile runs Node as an unprivileged user and mounts `/app/data`. The Docker image itself has not been built in this workspace. Use a trusted HTTPS reverse proxy and one durable application instance for SQLite. Multi-instance scale requires a shared database/storage design.

Back up **all** of the private data directory consistently, including SQLite/WAL state, uploads and archived versions, `license-key-master`, `.account-encryption-key` (unless a stable `ACCOUNT_ENCRYPTION_KEY` is supplied), and `.payment-encryption-key`. Losing a matching encryption key can make activation licenses, enrolled MFA, gateway settings or pending bank instructions unreadable. Partial upload sessions may be backed up or allowed to expire.

The server rejects a `DATA_DIR` inside public/dist web roots. Vite denies private database, uploads, environment and encryption-key paths during development. Account export omits authentication secrets and active recovery tokens. Account deletion revokes sessions and anonymizes/removes personal records and owned team workspaces, while preserving financial records and minimum trial-abuse hashes. Final retention/legal requirements depend on the operator's jurisdiction.

## Artwork

Logo files: `public/favicon.svg`, `public/rtr-digital-logo.svg`, and `src/components/Brand.tsx`. Current hero artwork and source notes: `public/images/rtr-digital-signal-hero.webp` / `public/images/ARTWORK.md`. Product cover compositions and alternate hero scenes are original CSS/SVG demonstrations. The current redesign screenshots in `docs/previews/` use the `rtr-signal-` prefix; earlier previews are retained for reference.
