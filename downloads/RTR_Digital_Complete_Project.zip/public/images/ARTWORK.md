# RTR Digital hero artwork

## Signal studio redesign — 24 October 2026

- File: `rtr-digital-signal-hero.webp`
- Exact slot: 1200 × 1000 pixels, 6:5 hero panel beside editable website typography.
- Measured size: 116,756 bytes; WebP quality 85 / method 6.
- Alt: Sculptural chrome ribbon, cobalt glass and chartreuse objects arranged in an architectural ivory studio.
- Original: `/workspace/generated_images/exec-9aa07009-ff18-41ac-ad6f-a5d9d27d64eb.png` (1374 × 1145).
- Style: Editorial sculptural 3D still life; large softbox from upper left; warm ivory #f7f6f2, near black #101310, acid chartreuse #d8ff3e and cobalt #4767ff; architectural three-quarter camera; seamless ivory background; no people, text or logos.
- Composition: Liquid-chrome ribbon, cobalt acrylic arch, chartreuse book, black audio disk, cobalt orb and ivory plinth. Generated as conceptual digital-product artwork. Resized to the slot and encoded locally; inspected in desktop/mobile browser layouts.

This image belongs to the redesigned interactive Design / Listen / Build showcase. Text overlays, controls, product attribution and prices remain editable HTML; alternate scenes are original CSS/SVG compositions.

## Earlier artwork retained with the project

- File: `rtr-digital-hero.webp`
- Dimensions: 1000 × 900 pixels
- File size: 69,468 bytes
- Format: WebP, quality 86
- Slot: Nearly square hero artwork panel
- Alt text: Lavender book, charcoal headphones, and a tablet arranged with glass arches and chrome sculptures in a mint studio.
- Generated original retained at: `/workspace/generated_images/exec-70d4d42c-c6af-425d-9e52-62a564d9fc8f.png`

## Shared style specification

Premium tactile 3D editorial still life, soft upper-left studio lighting, ivory #F8F7F2, mint #CDE9DE, lavender #B9ADEE, and charcoal #182B2A palette, three-quarter close camera, warm clean color grade, seamless pale mint studio background, no people.

## Generation prompt

Premium tactile 3D editorial still life, soft upper-left studio lighting, ivory #F8F7F2, mint #CDE9DE, lavender #B9ADEE, and charcoal #182B2A palette, three-quarter close camera, warm clean color grade, seamless pale mint studio background, no people. Artfully composed floating and stacked blank digital creator objects: a thick rounded lavender notebook/book standing vertical near right, charcoal over-ear headphones, mint translucent acrylic arch and chrome sculptural ribbon, cream cards with minimal abstract shapes, and a thin black tablet tilted with an abstract blue/lavender 3d sphere on screen. Refined product photography quality with believable shadows, playful gallery aesthetic, large 3d objects fill frame. Editorial high-end digital marketplace hero product still life. Nearly square landscape composition 10:9. No text, no letters, no logo, no brand marks, no watermark. Background seamless mint. Produce a polished, refined composition with one lavender book, one pair headphones, one tablet. Visually balanced premium studio art, tactile material textures, physically believable soft shadows.

## Processing

The original 1322 × 1190 PNG was fitted to exactly 1000 × 900 with Pillow LANCZOS resampling, converted to RGB, and encoded as WebP with quality 86 / method 6. Both original and delivered artwork were inspected visually. This is generated conceptual product artwork; it does not depict actual merchandise or a real person.
