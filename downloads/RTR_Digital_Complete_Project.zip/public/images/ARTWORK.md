# RTR Digital hero artwork

- File: `rtr-digital-hero.webp`
- Dimensions: 1000 × 900 pixels
- File size: 69,468 bytes
- Format: WebP, quality 86
- Slot: Nearly square hero artwork panel
- Alt text: Lavender book, charcoal headphones, and a tablet arranged with glass arches and chrome sculptures in a mint studio.
- Generated original retained at: `/workspace/generated_images/exec-70d4d42c-c6af-425d-9e52-62a564d9fc8f.png`

## Shared style specification

Premium tactile 3D editorial still life, soft upper-left studio lighting, ivory #F8F7F2, mint #CDE9DE, lavender #B9ADEE, and charcoal #182B2A palette, three-quarter close camera, warm clean color grade, seamless pale mint studio background, no people.

## Generation prompt

Premium tactile 3D editorial still life, soft upper-left studio lighting, ivory #F8F7F2, mint #CDE9DE, lavender #B9ADEE, and charcoal #182B2A palette, three-quarter close camera, warm clean color grade, seamless pale mint studio background, no people. Artfully composed floating and stacked blank digital creator objects: a thick rounded lavender notebook/book standing vertical near right, charcoal over-ear headphones, mint translucent acrylic arch and chrome sculptural ribbon, cream cards with minimal abstract shapes, and a thin black tablet tilted with an abstract blue/lavender 3d sphere on screen. Refined product photography quality with believable shadows, playful gallery aesthetic, large 3d objects fill frame. Editorial high-end digital marketplace hero product still life. Nearly square landscape composition 10:9. No text, no letters, no logo, no brand marks, no watermark. Background seamless mint. Produce a polished, refined composition with one lavender book, one pair headphones, one tablet. Visually balanced premium studio art, tactile material textures, physically believable soft shadows.

## Processing

The original 1322 × 1190 PNG was fitted to exactly 1000 × 900 with Pillow LANCZOS resampling, converted to RGB, and encoded as WebP with quality 86 / method 6. Both original and delivered artwork were inspected visually. This is generated conceptual product artwork; it does not depict actual merchandise or a real person.
