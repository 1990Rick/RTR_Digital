import { defineConfig, devices } from '@playwright/test';
import { tmpdir } from 'node:os';
import { join } from 'node:path';

export default defineConfig({
  testDir: './tests/e2e',
  fullyParallel: false,
  workers: 1,
  timeout: 35_000,
  expect: { timeout: 7_000 },
  reporter: [['list']],
  use: {
    baseURL: 'http://127.0.0.1:3081',
    trace: 'retain-on-failure',
    screenshot: 'only-on-failure',
    launchOptions: { executablePath: process.env.PLAYWRIGHT_CHROMIUM_EXECUTABLE || '/usr/bin/chromium', args: ['--no-sandbox'] },
  },
  projects: [{ name: 'chromium', use: { ...devices['Desktop Chrome'], viewport: { width: 1440, height: 1000 } } }],
  webServer: {
    command: 'node server/index.mjs',
    url: 'http://127.0.0.1:3081/api/health',
    reuseExistingServer: false,
    timeout: 20_000,
    env: { PORT: '3081', API_PORT: '3081', NODE_ENV: 'development', DEMO_MODE: 'true', DATA_DIR: join(tmpdir(), `rtr-playwright-${process.pid}`) },
  },
});
