# RTR Digital

## International payments and bank setup guide

Prepared 24 October 2026. Store currency: USD. Business location: India. Every product is sold and licensed by RTR Digital. This guide explains the implemented payment connections, account changes and reconciliation.

### 1. Supported connections

Stripe supports hosted card checkout and the wallets/local payment methods enabled and eligible in your Stripe account. It also provides automatic recurring monthly/yearly memberships and the customer billing portal.

PayPal uses server-created USD orders, buyer approval and server-side capture/verification. Razorpay uses provider-hosted payment links and server-side verification of the captured USD payment. These connections support individual purchases and a prepaid membership term without automatic renewal.

Wire transfer provides your configured receiving-bank instructions to the signed-in order owner. An administrator must verify cleared USD funds before access is granted. Wire memberships are also prepaid and nonrenewing.

These are four implemented payment routes, not a claim that every international payment company is connected. A wallet or local method appears only where supported by the selected gateway, buyer location, USD currency and your merchant approval. Other services require their own adapters. Transfers sent through a remittance service must still arrive as matching cleared funds in your configured bank.

### 2. Your bank and provider settlement

Open and verify the merchant account with each provider you intend to use. Complete the provider's business checks and connect your actual payout bank account in its merchant dashboard. The website cannot bypass provider onboarding, connect a bank without authorization, or move payouts merely because bank details have been typed into a form.

Gateway payout bank details are managed by Stripe, PayPal or Razorpay. Change them in the corresponding provider dashboard and follow its verification process. RTR Digital's wire-receiving details are managed separately in Commerce office > Payment connections.

Confirm that your India-based account can accept international USD digital-product sales and understand how the provider settles them into your bank, including conversion, fees, settlement timing and export documentation. USD storefront pricing does not guarantee USD settlement into an Indian account. Local INR-only methods are not promised for USD checkout.

### 3. Access the payment connections workspace

Sign in as the administrator and open Commerce office, then Payment connections. Provider states distinguish enabled/configured settings from an externally verified working connection. An unavailable provider cannot be selected as a working checkout method.

Sensitive settings require your current administrator password. Shared development demo administration has an explicitly labeled development shortcut; it is disabled in production. Secret inputs are write-only. Leaving them blank preserves the stored credential. Use the explicit removal controls to remove a credential when required.

Gateway credentials and bank snapshots are encrypted at rest using the private .payment-encryption-key. They are never embedded in the public frontend, customer exports or distributable ZIP. Bank account numbers are masked in the admin overview. Full receiving instructions are disclosed only to the signed-in owner of the relevant pending wire order, or through the administrator's password-protected reveal action.

### 4. Stripe setup

In your deployment secret store, set STRIPE_SECRET_KEY, STRIPE_WEBHOOK_SECRET and the final HTTPS PUBLIC_URL. Restart the application after changing runtime credentials. Do not paste live secrets into source files or upload them with the distributable project.

Register the deployed /api/stripe/webhook endpoint with Stripe for checkout completion, asynchronous success and expiry, subscription changes/deletion, invoice payment/failure/action-required and refund events. A browser success URL does not grant access. The server requires a signed event matching a known intent, amount, currency and verified billing state.

Enable the payment methods your business is eligible to accept in the Stripe dashboard. Configure the Billing customer portal and STRIPE_PRICE_STARTER_MONTHLY/YEARLY, STRIPE_PRICE_CREATOR_MONTHLY/YEARLY and STRIPE_PRICE_STUDIO_MONTHLY/YEARLY when enabling mapped provider plan changes. Stripe automatic tax is optional and requires your actual tax registrations/configuration.

Use Stripe test mode for external integration verification before live keys. Development tests bundled with the project are provider mocks, not proof that a real merchant account is connected.

### 5. PayPal setup and account changes

Create the correct PayPal business application and obtain its client ID, client secret and merchant ID. In Payment connections, select sandbox or live, enter those values and enable PayPal. The merchant ID is checked against the recipient of the completed payment.

The server creates the order in USD with its own reference, custom ID and invoice ID. After buyer approval, the signed-in owner can trigger server-side capture and verification. The server checks the recipient, the exact completed USD capture and the original order identity before granting access.

Use sandbox credentials only with sandbox. Production refuses sandbox grants and existing development payments. Changing the merchant account for future orders means updating the client ID, secret and merchant ID together. Change the receiving/payout bank in PayPal's business dashboard.

### 6. Razorpay setup and account changes

Obtain the API key ID and secret from the Razorpay merchant dashboard. Enter them in Payment connections and enable the provider. Test key IDs begin with rzp_test_; live key IDs begin with rzp_live_. Production requires live credentials and merchant approval for the USD international payment route.

The server creates a hosted payment link using the trusted USD amount and unique store reference. On return or refresh it retrieves the link and captured payment from Razorpay, checks the exact paid amount, currency, reference and captured state, and grants access only after verification. An unsigned callback or customer-provided transaction ID is insufficient.

Update the API key ID and secret to change the gateway account for future orders. Use Razorpay's own dashboard to change its payout bank and complete any required verification. Test keys never create valid production entitlements.

### 7. Add or change wire-receiving details

In Payment connections, enter the actual beneficiary name as held by the bank, bank name, receiving account number or IBAN, SWIFT/BIC, and any required routing number or IFSC. Add bank and beneficiary addresses, intermediary-bank instructions and transfer notes where your bank requires them. These details must come from your bank's international receiving instructions; do not invent routing information.

Keep RTR Digital as the seller/licensor while entering the accurate bank beneficiary. A sole proprietor's legal bank account name can differ from the trading brand. Confirm the bank accepts the intended international remittances and currency route before enabling wire checkout.

Enable bank transfers, enter your administrator password and save. Account numbers, IBANs and routing numbers remain blank in edit fields unless you are replacing them; blank sensitive fields preserve the saved value. To change banks later, enter the replacement details and save again.

Each pending order retains the version of bank instructions issued when it was created. Changing the account affects new orders; it does not silently redirect a customer who already received instructions. Monitor the old account for outstanding transfers before closing it. No actual bank details are included in the distributed files.

### 8. Customer wire flow

At checkout the customer chooses bank transfer, accepts the terms and requests instructions. The server records the products or prepaid membership, trusted USD total, unique payment reference, instruction snapshot and expiry. Wire instructions normally remain valid for seven days.

The customer sends the exact USD amount using the order reference. Fees or currency conversion can cause the amount actually received to differ; resolve any difference before confirming. The customer may report their bank reference and a note in Billing > Payment activity, but this does not unlock the product or prove funds arrived.

The customer can return to the private payment details later. Instructions are not a public bank directory and are not disclosed through an unauthenticated catalog endpoint.

### 9. Confirm or reject a wire

Open the transfer queue in Payment connections. Match the store reference, beneficiary/account version, received USD amount and the actual settled bank entry. Confirm only after funds have cleared in the correct bank account.

Record the unique bank reference, received amount and USD currency, confirm the cleared-funds declaration and authenticate as the administrator. Successful reconciliation records the paid order and grants its access exactly once. The same bank reference cannot be reused to fulfill another order. A rejected, expired, wrong-currency or short-paid transfer does not grant access.

If funds arrive after expiry, a provider request fails ambiguously, or a second membership payment conflicts with an active term, inspect the provider/bank records and audit trail before taking action. Contact the customer and reconcile or return the funds through the original provider/bank. Do not issue another charge merely to test whether the first succeeded.

### 10. Memberships and refunds

Stripe memberships renew automatically according to the chosen interval until canceled. PayPal, Razorpay and wire purchases pay once for a fixed term and expire automatically. A prepaid term cannot be upgraded or extended using the development plan-change endpoint. It is reported separately from recurring subscription MRR.

Customers request refunds from Billing. Stripe, PayPal and Razorpay approvals use the original provider connection and retain access while the refund is pending or unconfirmed. The site does not treat a provider timeout as a completed refund. In particular, an uncertain Razorpay refund requires checking the merchant dashboard before any retry that could duplicate a repayment.

Return wire funds through your bank first. Then use the wire refund confirmation fields in Commerce office to record the exact USD repayment, unique bank reference, administrator password and explicit confirmation that the bank refund has already cleared. This records a completed repayment and reverses the relevant access; it does not instruct the bank to send money.

Independent purchases remain valid when another order for the same product is refunded. Historic paid receipts keep their captured seller and financial details when you later change settings.

### 11. Preserve and verify your configuration

Back up the database, complete private data directory and .payment-encryption-key together with the account and license keys. Pending orders retain encrypted original provider settings so an ordinary account change does not silently substitute a different recipient during verification or refunds. Revoking old credentials at the provider can still require manual resolution of those older orders.

Before live use, test your own provider accounts: successful and failed checkout, an interrupted return, exact USD amount verification, wrong-recipient protection, duplicate retries, account changes with an outstanding payment, recurring renewal/cancellation and refunds. Verify bank instructions with your bank independently of the website form.

The included local tests use synthetic accounts, simulated bank data, provider mocks and signed local Stripe events. No real bank was linked, no live charge or wire was performed, and no external settlement was verified during development. See docs/VERIFICATION.md for the exact final local checks.
