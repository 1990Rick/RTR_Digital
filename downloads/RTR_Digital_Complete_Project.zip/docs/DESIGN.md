# RTR Digital — Signal studio design

The customer storefront uses an original editorial identity: warm ivory #f7f6f2, ink #101310, chartreuse #d8ff3e and cobalt #4767ff. Large Manrope typography, restrained borders and deliberately composed product artwork replace the previous pastel storefront. RTR Digital remains the only seller and licensor; prices stay in USD.

## Working interactions

- The homepage showcase moves between Design, Listen and Build every eight seconds, with a visible pause/play control. Hover, keyboard focus and hidden tabs pause playback. Manual selection stops automatic advancement until Play is chosen. Reduced-motion preference disables automatic playback and pointer movement.
- Each showcase links to an actual product from its category. Product previews, favorites and the shopping bag use the existing catalog and customer state.
- Hero search forwards the query to the catalog. Ctrl+K or Command+K opens search; Escape restores keyboard focus.
- Home discovery supports category changes, sorting and pagination. Catalog search includes titles, descriptions, categories, tags and formats; visible filter chips can be removed individually.
- Homepage plan totals and the full membership page switch between monthly and yearly prices. Actual checkout terms distinguish recurring Stripe plans from prepaid PayPal/Razorpay/wire terms.
- Editorial collections filter actual products by a selected edit or category and preserve the choice when browsing the catalog. No invented endorsements or sample ratings are presented as social proof.
- Responsive navigation, product dialogs, newsletters and the footer share the same design. Customer and administrator workflows retain their existing API-backed behavior.

## Main source files

`src/components/StudioHome.tsx`, `StudioEditorial.tsx`, `Storefront.tsx`, `Brand.tsx` and `src/App.tsx` provide the storefront. The four `studio-*.css` files are loaded after the shared legacy layout styles, with shell styling last. The original pastel home component was removed.

The hero artwork is delivered as `public/images/rtr-digital-signal-hero.webp`, exactly 1200 × 1000 pixels and 116,756 bytes. Its full source description and attribution are in `public/images/ARTWORK.md`. Other animated scenes and collection artwork are CSS/SVG compositions with editable HTML text.

## Verification

The design browser suite exercises scene/product navigation, actual search, keyboard focus, monthly/yearly totals, curated filtering, reduced motion and responsive public pages. The existing checkout, publishing, account, membership and payment suites check that the redesign preserves commerce behavior. See `docs/VERIFICATION.md` for final results and external-service boundaries.
