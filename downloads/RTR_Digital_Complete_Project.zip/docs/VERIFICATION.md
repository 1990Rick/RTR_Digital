# Verified delivery — RTR Digital

- `npm run build`: passed (TypeScript and production Vite build).
- `npm test`: **99 passed, 0 failed, 0 skipped** across actual isolated HTTP/database fixtures.
- Four isolated Playwright suites: **20 passed, 0 failed**, including 390px and 768px responsive routes. Each suite uses a fresh server/database to keep receiving-bank settings and authentication quotas independent.
- `npm audit --omit=dev --audit-level=high`: **0 reported vulnerabilities** at validation time.
- Actual Chromium upload: **101 MiB**, paused after 8 MiB, reloaded, wrong matching-size file rejected, original reselected, resumed, SHA-256 verified and finalized.
- Separate incremental browser checksum verification matched Node on 13 boundary/random vectors through a streamed 10 MiB input.
- Current built publisher, commerce office and account pages loaded without JavaScript page errors during visual capture.
- `git diff --check`: passed.

Server checks cover authenticated original and archived delivery, media range/HEAD access, draft protection, resumable storage recovery/path safeguards, trial conversion and expiry, team invitations/revocation, profile/recovery/MFA/privacy, concurrent promotions, receipts/refunds and signed provider state/tax fulfillment. Production data-directory and development file-serving protections are tested.

Sole-seller checks cover RTR Digital attribution on new uploads, drafts, edits/imports, stored catalog migration, reads, software license claims and checkout/renewal receipt snapshots. Override attempts cannot introduce another seller or licensor. Historical payment evidence remains unchanged. Browser checks confirm read-only seller/licensor fields and explicit RTR Digital receipt attribution; the existing development catalog was also checked after migration.

Payment checks cover encrypted/write-only credential updates, masked bank settings, immutable receiving-account snapshots, password reauthentication, private ownership, exact USD cleared-funds confirmation, duplicate bank references, expiry/rejection, authoritative PayPal/Razorpay verification, pre-capture recipient checks, provider/refund retries after restart, sandbox-to-production isolation, checkout quotas, membership checkout races and prepaid fixed-term access. Browser journeys cover wire reporting without grants, account changes with a pending order, exact original-byte delivery after confirmation, demonstration receipts, prepaid membership controls and mobile payment layouts.

The Signal studio redesign adds four browser cases for actual scene/product navigation, the eight-second playback boundary, Pause/Play and hover/focus pause, manual scene selection, reduced-motion handling, keyboard search and focus restoration, monthly/yearly totals, curated edit filtering and responsive public pages. Desktop/mobile views of the homepage, catalog, membership, collections and About pages were visually reviewed; current screenshots use the `rtr-signal-` prefix under docs/previews. The production build, all 99 server checks and the complete 20-journey browser runner passed after the redesign.

The two standalone PDF guides each contain five pages. Text extraction checked every numbered section and valid text encoding; representative pages were visually inspected. The final ZIP integrity check excludes private data, real bank details, credentials, encryption keys, node_modules and Git metadata.

Provider tests use injected clients and locally generated Stripe test signatures. **No real bank account was linked, no live charge or wire/settlement was performed, and no external email delivery, public deployment, live tax determination, full 5 GiB upload, Docker image build, production restore or global compliance certification was performed.** These remain operator/provider or deployment validation steps. Implemented payment routes are Stripe, PayPal, Razorpay and wire; this does not claim integration with every international payment service.

The download archive includes source, compiled frontend, original artwork, documentation, dependency lockfile and tests. Customer databases, actual uploaded content, encryption keys, `.env`, credentials, and installed dependency directories are excluded. Follow the README to install/run the application.
