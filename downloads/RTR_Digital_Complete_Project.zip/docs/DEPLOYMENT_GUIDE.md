# RTR Digital

## Deployment and operations guide

Prepared 24 October 2026. India-based business, global digital sales, USD pricing. RTR Digital is the sole seller and licensor. This guide accompanies the complete project ZIP and the separate payment/bank setup guide.

### 1. What is included

The ZIP contains the React/TypeScript storefront, compiled frontend, Express API, SQLite persistence, original artwork, administrator tools, automated tests, lockfile, Dockerfile and operating documentation. It excludes real customer records, uploaded commercial files, credentials, encryption keys and installed dependencies.

The website includes the catalog, customer accounts and security, private library, digital releases and resumable uploads, subscription/team workspaces, checkout, payment activity, promotions, receipts, refund decisions and support intake. The redesigned storefront adds an interactive three-scene showcase, keyboard search, curated product edits and responsive membership pricing with reduced-motion support. The sample catalog is illustrative and is hidden from the production public catalog.

### 2. Install and run locally

Use Node.js 24.2 or later and npm. Extract the ZIP into a private project directory, then run:

```sh
npm ci
npm run dev
```

The development frontend uses port 5173 and the API uses port 3001. Development provides explicitly labeled demo accounts and no-charge orders. Use a separately registered account for recovery, MFA, trials and customer payment checks. Development bank confirmations and sandbox gateways grant development access; these grants do not become valid production purchases.

To serve the compiled frontend with its API:

```sh
npm run build
npm start
```

The complete application then uses port 3001. The preview command by itself does not start the backend.

### 3. Configure production

Create a private persistent storage directory outside public/ and dist/. Configure runtime variables through your host's secret store. The supplied .env.example lists the supported names without credentials.

```text
NODE_ENV=production
PUBLIC_URL=https://your-real-domain.example
DATA_DIR=/absolute/private/persistent-directory
ADMIN_EMAIL=your-real-administrator-address
ADMIN_PASSWORD=your-unique-initial-password
```

Use an initial administrator password of at least 12 characters. Bootstrap settings create the administrator only if that email is not already registered. Remove the bootstrap password after provisioning. Password changes are available in the signed-in account workspace.

If using a private local environment file, Node must be told to load it:

```sh
node --env-file=.env server/index.mjs
```

Use HTTPS and a reverse proxy for a public deployment. Production cookies are Secure, HttpOnly and SameSite=Lax. Configure the final HTTPS origin before activating payment redirects or account email. Development/demo mode must not be exposed as the live store.

### 4. Hosting and storage

Run one durable application instance with persistent storage for this SQLite deployment. Restart the application using the host's process manager. Shared object storage and a shared database are additional integrations for multiple replicas; attaching separate local volumes to multiple replicas would split customer records and files.

The included Dockerfile runs the application as an unprivileged user and expects persistent storage at /app/data. Build and verify the container in your hosting environment before deployment:

```sh
docker build -t rtr-digital .
docker run --env-file .env -p 3001:3001 \
  -v rtr-digital-data:/app/data rtr-digital
```

The Docker image has not been built as part of the supplied local verification. Ensure the mounted volume is writable by the container's application user. Route the public HTTPS domain to the application through your host's supported proxy.

### 5. Publish real digital products

Open Publishing studio as the administrator. Create a draft, choose its category, USD price, description and membership eligibility. The seller/licensor remains RTR Digital for every upload and import.

Upload the actual licensed original and a release version. Standard uploads support 100 MB. Resumable releases default to 5 GiB per file, subject to storage reservations, quotas and available disk. Resume by selecting the same file; checksums prevent a different file with the same name and size from being substituted.

Add an optional public preview separately. A preview is public; full originals require a valid purchase, active eligible membership or valid Studio seat. Supported originals can be viewed as authenticated audio/video/PDF/text; other formats remain downloads. Add private software activation keys where required. Publish immediately or schedule publication after the original is stored.

Publish original eligible content before selling live memberships. The application refuses live checkout for illustrative sample files. Supply the final product-specific RTR Digital licensing terms and accurate business contact/tax information.

### 6. Activate payments and account email

Follow the separate payment/bank guide for Stripe, PayPal, Razorpay and wire instructions. No merchant account, real bank connection, credential or live transaction is included in the ZIP. Supported payment methods depend on each provider's approval and configuration for your business.

For account verification/recovery mail, configure RESEND_API_KEY, a verified EMAIL_FROM and HTTPS PUBLIC_URL. Development message previews are private local previews and are not delivered email. Verify external email delivery using your provider account.

### 7. Membership operations

Explorer, Creator and Studio are customer tiers. Stripe supports automatic monthly/yearly billing, provider-managed changes and cancellation at period end. Configure the documented Stripe price mappings and customer portal for live changes.

PayPal, Razorpay and bank transfers purchase one fixed monthly/yearly membership term. These prepaid terms do not auto-renew, cannot be extended through a free plan-change action, and expire automatically. Studio's five-seat customer workspace remains available during the owner's eligible term. Customer teams do not create seller accounts.

Production no-card trials are opt-in through TRIALS_ENABLED=true. They require verified email and original eligible content. A trial expires after seven days without a charge or automatic paid conversion.

### 8. Backup and recovery

Back up the entire private data directory consistently: the SQLite database and its WAL state, original and archived uploads, resumable sessions where desired, and every encryption key. Use a SQLite-aware backup or stop the application while taking a consistent copy.

Preserve these keys with their matching data:

- license-key-master: encrypted activation-key inventory.
- .account-encryption-key: MFA secrets, unless a stable ACCOUNT_ENCRYPTION_KEY is used.
- .payment-encryption-key: gateway credentials, bank instructions and pending-payment snapshots.

Do not replace a key on an existing installation. Losing a key can make the corresponding records unreadable. Keep encrypted backups private, restrict access, and exercise restoration on an isolated system before relying on them. The distributable ZIP deliberately contains none of these files.

### 9. Checks and operational boundaries

Run the following from the extracted project:

```sh
npm test
npm run build
npm run test:e2e
```

Browser tests use an isolated temporary database and Chromium. Set PLAYWRIGHT_CHROMIUM_EXECUTABLE when the browser is installed at a different path. Test fixtures use provider mocks and local signed events; they do not establish that your merchant account can collect or settle funds.

Inspect /api/health, the public catalog and a signed-in customer flow after deployment. Verify external payment success/failure, recurring renewal/cancellation, refunds, webhook delivery, email delivery, persistent storage and a full restore using your own test accounts before live sales.

Payment receipts are not statutory GST/export tax invoices. Supply the actual India/export/tax registrations, final policies and required accounting documents for the business. Local tests do not certify global compliance, production traffic capacity or every payment service worldwide.

### 10. Troubleshooting

Empty production catalog: publish real originals; illustrative samples are intentionally hidden. Payment method unavailable: check the provider settings, correct live/test environment, credentials, HTTPS origin and merchant eligibility. Bank transfer still pending: a customer's reference does not establish cleared funds; reconcile it in the bank before confirming.

Missing downloads after moving hosts: verify the persistent data volume, matching database/files/keys and the order's verified environment. Avoid changing the data directory to a new empty location. Unexpected or delayed membership payments appear in the audit records for review rather than overwriting another active paid term.

See README.md, server/README.md, docs/FEATURE_SCOPE.md and docs/VERIFICATION.md for the current implementation and exact verification record.
