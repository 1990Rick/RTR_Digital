"""Render the guides. Requires Python 3, reportlab, and system DejaVu fonts."""
from pathlib import Path
import re
from xml.sax.saxutils import escape

from reportlab.lib import colors
from reportlab.lib.enums import TA_LEFT
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.pagesizes import A4
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import (
    BaseDocTemplate, Frame, PageBreak, PageTemplate, Paragraph,
    Preformatted, Spacer,
)

ROOT = Path(__file__).resolve().parent.parent
OUT = ROOT / "deliverables"
OUT.mkdir(exist_ok=True)
FONT_DIR = Path("/usr/share/fonts/truetype/dejavu")
for name, filename in [
    ("Guide", "DejaVuSans.ttf"),
    ("GuideBold", "DejaVuSans-Bold.ttf"),
    ("GuideMono", "DejaVuSansMono.ttf"),
]:
    pdfmetrics.registerFont(TTFont(name, str(FONT_DIR / filename)))
pdfmetrics.registerFontFamily("Guide", normal="Guide", bold="GuideBold")

FOREST = colors.HexColor("#193c34")
MINT = colors.HexColor("#d1e8a8")
LAVENDER = colors.HexColor("#b9adee")
PAPER = colors.HexColor("#fafbf6")
MUTED = colors.HexColor("#62766a")
WIDTH, HEIGHT = A4
MARGIN = 49


def mark(canvas, x, y, size):
    canvas.saveState()
    canvas.translate(x, y + size)
    canvas.scale(size / 64, -size / 64)
    canvas.setFillColor(FOREST)
    canvas.roundRect(0, 0, 64, 64, 18, fill=1, stroke=0)
    canvas.setFillColor(MINT)
    path = canvas.beginPath()
    path.moveTo(17, 45)
    path.lineTo(17, 19)
    path.lineTo(33, 19)
    path.curveTo(48, 19, 49, 37, 35, 39)
    for point in [(47, 48), (33, 48), (22, 37), (32, 37)]:
        path.lineTo(*point)
    path.curveTo(41, 37, 41, 28, 32, 28)
    for point in [(27, 28), (27, 45)]:
        path.lineTo(*point)
    path.close()
    canvas.drawPath(path, fill=1, stroke=0)
    canvas.setFillColor(LAVENDER)
    path = canvas.beginPath()
    path.moveTo(17, 45)
    path.lineTo(27, 37)
    path.lineTo(27, 45)
    path.close()
    canvas.drawPath(path, fill=1, stroke=0)
    canvas.restoreState()


def decorate(canvas, doc):
    canvas.saveState()
    canvas.setFillColor(PAPER)
    canvas.rect(0, 0, WIDTH, HEIGHT, fill=1, stroke=0)
    mark(canvas, MARGIN, HEIGHT - 55, 24)
    canvas.setFillColor(FOREST)
    canvas.setFont("GuideBold", 12)
    canvas.drawString(MARGIN + 33, HEIGHT - 47, "RTR digital.")
    canvas.setFont("Guide", 7.6)
    canvas.setFillColor(MUTED)
    canvas.drawRightString(WIDTH - MARGIN, HEIGHT - 47, doc.short_title)
    canvas.setStrokeColor(colors.HexColor("#dce5d7"))
    canvas.line(MARGIN, 43, WIDTH - MARGIN, 43)
    canvas.setFont("Guide", 7.4)
    canvas.drawString(MARGIN, 28, "RTR Digital  ·  India → Worldwide  ·  USD")
    canvas.drawRightString(WIDTH - MARGIN, 28, str(doc.page))
    canvas.restoreState()


STYLES = {
    "body": ParagraphStyle("GuideBody", fontName="Guide", fontSize=9.4,
        leading=14.6, textColor=FOREST, spaceAfter=10, alignment=TA_LEFT),
    "section": ParagraphStyle("GuideSection", fontName="GuideBold", fontSize=14.3,
        leading=19, textColor=FOREST, spaceBefore=17, spaceAfter=9,
        keepWithNext=True),
    "bullet": ParagraphStyle("GuideBullet", fontName="Guide", fontSize=9.4,
        leading=14.6, textColor=FOREST, leftIndent=12, firstLineIndent=-10,
        spaceAfter=7),
    "code": ParagraphStyle("GuideCode", fontName="GuideMono", fontSize=7.4,
        leading=12, backColor=colors.HexColor("#eaf0e4"), borderPadding=10,
        textColor=FOREST, spaceBefore=5, spaceAfter=14),
    "title": ParagraphStyle("GuideTitle", fontName="GuideBold", fontSize=34,
        leading=42, textColor=FOREST, spaceAfter=22),
    "subtitle": ParagraphStyle("GuideSubtitle", fontName="Guide", fontSize=12,
        leading=19, textColor=MUTED, spaceAfter=17),
    "eyebrow": ParagraphStyle("GuideEyebrow", fontName="GuideBold", fontSize=8.5,
        leading=13, textColor=MUTED, spaceAfter=18),
}


def inline(text):
    text = escape(text)
    return re.sub(r"\*\*(.+?)\*\*", r"<b>\1</b>", text)


def content(lines):
    story, paragraph, code = [], [], None
    def flush():
        if paragraph:
            story.append(Paragraph(inline(" ".join(paragraph)), STYLES["body"]))
            paragraph.clear()
    for line in lines:
        if line.startswith("```"):
            flush()
            if code is None:
                code = []
            else:
                story.append(Preformatted("\n".join(code), STYLES["code"]))
                code = None
            continue
        if code is not None:
            code.append(line)
            continue
        if line.startswith("### "):
            flush()
            story.append(Paragraph(inline(line[4:]), STYLES["section"]))
        elif line.startswith("- "):
            flush()
            story.append(Paragraph("•  " + inline(line[2:]), STYLES["bullet"]))
        elif not line.strip():
            flush()
        elif not line.startswith("#"):
            paragraph.append(line.strip())
    flush()
    return story


def build(source, filename, short_title, cover_title, summary):
    doc = BaseDocTemplate(str(OUT / filename), pagesize=A4,
        leftMargin=MARGIN, rightMargin=MARGIN, topMargin=82, bottomMargin=61,
        title=f"RTR Digital — {short_title}", author="RTR Digital",
        subject="India-based digital commerce; USD; sole seller and licensor RTR Digital")
    doc.short_title = short_title
    doc.addPageTemplates(PageTemplate(id="guide", onPage=decorate,
        frames=[Frame(MARGIN, 61, WIDTH - 2 * MARGIN, HEIGHT - 143,
            leftPadding=0, rightPadding=0, topPadding=0, bottomPadding=0)]))
    story = [Spacer(1, 85),
        Paragraph("OWNER'S GUIDE / 24 OCTOBER 2026", STYLES["eyebrow"]),
        Paragraph(cover_title, STYLES["title"]),
        Paragraph(summary, STYLES["subtitle"]),
        Spacer(1, 25),
        Paragraph("One brand. Every digital possibility.", STYLES["section"]),
        Paragraph("RTR Digital is the sole seller and licensor. Built for an India-based business selling digital products globally in USD.", STYLES["body"]),
        Spacer(1, 14),
        Paragraph("Includes practical setup steps, account changes, operating boundaries and recovery guidance. Use alongside the complete project ZIP.", STYLES["body"]),
        PageBreak()]
    lines = (ROOT / "docs" / source).read_text().splitlines()
    story.extend(content(lines))
    doc.build(story)
    print(OUT / filename)


if __name__ == "__main__":
    build("DEPLOYMENT_GUIDE.md", "RTR_Digital_Deployment_Guide.pdf",
        "Deployment & operations", "From project<br/>to production.",
        "Install, configure, publish your original products, protect private data and operate your digital store.")
    build("PAYMENTS_GUIDE.md", "RTR_Digital_Payments_and_Bank_Setup_Guide.pdf",
        "Payments & bank setup", "Payments that<br/>reach your business.",
        "Configure Stripe, PayPal, Razorpay and wire transfers. Update accounts, verify funds and manage refunds.")
