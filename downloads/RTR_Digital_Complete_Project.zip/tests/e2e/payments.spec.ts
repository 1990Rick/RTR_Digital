import { expect, test } from '@playwright/test';
import type { APIResponse, BrowserContext, Locator, Page } from '@playwright/test';
import { randomUUID } from 'node:crypto';
import { readFile } from 'node:fs/promises';

const password = 'Payment-Browser-2026!';
const unique = () => randomUUID().slice(0, 8);
const bankFixture = (suffix = unique()) => ({
  beneficiary: `RTR Browser Fixture ${suffix}`,
  bankName: `Synthetic Receiving Bank ${suffix}`,
  accountNumber: `TEST-ONLY-${suffix}-0147`,
  swift: 'TESTINBBXXX',
  ifsc: 'TEST0000147',
  bankAddress: 'Synthetic branch, Mumbai, India',
  beneficiaryAddress: 'Synthetic merchant address, India',
  intermediaryBank: 'Synthetic correspondent · TESTUS33',
  instructions: 'Browser test fixture only. Use the order reference and send the exact USD total.',
});

async function data(response: APIResponse) {
  expect(response.ok(), await response.text()).toBeTruthy();
  return response.json();
}

async function localOnly(context: BrowserContext) {
  // Payment journeys must never contact a provider or a real bank.
  await context.route(/^https?:\/\//, route => {
    const url = new URL(route.request().url());
    return ['127.0.0.1', 'localhost'].includes(url.hostname)
      ? route.continue()
      : route.abort('blockedbyclient');
  });
}

async function register(page: Page, name: string) {
  await data(await page.request.post('/api/auth/register', {
    data: { name, email: `payment-${unique()}@example.test`, password },
  }));
}

async function paymentOffice(page: Page) {
  await page.goto('/operations');
  await page.getByRole('button', { name: 'Payment connections', exact: true }).click();
  await expect(page.getByRole('heading', { name: 'Your receiving account.', exact: true })).toBeVisible();
}

async function saveBank(page: Page, bank: ReturnType<typeof bankFixture>) {
  const enabled = page.getByRole('checkbox', { name: 'Offer bank transfer', exact: true });
  if (!await enabled.isChecked()) await page.getByText('Offer bank transfer', { exact: true }).click();
  await expect(enabled).toBeChecked();
  for (const [field, value] of Object.entries(bank)) {
    await page.locator(`[name="bank.${field}"]`).fill(value);
  }
  const saved = page.waitForResponse(response =>
    response.url().endsWith('/api/admin/payments/settings') && response.request().method() === 'PATCH');
  await page.getByRole('button', { name: 'Save payment settings', exact: true }).click();
  await data(await saved);
  await expect(page.locator('[name="bank.bankName"]')).toHaveValue(bank.bankName);
  await expect(page.locator('[name="bank.accountNumber"]')).toHaveValue('');
  const settings = await data(await page.request.get('/api/admin/payments'));
  expect(settings.bank.accountNumber).not.toContain(bank.accountNumber);
  expect(settings.bank.accountNumber).toContain('0147');
  return settings.bank.version as number;
}

async function productCheckout(page: Page, title: string) {
  await page.goto('/explore');
  await page.getByRole('textbox', { name: 'Search the collection', exact: true }).fill(title);
  await page.getByRole('button', { name: `View ${title}`, exact: true }).click();
  await page.getByRole('dialog').getByRole('button', { name: 'Add to bag', exact: true }).click();
  await page.getByRole('dialog').getByRole('button', { name: 'Close dialog', exact: true }).click();
  await page.getByRole('button', { name: 'Shopping bag, 1 items', exact: true }).click();
  await page.getByRole('button', { name: 'Make them yours', exact: true }).click();
}

async function startWire(page: Page) {
  const checkout = page.getByRole('dialog', { name: 'Your next chapter starts here' });
  await checkout.getByRole('radio', { name: /Pay by bank transfer/ }).check();
  await checkout.getByRole('checkbox').check();
  const created = page.waitForResponse(response =>
    response.url().endsWith('/api/payments/checkout') && response.request().method() === 'POST');
  await checkout.getByRole('button', { name: 'Get bank transfer instructions', exact: true }).click();
  const payment = await data(await created);
  await expect(page).toHaveURL(`/billing?payment=${payment.id}`);
  await expect(page.locator('.pay-detail .pay-status')).toHaveText('Awaiting cleared funds');
  return payment;
}

async function noGrant(page: Page, productId: string) {
  expect((await page.request.get(`/api/download/${productId}`)).status()).toBe(403);
  expect((await data(await page.request.get('/api/billing/orders'))).orders).toHaveLength(0);
}

async function reviewTransfer(admin: Page, id: string) {
  await paymentOffice(admin);
  const transfer = admin.locator('.pay-transfer').filter({ has: admin.locator('code', { hasText: id }) });
  await expect(transfer).toHaveCount(1);
  await transfer.getByRole('button', { name: 'Review transfer', exact: true }).click();
  return transfer;
}

async function clearTransfer(transfer: Locator, amount: number, reference: string) {
  await transfer.getByLabel('Cleared amount received (USD)', { exact: true }).fill(amount.toFixed(2));
  await transfer.getByLabel('Unique bank statement reference', { exact: true }).fill(reference);
  await transfer.getByRole('checkbox', { name: /I checked RTR Digital’s bank statement/ }).check();
  await transfer.getByRole('button', { name: 'Record demo cleared payment', exact: true }).click();
  await expect(transfer).toHaveCount(0);
}

async function fitsViewport(page: Page) {
  const dimensions = await page.evaluate(() => ({
    width: innerWidth,
    document: document.documentElement.scrollWidth,
    body: document.body.scrollWidth,
  }));
  expect(dimensions.document, JSON.stringify(dimensions)).toBeLessThanOrEqual(dimensions.width);
  expect(dimensions.body, JSON.stringify(dimensions)).toBeLessThanOrEqual(dimensions.width);
}

test('bank transfer reporting stays pending, preserves bank snapshots, and delivers exact bytes only after reconciliation', async ({ page: admin, browser }) => {
  test.setTimeout(90_000);
  await localOnly(admin.context());
  await data(await admin.request.post('/api/auth/demo', { data: { role: 'admin' } }));
  await paymentOffice(admin);
  const originalBank = bankFixture();
  const originalVersion = await saveBank(admin, originalBank);
  const title = `Wire Original Field Notes ${unique()}`;
  const bytes = Buffer.from(`Original wire browser fixture ${unique()}\nExact UTF-8 delivery: curiosity → possibility.\n`);
  const uploaded = await data(await admin.request.post('/api/admin/products', {
    multipart: {
      title,
      description: 'Original field notes for a complete browser bank-transfer delivery journey.',
      category: 'E-books', price: '12.50', status: 'published', subscriptionIncluded: 'true',
      file: { name: 'wire-original-notes.txt', mimeType: 'text/plain', buffer: bytes },
    },
  }));
  const productId = uploaded.product.id as string;
  const buyerContext = await browser.newContext({ baseURL: 'http://127.0.0.1:3081' });
  const nextContext = await browser.newContext({ baseURL: 'http://127.0.0.1:3081' });
  try {
    await localOnly(buyerContext);
    await localOnly(nextContext);
    const buyer = await buyerContext.newPage();
    await register(buyer, 'Wire Browser Buyer');
    await productCheckout(buyer, title);
    const pending = await startWire(buyer);
    expect(pending.total).toBe(12.5);
    expect(pending.recurring).toBe(false);
    const instructions = buyer.locator('.pay-bank-instructions');
    await expect(instructions).toContainText(originalBank.accountNumber);
    await expect(instructions).toContainText(originalBank.bankName);
    await expect(instructions).toContainText(pending.reference);
    await noGrant(buyer, productId);
    await buyer.getByRole('button', { name: 'Report a bank transfer', exact: true }).click();
    const reportedReference = `CUSTOMER-UNVERIFIED-${unique()}`;
    await buyer.getByLabel('Bank transfer reference', { exact: true }).fill(reportedReference);
    await buyer.getByLabel('Transfer note', { exact: false }).fill('Synthetic customer report; cleared funds are not yet verified.');
    await buyer.getByRole('button', { name: 'Submit transfer details', exact: true }).click();
    await expect(buyer.locator('.pay-reported')).toContainText('payment remains pending');
    await noGrant(buyer, productId);
    await buyer.goto('/library');
    await expect(buyer.getByRole('button', { name: `Download ${title}`, exact: true })).toHaveCount(0);

    const changedBank = bankFixture();
    const changedVersion = await saveBank(admin, changedBank);
    expect(changedVersion).toBeGreaterThan(originalVersion);
    await buyer.goto(`/billing?payment=${pending.id}`);
    await expect(buyer.locator('.pay-bank-instructions')).toContainText(originalBank.accountNumber);
    await expect(buyer.locator('.pay-bank-instructions')).not.toContainText(changedBank.accountNumber);
    const nextBuyer = await nextContext.newPage();
    await register(nextBuyer, 'New Bank Browser Buyer');
    await productCheckout(nextBuyer, title);
    const next = await startWire(nextBuyer);
    expect(next.bank.version).toBe(changedVersion);
    await expect(nextBuyer.locator('.pay-bank-instructions')).toContainText(changedBank.accountNumber);
    await noGrant(nextBuyer, productId);

    const transfer = await reviewTransfer(admin, pending.id);
    await expect(transfer).toContainText(reportedReference);
    await expect(transfer).toContainText(originalBank.bankName);
    await expect(transfer).toContainText(`v${originalVersion}`);
    await transfer.getByLabel('Cleared amount received (USD)', { exact: true }).fill('12.49');
    const bankReference = `BANK-CLEARED-${unique()}`;
    await transfer.getByLabel('Unique bank statement reference', { exact: true }).fill(bankReference);
    await transfer.getByRole('checkbox', { name: /I checked RTR Digital’s bank statement/ }).check();
    await transfer.getByRole('button', { name: 'Record demo cleared payment', exact: true }).click();
    await expect(transfer.getByRole('alert')).toContainText('exact USD amount');
    await noGrant(buyer, productId);
    await clearTransfer(transfer, 12.5, bankReference);
    await buyer.getByRole('button', { name: 'Refresh transfer status', exact: true }).click();
    await expect(buyer.locator('.pay-detail .pay-status')).toHaveText('Paid');
    await expect(buyer.locator('.pay-bank-instructions')).toHaveCount(0);
    await buyer.getByRole('button', { name: 'Open your library', exact: true }).click();
    const downloading = buyer.waitForEvent('download');
    await buyer.getByRole('button', { name: `Download ${title}`, exact: true }).click();
    expect(await readFile((await (await downloading).path())!)).toEqual(bytes);
    await noGrant(nextBuyer, productId);

    await buyer.goto('/billing');
    const order = buyer.locator('.co-order').filter({ hasText: pending.id });
    await expect(order).toContainText(title);
    await expect(order).toContainText('$12.50');
    const popup = buyer.waitForEvent('popup');
    await order.getByRole('link', { name: 'Open payment receipt', exact: true }).click();
    const receipt = await popup;
    await expect(receipt.locator('body')).toContainText('DEMONSTRATION — no money was charged.');
    await expect(receipt.locator('body')).toContainText('Total $12.50 USD');
    await expect(receipt.locator('body')).toContainText('Seller: RTR Digital');
    await expect(receipt.locator('body')).toContainText(title);
    await receipt.close();
    const orders = (await data(await buyer.request.get('/api/billing/orders'))).orders;
    expect(orders).toHaveLength(1);
    expect(orders[0].mode).toBe('demo');

    const errors: string[] = [];
    admin.on('pageerror', error => errors.push(error.message));
    buyer.on('pageerror', error => errors.push(error.message));
    await admin.setViewportSize({ width: 390, height: 844 });
    await paymentOffice(admin);
    await expect(admin.getByRole('button', { name: 'Save payment settings', exact: true })).toBeVisible();
    await fitsViewport(admin);
    await buyer.setViewportSize({ width: 390, height: 844 });
    await buyer.goto('/billing');
    await expect(buyer.locator('.co-order')).toContainText(title);
    await expect(buyer.getByRole('heading', { name: 'Payment activity', exact: true })).toBeVisible();
    await fitsViewport(buyer);
    expect(errors).toEqual([]);
  } finally {
    await data(await admin.request.patch(`/api/admin/products/${productId}`, { data: { status: 'draft' } }));
    await data(await admin.request.patch('/api/admin/payments/settings', { data: { bank: { enabled: false } } }));
    await buyerContext.close();
    await nextContext.close();
  }
});

test('a reconciled yearly wire membership grants one fixed term without renewal or automatic plan changes', async ({ page: admin, browser }) => {
  test.setTimeout(65_000);
  await localOnly(admin.context());
  await data(await admin.request.post('/api/auth/demo', { data: { role: 'admin' } }));
  await paymentOffice(admin);
  const bank = bankFixture();
  await saveBank(admin, bank);
  const context = await browser.newContext({ baseURL: 'http://127.0.0.1:3081' });
  try {
    await localOnly(context);
    const member = await context.newPage();
    await register(member, 'Prepaid Browser Member');
    await member.goto('/membership');
    await member.getByRole('button', { name: /Yearly/ }).click();
    await member.getByRole('button', { name: 'Choose Creator', exact: true }).click();
    const checkout = member.getByRole('dialog', { name: 'Your next chapter starts here' });
    await checkout.getByRole('radio', { name: /Pay by bank transfer/ }).check();
    await expect(checkout.getByText('Yearly membership · prepaid for one year', { exact: true })).toBeVisible();
    await expect(checkout.getByText('Fixed term. No automatic renewal or automatic charges.', { exact: true })).toBeVisible();
    const pending = await startWire(member);
    expect(pending.total).toBe(180);
    expect(pending.recurring).toBe(false);
    expect((await data(await member.request.get('/api/auth/me'))).user.subscription).toBeNull();
    await expect(member.locator('.pay-detail')).toContainText('Prepaid one year · no automatic renewal');
    const transfer = await reviewTransfer(admin, pending.id);
    await clearTransfer(transfer, 180, `PREPAID-BANK-${unique()}`);
    await member.getByRole('button', { name: 'Refresh transfer status', exact: true }).click();
    await expect(member.locator('.pay-detail .pay-status')).toHaveText('Paid');
    await member.getByRole('button', { name: 'Open your library', exact: true }).click();
    await member.getByRole('button', { name: 'Membership', exact: true }).click();
    const current = member.locator('.account-current-plan');
    await expect(current).toContainText('Prepaid membership · no automatic renewal');
    await expect(current).toContainText('Yearly · paid once');
    await expect(current).toContainText('Your purchased term expires automatically');
    await expect(member.getByRole('button', { name: 'Cancel renewal', exact: true })).toHaveCount(0);
    await expect(member.getByRole('button', { name: 'Keep my membership', exact: true })).toHaveCount(0);
    await expect(member.getByRole('combobox', { name: 'Change membership plan', exact: true })).toHaveCount(0);
    const subscription = (await data(await member.request.get('/api/auth/me'))).user.subscription;
    expect(subscription).toMatchObject({ plan: 'creator', interval: 'yearly', mode: 'demo', isPrepaid: true, autoRenew: false, cancelAtPeriodEnd: true, stripeSubscriptionId: null });
    const days = (Date.parse(subscription.currentPeriodEnd) - Date.now()) / 86_400_000;
    expect(days).toBeGreaterThan(364);
    expect(days).toBeLessThan(367);
    await member.reload();
    await member.getByRole('button', { name: 'Membership', exact: true }).click();
    await expect(member.locator('.account-current-plan')).toContainText('Prepaid membership · no automatic renewal');
    expect((await data(await member.request.get('/api/auth/me'))).user.subscription.currentPeriodEnd).toBe(subscription.currentPeriodEnd);
  } finally {
    await data(await admin.request.patch('/api/admin/payments/settings', { data: { bank: { enabled: false } } }));
    await context.close();
  }
});
