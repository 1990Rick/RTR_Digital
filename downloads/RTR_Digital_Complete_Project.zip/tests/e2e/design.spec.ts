import { expect, test } from "@playwright/test";

test.use({ reducedMotion: "reduce" });

test("the showcase cycles automatically, pauses for interaction, and respects a manual choice", async ({
  page,
}) => {
  await page.emulateMedia({ reducedMotion: "no-preference" });
  await page.clock.install({ time: new Date("2026-10-24T12:00:00Z") });
  await page.goto("/");
  const discipline = (name: string) =>
    page.locator(".studio-scene-tabs").getByRole("button", { name, exact: true });
  const spotlight = page.locator(".studio-spotlight");
  const outsideFocus = page.getByRole("textbox", {
    name: "Search digital products",
    exact: true,
  });
  async function leaveShowcase() {
    await page.mouse.move(0, 0);
    await outsideFocus.focus();
    await expect(outsideFocus).toBeFocused();
  }

  await expect(discipline("Design")).toHaveAttribute("aria-pressed", "true");
  await expect(page.getByRole("button", { name: "Pause showcase", exact: true })).toBeVisible();
  await page.clock.pauseAt((await page.evaluate(() => Date.now())) + 1000);
  await page.getByRole("button", { name: "Pause showcase", exact: true }).click();
  await page.getByRole("button", { name: "Play showcase", exact: true }).click();
  await leaveShowcase();
  await page.clock.fastForward(7999);
  await expect(discipline("Design")).toHaveAttribute("aria-pressed", "true");
  await page.clock.fastForward(1);
  await expect(discipline("Listen")).toHaveAttribute("aria-pressed", "true");
  await expect(spotlight).toContainText("Ambient Essentials Vol. 01");

  await page.getByRole("button", { name: "Pause showcase", exact: true }).click();
  await expect(page.getByRole("button", { name: "Play showcase", exact: true })).toBeVisible();
  await leaveShowcase();
  await page.clock.fastForward(16000);
  await expect(discipline("Listen")).toHaveAttribute("aria-pressed", "true");

  await page.getByRole("button", { name: "Play showcase", exact: true }).click();
  await expect(page.getByRole("button", { name: "Pause showcase", exact: true })).toBeVisible();
  await leaveShowcase();
  await page.clock.fastForward(8000);
  await expect(discipline("Build")).toHaveAttribute("aria-pressed", "true");
  await expect(spotlight).toContainText("Dev Toolkit Pro");

  await page.locator(".studio-stage").hover();
  await page.clock.fastForward(16000);
  await expect(discipline("Build")).toHaveAttribute("aria-pressed", "true");
  await page.getByRole("button", { name: "Pause showcase", exact: true }).focus();
  await page.mouse.move(0, 0);
  await page.clock.fastForward(8000);
  await expect(discipline("Build")).toHaveAttribute("aria-pressed", "true");
  await leaveShowcase();
  await page.clock.fastForward(8000);
  await expect(discipline("Design")).toHaveAttribute("aria-pressed", "true");

  await discipline("Listen").click();
  await expect(page.getByRole("button", { name: "Play showcase", exact: true })).toBeVisible();
  await leaveShowcase();
  await page.clock.fastForward(16000);
  await expect(discipline("Listen")).toHaveAttribute("aria-pressed", "true");
  await expect(spotlight).toContainText("Ambient Essentials Vol. 01");
});

test("creative disciplines open their own products and home search carries the query into the catalog", async ({
  page,
}) => {
  await page.goto("/");
  const spotlight = page.locator(".studio-spotlight");
  for (const { discipline, title } of [
    { discipline: "Design", title: "The Studio Brand Kit" },
    { discipline: "Listen", title: "Ambient Essentials Vol. 01" },
    { discipline: "Build", title: "Dev Toolkit Pro" },
  ]) {
    const choice = page
      .locator(".studio-scene-tabs")
      .getByRole("button", { name: discipline, exact: true });
    await choice.focus();
    await choice.press("Enter");
    await expect(choice).toHaveAttribute("aria-pressed", "true");
    await expect(spotlight).toContainText(title);
    await spotlight.focus();
    await spotlight.press("Enter");
    const product = page.getByRole("dialog", { name: title, exact: true });
    await expect(product).toBeVisible();
    await expect(
      product.getByRole("button", { name: "Add to bag", exact: true }),
    ).toBeEnabled();
    await page.keyboard.press("Escape");
    await expect(product).toBeHidden();
    await expect(spotlight).toBeFocused();
  }

  const homeSearch = page.getByRole("textbox", {
    name: "Search digital products",
    exact: true,
  });
  await homeSearch.fill("deep work");
  await homeSearch.press("Enter");
  await expect(page).toHaveURL("/explore");
  await expect(
    page.getByRole("textbox", { name: "Search the collection", exact: true }),
  ).toHaveValue("deep work");
  await expect(page.locator(".product-card .product-title")).toHaveText([
    "The Art of Deep Work",
  ]);

  const searchButton = page.getByRole("button", {
    name: "Search products",
    exact: true,
  });
  for (const shortcut of ["Control+k", "Meta+k"]) {
    await searchButton.focus();
    await page.keyboard.press(shortcut);
    const searchDialog = page.getByRole("dialog", {
      name: "Find your next favorite",
      exact: true,
    });
    await expect(searchDialog).toBeVisible();
    await expect(
      searchDialog.getByRole("textbox", {
        name: "Search products",
        exact: true,
      }),
    ).toHaveValue("deep work");
    await page.keyboard.press("Escape");
    await expect(searchDialog).toBeHidden();
    await expect(searchButton).toBeFocused();
  }
});

test("billing switches actual plan totals and curated edits preserve the selected category when browsing", async ({
  page,
}) => {
  await page.goto("/");
  const billing = page.getByRole("group", {
    name: "Membership billing interval",
    exact: true,
  });
  const prices = page.locator(".studio-plan-price strong");
  await expect(
    billing.getByRole("button", { name: "Monthly", exact: true }),
  ).toHaveAttribute("aria-pressed", "true");
  await expect(prices).toHaveText(["$9", "$19", "$39"]);
  await billing.getByRole("button", { name: /Yearly/ }).click();
  await expect(billing.getByRole("button", { name: /Yearly/ })).toHaveAttribute(
    "aria-pressed",
    "true",
  );
  await expect(prices).toHaveText(["$84", "$180", "$372"]);
  await expect(page.locator(".studio-plan-price > span")).toHaveText([
    "/ year",
    "/ year",
    "/ year",
  ]);
  await billing.getByRole("button", { name: "Monthly", exact: true }).click();
  await expect(prices).toHaveText(["$9", "$19", "$39"]);

  await page
    .getByRole("button", { name: "All collections", exact: true })
    .click();
  await expect(page).toHaveURL("/collections");
  const selection = page.locator("#se-edit-selection");
  const filters = selection.getByRole("group", {
    name: "Filter selected products by category",
    exact: true,
  });
  const learning = page.getByRole("button", {
    name: "View the learning edit",
    exact: true,
  });
  await learning.focus();
  await learning.press("Enter");
  await expect(learning).toHaveAttribute("aria-pressed", "true");
  await expect(selection.locator(".product-card .product-title")).toHaveText([
    "The Art of Deep Work",
    "The Creative Business Playbook",
    "Make Something for the Web",
  ]);
  const ebooks = filters.getByRole("button", { name: "E-books", exact: true });
  await ebooks.focus();
  await ebooks.press("Space");
  await expect(ebooks).toHaveAttribute("aria-pressed", "true");
  await expect(selection.locator(".product-card .product-title")).toHaveText([
    "The Art of Deep Work",
    "The Creative Business Playbook",
  ]);
  await expect(selection.locator(".product-category")).toHaveText([
    "E-books",
    "E-books",
  ]);

  await selection
    .getByRole("button", { name: "All collections", exact: true })
    .click();
  await expect(learning).toHaveAttribute("aria-pressed", "false");
  await expect(
    filters.getByRole("button", { name: "All picks", exact: true }),
  ).toHaveAttribute("aria-pressed", "true");
  await expect(selection.locator(".product-card")).toHaveCount(4);
  await expect(
    filters.getByRole("button", { name: "Software", exact: true }),
  ).toBeVisible();
  await page
    .getByRole("button", { name: "View the audio edit", exact: true })
    .click();
  await expect(selection.locator(".product-card .product-title")).toHaveText([
    "Ambient Essentials Vol. 01",
    "Mindful Mornings",
  ]);
  await selection
    .getByRole("button", { name: "Explore audio & music", exact: true })
    .click();
  await expect(page).toHaveURL("/explore");
  await expect(
    page
      .locator(".category-row")
      .getByRole("button", { name: "Audio & music", exact: true }),
  ).toHaveAttribute("aria-pressed", "true");
  await expect(page.locator(".product-card")).toHaveCount(2);
  for (const title of ["Ambient Essentials Vol. 01", "Mindful Mornings"]) {
    await expect(
      page.getByRole("button", { name: `View ${title}`, exact: true }),
    ).toBeVisible();
  }
});

test("public pages fit mobile and tablet screens, and reduced motion keeps the hero still under the pointer", async ({
  page,
}) => {
  const errors: string[] = [];
  page.on("pageerror", (error) => errors.push(error.message));
  await page.goto("/");
  await expect(
    page.getByRole("button", {
      name: "Automatic showcase disabled for reduced motion",
      exact: true,
    }),
  ).toBeDisabled();
  const artwork = page.locator(".studio-design-scene > img");
  await expect(artwork).toBeVisible();
  const transformBefore = await artwork.evaluate(
    (element) => getComputedStyle(element).transform,
  );
  const stage = await page.locator(".studio-stage").boundingBox();
  expect(stage).not.toBeNull();
  await page.mouse.move(
    stage!.x + stage!.width * 0.85,
    stage!.y + stage!.height * 0.25,
  );
  await expect
    .poll(() =>
      artwork.evaluate((element) => getComputedStyle(element).transform),
    )
    .toBe(transformBefore);

  for (const viewport of [
    { width: 390, height: 844 },
    { width: 768, height: 1024 },
  ]) {
    await page.setViewportSize(viewport);
    for (const path of [
      "/",
      "/explore",
      "/membership",
      "/collections",
      "/about",
      "/support",
    ]) {
      await page.goto(path);
      await expect(page.getByRole("heading", { level: 1 })).toBeVisible();
      await page.evaluate(() => document.fonts.ready);
      await expect
        .poll(
          () =>
            page.evaluate(
              () => document.documentElement.scrollWidth <= window.innerWidth,
            ),
          { message: `Horizontal overflow at ${viewport.width}px on ${path}` },
        )
        .toBe(true);
    }
  }
  expect(errors).toEqual([]);
});
