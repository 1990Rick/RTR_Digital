import { expect, test } from '@playwright/test';
import type { Browser, Page } from '@playwright/test';
import { createHash, createHmac } from 'node:crypto';
import { readFile } from 'node:fs/promises';

const password = 'Creative-Account-2026!';
const email = () => `expanded-${Date.now()}-${Math.random().toString(36).slice(2, 8)}@example.test`;
const apiData = async (response: Awaited<ReturnType<Page['request']['get']>>) => {
  expect(response.ok(), await response.text()).toBeTruthy();
  return response.json();
};
async function account(page: Page, name = 'Expanded Creative', address = email()) {
  await apiData(await page.request.post('/api/auth/register', { data: { name, email: address, password } }));
  return address;
}
async function admin(page: Page) {
  await apiData(await page.request.post('/api/auth/demo', { data: { role: 'admin' } }));
}
async function logout(page: Page) {
  await page.getByRole('button', { name: 'Open account menu', exact: true }).click();
  await page.getByRole('button', { name: 'Sign out', exact: true }).click();
  await expect(page.locator('.site-header .sign-in-button')).toBeVisible();
}
async function login(page: Page, address: string, pass = password) {
  await page.locator('.site-header .sign-in-button').click();
  const dialog = page.getByRole('dialog');
  await dialog.getByLabel('Email address', { exact: true }).fill(address);
  await dialog.getByLabel('Password', { exact: true }).fill(pass);
  await dialog.getByRole('button', { name: 'Welcome back', exact: true }).click();
}
async function expectFitsViewport(page: Page, route: string) {
  const layout = await page.evaluate(() => ({
    width: innerWidth,
    scrollWidth: document.documentElement.scrollWidth,
    overflowing: [...document.querySelectorAll('main *')]
      .filter(element => element.getBoundingClientRect().right > innerWidth + 1)
      .map(element => ({
        tag: element.tagName,
        className: element.getAttribute('class'),
        right: element.getBoundingClientRect().right,
      }))
      .slice(0, 12),
  }));
  expect(layout.scrollWidth <= layout.width, `overflow on ${route}: ${JSON.stringify(layout)}`).toBe(true);
}
function authenticatorCode(secret: string) {
  const alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';
  let bits = '';
  for (const letter of secret) bits += alphabet.indexOf(letter).toString(2).padStart(5, '0');
  const bytes: number[] = [];
  for (let i = 0; i + 8 <= bits.length; i += 8) bytes.push(parseInt(bits.slice(i, i + 8), 2));
  const counter = Buffer.alloc(8);
  counter.writeBigUInt64BE(BigInt(Math.floor(Date.now() / 30_000)));
  const digest = createHmac('sha1', Buffer.from(bytes)).update(counter).digest();
  const offset = digest[digest.length - 1] & 15;
  return ((digest.readUInt32BE(offset) & 0x7fffffff) % 1_000_000).toString().padStart(6, '0');
}

// Every setup request uses this browser run's isolated temporary database.
// Unique registered accounts keep trials, seats, sessions, and grants independent.
test('profile, verification mailbox, consent choices, and session controls persist', async ({ page }) => {
  await account(page);
  await page.goto('/account');
  await expect(page.getByRole('heading', { name: 'A space that’s yours.', exact: true })).toBeVisible();
  await page.getByLabel('Your name', { exact: true }).fill('A More Curious Creative');
  await page.getByRole('button', { name: 'Save your details', exact: true }).click();
  await expect(page.getByLabel('Your name', { exact: true })).toHaveValue('A More Curious Creative');
  await page.getByRole('button', { name: 'Send verification', exact: true }).click();
  await page.locator('.identity-mail-list button').filter({ hasText: 'Verify your RTR Digital email' }).first().click();
  await page.getByRole('link', { name: 'Open account action', exact: true }).click();
  await page.getByRole('button', { name: 'Verify email address', exact: true }).click();
  await expect(page.locator('.identity-recovery-success')).toContainText(/verified/i);
  await page.goto('/account');
  await expect(page.getByText('Verified email', { exact: true })).toBeVisible();
  await page.getByRole('button', { name: /^Notifications/ }).click();
  const updates = page.getByRole('checkbox', { name: 'New finds & product updates', exact: true });
  await expect(updates).toBeChecked();
  await updates.click();
  await expect.poll(async () => (await apiData(await page.request.get('/api/account/settings'))).preferences.productUpdates).toBe(false);
  await expect(updates).not.toBeChecked();
  const newsletter = page.getByRole('checkbox', { name: 'A little creative inspiration', exact: true });
  await expect(newsletter).not.toBeChecked();
  await newsletter.click();
  await expect.poll(async () => (await apiData(await page.request.get('/api/account/settings'))).preferences.newsletter).toBe(true);
  await expect(newsletter).toBeChecked();
  await page.reload();
  await page.getByRole('button', { name: /^Notifications/ }).click();
  await expect(updates).not.toBeChecked();
  await expect(newsletter).toBeChecked();
  await page.getByRole('button', { name: 'Sessions', exact: true }).click();
  await expect(page.getByText('This browser', { exact: true })).toBeVisible();
  await page.getByRole('button', { name: 'Sign out other sessions', exact: true }).click();
  await expect(page.getByText('This browser', { exact: true })).toBeVisible();
});

test('recovery links reset a password once, and authenticator sign-in requires its second factor', async ({ page, browser }) => {
  test.setTimeout(70_000);
  const address = await account(page, 'Security Creative');
  const other = await browser.newContext({ baseURL: 'http://127.0.0.1:3081' });
  try {
    await apiData(await other.request.post('/api/auth/login', { data: { email: address, password } }));
    await page.goto('/account');
    await logout(page);
    await page.locator('.site-header .sign-in-button').click();
    await page.getByRole('button', { name: 'Forgot your password?', exact: true }).click();
    await page.getByRole('dialog').getByLabel('Email address', { exact: true }).fill(address);
    await page.getByRole('button', { name: 'Request recovery link', exact: true }).click();
    await expect(page.locator('.identity-recovery-success')).toBeVisible();
    const settings = await apiData(await other.request.get('/api/account/settings'));
    const message = settings.mail.messages.find((item: { subject: string }) => /reset|recover/i.test(item.subject));
    expect(message).toBeTruthy();
    const mail = await apiData(await other.request.get(`/api/account/mail/${message.id}`));
    const action = mail.message.body.match(/https?:\/\/\S+/)?.[0];
    expect(action).toBeTruthy();
    const url = new URL(action);
    await page.goto(url.pathname + url.search);
    const fresh = 'A-fresh-creative-password-2026!';
    await page.getByLabel('New password', { exact: true }).fill(fresh);
    await page.getByLabel('Confirm new password', { exact: true }).fill(fresh);
    await page.getByRole('button', { name: 'Save new password', exact: true }).click();
    await expect(page.locator('.identity-recovery-success')).toContainText(/reset/i);
    const replay = await page.request.post('/api/auth/reset-password', { data: { token: url.searchParams.get('token'), password: fresh } });
    expect(replay.status()).toBe(400);
    await page.goto('/');
    await login(page, address, fresh);
    await expect(page.getByRole('button', { name: 'Open account menu', exact: true })).toBeVisible();
    await page.goto('/account');
    await page.getByRole('button', { name: 'Security', exact: true }).click();
    await page.getByLabel('Confirm your password', { exact: true }).fill(fresh);
    await page.getByRole('button', { name: 'Set up authenticator', exact: true }).click();
    const secret = (await page.locator('.identity-mfa-setup > code').textContent())!.trim();
    await page.getByLabel('Six-digit authenticator code', { exact: true }).fill(authenticatorCode(secret));
    await page.getByRole('button', { name: 'Confirm authenticator', exact: true }).click();
    await expect(page.getByText('Two-factor authentication enabled', { exact: true })).toBeVisible();
    const backup = (await page.locator('.identity-recovery-codes code').first().textContent())!.trim();
    await logout(page);
    await login(page, address, fresh);
    await expect(page.getByRole('heading', { name: 'One more step. All yours.', exact: true })).toBeVisible();
    await expect(page.getByRole('button', { name: 'Open account menu', exact: true })).toBeHidden();
    await page.getByLabel('Authentication code', { exact: true }).fill(backup);
    await page.getByRole('button', { name: 'Verify & sign in', exact: true }).click();
    await expect(page.getByRole('button', { name: 'Open account menu', exact: true })).toBeVisible();
    await logout(page);
    await login(page, address, fresh);
    await page.getByLabel('Authentication code', { exact: true }).fill(backup);
    await page.getByRole('button', { name: 'Verify & sign in', exact: true }).click();
    await expect(page.getByRole('dialog').getByRole('alert')).toBeVisible();
    await expect(page.getByRole('button', { name: 'Open account menu', exact: true })).toBeHidden();
  } finally { await other.close(); }
});

test('seven-day trial grants real library access and is not offered twice', async ({ page }) => {
  await account(page, 'Trial Creative');
  await page.goto('/members');
  await expect(page.getByRole('heading', { name: 'Seven days. See what sparks.', exact: true })).toBeVisible();
  await page.getByRole('checkbox', { name: 'I understand this is a free demo preview that expires automatically.', exact: true }).check();
  await page.getByRole('button', { name: 'Start my seven-day preview', exact: true }).click();
  await expect(page.getByText('Seven-day preview', { exact: true })).toBeVisible();
  await expect(page.getByText('No automatic charge', { exact: true })).toBeVisible();
  await page.goto('/library');
  await expect(page.locator('.account-library-card')).toHaveCount(12);
  await page.goto('/members');
  await expect(page.getByRole('button', { name: 'Start my seven-day preview', exact: true })).toBeHidden();
  const again = await page.request.post('/api/membership/trial', { data: { plan: 'creator' } });
  expect(again.status()).toBe(409);
});

test('Studio invitations bind to the invited account and removing a seat revokes shared downloads', async ({ page, browser }) => {
  test.setTimeout(55_000);
  await account(page, 'Studio Owner');
  await apiData(await page.request.post('/api/checkout', { data: { mode: 'demo', plan: 'studio', interval: 'monthly' } }));
  await page.goto('/members');
  await page.getByRole('button', { name: /^Your team/ }).click();
  await page.getByLabel('Your workspace name', { exact: true }).fill('A Shared Creative Space');
  await page.getByRole('button', { name: 'Create your workspace', exact: true }).click();
  await expect(page.getByRole('heading', { name: 'A Shared Creative Space', exact: true })).toBeVisible();
  const address = email();
  await page.getByLabel('Invite a curious mind', { exact: true }).fill(address);
  await page.getByRole('button', { name: 'Create invitation', exact: true }).click();
  const privateLink = await page.getByRole('textbox', { name: 'Private invitation link', exact: true }).inputValue();
  const url = new URL(privateLink);
  const context = await browser.newContext({ baseURL: 'http://127.0.0.1:3081' });
  try {
    const teammate = await context.newPage();
    await account(teammate, 'A Different Creative');
    const wrongAccount = await teammate.request.post(`/api/membership/team/invites/${url.searchParams.get('invite')}/accept`);
    expect(wrongAccount.status()).toBe(404);
    await account(teammate, 'A Curious Teammate', address);
    await teammate.goto(url.pathname + url.search);
    await expect(teammate.getByRole('region', { name: 'Workspace invitation', exact: true })).toContainText(address);
    await teammate.getByRole('button', { name: 'Accept invitation', exact: true }).click();
    await expect(teammate.getByText('Workspace active', { exact: true })).toBeVisible();
    const before = await teammate.request.get('/api/download/ambient-essentials');
    expect(before.status()).toBe(200);
    await page.reload();
    await page.getByRole('button', { name: /^Your team/ }).click();
    await page.getByRole('button', { name: 'Remove A Curious Teammate from team', exact: true }).click();
    await page.getByRole('button', { name: 'Confirm removal', exact: true }).click();
    await expect(page.getByRole('button', { name: 'Remove A Curious Teammate from team', exact: true })).toBeHidden();
    const after = await teammate.request.get('/api/download/ambient-essentials');
    expect(after.status()).toBe(403);
    await teammate.reload();
    await teammate.getByRole('button', { name: /^Your team/ }).click();
    await expect(teammate.getByRole('heading', { name: 'Great things start with good company.', exact: true })).toBeVisible();
  } finally { await context.close(); }
});

async function customerContext(browser: Browser) {
  return browser.newContext({ baseURL: 'http://127.0.0.1:3081' });
}

test('publisher releases original bytes, previews, license keys, and learning bookmarks', async ({ page, browser }) => {
  test.setTimeout(70_000);
  await admin(page);
  await page.goto('/publisher');
  await expect(page.getByRole('heading', { name: 'The publishing studio.', exact: true })).toBeVisible();
  await page.getByRole('textbox', { name: 'Find a product to edit', exact: true }).fill('Make Something for the Web');
  await page.locator('.pub-product-option').filter({ hasText: 'Make Something for the Web' }).click();
  const productLicensor = page.getByRole('textbox', { name: 'Seller & licensor', exact: true });
  await expect(productLicensor).toHaveValue('RTR Digital');
  await expect(productLicensor).toHaveAttribute('readonly', '');
  await page.getByLabel('Discovery tags', { exact: false }).fill('Creative coding, Browser verified');
  await page.getByRole('button', { name: 'Save product details', exact: true }).click();
  await expect(page.getByLabel('Discovery tags', { exact: false })).toHaveValue('Creative coding, Browser verified');
  await page.getByRole('button', { name: 'Releases', exact: true }).click();
  const contents = Buffer.from('Original course resource. New version with complete creative coding field notes.');
  await page.getByLabel('Release version', { exact: true }).fill(`2.${Date.now()}.0`);
  await page.getByRole('button', { name: 'New release file', exact: true }).setInputFiles({ name: 'creative-course-notes.txt', mimeType: 'text/plain', buffer: contents });
  await page.getByLabel('What’s new?', { exact: true }).fill('New field notes with working examples and a creative project checklist.');
  await page.getByRole('button', { name: 'Publish this release', exact: true }).click();
  await expect(page.locator('.pub-release-history')).toContainText('New field notes');
  await expect(page.locator('.pub-release-history')).toContainText(createHash('sha256').update(contents).digest('hex'));
  await page.getByRole('button', { name: 'Preview', exact: true }).click();
  const preview = 'A public course sample: begin with curiosity, then make a little room for your next idea.';
  await page.getByRole('button', { name: 'Public product preview file', exact: true }).setInputFiles({ name: 'creative-course-preview.txt', mimeType: 'text/plain', buffer: Buffer.from(preview) });
  await page.getByRole('checkbox', { name: /I understand this preview is public/ }).check();
  await page.getByRole('button', { name: 'Save public preview', exact: true }).click();
  await expect(page.getByText('Public text preview', { exact: true })).toBeVisible();
  await page.getByRole('button', { name: 'License keys', exact: true }).click();
  const license = `RTR-E2E-PRIVATE-${Date.now()}`;
  await page.getByLabel('Private activation keys', { exact: false }).fill(license);
  await page.getByRole('button', { name: 'Add private keys', exact: true }).click();
  await expect(page.locator('.pub-license-stats')).toContainText('Available');
  const context = await customerContext(browser);
  try {
    const customer = await context.newPage();
    expect((await customer.request.get('/api/products/modern-web-masterclass/content')).status()).toBe(401);
    const sample = await customer.request.get('/api/products/modern-web-masterclass/preview');
    expect(sample.status()).toBe(200);
    expect(await sample.text()).toBe(preview);
    await account(customer, 'Learning Creative');
    expect((await customer.request.get('/api/products/modern-web-masterclass/content')).status()).toBe(403);
    await apiData(await customer.request.post('/api/checkout', { data: { mode: 'demo', productIds: ['modern-web-masterclass'] } }));
    await customer.goto('/library');
    await customer.getByRole('button', { name: 'View Make Something for the Web', exact: true }).click();
    const dialog = customer.getByRole('dialog');
    await expect(dialog.locator('.exp-text-preview')).toHaveText(contents.toString());
    await expect(dialog.locator('.exp-preview-label')).toContainText('YOUR FULL CONTENT');
    await dialog.getByRole('button', { name: 'Public preview', exact: true }).click();
    await expect(dialog.locator('.exp-text-preview')).toHaveText(preview);
    await dialog.getByRole('button', { name: 'Your full content', exact: true }).click();
    await expect(dialog.locator('.exp-text-preview')).toHaveText(contents.toString());
    await dialog.getByRole('textbox', { name: 'Your notes', exact: true }).fill('Start at the creative project checklist next time.');
    await dialog.getByRole('checkbox', { name: 'Mark as completed', exact: true }).check();
    await dialog.getByRole('button', { name: 'Save my place', exact: true }).click();
    await dialog.getByRole('button', { name: 'Claim my key', exact: true }).click();
    await expect(dialog.locator('.exp-license-value code')).toHaveText(license);
    const downloading = customer.waitForEvent('download');
    await dialog.getByRole('link', { name: 'Download the latest release', exact: true }).click();
    expect(await readFile((await (await downloading).path())!)).toEqual(contents);
    await dialog.getByRole('button', { name: 'Close dialog', exact: true }).click();
    await customer.reload();
    await customer.getByRole('button', { name: 'View Make Something for the Web', exact: true }).click();
    await expect(customer.getByRole('dialog').getByRole('textbox', { name: 'Your notes', exact: true })).toHaveValue('Start at the creative project checklist next time.');
    await expect(customer.getByRole('dialog').getByRole('checkbox', { name: 'Mark as completed', exact: true })).toBeChecked();
  } finally { await context.close(); }
});

test('expanded customer and administrator pages fit mobile screens without browser errors', async ({ page }) => {
  const errors: string[] = [];
  page.on('pageerror', error => errors.push(error.message));
  await page.setViewportSize({ width: 390, height: 844 });
  await account(page, 'Mobile Creative');
  for (const route of ['/account', '/members', '/billing']) {
    await page.goto(route);
    await expect(page.getByRole('heading', { level: 1 })).toBeVisible();
    await expectFitsViewport(page, route);
  }
  await admin(page);
  for (const route of ['/publisher', '/operations']) {
    await page.goto(route);
    await expect(page.getByRole('heading', { level: 1 })).toBeVisible();
    await expectFitsViewport(page, route);
  }
  expect(errors).toEqual([]);
});

test('administrator promotions price real checkout and a reviewed refund reverses the exact access grant', async ({ page, browser }) => {
  test.setTimeout(70_000);
  await admin(page);
  await page.goto('/operations');
  await expect(page.getByRole('heading', { name: 'The commerce office.', exact: true })).toBeVisible();
  await page.getByRole('button', { name: 'Seller details', exact: true }).click();
  const seller = page.getByRole('textbox', { name: 'Seller & licensor', exact: true });
  await expect(seller).toHaveValue('RTR Digital');
  await expect(seller).toHaveAttribute('readonly', '');
  await page.getByRole('button', { name: 'Promotions', exact: true }).click();
  await page.getByRole('button', { name: 'Create promotion', exact: true }).click();
  const code = `EXTRA${Date.now()}`;
  await page.getByLabel('Promotion code', { exact: true }).fill(code);
  await page.getByLabel('Discount (%)', { exact: true }).fill('25');
  await page.getByRole('combobox', { name: 'Applies to', exact: true }).selectOption('products');
  await page.getByLabel('Minimum subtotal (USD)', { exact: true }).fill('5');
  await page.getByLabel('Maximum redemptions', { exact: true }).fill('2');
  await page.getByLabel('Redemptions per account', { exact: true }).fill('1');
  await page.getByRole('button', { name: 'Save promotion', exact: true }).click();
  await expect(page.getByRole('row').filter({ hasText: code })).toContainText('25%');
  const context = await customerContext(browser);
  try {
    const customer = await context.newPage();
    const buyerName = `Refund Creative ${Date.now()}`;
    await account(customer, buyerName);
    await customer.goto('/explore');
    await customer.getByRole('textbox', { name: 'Search the collection', exact: true }).fill('Cinematic Color Collection');
    await customer.getByRole('button', { name: 'View Cinematic Color Collection', exact: true }).click();
    await customer.getByRole('dialog').getByRole('button', { name: 'Add to bag', exact: true }).click();
    await customer.getByRole('dialog').getByRole('button', { name: 'Close dialog', exact: true }).click();
    await customer.getByRole('button', { name: 'Shopping bag, 1 items', exact: true }).click();
    await customer.getByRole('button', { name: 'Make them yours', exact: true }).click();
    const checkout = customer.getByRole('dialog');
    await checkout.getByRole('textbox', { name: 'Promo code', exact: true }).fill(code);
    await checkout.getByRole('button', { name: 'Apply', exact: true }).click();
    await expect(checkout.getByText(`${code} · 25% off`, { exact: true })).toBeVisible();
    await expect(checkout.locator('.checkout-total')).toContainText('$26.25');
    await checkout.getByRole('checkbox').check();
    await checkout.getByRole('button', { name: 'Complete demo checkout', exact: true }).click();
    await expect(customer).toHaveURL('/library');
    expect((await customer.request.get('/api/download/cinematic-luts')).status()).toBe(200);
    await customer.goto('/billing');
    await expect(customer.locator('.co-order')).toContainText('$26.25');
    const receiptPromise = customer.waitForEvent('popup');
    await customer.getByRole('link', { name: 'Open payment receipt', exact: true }).click();
    const receipt = await receiptPromise;
    await expect(receipt.locator('body')).toContainText('DEMONSTRATION');
    await expect(receipt.locator('body')).toContainText('26.25 USD');
    await expect(receipt.locator('body')).toContainText('India');
    await expect(receipt.locator('body')).toContainText('Seller: RTR Digital');
    await expect(receipt.locator('body')).toContainText('Licensor: RTR Digital');
    await receipt.close();
    await customer.getByRole('button', { name: 'Request a refund', exact: true }).click();
    await customer.getByLabel('Reason for refund', { exact: true }).fill('Please review this digital purchase. This complete browser journey verifies a clear refund decision.');
    await customer.getByRole('button', { name: 'Submit refund request', exact: true }).click();
    await expect(customer.locator('.co-order-refund')).toContainText('requested');
    await page.getByRole('button', { name: 'Refresh records', exact: true }).click();
    await page.getByRole('button', { name: /^Refund requests/ }).click();
    const request = page.locator('.co-refund').filter({ hasText: buyerName });
    await expect(request).toHaveCount(1);
    await request.getByRole('button', { name: 'Review refund', exact: true }).click();
    await request.getByRole('button', { name: 'Confirm refund', exact: true }).click();
    await expect(request.locator('.co-status')).toHaveText('approved');
    await customer.getByRole('button', { name: 'Refresh orders', exact: true }).click();
    await expect(customer.locator('.co-order-refund')).toContainText('approved');
    expect((await customer.request.get('/api/download/cinematic-luts')).status()).toBe(403);
    await page.getByRole('button', { name: 'Promotions', exact: true }).click();
    await page.getByRole('row').filter({ hasText: code }).getByRole('button', { name: 'Pause', exact: true }).click();
    await expect(page.getByRole('row').filter({ hasText: code })).toContainText('disabled');
  } finally { await context.close(); }
});
