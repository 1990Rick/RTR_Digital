import { spawnSync } from "node:child_process";
import { readdirSync } from "node:fs";
import { resolve } from "node:path";
import { fileURLToPath } from "node:url";

const root = fileURLToPath(new URL("../..", import.meta.url));
const directory = fileURLToPath(new URL(".", import.meta.url));
const cli = resolve(root, "node_modules/@playwright/test/cli.js");
// Each suite gets a fresh server, database, and authentication quota. This keeps
// synthetic bank settings and registrations independent without relaxing limits.
for (const name of readdirSync(directory).filter((name) => name.endsWith(".spec.ts")).sort()) {
  const result = spawnSync(process.execPath, [cli, "test", resolve(directory, name), ...process.argv.slice(2)], {
    cwd: root,
    stdio: "inherit",
    env: process.env,
  });
  if (result.error) throw result.error;
  if (result.status !== 0) process.exit(result.status || 1);
}
