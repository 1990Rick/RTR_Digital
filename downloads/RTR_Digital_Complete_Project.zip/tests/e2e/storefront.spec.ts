import { expect, test } from '@playwright/test';
import type { Page } from '@playwright/test';
import { readFile } from 'node:fs/promises';

const uniqueEmail = () => `e2e-${Date.now()}-${Math.random().toString(36).slice(2, 8)}@example.test`;

async function createAccount(page: Page, name = 'Curious Creative') {
  const auth = page.getByRole('dialog', { name: 'Welcome to RTR Digital' });
  await auth.getByRole('button', { name: 'Create account', exact: true }).click();
  await auth.getByLabel('Your name', { exact: true }).fill(name);
  await auth.getByLabel('Email address', { exact: true }).fill(uniqueEmail());
  await auth.getByLabel('Password', { exact: true }).fill('A-creative-password-2026');
  await auth.getByRole('button', { name: 'Create your account', exact: true }).click();
}

async function completeDemoCheckout(page: Page) {
  const checkout = page.getByRole('dialog', { name: 'Your next chapter starts here' });
  await checkout.getByRole('radio', { name: /Explore with demo checkout/ }).check();
  await expect(checkout.getByText('No card. No charge. Sample content and test access only.')).toBeVisible();
  await checkout.getByRole('checkbox').check();
  await checkout.getByRole('button', { name: 'Complete demo checkout', exact: true }).click();
  await expect(page).toHaveURL('/library');
  await expect(page.getByRole('heading', { name: 'Your creative library.' })).toBeVisible();
}

async function signOut(page: Page) {
  await page.getByRole('button', { name: 'Open account menu' }).click();
  await page.getByRole('button', { name: 'Sign out', exact: true }).click();
  await expect(page.locator('.site-header .sign-in-button')).toBeVisible();
}

test('home renders original artwork without browser errors and search dialogs support keyboard access', async ({ page }) => {
  const errors: string[] = [];
  page.on('pageerror', error => errors.push(error.message));
  await page.goto('/');
  await expect(page.getByRole('heading', { level: 1 })).toContainText('Big ideas.');
  const hero = page.locator('.hero-image-wrap > img');
  await expect(hero).toBeVisible();
  await expect.poll(() => hero.evaluate(image => (image as HTMLImageElement).naturalWidth)).toBe(1000);
  await expect(page.locator('.product-card')).toHaveCount(4);
  expect(await page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth)).toBe(true);

  const searchButton = page.getByRole('button', { name: 'Search products', exact: true });
  await searchButton.click();
  const dialog = page.getByRole('dialog', { name: 'Find your next favorite' });
  await dialog.getByRole('textbox', { name: 'Search products', exact: true }).pressSequentially('deep work', { delay: 20 });
  await expect(dialog.getByRole('textbox')).toHaveValue('deep work');
  await page.keyboard.press('Escape');
  await expect(dialog).toBeHidden();
  await expect(searchButton).toBeFocused();
  await searchButton.click();
  await page.getByRole('dialog').getByRole('button', { name: 'Search', exact: true }).click();
  await expect(page).toHaveURL('/explore');
  await expect(page.locator('.product-card')).toHaveCount(1);
  await expect(page.locator('.product-card .product-title')).toHaveText('The Art of Deep Work');
  expect(errors).toEqual([]);
});

test('catalog filters, sorting, and anonymous wishlists remain useful after refresh', async ({ page }) => {
  await page.goto('/explore');
  await expect(page.locator('.product-card')).toHaveCount(12);
  await page.locator('.category-row').getByRole('button', { name: 'E-books', exact: true }).click();
  await expect(page.locator('.product-card')).toHaveCount(2);
  await page.getByRole('combobox', { name: 'Sort products' }).selectOption('low');
  await expect(page.locator('.product-card .product-title').first()).toHaveText('The Art of Deep Work');
  const first = page.locator('.product-card').first();
  await first.getByRole('button', { name: 'Save The Art of Deep Work to wishlist' }).click();
  await page.reload();
  await page.getByRole('button', { name: 'View wishlist', exact: true }).click();
  await expect(page.getByRole('heading', { level: 1 })).toHaveText('Your little list of possibilities.');
  await expect(page.locator('.product-card')).toHaveCount(1);
  await page.getByRole('button', { name: 'Filters', exact: true }).click();
  await page.getByRole('slider', { name: 'Maximum price' }).fill('10');
  await expect(page.getByRole('heading', { name: 'No finds just yet.' })).toBeVisible();
  await page.getByRole('button', { name: 'Reset filters', exact: true }).click();
  await expect(page.locator('.product-card')).toHaveCount(1);
});

test('customer buys a product, receives a real authenticated sample download, and sees the order', async ({ page }) => {
  await page.goto('/explore');
  await page.getByRole('button', { name: 'View The Studio Brand Kit', exact: true }).click();
  const product = page.getByRole('dialog', { name: 'The Studio Brand Kit' });
  await expect(product.getByText('Preview product · Download contains a labeled sample file.')).toBeVisible();
  await product.getByRole('button', { name: 'Add a little possibility', exact: true }).click();
  await product.getByRole('button', { name: 'Close dialog' }).click();
  await page.getByRole('button', { name: 'Shopping bag, 1 items', exact: true }).click();
  await page.getByRole('button', { name: 'Make them yours', exact: true }).click();
  await createAccount(page);
  const checkout = page.getByRole('dialog', { name: 'Your next chapter starts here' });
  await checkout.getByText('Pay securely with Stripe', { exact: true }).click();
  await checkout.getByRole('checkbox').check();
  await expect(checkout.getByRole('button', { name: 'Continue to secure payment', exact: true })).toBeDisabled();
  await checkout.getByText('Explore with demo checkout', { exact: true }).click();
  await checkout.getByRole('textbox', { name: 'Promo code', exact: true }).fill('INVALID');
  await checkout.getByRole('button', { name: 'Apply', exact: true }).click();
  await expect(checkout.getByRole('alert')).toHaveText('This promo code is not available.');
  await checkout.getByRole('textbox', { name: 'Promo code', exact: true }).fill('WELCOME10');
  await checkout.getByRole('button', { name: 'Apply', exact: true }).click();
  await expect(checkout.getByText('WELCOME10 · 10% off')).toBeVisible();
  await completeDemoCheckout(page);
  await expect(page.getByRole('button', { name: 'Download The Studio Brand Kit', exact: true })).toBeVisible();
  const downloadPromise = page.waitForEvent('download');
  await page.getByRole('button', { name: 'Download The Studio Brand Kit', exact: true }).click();
  const download = await downloadPromise;
  expect(await download.failure()).toBeNull();
  const content = await readFile((await download.path())!, 'utf8');
  expect(content).toContain('DEMONSTRATION DOWNLOAD');
  expect(content).toContain('The Studio Brand Kit');
  await page.getByRole('button', { name: 'Order history', exact: true }).click();
  await expect(page.getByRole('table')).toContainText('The Studio Brand Kit');
  await expect(page.getByRole('table')).toContainText('$35.10');
  await page.reload();
  await expect(page.getByRole('button', { name: 'Download The Studio Brand Kit', exact: true })).toBeVisible();
});

test('yearly and monthly membership pricing work, with cancellation and resumption preserving access', async ({ page }) => {
  await page.goto('/membership');
  await expect(page.getByText('$180 billed yearly', { exact: true })).toBeVisible();
  await page.getByRole('button', { name: 'Monthly', exact: true }).click();
  await expect(page.locator('.pricing-card').nth(1).locator('.plan-price')).toContainText('$19');
  await page.getByRole('button', { name: /Yearly/ }).click();
  await page.getByRole('button', { name: 'Choose Creator', exact: true }).click();
  await createAccount(page, 'Member Creative');
  const checkout = page.getByRole('dialog', { name: 'Your next chapter starts here' });
  await checkout.getByRole('radio', { name: /Explore with demo checkout/ }).check();
  await expect(checkout.getByText('Yearly membership · billed once per year')).toBeVisible();
  await completeDemoCheckout(page);
  await expect(page.locator('.account-library-card')).toHaveCount(12);
  await page.getByRole('button', { name: 'Membership', exact: true }).click();
  await expect(page.getByText('Yearly', { exact: true })).toBeVisible();
  await page.getByRole('button', { name: 'Cancel renewal', exact: true }).click();
  await expect(page.getByText('Ends after this billing period', { exact: true })).toBeVisible();
  await page.getByRole('button', { name: 'Keep my membership', exact: true }).click();
  await expect(page.getByRole('button', { name: 'Cancel renewal', exact: true })).toBeVisible();
  await page.getByRole('combobox', { name: 'Change membership plan', exact: true }).selectOption('starter');
  await page.getByRole('combobox', { name: 'Change billing cycle', exact: true }).selectOption('monthly');
  await page.getByRole('button', { name: 'Change demo plan', exact: true }).click();
  await expect(page.locator('.account-current-plan')).toContainText('Monthly');
  const exporting = page.waitForEvent('download');
  await page.getByRole('link', { name: 'Export my account data', exact: true }).click();
  const exported = await exporting;
  const profile = JSON.parse(await readFile((await exported.path())!, 'utf8'));
  expect(JSON.stringify(profile)).toContain('Member Creative');
  await page.getByRole('button', { name: 'Order history', exact: true }).click();
  await expect(page.getByRole('table')).toContainText('Creator membership');
  await expect(page.getByRole('table')).toContainText('$180');
});

test('administrator publishes an original file which customers can buy and download intact', async ({ page }) => {
  await page.goto('/admin');
  await page.getByRole('button', { name: 'Sign in as administrator', exact: true }).click();
  await page.getByRole('dialog').getByRole('button', { name: 'Admin workspace', exact: true }).click();
  await expect(page.getByRole('heading', { name: 'The control room.' })).toBeVisible();
  await page.getByRole('button', { name: 'Upload a product', exact: true }).click();
  const upload = page.getByRole('dialog', { name: 'Publish a possibility.' });
  const title = `Original E2E Field Notes ${Date.now()}`;
  const contents = 'RTR original field notes. Actual uploaded bytes delivered to a paying test account.';
  await upload.getByLabel('Product name', { exact: true }).fill(title);
  await upload.getByLabel('Description', { exact: true }).fill('Original creative field notes uploaded for a complete digital delivery verification.');
  await upload.getByRole('combobox', { name: 'Category', exact: true }).selectOption('E-books');
  await upload.getByLabel('Price (USD)', { exact: true }).fill('12.50');
  await upload.getByRole('combobox', { name: 'Visibility', exact: true }).selectOption('published');
  await upload.getByLabel('Choose digital product file', { exact: true }).setInputFiles({ name: 'rtr-original-notes.txt', mimeType: 'text/plain', buffer: Buffer.from(contents) });
  await upload.getByRole('button', { name: 'Add to catalog', exact: true }).click();
  await expect(upload).toBeHidden();
  await page.getByRole('textbox', { name: 'Search product catalog', exact: true }).fill(title);
  await expect(page.getByRole('table')).toContainText(title);
  await expect(page.getByRole('table')).toContainText('$12.50');
  await signOut(page);
  await page.goto('/explore');
  await page.getByRole('textbox', { name: 'Search the collection', exact: true }).fill(title);
  await expect(page.locator('.product-card')).toHaveCount(1);
  await page.getByRole('button', { name: `View ${title}`, exact: true }).click();
  await page.getByRole('dialog').getByRole('button', { name: 'Add a little possibility', exact: true }).click();
  await page.getByRole('dialog').getByRole('button', { name: 'Close dialog', exact: true }).click();
  await page.getByRole('button', { name: 'Shopping bag, 1 items', exact: true }).click();
  await page.getByRole('button', { name: 'Make them yours', exact: true }).click();
  await createAccount(page, 'Original Buyer');
  await completeDemoCheckout(page);
  const downloading = page.waitForEvent('download');
  await page.getByRole('button', { name: `Download ${title}`, exact: true }).click();
  const download = await downloading;
  expect(await readFile((await download.path())!, 'utf8')).toBe(contents);
});


test('support messages reach the administrator inbox and can be resolved', async ({ page }) => {
  const subject = `A little E2E support ${Date.now()}`;
  await page.goto('/support');
  await page.getByLabel('Email address', { exact: true }).fill(uniqueEmail());
  await page.getByLabel('What’s it about?', { exact: true }).fill(subject);
  await page.getByLabel('Your message', { exact: true }).fill('Please confirm that my support message reaches the administrator workspace.');
  await page.getByRole('button', { name: 'Send your message', exact: true }).click();
  await expect(page.getByRole('heading', { name: 'A question worth answering.' })).toBeVisible();
  await page.getByRole('textbox', { name: 'Your email address', exact: true }).fill(uniqueEmail());
  await page.getByRole('button', { name: 'Subscribe to newsletter', exact: true }).click();
  await expect(page.getByText('You’re on the list. Thank you for your curiosity.', { exact: true })).toBeVisible();
  await page.goto('/admin');
  await page.getByRole('button', { name: 'Sign in as administrator', exact: true }).click();
  await page.getByRole('dialog').getByRole('button', { name: 'Admin workspace', exact: true }).click();
  await page.getByRole('button', { name: /^Support inbox/ }).click();
  await page.getByRole('textbox', { name: 'Search support requests', exact: true }).fill(subject);
  await expect(page.locator('.account-ticket')).toHaveCount(1);
  await page.getByRole('button', { name: 'Mark resolved', exact: true }).click();
  await expect(page.getByRole('heading', { name: 'No matching conversations.' })).toBeVisible();
  await page.getByRole('button', { name: /^Resolved/ }).click();
  await expect(page.locator('.account-ticket')).toHaveCount(1);
  await page.getByRole('button', { name: 'Reopen request', exact: true }).click();
  await expect(page.getByRole('button', { name: 'Reopen request', exact: true })).toBeHidden();
  await page.locator('.account-ticket-filters').getByRole('button', { name: /^Needs attention/ }).click();
  await expect(page.locator('.account-ticket')).toContainText(subject);
});

test('mobile navigation and core pages fit a narrow screen', async ({ page }) => {
  await page.setViewportSize({ width: 390, height: 844 });
  for (const path of ['/', '/explore', '/membership', '/collections', '/support']) {
    await page.goto(path);
    await expect(page.getByRole('heading', { level: 1 })).toBeVisible();
    expect(await page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth), `overflow on ${path}`).toBe(true);
  }
  await page.goto('/');
  await page.getByRole('button', { name: 'Toggle navigation', exact: true }).click();
  const nav = page.getByRole('navigation', { name: 'Main navigation', exact: true });
  await expect(nav).toBeVisible();
  await nav.getByRole('button', { name: /Digital Pass/ }).click();
  await expect(page).toHaveURL('/membership');
  await expect(page.getByRole('heading', { level: 1 })).toContainText('Make room for');
});
