import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
export default defineConfig({
  plugins: [react()],
  server: {
    host: "0.0.0.0",
    port: 5173,
    fs: {
      deny: [
        "**/.git/**",
        "**/.env",
        "**/.env.*",
        "**/*.{crt,pem}",
        "**/data/**",
        "**/uploads/**",
        "**/upload-sessions/**",
        "**/*.sqlite",
        "**/*.sqlite-*",
        "**/.account-encryption-key",
        "**/.payment-encryption-key",
        "**/license-key-master",
      ],
    },
    proxy: { "/api": "http://127.0.0.1:3001" },
  },
  preview: { host: "0.0.0.0", port: 4173 },
});
