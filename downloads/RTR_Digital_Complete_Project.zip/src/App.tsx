import { useCallback, useEffect, useRef, useState } from "react";
import type { FormEvent, ReactNode } from "react";
import {
  ArrowRight,
  ArrowUpRight,
  BadgeCheck,
  Check,
  CheckCircle2,
  ChevronDown,
  CreditCard,
  Download,
  Heart,
  LayoutDashboard,
  Library,
  Loader2,
  LockKeyhole,
  LogOut,
  Mail,
  Menu,
  Search,
  ShieldCheck,
  ShoppingBag,
  Sparkles,
  Star,
  Trash2,
  UserRound,
  X,
} from "lucide-react";
import { api, money } from "./lib/api";
import { SELLER_NAME } from "./lib/brand";
import type { Page, Product, User } from "./lib/types";
import { Brand, ProductArt } from "./components/Brand";
import {
  ExplorePage,
  HomePage,
  MembershipPage,
  ProductCard,
} from "./components/Storefront";
import { AdminPage, LibraryPage } from "./components/AccountPanels";
import { Comparison } from "./features/Comparison";
import { AccountSettings, RecoveryForm } from "./features/AccountSettings";
import { MembershipHub } from "./features/MembershipHub";
import { PublisherStudio } from "./features/PublisherStudio";
import { ProductExperience } from "./features/ProductExperience";
import { CommerceOffice, BillingRecords } from "./features/CommerceOffice";
import { CheckoutForm, PaymentActivity } from "./features/PaymentCheckout";
import seedProducts from "../shared/catalog.json";
type Modal =
  | "search"
  | "auth"
  | "cart"
  | "checkout"
  | "product"
  | "forgot"
  | "reset"
  | "verify"
  | null;
const pathFor: Record<Page, string> = {
  home: "/",
  explore: "/explore",
  membership: "/membership",
  collections: "/collections",
  library: "/library",
  admin: "/admin",
  about: "/about",
  support: "/support",
  legal: "/policies",
  compare: "/compare",
  account: "/account",
  members: "/members",
  publisher: "/publisher",
  operations: "/operations",
  billing: "/billing",
};
const currentPage = (): Page =>
  (Object.keys(pathFor) as Page[]).find(
    (p) => pathFor[p] === location.pathname,
  ) || "home";
const readList = (key: string): string[] => {
  try {
    const x = JSON.parse(localStorage.getItem(key) || "[]");
    return Array.isArray(x) ? x.filter((v) => typeof v === "string") : [];
  } catch {
    return [];
  }
};
export default function App() {
  const [page, setPage] = useState<Page>(currentPage);
  const [modal, setModal] = useState<Modal>(null);
  const [products, setProducts] = useState<Product[]>(
    seedProducts as Product[],
  );
  const [user, setUser] = useState<User | null>(null);
  const [config, setConfig] = useState({
    demoMode: false,
    stripeConfigured: false,
  });
  const [cart, setCart] = useState<string[]>(() => readList("rtr-cart"));
  const [wishlist, setWishlist] = useState<string[]>(() =>
    readList("rtr-wishlist"),
  );
  const [selected, setSelected] = useState<Product | null>(null);
  const [initialCategory, setInitialCategory] = useState("All products");
  const [wishlistOnly, setWishlistOnly] = useState(false);
  const [search, setSearch] = useState("");
  const [menu, setMenu] = useState(false);
  const [userMenu, setUserMenu] = useState(false);
  const [toast, setToast] = useState<{ message: string; kind: string } | null>(
    null,
  );
  const [refreshKey, setRefreshKey] = useState(0);
  const [plan, setPlan] = useState<{ id: string; interval: string } | null>(
    null,
  );
  const [pendingCheckout, setPendingCheckout] = useState(false);
  const [apiError, setApiError] = useState(false);
  const notify = useCallback(
    (message: string, kind = "success") => setToast({ message, kind }),
    [],
  );
  const loadCatalog = useCallback(
    () =>
      api<{ products: Product[] }>("/catalog")
        .then((data) => {
          setProducts(data.products);
          setApiError(false);
        })
        .catch(() => setApiError(true)),
    [],
  );
  const loadUser = useCallback(
    () =>
      api<{ user: User | null }>("/auth/me")
        .then((d) => {
          setUser(d.user);
          return d.user;
        })
        .catch(() => null),
    [],
  );
  useEffect(() => {
    void loadCatalog();
    void loadUser();
    void api<typeof config>("/config")
      .then(setConfig)
      .catch(() => {});
    const params = new URLSearchParams(location.search);
    if (
      ["/reset-password", "/account/reset-password"].includes(
        location.pathname,
      ) &&
      params.has("token")
    )
      setModal("reset");
    if (
      ["/verify-email", "/account/verify-email"].includes(location.pathname) &&
      params.has("token")
    )
      setModal("verify");
    if (params.get("checkout") === "success") {
      notify(
        "Payment submitted. Your library updates after secure payment confirmation.",
      );
      setPage("library");
      history.replaceState({}, "", pathFor.library);
    }
    if (params.get("checkout") === "cancelled")
      notify("Checkout cancelled. Your collection is still here.");
    const back = () => {
      setPage(currentPage());
      setModal(null);
      setMenu(false);
    };
    window.addEventListener("popstate", back);
    return () => window.removeEventListener("popstate", back);
  }, [loadCatalog, loadUser, notify]);
  useEffect(() => {
    localStorage.setItem("rtr-cart", JSON.stringify(cart));
  }, [cart]);
  useEffect(() => {
    localStorage.setItem("rtr-wishlist", JSON.stringify(wishlist));
  }, [wishlist]);
  useEffect(() => {
    if (!user) return;
    let active = true;
    api<{ productIds: string[] }>("/wishlist")
      .then((d) => {
        if (active)
          setWishlist((prev) => {
            const combined = [...new Set([...prev, ...d.productIds])];
            void api("/wishlist", {
              method: "PUT",
              body: JSON.stringify({ productIds: combined }),
            }).catch(() => {});
            return combined;
          });
      })
      .catch(() => {});
    return () => {
      active = false;
    };
  }, [user?.id]);
  useEffect(() => {
    if (!toast) return;
    const id = setTimeout(() => setToast(null), 5000);
    return () => clearTimeout(id);
  }, [toast]);
  useEffect(() => {
    const titles: Partial<Record<Page, string>> = {
      home: "Make something extraordinary.",
      explore: "Explore the collection",
      membership: "Your Digital Pass",
      library: "Your personal library",
      admin: "The creative workspace",
      collections: "Thoughtfully curated collections",
    };
    document.title = `RTR Digital — ${titles[page] || page.charAt(0).toUpperCase() + page.slice(1)}`;
  }, [page]);
  function navigate(p: Page) {
    setPage(p);
    setModal(null);
    setMenu(false);
    setUserMenu(false);
    history.pushState({}, "", pathFor[p]);
    window.scrollTo({ top: 0, behavior: "instant" });
    if (["home", "explore", "collections"].includes(p)) void loadCatalog();
  }
  function explore(category = "All products") {
    setInitialCategory(category);
    setWishlistOnly(false);
    setSearch("");
    navigate("explore");
  }
  function wish(p: Product) {
    const next = wishlist.includes(p.id)
      ? wishlist.filter((id) => id !== p.id)
      : [...wishlist, p.id];
    setWishlist(next);
    if (user)
      void api("/wishlist", {
        method: "PUT",
        body: JSON.stringify({ productIds: next }),
      }).catch((e) => notify(e.message, "error"));
    notify(
      wishlist.includes(p.id)
        ? "Removed from your favorites."
        : "A good find, saved for later.",
    );
  }
  function viewProduct(p: Product) {
    setSelected(p);
    setModal("product");
    history.pushState(
      { originPage: page },
      "",
      `/products/${encodeURIComponent(p.id)}`,
    );
  }
  function closeModal() {
    if (modal === "product" && location.pathname.startsWith("/products/"))
      history.replaceState({}, "", pathFor[page]);
    setModal(null);
  }
  useEffect(() => {
    if (location.pathname.startsWith("/products/")) {
      const id = decodeURIComponent(
        location.pathname.slice("/products/".length),
      );
      const item = products.find((p) => p.id === id);
      if (item) {
        setSelected(item);
        setModal("product");
      }
    }
  }, [products]);
  useEffect(() => {
    if (modal === "product" && selected)
      document.title = `${selected.title} — RTR Digital`;
  }, [modal, selected]);
  function addToCart(p: Product) {
    if (cart.includes(p.id)) {
      setModal("cart");
      return;
    }
    setCart((prev) => [...prev, p.id]);
    notify("A little possibility, added to your bag.");
  }
  function choosePlan(id: string, interval: string) {
    setPlan({ id, interval });
    if (!user) {
      setPendingCheckout(true);
      setModal("auth");
    } else setModal("checkout");
  }
  function checkout() {
    setPlan(null);
    if (!user) {
      setPendingCheckout(true);
      setModal("auth");
    } else setModal("checkout");
  }
  function signedIn(u: User) {
    setUser(u);
    setModal(pendingCheckout ? "checkout" : null);
    setPendingCheckout(false);
    notify(`Welcome ${u.name.split(" ")[0]}. Make yourself at home.`);
  }
  async function logout() {
    try {
      await api("/auth/logout", { method: "POST" });
      setUser(null);
      setUserMenu(false);
      setWishlist([]);
      notify("You’re signed out. See you soon.");
    } catch (e) {
      notify((e as Error).message, "error");
    }
  }
  const catalogProps = {
    products,
    wishlist,
    onWish: wish,
    onProduct: viewProduct,
    onExplore: explore,
    onMembership: () => navigate("membership"),
    onCollection: () => navigate("collections"),
  };
  const accountProps = {
    user,
    onSignIn: () => {
      setPendingCheckout(false);
      setModal("auth");
    },
    onToast: notify,
    onExplore: () => explore(),
    onMembership: () => navigate("membership"),
    onMembershipHub: () => navigate("members"),
    onProduct: viewProduct,
    refreshKey,
    onUserChange: () => {
      void loadUser();
      setRefreshKey((v) => v + 1);
    },
  };
  const cartProducts = cart
    .map((id) => products.find((p) => p.id === id))
    .filter((p): p is Product => Boolean(p));
  return (
    <>
      <a className="skip-link" href="#main">
        Skip to content
      </a>
      <div className="announcement">
        <span>A whole world of digital. One beautifully simple pass.</span>
        <button onClick={() => navigate("membership")}>
          Meet your Digital Pass <ArrowRight size={13} />
        </button>
        <span className="announcement-star">✺</span>
      </div>
      <header className="site-header">
        <div className="nav-inner page-width">
          <button
            className="brand-link"
            onClick={() => navigate("home")}
            aria-label="RTR Digital home"
          >
            <Brand />
          </button>
          <nav
            className={menu ? "main-nav open" : "main-nav"}
            aria-label="Main navigation"
          >
            <button
              className={page === "explore" ? "active" : ""}
              onClick={() => explore()}
            >
              Explore <ChevronDown size={12} />
            </button>
            <button
              className={page === "membership" ? "active" : ""}
              onClick={() => navigate("membership")}
            >
              Digital Pass <span className="nav-new">NEW</span>
            </button>
            <button
              className={page === "collections" ? "active" : ""}
              onClick={() => navigate("collections")}
            >
              Collections
            </button>
            <button
              className={page === "about" ? "active" : ""}
              onClick={() => navigate("about")}
            >
              Our story
            </button>
          </nav>
          <div className="nav-actions">
            <button
              className="icon-button"
              aria-label="Search products"
              onClick={() => setModal("search")}
            >
              <Search size={20} />
            </button>
            <button
              className="icon-button desktop-icon"
              aria-label="View wishlist"
              onClick={() => {
                setInitialCategory("All products");
                setSearch("");
                setWishlistOnly(true);
                navigate("explore");
              }}
            >
              <Heart size={20} />
              {wishlist.length > 0 && <span className="tiny-dot" />}
            </button>
            <button
              className="icon-button bag-button"
              aria-label={`Shopping bag, ${cartProducts.length} items`}
              onClick={() => setModal("cart")}
            >
              <ShoppingBag size={20} />
              {cartProducts.length > 0 && (
                <span className="bag-count">{cartProducts.length}</span>
              )}
            </button>
            <span className="nav-divider" />
            {user ? (
              <div className="user-menu-wrap">
                <button
                  className="user-avatar"
                  aria-label="Open account menu"
                  onClick={() => setUserMenu(!userMenu)}
                >
                  {user.name.slice(0, 1).toUpperCase()}
                </button>
                {userMenu && (
                  <>
                    <button
                      className="menu-dismiss"
                      aria-label="Close account menu"
                      onClick={() => setUserMenu(false)}
                    />
                    <div className="user-dropdown">
                      <strong>{user.name}</strong>
                      <small>{user.email}</small>
                      <button onClick={() => navigate("library")}>
                        <Library size={16} />
                        My library
                      </button>
                      {user.role === "admin" && (
                        <button onClick={() => navigate("admin")}>
                          <LayoutDashboard size={16} />
                          Admin workspace
                        </button>
                      )}
                      <button onClick={() => navigate("account")}>
                        <ShieldCheck size={16} />
                        Account & security
                      </button>
                      <button onClick={() => navigate("members")}>
                        <Sparkles size={16} />
                        Membership & team
                      </button>
                      <button onClick={() => navigate("billing")}>
                        <CreditCard size={16} />
                        Orders & billing
                      </button>
                      {user.role === "admin" && (
                        <>
                          <button onClick={() => navigate("publisher")}>
                            <LayoutDashboard size={16} />
                            Publishing studio
                          </button>
                          <button onClick={() => navigate("operations")}>
                            <CreditCard size={16} />
                            Commerce office
                          </button>
                        </>
                      )}
                      <button onClick={() => void logout()}>
                        <LogOut size={16} />
                        Sign out
                      </button>
                    </div>
                  </>
                )}
              </div>
            ) : (
              <button
                className="sign-in-button"
                onClick={() => {
                  setPendingCheckout(false);
                  setModal("auth");
                }}
              >
                <span>Sign in</span>{" "}
                <ArrowUpRight className="signin-arrow" size={15} />
                <UserRound className="signin-person" size={20} />
              </button>
            )}
            <button
              className="icon-button mobile-menu"
              aria-label="Toggle navigation"
              aria-expanded={menu}
              onClick={() => setMenu(!menu)}
            >
              {menu ? <X /> : <Menu />}
            </button>
          </div>
        </div>
      </header>
      {apiError && (
        <div className="connection-banner">
          Showing the sample collection. The store service is unavailable.{" "}
          <button onClick={() => void loadCatalog()}>Try again</button>
        </div>
      )}
      {[
        "library",
        "admin",
        "account",
        "members",
        "publisher",
        "operations",
        "billing",
      ].includes(page) && (
        <nav
          className="workspace-navigation page-width"
          aria-label="Your workspace"
        >
          <button
            className={page === "library" ? "active" : ""}
            onClick={() => navigate("library")}
          >
            <Library size={15} />
            Library
          </button>
          <button
            className={page === "members" ? "active" : ""}
            onClick={() => navigate("members")}
          >
            <Sparkles size={15} />
            Membership & team
          </button>
          <button
            className={page === "billing" ? "active" : ""}
            onClick={() => navigate("billing")}
          >
            <CreditCard size={15} />
            Orders & billing
          </button>
          <button
            className={page === "account" ? "active" : ""}
            onClick={() => navigate("account")}
          >
            <ShieldCheck size={15} />
            Account & security
          </button>
          {user?.role === "admin" && (
            <>
              <button
                className={page === "admin" ? "active" : ""}
                onClick={() => navigate("admin")}
              >
                Overview
              </button>
              <button
                className={page === "publisher" ? "active" : ""}
                onClick={() => navigate("publisher")}
              >
                Publishing studio
              </button>
              <button
                className={page === "operations" ? "active" : ""}
                onClick={() => navigate("operations")}
              >
                Commerce office
              </button>
            </>
          )}
        </nav>
      )}
      <main id="main">
        {page === "compare" && (
          <Comparison
            products={products}
            onProduct={viewProduct}
            onExplore={() => explore()}
          />
        )}
        {page === "account" && <AccountSettings {...accountProps} />}
        {page === "members" && <MembershipHub {...accountProps} />}
        {page === "publisher" && (
          <PublisherStudio
            {...accountProps}
            onRefresh={() => void loadCatalog()}
          />
        )}
        {page === "operations" && <CommerceOffice {...accountProps} />}
        {page === "billing" && (
          <>
            <BillingRecords
              {...accountProps}
              key={`${user?.id || "signed-out"}:${refreshKey}`}
            />
            <PaymentActivity
              key={user?.id || "signed-out"}
              user={user}
              refreshKey={refreshKey}
              onToast={notify}
              onConfirmed={() => {
                void loadUser();
                setRefreshKey((v) => v + 1);
              }}
              onLibrary={() => navigate("library")}
            />
          </>
        )}
        {page === "home" && <HomePage {...catalogProps} />}{" "}
        {page === "explore" && (
          <ExplorePage
            key={`${initialCategory}-${wishlistOnly}`}
            {...catalogProps}
            initialCategory={initialCategory}
            search={search}
            onSearch={setSearch}
            wishlistOnly={wishlistOnly}
          />
        )}{" "}
        {page === "membership" && (
          <MembershipPage
            onChoose={choosePlan}
            onExplore={() => explore()}
            onManage={() => navigate("members")}
          />
        )}{" "}
        {page === "library" && <LibraryPage {...accountProps} />}{" "}
        {page === "admin" && <AdminPage {...accountProps} />}{" "}
        {page === "collections" && <CollectionsPage {...catalogProps} />}{" "}
        {page === "about" && (
          <AboutPage
            onExplore={() => explore()}
            onMembership={() => navigate("membership")}
          />
        )}{" "}
        {page === "support" && <SupportPage user={user} onToast={notify} />}{" "}
        {page === "legal" && <PoliciesPage />}
      </main>
      <Newsletter onToast={notify} />
      <footer className="site-footer">
        <div className="footer-main page-width">
          <div className="footer-brand">
            <button className="brand-link" onClick={() => navigate("home")}>
              <Brand />
            </button>
            <p>
              Made for curious minds.
              <br />
              Built for limitless possibilities.
            </p>
            <span className="footer-signature">
              A little digital. A lot of possibility. <span>✺</span>
            </span>
          </div>
          <div>
            <h3>Find your thing</h3>
            {[
              "Design assets",
              "E-books",
              "Audio & music",
              "Software",
              "Templates",
            ].map((c) => (
              <button key={c} onClick={() => explore(c)}>
                {c}
              </button>
            ))}
          </div>
          <div>
            <h3>A little more RTR</h3>
            <button onClick={() => navigate("compare")}>
              Compare digital finds
            </button>
            <button onClick={() => navigate("membership")}>
              The Digital Pass <ArrowUpRight size={12} />
            </button>
            <button onClick={() => navigate("collections")}>
              Curated collections
            </button>
            <button onClick={() => navigate("about")}>Our story</button>
            <button onClick={() => navigate("library")}>Your library</button>
            <button onClick={() => navigate("admin")}>Admin workspace</button>
          </div>
          <div>
            <h3>Here to help</h3>
            <button onClick={() => navigate("support")}>Help & support</button>
            <button onClick={() => navigate("legal")}>Licensing & usage</button>
            <button onClick={() => navigate("legal")}>Privacy policy</button>
            <button onClick={() => navigate("legal")}>Terms & refunds</button>
            <span className="footer-payments">
              <CreditCard size={24} />
              <strong>VISA</strong>
              <strong>
                mastercard<span>●●</span>
              </strong>
              <LockKeyhole size={16} />
            </span>
          </div>
        </div>
        <div className="footer-bottom page-width">
          <span>
            © {new Date().getFullYear()} RTR Digital. A space for your next big
            thing.
          </span>
          <span>
            {config.demoMode
              ? "Preview storefront · Sample catalog"
              : "Made with possibility."}{" "}
            <span className="footer-locale">English · USD $</span>
          </span>
        </div>
      </footer>
      {modal && (
        <Dialog
          key={modal}
          onClose={closeModal}
          className={
            modal === "cart"
              ? "drawer-modal"
              : modal === "product"
                ? "product-modal"
                : modal === "search"
                  ? "search-modal"
                  : ""
          }
          title={
            modal === "search"
              ? "Find your next favorite"
              : modal === "cart"
                ? "Your bag"
                : modal === "product"
                  ? selected?.title || "Product details"
                  : modal === "checkout"
                    ? "Your next chapter starts here"
                    : "Welcome to RTR Digital"
          }
        >
          {modal === "search" && (
            <div className="search-dialog">
              <span className="eyebrow">
                A LITTLE CURIOSITY GOES A LONG WAY
              </span>
              <h2>What sparks your interest?</h2>
              <form
                onSubmit={(e) => {
                  e.preventDefault();
                  setInitialCategory("All products");
                  setWishlistOnly(false);
                  navigate("explore");
                }}
              >
                <Search size={22} />
                <input
                  aria-label="Search products"
                  placeholder="Try “design”, “deep work”, “music”…"
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                  autoFocus
                />
                <button type="submit" className="btn btn-primary">
                  <ArrowRight size={20} />
                  <span className="sr-only">Search</span>
                </button>
              </form>
              <small>A GOOD PLACE TO START</small>
              <div className="search-suggestions">
                {["Design assets", "E-books", "Audio & music", "Templates"].map(
                  (c) => (
                    <button key={c} onClick={() => explore(c)}>
                      {c}
                      <ArrowUpRight size={14} />
                    </button>
                  ),
                )}
              </div>
            </div>
          )}
          {["forgot", "reset", "verify"].includes(modal) && (
            <RecoveryForm
              kind={modal as "forgot" | "reset" | "verify"}
              token={
                new URLSearchParams(location.search).get("token") || undefined
              }
              onDone={() => {
                history.replaceState({}, "", "/");
                setModal("auth");
              }}
            />
          )}
          {modal === "auth" && (
            <AuthForm
              onForgot={() => setModal("forgot")}
              demoMode={config.demoMode}
              onSuccess={signedIn}
              onToast={notify}
            />
          )}
          {modal === "product" && selected && (
            <ProductDetails
              product={selected}
              onCart={() => addToCart(selected)}
              inCart={cart.includes(selected.id)}
              onMembership={() => navigate("membership")}
              wished={wishlist.includes(selected.id)}
              onWish={() => wish(selected)}
              user={user}
              onToast={notify}
            />
          )}
          {modal === "cart" && (
            <div className="bag-panel">
              <div className="drawer-heading">
                <span className="eyebrow">
                  GOOD FINDS. GREAT POSSIBILITIES.
                </span>
                <h2>
                  Your little bag of ideas<span>({cartProducts.length})</span>
                </h2>
              </div>
              {cartProducts.length ? (
                <>
                  <div className="bag-items">
                    {cartProducts.map((p) => (
                      <div className="bag-item" key={p.id}>
                        <div className="bag-art">
                          <ProductArt product={p} />
                        </div>
                        <div>
                          <span>{p.category}</span>
                          <h3>{p.title}</h3>
                          <strong>{money(p.price)}</strong>
                        </div>
                        <button
                          className="icon-button"
                          aria-label={`Remove ${p.title}`}
                          onClick={() =>
                            setCart(cart.filter((id) => id !== p.id))
                          }
                        >
                          <Trash2 size={17} />
                        </button>
                      </div>
                    ))}
                  </div>
                  <button
                    className="bag-pass-note"
                    onClick={() => navigate("membership")}
                  >
                    <Sparkles size={20} />
                    <span>
                      All these finds. One simple pass.
                      <small>Explore membership from $9/month.</small>
                    </span>
                    <ArrowUpRight size={17} />
                  </button>
                  <div className="bag-summary">
                    <span>
                      Subtotal
                      <strong>
                        {money(cartProducts.reduce((a, p) => a + p.price, 0))}
                      </strong>
                    </span>
                    <small>Digital delivery. No shipping, no waiting.</small>
                    <button className="btn btn-primary" onClick={checkout}>
                      Make them yours <ArrowRight size={17} />
                    </button>
                    <p>
                      <ShieldCheck size={14} /> Safe checkout. Instant library
                      access.
                    </p>
                  </div>
                </>
              ) : (
                <div className="empty-state bag-empty">
                  <ShoppingBag size={40} strokeWidth={1} />
                  <h3>A little room for something great.</h3>
                  <p>Your bag is waiting for its first good find.</p>
                  <button className="btn btn-primary" onClick={() => explore()}>
                    Find your next favorite <ArrowUpRight size={16} />
                  </button>
                </div>
              )}
            </div>
          )}
          {modal === "checkout" && (
            <CheckoutForm
              user={user}
              products={cartProducts}
              plan={plan}
              config={config}
              onBack={() => setModal(plan ? null : "cart")}
              onToast={notify}
              onPaymentPending={(id) => {
                setModal(null);
                setPage("billing");
                history.pushState(
                  {},
                  "",
                  `/billing?payment=${encodeURIComponent(id)}`,
                );
                setRefreshKey((v) => v + 1);
                window.scrollTo({ top: 0, behavior: "instant" });
              }}
              onSuccess={async () => {
                if (!plan) setCart([]);
                await loadUser();
                setRefreshKey((v) => v + 1);
                navigate("library");
              }}
            />
          )}
        </Dialog>
      )}
      {toast && (
        <div className={`toast ${toast.kind}`} role="status">
          {toast.kind === "error" ? (
            <X size={18} />
          ) : (
            <CheckCircle2 size={18} />
          )}
          <span>{toast.message}</span>
          <button
            aria-label="Dismiss notification"
            onClick={() => setToast(null)}
          >
            <X size={16} />
          </button>
        </div>
      )}
    </>
  );
}
function Dialog({
  children,
  onClose,
  className = "",
  title,
}: {
  children: ReactNode;
  onClose: () => void;
  className?: string;
  title: string;
}) {
  const ref = useRef<HTMLDivElement>(null);
  const returnFocus = useRef(document.activeElement as HTMLElement);
  const closeRef = useRef(onClose);
  closeRef.current = onClose;
  useEffect(() => {
    const previous = returnFocus.current;
    const oldOverflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    const el = ref.current;
    const focusables = () =>
      el?.querySelectorAll<HTMLElement>(
        'button:not([disabled]), a[href], input, textarea, select, [tabindex="0"]',
      );
    const first = focusables()?.[0];
    first?.focus();
    const key = (e: KeyboardEvent) => {
      if (e.key === "Escape") closeRef.current();
      if (e.key === "Tab") {
        const list = focusables();
        if (!list?.length) return;
        const first = list[0],
          last = list[list.length - 1];
        if (e.shiftKey && document.activeElement === first) {
          e.preventDefault();
          last.focus();
        } else if (!e.shiftKey && document.activeElement === last) {
          e.preventDefault();
          first.focus();
        }
      }
    };
    document.addEventListener("keydown", key);
    return () => {
      document.body.style.overflow = oldOverflow;
      document.removeEventListener("keydown", key);
      if (previous?.isConnected) previous.focus();
      else
        document
          .querySelector<HTMLButtonElement>(".site-header .brand-link")
          ?.focus();
    };
  }, []);
  return (
    <div
      className={`modal-backdrop ${className}`}
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
    >
      <div
        className="modal-panel"
        ref={ref}
        role="dialog"
        aria-modal="true"
        aria-label={title}
      >
        <button
          className="modal-close icon-button"
          aria-label="Close dialog"
          onClick={onClose}
        >
          <X size={20} />
        </button>
        {children}
      </div>
    </div>
  );
}
function AuthForm({
  demoMode,
  onSuccess,
  onToast,
  onForgot,
}: {
  demoMode: boolean;
  onSuccess: (u: User) => void;
  onToast: (m: string, k?: string) => void;
  onForgot: () => void;
}) {
  const [register, setRegister] = useState(false),
    [busy, setBusy] = useState(false),
    [error, setError] = useState(""),
    [challenge, setChallenge] = useState("");
  async function submit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setBusy(true);
    setError("");
    const fields = Object.fromEntries(new FormData(e.currentTarget));
    try {
      const result = await api<{
        user?: User;
        mfaRequired?: boolean;
        challengeToken?: string;
      }>(
        challenge ? "/auth/mfa" : register ? "/auth/register" : "/auth/login",
        {
          method: "POST",
          body: JSON.stringify(
            challenge
              ? { challengeToken: challenge, code: fields.code }
              : fields,
          ),
        },
      );
      if (result.mfaRequired && result.challengeToken) {
        setChallenge(result.challengeToken);
        return;
      }
      if (result.user) onSuccess(result.user);
      else throw new Error("Sign-in could not be completed.");
    } catch (err) {
      setError((err as Error).message);
    } finally {
      setBusy(false);
    }
  }
  async function demo(role: string) {
    setBusy(true);
    try {
      const data = await api<{ user: User }>("/auth/demo", {
        method: "POST",
        body: JSON.stringify({ role }),
      });
      onSuccess(data.user);
    } catch (err) {
      onToast((err as Error).message, "error");
    } finally {
      setBusy(false);
    }
  }
  return (
    <div className="auth-form">
      <Brand />
      <span className="eyebrow">YOUR NEXT CHAPTER STARTS HERE</span>
      <h2>
        {challenge
          ? "One more step. All yours."
          : register
            ? "Make a little space for you."
            : "Good to have you here."}
      </h2>
      <p>
        {challenge
          ? "Enter the code from your authenticator or a backup code."
          : register
            ? "An account for all your digital possibilities."
            : "Your favorites, your library, your creative world."}
      </p>
      <div className="auth-switch">
        <button
          className={!register ? "active" : ""}
          onClick={() => {
            setRegister(false);
            setChallenge("");
            setError("");
          }}
        >
          Sign in
        </button>
        <button
          className={register ? "active" : ""}
          onClick={() => {
            setRegister(true);
            setChallenge("");
            setError("");
          }}
        >
          Create account
        </button>
      </div>
      <form onSubmit={(e) => void submit(e)}>
        {challenge ? (
          <label>
            Authentication code
            <input
              name="code"
              required
              autoComplete="one-time-code"
              placeholder="123456 or your backup code"
              autoFocus
            />
          </label>
        ) : (
          <>
            {register && (
              <label>
                Your name
                <input
                  name="name"
                  required
                  minLength={2}
                  maxLength={80}
                  autoComplete="name"
                  placeholder="Alex Creative"
                />
              </label>
            )}
            <label>
              Email address
              <input
                name="email"
                type="email"
                required
                autoComplete="email"
                placeholder="you@example.com"
              />
            </label>
            <label>
              Password
              <input
                name="password"
                type="password"
                required
                minLength={register ? 8 : undefined}
                autoComplete={register ? "new-password" : "current-password"}
                placeholder={
                  register ? "At least 8 characters" : "Your password"
                }
              />
            </label>
            {!register && (
              <button
                className="text-link forgot-password"
                type="button"
                onClick={onForgot}
              >
                Forgot your password?
              </button>
            )}
          </>
        )}
        {error && (
          <div className="form-error" role="alert">
            {error}
          </div>
        )}
        <button className="btn btn-primary" disabled={busy}>
          {busy && <Loader2 size={17} className="spin" />}
          {challenge
            ? "Verify & sign in"
            : register
              ? "Create your account"
              : "Welcome back"}
          <ArrowRight size={17} />
        </button>
      </form>
      {demoMode && !challenge && (
        <div className="demo-access">
          <span>JUST EXPLORING? TRY THE DEMO</span>
          <div>
            <button disabled={busy} onClick={() => void demo("customer")}>
              <UserRound size={15} />
              Customer experience
            </button>
            <button disabled={busy} onClick={() => void demo("admin")}>
              <LayoutDashboard size={15} />
              Admin workspace
            </button>
          </div>
          <small>Demo accounts are shared. Use sample information only.</small>
        </div>
      )}
      <small className="auth-footnote">
        <LockKeyhole size={12} />
        Your account. Your possibilities. Secure by design.
      </small>
    </div>
  );
}
interface Review {
  id: string;
  rating: number;
  body: string;
  createdAt: string;
  name: string;
}
function ProductDetails({
  product: p,
  onCart,
  inCart,
  onMembership,
  wished,
  onWish,
  user,
  onToast,
}: {
  product: Product;
  onCart: () => void;
  inCart: boolean;
  onMembership: () => void;
  wished: boolean;
  onWish: () => void;
  user: User | null;
  onToast: (m: string, k?: string) => void;
}) {
  const [tab, setTab] = useState("Details");
  const [reviews, setReviews] = useState<Review[]>([]);
  const [busy, setBusy] = useState(false);
  const [rating, setRating] = useState(5);
  useEffect(() => {
    void api<{ reviews: Review[] }>(`/reviews/${p.id}`)
      .then((r) => setReviews(r.reviews))
      .catch(() => {});
  }, [p.id]);
  async function review(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setBusy(true);
    const form = e.currentTarget;
    try {
      await api(`/reviews/${p.id}`, {
        method: "POST",
        body: JSON.stringify({ rating, body: new FormData(form).get("body") }),
      });
      const data = await api<{ reviews: Review[] }>(`/reviews/${p.id}`);
      setReviews(data.reviews);
      form.reset();
      onToast("Your perspective, shared. Thank you.");
    } catch (e) {
      onToast((e as Error).message, "error");
    } finally {
      setBusy(false);
    }
  }
  return (
    <div className="product-details">
      <div className="detail-visual">
        <ProductArt product={p} large />
        <div className="preview-caption">
          <BadgeCheck size={14} /> Licensed by {SELLER_NAME}
        </div>
      </div>
      <div className="detail-info">
        <span className="eyebrow">
          {p.category.toUpperCase()} / A GOOD FIND
        </span>
        <h2>{p.title}</h2>
        <span className="detail-creator">
          Sold & licensed by {SELLER_NAME} <BadgeCheck size={14} />
        </span>
        <div className="detail-rating">
          <Star size={15} fill="currentColor" /> {p.rating || "New"}{" "}
          <span>
            ({reviews.length || p.reviewCount}{" "}
            {reviews.length || (!p.ratingIsSample && !p.isSample)
              ? "verified reviews"
              : "sample ratings"}
            )
          </span>
        </div>
        <p className="detail-description">{p.description}</p>
        <div className="detail-formats">
          <span>
            <Download size={17} />
            <strong>{p.format}</strong>
            <small>File format</small>
          </span>
          <span>
            <LayersIcon />
            <strong>{p.size}</strong>
            <small>Digital download</small>
          </span>
        </div>
        <div className="detail-price">
          <strong>{money(p.price)}</strong>
          {p.originalPrice && p.originalPrice > p.price && (
            <del>{money(p.originalPrice)}</del>
          )}
          <span>One-time purchase</span>
        </div>
        <div className="detail-actions">
          <button className="btn btn-primary" onClick={onCart}>
            {inCart ? "View in your bag" : "Add a little possibility"}
            <ShoppingBag size={17} />
          </button>
          <button
            className={`btn btn-outline detail-wish ${wished ? "is-wished" : ""}`}
            aria-label={wished ? "Remove from wishlist" : "Save to wishlist"}
            onClick={onWish}
          >
            <Heart size={20} fill={wished ? "currentColor" : "none"} />
          </button>
        </div>
        {p.subscriptionIncluded && (
          <button className="detail-pass" onClick={onMembership}>
            <Sparkles size={20} />
            <span>
              Or unlock it with your Digital Pass.
              <small>All-access membership from $9/month.</small>
            </span>
            <ArrowUpRight size={17} />
          </button>
        )}
        <p className="sample-note">
          {(p as Product & { isSample?: boolean }).isSample
            ? "Preview product · Download contains a labeled sample file."
            : "Original digital product · Delivered directly to your library."}
        </p>
      </div>
      <div className="detail-more">
        <ProductExperience product={p} user={user} onToast={onToast} />
        <div className="catalog-tabs">
          {["Details", "License & access", "Reviews"].map((t) => (
            <button
              className={tab === t ? "active" : ""}
              onClick={() => setTab(t)}
              key={t}
            >
              {t}
            </button>
          ))}
        </div>
        {tab === "Details" && (
          <div>
            <h3>Made for what comes next.</h3>
            <p>{p.description}</p>
            <div className="detail-tags">
              {p.tags.map((t) => (
                <span key={t}>{t}</span>
              ))}
            </div>
            <p>
              Access your download from your personal library after checkout.
              Need a hand? Our support form connects your question to the
              administrator workspace.
            </p>
          </div>
        )}
        {tab === "License & access" && (
          <div>
            <h3>Clear rights. More room to create.</h3>
            <p>
              RTR Digital sells and licenses every product in this collection.
              Individual purchases are for personal use unless the included RTR
              Digital license specifies otherwise. Creator memberships cover
              commercial client projects; Studio covers project usage by up to
              five team members. Reselling or sharing original files is not
              permitted.
            </p>
            <p>
              Individual purchases remain in your library. Membership downloads
              are accessible while the plan is active. Studio workspaces manage
              up to five seats. Software keys are assigned from RTR Digital’s
              inventory when a product requires activation. Activation
              requirements are listed with the product.
            </p>
          </div>
        )}
        {tab === "Reviews" && (
          <div className="review-section">
            <h3>A little perspective.</h3>
            {reviews.length ? (
              reviews.map((r) => (
                <article key={r.id}>
                  <strong>{r.name}</strong>
                  <span>{"★".repeat(r.rating)}</span>
                  <p>{r.body}</p>
                </article>
              ))
            ) : (
              <p>
                No verified reviews yet. The catalog rating is illustrative
                sample data.
              </p>
            )}
            {user ? (
              <form onSubmit={(e) => void review(e)}>
                <label>
                  Your rating
                  <select
                    value={rating}
                    onChange={(e) => setRating(Number(e.target.value))}
                  >
                    {[5, 4, 3, 2, 1].map((n) => (
                      <option key={n} value={n}>
                        {n} stars
                      </option>
                    ))}
                  </select>
                </label>
                <label>
                  Your experience
                  <textarea
                    name="body"
                    minLength={10}
                    maxLength={2000}
                    required
                    placeholder="A thoughtful word for the next curious mind…"
                  />
                </label>
                <small>
                  Only customers with product access can submit a review.
                </small>
                <button className="btn btn-primary" disabled={busy}>
                  Share your review <ArrowUpRight size={16} />
                </button>
              </form>
            ) : (
              <p>Sign in after purchasing to share a verified review.</p>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
function LayersIcon() {
  return <Download size={17} />;
}
function Newsletter({ onToast }: { onToast: (m: string, k?: string) => void }) {
  const [busy, setBusy] = useState(false);
  const [done, setDone] = useState(false);
  async function subscribe(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setBusy(true);
    const form = e.currentTarget;
    try {
      await api("/newsletter", {
        method: "POST",
        body: JSON.stringify({ email: new FormData(form).get("email") }),
      });
      setDone(true);
      onToast("You’re on the list. A little inspiration is a good thing.");
      form.reset();
    } catch (e) {
      onToast((e as Error).message, "error");
    } finally {
      setBusy(false);
    }
  }
  return (
    <section className="newsletter">
      <div className="page-width newsletter-inner">
        <div>
          <span className="eyebrow">A LITTLE INSPIRATION, IN YOUR INBOX</span>
          <h2>Good finds. First dibs.</h2>
          <p>
            Fresh releases, creative sparks, and a little something just for
            you.
          </p>
        </div>
        <form onSubmit={(e) => void subscribe(e)}>
          <label className="sr-only" htmlFor="newsletter-email">
            Your email address
          </label>
          <div>
            <Mail size={18} />
            <input
              id="newsletter-email"
              name="email"
              type="email"
              required
              placeholder="Your email goes here"
              disabled={done}
            />
            <button
              aria-label="Subscribe to newsletter"
              disabled={busy || done}
            >
              {done ? (
                <Check size={20} />
              ) : busy ? (
                <Loader2 size={20} className="spin" />
              ) : (
                <ArrowUpRight size={22} />
              )}
            </button>
          </div>
          <small>
            {done
              ? "You’re on the list. Thank you for your curiosity."
              : "Just the good stuff. Unsubscribe anytime."}
          </small>
        </form>
        <span className="newsletter-spark">✺</span>
      </div>
    </section>
  );
}
function CollectionsPage(props: Parameters<typeof HomePage>[0]) {
  const collections = [
    {
      name: "The creative head start",
      category: "Design assets",
      copy: "The little essentials behind your biggest ideas.",
    },
    {
      name: "A calmer kind of productive",
      category: "Templates",
      copy: "Make space for what matters. One good system at a time.",
    },
    {
      name: "Sounds like possibility",
      category: "Audio & music",
      copy: "Find the soundtrack for your next chapter.",
    },
    {
      name: "A little food for thought",
      category: "E-books",
      copy: "Big ideas, new perspectives, and a moment to yourself.",
    },
  ];
  return (
    <section className="page-width page-shell collections-page">
      <div className="page-intro">
        <span className="eyebrow">
          THOUGHTFULLY FOUND. BEAUTIFULLY TOGETHER.
        </span>
        <h1>Good things belong together.</h1>
        <p>Consider this your shortcut to something extraordinary.</p>
      </div>
      {collections.map((c, i) => (
        <section className="curated-row" key={c.name}>
          <div className={`curated-intro curated-${i}`}>
            <span className="eyebrow">COLLECTION / 0{i + 1}</span>
            <h2>{c.name}</h2>
            <p>{c.copy}</p>
            <button
              className="text-link"
              onClick={() => props.onExplore(c.category)}
            >
              Explore the collection <ArrowUpRight size={17} />
            </button>
            <span className="curated-shape">{i % 2 === 0 ? "✺" : "◒"}</span>
          </div>
          {props.products
            .filter((p) => p.category === c.category)
            .slice(0, 2)
            .map((p) => (
              <ProductCard
                key={p.id}
                product={p}
                wished={props.wishlist.includes(p.id)}
                onWish={() => props.onWish(p)}
                onProduct={() => props.onProduct(p)}
              />
            ))}
        </section>
      ))}
    </section>
  );
}
function AboutPage({
  onExplore,
  onMembership,
}: {
  onExplore: () => void;
  onMembership: () => void;
}) {
  return (
    <section className="page-width page-shell about-page">
      <div className="page-intro">
        <span className="eyebrow">HELLO. WE’RE RTR DIGITAL.</span>
        <h1>
          A little digital.
          <br />A world of <em>possibility.</em>
        </h1>
        <p>For the curious. The creators. The “what if?” people.</p>
      </div>
      <div className="about-feature">
        <div className="about-visual">
          <span>✺</span>
          <strong>
            Good things.
            <br />
            <em>Digital.</em>
          </strong>
        </div>
        <div>
          <span className="eyebrow">MADE FOR WHAT COMES NEXT</span>
          <h2>
            Because every great thing
            <br />
            starts with a little spark.
          </h2>
          <p>
            A book that changes your perspective. A sound that sets the mood. A
            tool that turns “someday” into “today.” Digital products can open
            real possibilities.
          </p>
          <p>
            RTR Digital is the sole seller and licensor of every product in this
            collection. Explore individual finds or open up the collection with
            a Digital Pass that fits the way you create. Every purchase and
            product license comes directly from RTR Digital.
          </p>
          <p>
            Our conceptual ribbon R represents an idea becoming something real:
            one continuous path from curiosity to creation.
          </p>
          <div className="hero-actions">
            <button className="btn btn-primary" onClick={onExplore}>
              Find your spark <ArrowUpRight size={17} />
            </button>
            <button className="text-link" onClick={onMembership}>
              Meet the Pass <ArrowRight size={17} />
            </button>
          </div>
        </div>
      </div>
      <div className="about-note">
        <BadgeCheck size={25} />
        <p>
          This storefront includes an illustrative sample catalog so you can
          explore the complete buying experience. Product names, download
          counts, and ratings are demonstration content. Every listing is
          offered under RTR Digital. Original products can be published through
          the administrator workspace.
        </p>
      </div>
    </section>
  );
}
function SupportPage({
  user,
  onToast,
}: {
  user: User | null;
  onToast: (m: string, k?: string) => void;
}) {
  const [busy, setBusy] = useState(false);
  const [ticket, setTicket] = useState("");
  async function submit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setBusy(true);
    const form = e.currentTarget;
    try {
      const data = await api<{ ticketId: string }>("/support", {
        method: "POST",
        body: JSON.stringify(Object.fromEntries(new FormData(form))),
      });
      setTicket(data.ticketId);
      form.reset();
      onToast("Your question has a home. Your support ticket is saved.");
    } catch (e) {
      onToast((e as Error).message, "error");
    } finally {
      setBusy(false);
    }
  }
  return (
    <section className="page-width page-shell support-page">
      <div className="page-intro">
        <span className="eyebrow">A LITTLE HELP GOES A LONG WAY</span>
        <h1>Let’s figure it out together.</h1>
        <p>
          Your downloads, your membership, your next step. We’re here for it.
        </p>
      </div>
      <div className="support-layout">
        <div>
          <span className="plan-icon">
            <Mail />
          </span>
          <h2>What’s on your mind?</h2>
          <p>
            Send a question to the administrator workspace. Include an order
            reference if it’s about a purchase. Please keep passwords and
            payment details out of your message.
          </p>
          <div className="support-tip">
            <Download size={23} />
            <div>
              <h3>Looking for your files?</h3>
              <p>
                Sign in and open My library. Individual purchases and active
                membership products appear there.
              </p>
            </div>
          </div>
          <div className="support-tip">
            <Sparkles size={23} />
            <div>
              <h3>Managing your membership?</h3>
              <p>
                Your library includes renewal details and the option to cancel
                or resume renewal.
              </p>
            </div>
          </div>
        </div>
        {ticket ? (
          <div className="ticket-success">
            <CheckCircle2 size={43} />
            <h2>A question worth answering.</h2>
            <p>Your message is saved in the administrator workspace.</p>
            <strong>{ticket}</strong>
            <button className="btn btn-outline" onClick={() => setTicket("")}>
              Send another message
            </button>
          </div>
        ) : (
          <form onSubmit={(e) => void submit(e)}>
            <label>
              Email address
              <input
                type="email"
                name="email"
                defaultValue={user?.email || ""}
                required
                placeholder="you@example.com"
              />
            </label>
            <label>
              What’s it about?
              <input
                name="subject"
                required
                minLength={3}
                maxLength={150}
                placeholder="A little help with…"
              />
            </label>
            <label>
              Your message
              <textarea
                name="message"
                required
                minLength={10}
                maxLength={5000}
                rows={6}
                placeholder="Tell us a little more so we can help."
              />
            </label>
            <button className="btn btn-primary" disabled={busy}>
              {busy && <Loader2 className="spin" size={17} />}Send your message{" "}
              <ArrowUpRight size={17} />
            </button>
            <small>
              Messages are stored for administrator review. Email delivery is
              not enabled in this preview.
            </small>
          </form>
        )}
      </div>
    </section>
  );
}
function PoliciesPage() {
  const [tab, setTab] = useState("Licensing");
  return (
    <section className="page-width page-shell policies-page">
      <div className="page-intro">
        <span className="eyebrow">CLEAR IS A GOOD THING</span>
        <h1>A little clarity. A lot of trust.</h1>
        <p>How your digital finds, your access, and your information work.</p>
      </div>
      <div className="catalog-tabs">
        {["Licensing", "Privacy", "Terms & refunds"].map((t) => (
          <button
            key={t}
            className={tab === t ? "active" : ""}
            onClick={() => setTab(t)}
          >
            {t}
          </button>
        ))}
      </div>
      <div className="policy-copy">
        {tab === "Licensing" ? (
          <>
            <h2>Room to create. Rights that make sense.</h2>
            <p>
              RTR Digital is the sole seller and licensor of every product in
              this store. Individual products carry personal-use rights unless
              the included RTR Digital product license says otherwise. Explorer
              membership is for personal use. Creator permits use in commercial
              client projects, and Studio permits project use by a team of up to
              five people.
            </p>
            <h3>What’s yours to do</h3>
            <p>
              Use products within the applicable license and create your own
              original work. Individual purchases remain accessible in your
              library independently of a subscription. Membership access lasts
              through your current paid period.
            </p>
            <h3>What requires permission</h3>
            <p>
              Redistributing, reselling, sharing, sublicensing, or making
              original downloaded files publicly available requires RTR
              Digital’s written permission. A membership does not transfer
              copyright. Product-specific terms issued by RTR Digital still
              apply.
            </p>
            <h3>Preview content</h3>
            <p>
              The seeded products are illustrative and download labeled sample
              files. No rights to an advertised commercial asset are conveyed by
              a demo checkout. RTR Digital must supply original products and
              final product-specific license terms before launch.
            </p>
          </>
        ) : tab === "Privacy" ? (
          <>
            <h2>Your information has a purpose.</h2>
            <p>
              The application stores account names, email addresses, password
              hashes, sessions, wishlists, orders, memberships, support
              messages, and optional newsletter sign-ups in its database.
              Passwords are hashed; plain-text passwords are not stored.
            </p>
            <h3>Payments and cookies</h3>
            <p>
              Essential HttpOnly cookies maintain your authenticated session.
              The shopping bag and anonymous wishlist are kept in your browser’s
              local storage. Live card information is handled by Stripe’s hosted
              checkout and is not collected by this site.
            </p>
            <h3>Your choices</h3>
            <p>
              Manage sessions, communication preferences, account export, and
              account closure from Account & security; use support for
              additional assistance. Signed-in users can export their account
              data from /api/account/export. An automatic marketing email
              service and analytics tracking are not enabled in this preview.
            </p>
            <h3>Before public launch</h3>
            <p>
              RTR Digital must add its legal business details, privacy contact,
              retention schedule, service-provider disclosures, and
              jurisdiction-specific privacy details. These are functional
              preview explanations, not finalized legal terms.
            </p>
          </>
        ) : (
          <>
            <h2>A good experience starts with clear terms.</h2>
            <p>
              This preview demonstrates a digital-products storefront. Demo
              checkout does not charge money and provides test access only. RTR
              Digital is the seller for every listing. Sample catalog titles,
              ratings, and usage counts are illustrative.
            </p>
            <h3>Membership renewal</h3>
            <p>
              Monthly and yearly memberships renew at the selected interval
              until cancelled. The full price and billing interval appear before
              checkout. Cancel or resume renewal from your library; access
              continues through the current paid period.
            </p>
            <h3>Digital delivery and refunds</h3>
            <p>
              Products are delivered through an authenticated library after
              payment confirmation. Contact support about failed downloads,
              duplicate charges, or content problems. Digital-content refund
              eligibility depends on RTR Digital’s final policy and applicable
              consumer law; this preview does not promise a universal refund
              period.
            </p>
            <h3>Live commerce</h3>
            <p>
              Live payments require configured Stripe credentials, signed
              webhooks, original licensed files, final legal terms, appropriate
              tax handling, secure deployment, and operational support. This
              application does not by itself establish those business
              prerequisites.
            </p>
          </>
        )}
      </div>
    </section>
  );
}
