import { useCallback, useEffect, useRef, useState } from "react";
import type { FormEvent } from "react";
import {
  ArrowRight,
  ArrowUpRight,
  Bell,
  CalendarDays,
  Check,
  CheckCircle2,
  CircleAlert,
  Copy,
  Crown,
  Gift,
  History,
  Link2,
  LoaderCircle,
  Mail,
  Plus,
  RefreshCw,
  ShieldCheck,
  Trash2,
  UserPlus,
  Users,
  X,
} from "lucide-react";
import { api, money } from "../lib/api";
import type { Subscription, User } from "../lib/types";
import "./memberships.css";

type Member = {
  id: string;
  name: string;
  email: string;
  role: string;
  joinedAt: string;
};
type Invite = {
  id: string;
  email: string;
  expiresAt: string;
  createdAt: string;
};
type Team = {
  id: string;
  name: string;
  role: "owner" | "member";
  owner: { id: string; name: string; email: string };
  active: boolean;
  seatLimit: number;
  occupiedSeats?: number;
  reservedSeats?: number;
  members: Member[];
  invites: Invite[];
};
type BillingEvent = {
  id: string;
  type: string;
  title: string;
  detail: string;
  amount: number | null;
  currency: string;
  mode: string;
  createdAt: string;
};
type Reminder = {
  id: string;
  title: string;
  message: string;
  dueAt: string;
  read: boolean;
};
type Hub = {
  subscription:
    | (Subscription & { mode?: string; autoRenew?: boolean; isTrial?: boolean })
    | null;
  trialEligible: boolean;
  trialPolicy: {
    enabled: boolean;
    mode: "demo" | "trial";
    durationDays: number;
    automaticRenewal: boolean;
    requiresCard: boolean;
    requiresVerifiedEmail: boolean;
    requiresOriginalContent: boolean;
  };
  trialUnavailableReason: string | null;
  team: Team | null;
  events: BillingEvent[];
  reminders: Reminder[];
};
type Invitation = {
  email: string;
  teamName: string;
  ownerName: string;
  expiresAt: string;
};
type Props = {
  user: User | null;
  onSignIn: () => void;
  onToast: (message: string, kind?: "success" | "error") => void;
  onUserChange: () => void;
  onMembership: () => void;
};
const errorMessage = (error: unknown) =>
  error instanceof Error
    ? error.message
    : "Something went wrong. Please try again.";
const date = (value?: string) =>
  value && Number.isFinite(Date.parse(value))
    ? new Date(value).toLocaleDateString("en-US", {
        month: "short",
        day: "numeric",
        year: "numeric",
      })
    : "—";
const label = (plan?: string) =>
  plan === "starter"
    ? "Explorer"
    : plan
      ? plan.charAt(0).toUpperCase() + plan.slice(1)
      : "No active plan";

export function MembershipHub({
  user,
  onSignIn,
  onToast,
  onUserChange,
  onMembership,
}: Props) {
  const [hubResult, setHubResult] = useState<{
    userId: string;
    hub: Hub;
  } | null>(null);
  const data =
    hubResult && hubResult.userId === user?.id ? hubResult.hub : null;
  const currentUserId = useRef(user?.id);
  currentUserId.current = user?.id;
  const loadVersion = useRef(0);
  const [tab, setTab] = useState<"overview" | "team" | "activity">("overview");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [busy, setBusy] = useState("");
  const [formError, setFormError] = useState("");
  const [newInvite, setNewInvite] = useState("");
  const [confirm, setConfirm] = useState<string | null>(null);
  const [inviteToken, setInviteToken] = useState(
    () => new URLSearchParams(location.search).get("invite") || "",
  );
  const [inviteResult, setInviteResult] = useState<{
    userId: string;
    invite: Invitation;
  } | null>(null);
  const invitation =
    inviteResult && inviteResult.userId === user?.id
      ? inviteResult.invite
      : null;
  const [inviteError, setInviteError] = useState("");
  const [trialConfirmed, setTrialConfirmed] = useState(false);

  const load = useCallback(async () => {
    if (!user) return;
    const userId = user.id;
    const version = ++loadVersion.current;
    const isCurrent = () =>
      currentUserId.current === userId && loadVersion.current === version;
    setLoading(true);
    setError("");
    try {
      const hub = await api<Hub>("/membership/hub");
      if (isCurrent()) setHubResult({ userId, hub });
    } catch (err) {
      if (isCurrent()) setError(errorMessage(err));
    } finally {
      if (isCurrent()) setLoading(false);
    }
  }, [user?.id]);
  useEffect(() => {
    setHubResult(null);
    setInviteResult(null);
    setError("");
    setFormError("");
    setNewInvite("");
    setConfirm(null);
    setTrialConfirmed(false);
    setBusy("");
    setLoading(false);
    void load();
    return () => {
      loadVersion.current += 1;
    };
  }, [load]);
  useEffect(() => {
    setInviteResult(null);
    setInviteError("");
    if (!user || !inviteToken) return;
    let active = true;
    const userId = user.id;
    void api<{ invite: Invitation }>(
      `/membership/team/invites/${encodeURIComponent(inviteToken)}`,
    )
      .then((result) => {
        if (active && currentUserId.current === userId)
          setInviteResult({ userId, invite: result.invite });
      })
      .catch((err) => {
        if (active && currentUserId.current === userId)
          setInviteError(errorMessage(err));
      });
    return () => {
      active = false;
    };
  }, [user?.id, inviteToken]);
  async function mutate(
    key: string,
    path: string,
    method = "POST",
    body?: object,
  ) {
    const userId = user?.id;
    setBusy(key);
    setFormError("");
    try {
      const result = await api<Record<string, unknown>>(path, {
        method,
        ...(body ? { body: JSON.stringify(body) } : {}),
      });
      if (currentUserId.current !== userId) return null;
      await load();
      if (currentUserId.current !== userId) return null;
      onUserChange();
      return result;
    } catch (err) {
      if (currentUserId.current !== userId) return null;
      const message = errorMessage(err);
      setFormError(message);
      onToast(message, "error");
      return null;
    } finally {
      if (currentUserId.current === userId) {
        setBusy("");
        setConfirm(null);
      }
    }
  }
  async function startTrial() {
    const result = await mutate("trial", "/membership/trial", "POST", {
      plan: "creator",
    });
    if (result) {
      setTrialConfirmed(false);
      onToast(
        "Your seven-day preview has begun. It expires automatically; no payment is collected.",
      );
    }
  }
  async function createTeam(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const form = event.currentTarget;
    const result = await mutate("create-team", "/membership/team", "POST", {
      name: new FormData(form).get("name"),
    });
    if (result) {
      form.reset();
      onToast("A little room for the whole team. Your workspace is ready.");
    }
  }
  async function inviteMember(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const form = event.currentTarget;
    setNewInvite("");
    const result = await mutate("invite", "/membership/team/invites", "POST", {
      email: new FormData(form).get("email"),
    });
    if (result && typeof result.inviteUrl === "string") {
      setNewInvite(new URL(result.inviteUrl, location.origin).href);
      form.reset();
      onToast(
        "Invitation created. Copy the private link and share it with this person.",
      );
    }
  }
  async function copyInvite() {
    try {
      await navigator.clipboard.writeText(newInvite);
      onToast("Private invitation link copied.");
    } catch {
      onToast("Copy the invitation from the link field below.", "error");
    }
  }
  async function acceptInvite() {
    const result = await mutate(
      "accept",
      `/membership/team/invites/${encodeURIComponent(inviteToken)}/accept`,
    );
    if (result) {
      setInviteToken("");
      setInviteResult(null);
      const url = new URL(location.href);
      url.searchParams.delete("invite");
      history.replaceState({}, "", url.pathname + url.search + url.hash);
      setTab("team");
      onToast("You’re in. Good things happen together.");
    }
  }
  if (!user)
    return (
      <section className="page-width page-shell mh-page">
        <div className="mh-guest">
          <span className="mh-symbol">
            <Users size={34} />
          </span>
          <span className="eyebrow">A LITTLE MORE POSSIBILITY</span>
          <h1>
            {inviteToken
              ? "Good things happen together."
              : "Your membership, with room to grow."}
          </h1>
          <p>
            {inviteToken
              ? "Sign in with the email address on your invitation to review and join the workspace."
              : "Manage your team, explore your trial, and keep every membership moment in view."}
          </p>
          <button className="btn btn-primary" onClick={onSignIn}>
            Sign in to continue <ArrowRight size={17} />
          </button>
          <small>
            <ShieldCheck size={13} /> Team access is protected by your account.
          </small>
        </div>
      </section>
    );
  const subscription = data?.subscription;
  const activePlan =
    subscription &&
    ["active", "trialing"].includes(subscription.status) &&
    Boolean(
      subscription.currentPeriodEnd &&
      Date.parse(subscription.currentPeriodEnd) > Date.now(),
    );
  const isTrial = Boolean(
    subscription?.isTrial || subscription?.interval === "trial",
  );
  const team = data?.team;
  const owner = team?.role === "owner";
  const unread = (data?.reminders || []).filter((reminder) => !reminder.read);
  const seats = team
    ? (team.occupiedSeats ?? team.members.length) +
      (team.reservedSeats ?? team.invites.length)
    : 0;
  return (
    <section className="page-width page-shell mh-page">
      <header className="mh-heading">
        <div>
          <span className="eyebrow">YOUR POSSIBILITIES, CONNECTED</span>
          <h1>
            A little more together<span>.</span>
          </h1>
          <p>
            Your membership, your people, and the moments that keep it all
            moving.
          </p>
        </div>
        <button className="btn btn-outline" onClick={onMembership}>
          Explore the plans <ArrowUpRight size={16} />
        </button>
      </header>
      {inviteToken && (
        <section className="mh-invitation" aria-label="Workspace invitation">
          <span className="mh-invitation-icon">
            <UserPlus size={24} />
          </span>
          <div>
            <span className="eyebrow">YOU’RE INVITED</span>
            <h2>
              {invitation
                ? `Join ${invitation.teamName}.`
                : "A little room for you."}
            </h2>
            <p>
              {invitation
                ? `${invitation.ownerName} invited ${invitation.email}. This private invitation expires ${date(invitation.expiresAt)}.`
                : inviteError || "Checking your invitation…"}
            </p>
          </div>
          {invitation && (
            <button
              className="btn btn-primary"
              onClick={() => void acceptInvite()}
              disabled={Boolean(busy)}
            >
              {busy === "accept" ? (
                <LoaderCircle size={16} className="spin" />
              ) : (
                <CheckCircle2 size={16} />
              )}
              Accept invitation
            </button>
          )}
        </section>
      )}
      <nav className="mh-tabs" aria-label="Membership management">
        <button
          className={tab === "overview" ? "active" : ""}
          onClick={() => setTab("overview")}
        >
          <Crown size={17} />
          Overview
        </button>
        <button
          className={tab === "team" ? "active" : ""}
          onClick={() => setTab("team")}
        >
          <Users size={17} />
          Your team{team && <span>{team.members.length}</span>}
        </button>
        <button
          className={tab === "activity" ? "active" : ""}
          onClick={() => setTab("activity")}
        >
          <History size={17} />
          Billing activity
        </button>
        <button
          className="mh-refresh"
          aria-label="Refresh membership"
          onClick={() => void load()}
          disabled={loading}
        >
          <RefreshCw size={16} className={loading ? "spin" : ""} />
        </button>
      </nav>
      {loading && !data ? (
        <div className="mh-loading" role="status">
          <LoaderCircle className="spin" size={24} />
          Getting your possibilities together…
        </div>
      ) : error ? (
        <div className="mh-error" role="alert">
          <CircleAlert size={21} />
          <div>
            <strong>A little interruption.</strong>
            <p>{error}</p>
          </div>
          <button className="btn btn-outline" onClick={() => void load()}>
            Try again
          </button>
        </div>
      ) : tab === "overview" ? (
        <>
          <div className="mh-overview-grid">
            <article className="mh-plan-card">
              <div className="mh-plan-top">
                <span className="eyebrow">YOUR MEMBERSHIP</span>
                <Crown size={25} />
              </div>
              <h2>
                {activePlan
                  ? label(subscription?.plan)
                  : "Room for something new."}
              </h2>
              <span className={`mh-status ${activePlan ? "" : "muted"}`}>
                <i />
                {activePlan
                  ? isTrial
                    ? subscription?.mode === "trial"
                      ? "Seven-day free trial"
                      : "Seven-day preview"
                    : subscription?.isPrepaid
                      ? "Prepaid · expires automatically"
                      : subscription?.cancelAtPeriodEnd
                        ? "Renewal cancelled"
                        : "Active membership"
                  : "No active membership"}
              </span>
              <p>
                {activePlan
                  ? isTrial
                    ? "A little time to explore. Your preview expires automatically and does not convert into a paid subscription."
                    : subscription?.isPrepaid
                      ? "Your purchased term opens the included collection and expires automatically. No recurring charge will be made."
                      : "Your membership opens the included collection. Create, learn, and make a little more possible."
                  : "One pass can open up a world of ideas. Choose a membership that fits the way you create."}
              </p>
              {activePlan && (
                <dl>
                  <div>
                    <dt>
                      {isTrial
                        ? "Preview ends"
                        : subscription?.cancelAtPeriodEnd
                          ? "Access until"
                          : "Current period ends"}
                    </dt>
                    <dd>{date(subscription?.currentPeriodEnd)}</dd>
                  </div>
                  <div>
                    <dt>Billing</dt>
                    <dd>
                      {isTrial
                        ? "No automatic charge"
                        : subscription?.isPrepaid
                          ? "Paid once · no automatic renewal"
                          : subscription?.interval === "yearly"
                            ? "Yearly"
                            : "Monthly"}
                    </dd>
                  </div>
                  <div>
                    <dt>Payment mode</dt>
                    <dd>
                      {subscription?.mode === "stripe"
                        ? "Stripe"
                        : subscription?.isPrepaid
                          ? subscription.mode === "wire"
                            ? "Confirmed bank transfer"
                            : subscription.mode === "paypal"
                              ? "PayPal"
                              : "Razorpay"
                          : subscription?.mode === "trial"
                            ? "Free trial · no charge"
                            : "Demo · no charge"}
                    </dd>
                  </div>
                </dl>
              )}
              <button className="btn btn-primary" onClick={onMembership}>
                {activePlan ? "See what comes next" : "Find your perfect pass"}
                <ArrowUpRight size={16} />
              </button>
              {activePlan && isTrial && (
                <div className="mh-trial-end">
                  {confirm === "end-trial" ? (
                    <div className="mh-confirm-actions">
                      <button
                        disabled={Boolean(busy)}
                        onClick={async () => {
                          const result = await mutate(
                            "end-trial",
                            "/membership/trial/end",
                          );
                          if (result)
                            onToast(
                              "Your preview has ended. Your individual purchases remain in your library.",
                            );
                        }}
                      >
                        Confirm end preview
                      </button>
                      <button onClick={() => setConfirm(null)}>
                        Keep exploring
                      </button>
                    </div>
                  ) : (
                    <button
                      className="mh-text-button"
                      onClick={() => setConfirm("end-trial")}
                    >
                      End my free preview <X size={14} />
                    </button>
                  )}
                </div>
              )}
            </article>
            <article className="mh-grow-card">
              <span className="mh-symbol">
                <Users size={26} />
              </span>
              <span className="eyebrow">MADE FOR GOOD COMPANY</span>
              <h2>
                Big ideas.
                <br />
                Better together.
              </h2>
              <p>
                The Studio membership connects a team of up to five people.
                Invite by email, share access to included products, and keep
                control of every seat.
              </p>
              <ul>
                <li>
                  <Check size={15} /> Five seats including the owner
                </li>
                <li>
                  <Check size={15} /> Private, expiring invitation links
                </li>
                <li>
                  <Check size={15} /> Access follows the owner’s active Studio
                  plan
                </li>
                <li>
                  <Check size={15} /> Remove a seat when the project changes
                </li>
              </ul>
              <button className="mh-text-button" onClick={() => setTab("team")}>
                {team
                  ? "Open your workspace"
                  : "Make a little room for your team"}
                <ArrowRight size={16} />
              </button>
            </article>
          </div>
          {data?.trialEligible && (
            <article className="mh-trial-card">
              <span className="mh-symbol">
                <Gift size={26} />
              </span>
              <div>
                <span className="eyebrow">A LITTLE TIME TO EXPLORE</span>
                <h2>Seven days. See what sparks.</h2>
                <p>
                  {data.trialPolicy.mode === "trial"
                    ? "Try Creator access free for seven days."
                    : "Try Creator access in this demonstration for seven days."}{" "}
                  No card, no payment, no automatic renewal. One trial per
                  account and{" "}
                  {data.trialPolicy.requiresVerifiedEmail
                    ? "verified"
                    : "registered"}{" "}
                  email address.
                </p>
                <label className="mh-trial-consent">
                  <input
                    type="checkbox"
                    checked={trialConfirmed}
                    onChange={(event) =>
                      setTrialConfirmed(event.target.checked)
                    }
                  />
                  {data.trialPolicy.mode === "trial"
                    ? "I understand this free trial expires automatically without a charge or renewal."
                    : "I understand this is a free demo preview that expires automatically."}
                </label>
              </div>
              <button
                className="btn btn-primary"
                disabled={!trialConfirmed || Boolean(busy)}
                onClick={() => void startTrial()}
              >
                {busy === "trial" && (
                  <LoaderCircle size={16} className="spin" />
                )}
                {data.trialPolicy.mode === "trial"
                  ? "Start my seven-day trial"
                  : "Start my seven-day preview"}{" "}
                <ArrowUpRight size={16} />
              </button>
            </article>
          )}
          {data?.trialPolicy.enabled &&
            !data.trialEligible &&
            !activePlan &&
            data.trialUnavailableReason && (
              <div className="mh-trial-policy">
                <Gift size={19} />
                <div>
                  <strong>Seven-day no-card trial</strong>
                  <p>{data.trialUnavailableReason}</p>
                  {data.trialUnavailableReason.includes(
                    "Verify your email",
                  ) && (
                    <a className="text-link" href="/account">
                      Open Account & security <ArrowUpRight size={14} />
                    </a>
                  )}
                </div>
              </div>
            )}
          <section className="mh-reminders">
            <div className="mh-section-title">
              <div>
                <span className="eyebrow">A LITTLE CLARITY, RIGHT ON TIME</span>
                <h2>Keep it in view.</h2>
              </div>
              <span className="mh-count">{unread.length} unread</span>
            </div>
            {data?.reminders.length ? (
              <div className="mh-reminder-list">
                {data.reminders.map((reminder) => (
                  <article
                    key={reminder.id}
                    className={reminder.read ? "read" : ""}
                  >
                    <span className="mh-reminder-icon">
                      <Bell size={18} />
                    </span>
                    <div>
                      <h3>{reminder.title}</h3>
                      <p>{reminder.message}</p>
                      <small>
                        <CalendarDays size={12} />
                        {date(reminder.dueAt)}
                      </small>
                    </div>
                    {!reminder.read && (
                      <button
                        className="mh-icon-button"
                        aria-label={`Mark ${reminder.title} as read`}
                        disabled={Boolean(busy)}
                        onClick={() =>
                          void mutate(
                            `read-${reminder.id}`,
                            `/membership/reminders/${encodeURIComponent(reminder.id)}/read`,
                          )
                        }
                      >
                        <Check size={17} />
                      </button>
                    )}
                  </article>
                ))}
              </div>
            ) : (
              <div className="mh-quiet">
                <Bell size={25} />
                <p>No reminders right now. You’re all caught up.</p>
              </div>
            )}
          </section>
        </>
      ) : tab === "team" ? (
        <section className="mh-team-section">
          {team ? (
            <>
              <div className="mh-team-banner">
                <span className="mh-symbol">
                  <Users size={25} />
                </span>
                <div>
                  <span className="eyebrow">YOUR SHARED CREATIVE SPACE</span>
                  <h2>{team.name}</h2>
                  <p>
                    {owner
                      ? "You keep the team connected."
                      : `Owned by ${team.owner.name}.`}{" "}
                    {team.active
                      ? "Included products are ready for your next idea."
                      : "Access is paused because the owner does not have an active Studio plan."}
                  </p>
                </div>
                <span className={`mh-status ${team.active ? "" : "muted"}`}>
                  <i />
                  {team.active ? "Workspace active" : "Access paused"}
                </span>
              </div>
              <div className="mh-team-topline">
                <div>
                  <h3>A little room for everyone.</h3>
                  <p>
                    {seats} of {team.seatLimit} seats used or reserved. Pending
                    invitations reserve a seat.
                  </p>
                </div>
                <span
                  className="mh-seat-indicator"
                  aria-label={`${seats} of ${team.seatLimit} seats used`}
                >
                  {Array.from({ length: team.seatLimit }, (_, index) => (
                    <i key={index} className={index < seats ? "used" : ""} />
                  ))}
                </span>
              </div>
              {owner && (
                <form
                  className="mh-invite-form"
                  onSubmit={(event) => void inviteMember(event)}
                >
                  <label htmlFor="mh-invite-email">
                    Invite a curious mind
                    <input
                      id="mh-invite-email"
                      name="email"
                      type="email"
                      placeholder="teammate@example.com"
                      required
                      disabled={
                        Boolean(busy) || seats >= team.seatLimit || !team.active
                      }
                    />
                  </label>
                  <button
                    className="btn btn-primary"
                    disabled={
                      Boolean(busy) || seats >= team.seatLimit || !team.active
                    }
                  >
                    {busy === "invite" ? (
                      <LoaderCircle size={16} className="spin" />
                    ) : (
                      <Plus size={16} />
                    )}
                    Create invitation
                  </button>
                  <small>
                    <Link2 size={12} />A private link is created for you to
                    share. No email is sent automatically.
                  </small>
                </form>
              )}
              {newInvite && (
                <div className="mh-invite-link">
                  <div>
                    <ShieldCheck size={18} />
                    <strong>For your teammate’s eyes only.</strong>
                    <button
                      className="mh-icon-button"
                      aria-label="Hide invitation link"
                      onClick={() => setNewInvite("")}
                    >
                      <X size={16} />
                    </button>
                  </div>
                  <p>
                    This link is shown here once. It is bound to the invited
                    email and expires in seven days.
                  </p>
                  <div>
                    <input
                      aria-label="Private invitation link"
                      value={newInvite}
                      readOnly
                      onFocus={(event) => event.currentTarget.select()}
                    />
                    <button
                      className="btn btn-outline"
                      type="button"
                      onClick={() => void copyInvite()}
                    >
                      <Copy size={15} />
                      Copy link
                    </button>
                  </div>
                </div>
              )}
              {formError && (
                <div className="mh-error" role="alert">
                  <CircleAlert size={18} />
                  {formError}
                </div>
              )}
              {owner && (
                <form
                  className="mh-rename-form"
                  onSubmit={async (event) => {
                    event.preventDefault();
                    const result = await mutate(
                      "rename-team",
                      "/membership/team",
                      "PATCH",
                      { name: new FormData(event.currentTarget).get("name") },
                    );
                    if (result) onToast("Workspace name updated.");
                  }}
                >
                  <label>
                    Workspace name
                    <input
                      name="name"
                      defaultValue={team.name}
                      minLength={2}
                      maxLength={80}
                      required
                    />
                  </label>
                  <button className="btn btn-outline" disabled={Boolean(busy)}>
                    Save name <Check size={14} />
                  </button>
                </form>
              )}
              <div className="mh-member-list">
                {team.members.map((member) => (
                  <article key={member.id}>
                    <span className="mh-avatar">
                      {member.name.slice(0, 1).toUpperCase()}
                    </span>
                    <div>
                      <h3>
                        {member.name}
                        {member.id === user.id && <small>You</small>}
                      </h3>
                      <p>{member.email}</p>
                      <small>Joined {date(member.joinedAt)}</small>
                    </div>
                    <span className="mh-member-role">
                      {member.role === "owner" ? (
                        <>
                          <Crown size={13} />
                          Owner
                        </>
                      ) : (
                        "Member"
                      )}
                    </span>
                    {owner &&
                      member.role !== "owner" &&
                      (confirm === `member-${member.id}` ? (
                        <div className="mh-confirm-actions">
                          <button
                            disabled={Boolean(busy)}
                            onClick={async () => {
                              const result = await mutate(
                                `remove-${member.id}`,
                                `/membership/team/members/${encodeURIComponent(member.id)}`,
                                "DELETE",
                              );
                              if (result)
                                onToast(
                                  "Team seat removed. Shared access has ended.",
                                );
                            }}
                          >
                            Confirm removal
                          </button>
                          <button onClick={() => setConfirm(null)}>Keep</button>
                        </div>
                      ) : (
                        <button
                          className="mh-icon-button"
                          aria-label={`Remove ${member.name} from team`}
                          disabled={Boolean(busy)}
                          onClick={() => setConfirm(`member-${member.id}`)}
                        >
                          <Trash2 size={16} />
                        </button>
                      ))}
                  </article>
                ))}
              </div>
              {owner && team.invites.length > 0 && (
                <section className="mh-pending">
                  <div className="mh-section-title">
                    <h3>Possibilities on their way.</h3>
                    <span>{team.invites.length} pending</span>
                  </div>
                  {team.invites.map((invite) => (
                    <article key={invite.id}>
                      <Mail size={19} />
                      <div>
                        <strong>{invite.email}</strong>
                        <p>Invitation expires {date(invite.expiresAt)}</p>
                      </div>
                      <button
                        className="mh-text-button"
                        disabled={Boolean(busy)}
                        onClick={async () => {
                          const result = await mutate(
                            `revoke-${invite.id}`,
                            `/membership/team/invites/${encodeURIComponent(invite.id)}`,
                            "DELETE",
                          );
                          if (result) {
                            setNewInvite("");
                            onToast(
                              "Invitation revoked. The reserved seat is available again.",
                            );
                          }
                        }}
                      >
                        Revoke <X size={14} />
                      </button>
                    </article>
                  ))}
                </section>
              )}
              {owner && (
                <div className="mh-leave">
                  <p>
                    Closing this workspace revokes all team invitations and
                    shared access. Your own membership and purchases remain
                    unchanged.
                  </p>
                  {confirm === "close-team" ? (
                    <div className="mh-confirm-actions">
                      <button
                        disabled={Boolean(busy)}
                        onClick={async () => {
                          const result = await mutate(
                            "close-team",
                            "/membership/team",
                            "DELETE",
                          );
                          if (result) {
                            setNewInvite("");
                            onToast(
                              "Workspace closed. Shared access and invitations have ended.",
                            );
                          }
                        }}
                      >
                        Confirm close workspace
                      </button>
                      <button onClick={() => setConfirm(null)}>
                        Keep workspace
                      </button>
                    </div>
                  ) : (
                    <button
                      className="btn btn-outline"
                      onClick={() => setConfirm("close-team")}
                    >
                      Close workspace <Trash2 size={14} />
                    </button>
                  )}
                </div>
              )}
              {!owner && (
                <div className="mh-leave">
                  <p>
                    Leaving ends access from this workspace. Your own purchases
                    and personal membership stay with you.
                  </p>
                  {confirm === "leave" ? (
                    <div className="mh-confirm-actions">
                      <button
                        disabled={Boolean(busy)}
                        onClick={async () => {
                          const result = await mutate(
                            "leave",
                            "/membership/team/leave",
                          );
                          if (result) onToast("You have left the workspace.");
                        }}
                      >
                        Confirm leave
                      </button>
                      <button onClick={() => setConfirm(null)}>Stay</button>
                    </div>
                  ) : (
                    <button
                      className="btn btn-outline"
                      onClick={() => setConfirm("leave")}
                    >
                      Leave workspace <ArrowUpRight size={15} />
                    </button>
                  )}
                </div>
              )}
            </>
          ) : (
            <div className="mh-no-team">
              <span className="mh-symbol">
                <Users size={32} />
              </span>
              <span className="eyebrow">A SPACE FOR SHARED POSSIBILITIES</span>
              <h2>Great things start with good company.</h2>
              <p>
                An active Studio owner can create a workspace for up to five
                people. A private invitation lets each teammate access included
                products from their own account.
              </p>
              {activePlan && subscription?.plan === "studio" ? (
                <form onSubmit={(event) => void createTeam(event)}>
                  <label htmlFor="mh-team-name">
                    Your workspace name
                    <input
                      id="mh-team-name"
                      name="name"
                      required
                      minLength={2}
                      maxLength={80}
                      placeholder="The Monday Studio"
                      disabled={Boolean(busy)}
                    />
                  </label>
                  {formError && (
                    <p className="mh-inline-error" role="alert">
                      {formError}
                    </p>
                  )}
                  <button className="btn btn-primary" disabled={Boolean(busy)}>
                    {busy === "create-team" ? (
                      <LoaderCircle size={16} className="spin" />
                    ) : (
                      <Plus size={16} />
                    )}
                    Create your workspace
                  </button>
                </form>
              ) : (
                <button className="btn btn-primary" onClick={onMembership}>
                  Find the Studio plan <ArrowUpRight size={17} />
                </button>
              )}
              <small>
                <ShieldCheck size={13} /> Already invited? Open the private link
                from your team owner.
              </small>
            </div>
          )}
        </section>
      ) : (
        <section className="mh-activity">
          <div className="mh-section-title">
            <div>
              <span className="eyebrow">EVERY MEMBERSHIP MOMENT</span>
              <h2>A clear view of what’s changed.</h2>
            </div>
            <span className="mh-activity-note">
              <ShieldCheck size={14} />
              Actual account activity
            </span>
          </div>
          {data?.events.length ? (
            <div className="mh-event-list">
              {data.events.map((event) => (
                <article key={event.id}>
                  <span
                    className={`mh-event-icon ${/fail|past_due/.test(event.type) ? "warning" : ""}`}
                  >
                    {/fail|past_due/.test(event.type) ? (
                      <CircleAlert size={20} />
                    ) : (
                      <CheckCircle2 size={20} />
                    )}
                  </span>
                  <div>
                    <h3>{event.title}</h3>
                    <p>{event.detail}</p>
                    <small>
                      {date(event.createdAt)} <i>·</i>{" "}
                      {event.type.startsWith("team.")
                        ? "Studio workspace"
                        : event.mode === "stripe"
                          ? "Stripe billing"
                          : event.mode === "trial"
                            ? "Free trial · no payment collected"
                            : "Demo · no payment collected"}
                    </small>
                  </div>
                  {event.amount !== null && (
                    <strong>
                      {money(event.amount)}
                      <small>{event.currency || "USD"}</small>
                    </strong>
                  )}
                </article>
              ))}
            </div>
          ) : (
            <div className="mh-quiet">
              <History size={32} />
              <h3>Every story starts somewhere.</h3>
              <p>
                Verified billing events and membership changes will appear here
                as they happen.
              </p>
            </div>
          )}
          <div className="mh-activity-disclosure">
            <ShieldCheck size={17} />
            <p>
              Demo events never represent real money. Live billing activity is
              recorded only from verified payment-provider events. Stripe’s
              billing portal handles payment-method updates and
              provider-supported plan changes.
            </p>
          </div>
        </section>
      )}
    </section>
  );
}
