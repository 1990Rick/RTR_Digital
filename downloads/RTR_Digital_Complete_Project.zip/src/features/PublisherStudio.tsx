import { useCallback, useEffect, useRef, useState } from "react";
import type { FormEvent } from "react";
import {
  ArrowUpRight,
  CalendarClock,
  Check,
  CheckCircle2,
  ChevronRight,
  CircleAlert,
  FileCode2,
  FileDown,
  FileUp,
  KeyRound,
  Layers3,
  Loader2,
  LockKeyhole,
  PencilLine,
  Search,
  ShieldCheck,
  Sparkles,
  UploadCloud,
  X,
} from "lucide-react";
import { api, money } from "../lib/api";
import { SELLER_NAME } from "../lib/brand";
import type { Product, User } from "../lib/types";
import { ProductArt } from "../components/Brand";
import "./publishing.css";

type Props = {
  user: User | null;
  onSignIn: () => void;
  onToast: (message: string, kind?: "success" | "error") => void;
  onProduct: (product: Product) => void;
  onRefresh?: () => void;
};
type Version = {
  id: string;
  version: string;
  changelog: string;
  checksum: string;
  bytes: number;
  createdAt: string;
};
type UploadSession = {
  id: string;
  productId: string;
  filename: string;
  version: string;
  changelog: string;
  totalBytes: number;
  receivedBytes: number;
  expectedSha256: string | null;
  status:
    | "uploading"
    | "finalizing"
    | "failed"
    | "completed"
    | "canceled"
    | "expired";
  error: string | null;
  chunkBytes: number;
};
type UploadCapabilities = { chunkBytes: number; maxBytes: number };
const bytesLabel = (bytes: number) =>
  bytes >= 1024 ** 3
    ? `${(bytes / 1024 ** 3).toFixed(1)} GB`
    : `${(bytes / 1024 ** 2).toFixed(1)} MB`;

// Incremental hashing keeps even a multi-gigabyte original out of browser memory.
class ReleaseSha256 {
  private state = new Uint32Array([
    0x6a09e667, 0xbb67ae85, 0x3c6ef372, 0xa54ff53a, 0x510e527f, 0x9b05688c,
    0x1f83d9ab, 0x5be0cd19,
  ]);
  private block = new Uint8Array(64);
  private words = new Uint32Array(64);
  private buffered = 0;
  private length = 0;
  private static rounds = new Uint32Array([
    0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5, 0x3956c25b, 0x59f111f1,
    0x923f82a4, 0xab1c5ed5, 0xd807aa98, 0x12835b01, 0x243185be, 0x550c7dc3,
    0x72be5d74, 0x80deb1fe, 0x9bdc06a7, 0xc19bf174, 0xe49b69c1, 0xefbe4786,
    0x0fc19dc6, 0x240ca1cc, 0x2de92c6f, 0x4a7484aa, 0x5cb0a9dc, 0x76f988da,
    0x983e5152, 0xa831c66d, 0xb00327c8, 0xbf597fc7, 0xc6e00bf3, 0xd5a79147,
    0x06ca6351, 0x14292967, 0x27b70a85, 0x2e1b2138, 0x4d2c6dfc, 0x53380d13,
    0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85, 0xa2bfe8a1, 0xa81a664b,
    0xc24b8b70, 0xc76c51a3, 0xd192e819, 0xd6990624, 0xf40e3585, 0x106aa070,
    0x19a4c116, 0x1e376c08, 0x2748774c, 0x34b0bcb5, 0x391c0cb3, 0x4ed8aa4a,
    0x5b9cca4f, 0x682e6ff3, 0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208,
    0x90befffa, 0xa4506ceb, 0xbef9a3f7, 0xc67178f2,
  ]);
  private compress(bytes: Uint8Array, start: number) {
    const w = this.words;
    const rotate = (x: number, n: number) => (x >>> n) | (x << (32 - n));
    for (let i = 0; i < 16; i++) {
      const j = start + i * 4;
      w[i] =
        (bytes[j] << 24) |
        (bytes[j + 1] << 16) |
        (bytes[j + 2] << 8) |
        bytes[j + 3];
    }
    for (let i = 16; i < 64; i++) {
      const x = w[i - 15],
        y = w[i - 2];
      w[i] =
        w[i - 16] +
        (rotate(x, 7) ^ rotate(x, 18) ^ (x >>> 3)) +
        w[i - 7] +
        (rotate(y, 17) ^ rotate(y, 19) ^ (y >>> 10));
    }
    let [a, b, c, d, e, f, g, h] = this.state;
    for (let i = 0; i < 64; i++) {
      const first =
        (h +
          (rotate(e, 6) ^ rotate(e, 11) ^ rotate(e, 25)) +
          ((e & f) ^ (~e & g)) +
          ReleaseSha256.rounds[i] +
          w[i]) >>>
        0;
      const second =
        ((rotate(a, 2) ^ rotate(a, 13) ^ rotate(a, 22)) +
          ((a & b) ^ (a & c) ^ (b & c))) >>>
        0;
      h = g;
      g = f;
      f = e;
      e = (d + first) >>> 0;
      d = c;
      c = b;
      b = a;
      a = (first + second) >>> 0;
    }
    [a, b, c, d, e, f, g, h].forEach((value, i) => {
      this.state[i] += value;
    });
  }
  update(bytes: Uint8Array) {
    this.length += bytes.length;
    let offset = 0;
    if (this.buffered) {
      const take = Math.min(64 - this.buffered, bytes.length);
      this.block.set(bytes.subarray(0, take), this.buffered);
      this.buffered += take;
      offset += take;
      if (this.buffered === 64) {
        this.compress(this.block, 0);
        this.buffered = 0;
      }
    }
    while (offset + 64 <= bytes.length) {
      this.compress(bytes, offset);
      offset += 64;
    }
    if (offset < bytes.length) {
      this.block.set(bytes.subarray(offset));
      this.buffered = bytes.length - offset;
    }
  }
  digest() {
    const padding = new Uint8Array(this.buffered < 56 ? 64 : 128);
    padding.set(this.block.subarray(0, this.buffered));
    padding[this.buffered] = 0x80;
    const view = new DataView(padding.buffer);
    view.setUint32(padding.length - 8, Math.floor(this.length / 0x20000000));
    view.setUint32(padding.length - 4, (this.length * 8) >>> 0);
    for (let offset = 0; offset < padding.length; offset += 64)
      this.compress(padding, offset);
    return Array.from(this.state, (value) =>
      value.toString(16).padStart(8, "0"),
    ).join("");
  }
}
async function releaseChecksum(
  file: File,
  signal: AbortSignal,
  progress: (value: number) => void,
) {
  const hash = new ReleaseSha256();
  for (let offset = 0; offset < file.size; offset += 2 * 1024 * 1024) {
    if (signal.aborted) throw new DOMException("Upload paused.", "AbortError");
    hash.update(
      new Uint8Array(
        await file.slice(offset, offset + 2 * 1024 * 1024).arrayBuffer(),
      ),
    );
    progress(Math.min(file.size, offset + 2 * 1024 * 1024));
    await new Promise<void>((resolve) => setTimeout(resolve, 0));
  }
  if (signal.aborted) throw new DOMException("Upload paused.", "AbortError");
  return hash.digest();
}

type Preview = { kind: string; mime: string; url: string };
type Details = {
  product: Product;
  versions: Version[];
  preview: Preview | null;
  licenses: { total: number; assigned: number; available: number };
  scheduledAt: string | null;
};
type Draft = {
  title: string;
  description: string;
  category: string;
  price: string;
  format: string;
  tags: string;
  subscriptionIncluded: boolean;
  status: string;
  scheduledAt: string;
};
type ModeratedReview = {
  id: string;
  productId: string;
  name: string;
  body: string;
  rating: number;
  hidden: boolean;
  moderationReason: string;
  createdAt: string;
};
type ReviewReport = {
  id: string;
  review_id: string;
  reason: string;
  status: string;
};
const categories = [
  "Design assets",
  "E-books",
  "Audio & music",
  "Courses",
  "Software",
  "Templates",
  "Video",
];
const message = (error: unknown) =>
  error instanceof Error
    ? error.message
    : "That operation could not be completed.";
const dateLabel = (value?: string | null) =>
  value
    ? new Date(value).toLocaleString("en-US", {
        year: "numeric",
        month: "short",
        day: "numeric",
        hour: "2-digit",
        minute: "2-digit",
        timeZone: "UTC",
        timeZoneName: "short",
      })
    : "Not scheduled";
const draftFor = (d: Details): Draft => ({
  title: d.product.title,
  description: d.product.description,
  category: d.product.category,
  price: String(d.product.price),
  format: d.product.format,
  tags: d.product.tags.join(", "),
  subscriptionIncluded: d.product.subscriptionIncluded,
  status: d.product.status || "draft",
  scheduledAt: d.scheduledAt
    ? new Date(d.scheduledAt).toISOString().slice(0, 16)
    : "",
});

function csvRows(text: string): string[][] {
  const rows: string[][] = [];
  let row: string[] = [];
  let field = "";
  let quoted = false;
  for (let i = 0; i < text.length; i++) {
    const c = text[i];
    if (c === '"') {
      if (quoted && text[i + 1] === '"') {
        field += '"';
        i++;
      } else quoted = !quoted;
    } else if (c === "," && !quoted) {
      row.push(field);
      field = "";
    } else if ((c === "\n" || c === "\r") && !quoted) {
      if (c === "\r" && text[i + 1] === "\n") i++;
      row.push(field);
      if (row.some((v) => v.trim())) rows.push(row);
      row = [];
      field = "";
    } else field += c;
  }
  if (quoted) throw new Error("The CSV contains an unclosed quoted field.");
  row.push(field);
  if (row.some((v) => v.trim())) rows.push(row);
  return rows;
}
function parseImport(text: string): Record<string, unknown>[] {
  const trimmed = text.replace(/^\uFEFF/, "").trim();
  let rows: unknown;
  if (trimmed.startsWith("[") || trimmed.startsWith("{")) {
    const parsed: unknown = JSON.parse(trimmed);
    rows = Array.isArray(parsed)
      ? parsed
      : (parsed as { products?: unknown }).products;
  } else {
    const parsed = csvRows(trimmed);
    const headers = parsed.shift()?.map((v) => v.trim()) || [];
    if (!headers.includes("id")) throw new Error("The CSV needs an id column.");
    rows = parsed.map((row) =>
      Object.fromEntries(
        headers.map((header, i) => {
          const raw = row[i] || "";
          let value: unknown = raw;
          if (header === "price") value = Number(raw);
          if (header === "subscriptionIncluded") {
            if (!["true", "false"].includes(raw.toLowerCase()))
              throw new Error("subscriptionIncluded must be true or false.");
            value = raw.toLowerCase() === "true";
          }
          if (header === "tags")
            value = raw
              .split("|")
              .map((v) => v.trim())
              .filter(Boolean);
          return [header, value];
        }),
      ),
    );
  }
  if (
    !Array.isArray(rows) ||
    !rows.length ||
    rows.length > 100 ||
    rows.some(
      (row) =>
        !row ||
        typeof row !== "object" ||
        Array.isArray(row) ||
        typeof (row as { id?: unknown }).id !== "string",
    )
  )
    throw new Error(
      "Provide between 1 and 100 product records, each with an existing product id.",
    );
  return rows as Record<string, unknown>[];
}

export function PublisherStudio({
  user,
  onSignIn,
  onToast,
  onProduct,
  onRefresh,
}: Props) {
  const [products, setProducts] = useState<Product[]>([]);
  const [selected, setSelected] = useState("");
  const [details, setDetails] = useState<Details | null>(null);
  const [draft, setDraft] = useState<Draft | null>(null);
  const [query, setQuery] = useState("");
  const [tab, setTab] = useState("Metadata");
  const [loading, setLoading] = useState(false);
  const [loadingDetail, setLoadingDetail] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [importOpen, setImportOpen] = useState(false);
  const [createOpen, setCreateOpen] = useState(false);
  const [importText, setImportText] = useState("");
  const [importError, setImportError] = useState("");
  const [release, setRelease] = useState<File | null>(null);
  const [preview, setPreview] = useState<File | null>(null);
  const [uploadCapabilities, setUploadCapabilities] =
    useState<UploadCapabilities>({
      chunkBytes: 8 * 1024 * 1024,
      maxBytes: 5 * 1024 ** 3,
    });
  const [uploads, setUploads] = useState<UploadSession[]>([]);
  const [activeUpload, setActiveUpload] = useState<UploadSession | null>(null);
  const [releaseVersion, setReleaseVersion] = useState("");
  const [releaseChangelog, setReleaseChangelog] = useState("");
  const [uploadPhase, setUploadPhase] = useState<
    "" | "checking" | "uploading" | "finalizing"
  >("");
  const [checkedBytes, setCheckedBytes] = useState(0);
  const uploadController = useRef<AbortController | null>(null);
  const uploadRequest = useRef(0);
  const [keys, setKeys] = useState("");
  const [reviews, setReviews] = useState<ModeratedReview[]>([]);
  const [reports, setReports] = useState<ReviewReport[]>([]);
  const importModal = useRef<HTMLElement>(null);
  const busyRef = useRef(busy);
  busyRef.current = busy;
  const detailRequest = useRef(0);
  const loadReviews = useCallback(async () => {
    const data = await api<{
      reviews: ModeratedReview[];
      reports: ReviewReport[];
    }>("/publisher/reviews");
    setReviews(data.reviews);
    setReports(data.reports);
  }, []);
  useEffect(() => {
    if (tab === "Reviews" && user?.role === "admin")
      void loadReviews().catch((error) => setError(message(error)));
  }, [tab, user?.role, loadReviews]);
  useEffect(() => {
    if (!importOpen) return;
    const trigger = document.activeElement as HTMLElement;
    const oldOverflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    const controls = () =>
      importModal.current?.querySelectorAll<HTMLElement>(
        "button:not([disabled]), input:not([disabled]), textarea:not([disabled]), select:not([disabled]), summary, a[href]",
      );
    controls()?.[0]?.focus();
    const keyboard = (event: KeyboardEvent) => {
      if (event.key === "Escape" && !busyRef.current) setImportOpen(false);
      if (event.key !== "Tab") return;
      const nodes = controls();
      if (!nodes?.length) return;
      const first = nodes[0],
        last = nodes[nodes.length - 1];
      if (event.shiftKey && document.activeElement === first) {
        event.preventDefault();
        last.focus();
      } else if (!event.shiftKey && document.activeElement === last) {
        event.preventDefault();
        first.focus();
      }
    };
    document.addEventListener("keydown", keyboard);
    return () => {
      document.removeEventListener("keydown", keyboard);
      document.body.style.overflow = oldOverflow;
      if (trigger?.isConnected) trigger.focus();
    };
  }, [importOpen]);
  const loadProducts = useCallback(async () => {
    if (user?.role !== "admin") return;
    setLoading(true);
    try {
      const d = await api<{ products: Product[] }>("/publisher/products");
      setProducts(d.products);
      setSelected((current) =>
        current && d.products.some((p) => p.id === current)
          ? current
          : d.products[0]?.id || "",
      );
      setError("");
    } catch (err) {
      setError(message(err));
    } finally {
      setLoading(false);
    }
  }, [user?.id, user?.role]);
  const loadDetail = useCallback(async (id: string) => {
    if (!id) return;
    const request = ++detailRequest.current;
    setLoadingDetail(true);
    try {
      const d = await api<Details>(
        `/publisher/products/${encodeURIComponent(id)}`,
      );
      if (request !== detailRequest.current) return;
      setDetails(d);
      setDraft(draftFor(d));
      setError("");
    } catch (err) {
      if (request === detailRequest.current) setError(message(err));
    } finally {
      if (request === detailRequest.current) setLoadingDetail(false);
    }
  }, []);
  const loadUploads = useCallback(
    async (id: string) => {
      const request = ++uploadRequest.current;
      if (!id || user?.role !== "admin") return;
      try {
        const [data, capabilities] = await Promise.all([
          api<{ uploads: UploadSession[] }>(
            `/publisher/uploads?productId=${encodeURIComponent(id)}`,
          ),
          api<UploadCapabilities>("/publisher/upload-capabilities"),
        ]);
        if (request !== uploadRequest.current) return;
        setUploads(data.uploads);
        setUploadCapabilities(capabilities);
        setActiveUpload(
          (current) =>
            data.uploads.find((upload) => upload.id === current?.id) ||
            data.uploads[0] ||
            null,
        );
      } catch (err) {
        if (request === uploadRequest.current) setError(message(err));
      }
    },
    [user?.id, user?.role],
  );
  useEffect(() => {
    if (!activeUpload) return;
    setReleaseVersion(activeUpload.version);
    setReleaseChangelog(activeUpload.changelog);
  }, [activeUpload?.id]);
  useEffect(
    () => () => {
      uploadController.current?.abort();
    },
    [],
  );
  useEffect(() => {
    void loadProducts();
  }, [loadProducts]);
  useEffect(() => {
    setDetails(null);
    setDraft(null);
    setRelease(null);
    setPreview(null);
    setKeys("");
    setUploads([]);
    setActiveUpload(null);
    setReleaseVersion("");
    setReleaseChangelog("");
    void loadDetail(selected);
    void loadUploads(selected);
  }, [selected, loadDetail, loadUploads]);
  const refresh = async () => {
    await Promise.all([loadProducts(), loadDetail(selected)]);
    onRefresh?.();
  };
  const patchDraft = <K extends keyof Draft>(key: K, value: Draft[K]) =>
    setDraft((d) => (d ? { ...d, [key]: value } : d));
  async function save(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    if (!draft) return;
    setBusy(true);
    setError("");
    try {
      await api(`/publisher/products/${encodeURIComponent(selected)}`, {
        method: "PATCH",
        body: JSON.stringify({
          ...draft,
          creator: SELLER_NAME,
          price: Number(draft.price),
          tags: draft.tags
            .split(",")
            .map((v) => v.trim())
            .filter(Boolean),
          scheduledAt: draft.scheduledAt
            ? new Date(`${draft.scheduledAt}Z`).toISOString()
            : null,
        }),
      });
      await refresh();
      onToast("Product details saved. Your collection is up to date.");
    } catch (err) {
      setError(message(err));
    } finally {
      setBusy(false);
    }
  }
  async function createDraft(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setBusy(true);
    setError("");
    const form = e.currentTarget,
      values = new FormData(form);
    try {
      const result = await api<{ product: Product }>("/publisher/products", {
        method: "POST",
        body: JSON.stringify({
          title: values.get("title"),
          description: values.get("description"),
          creator: SELLER_NAME,
          category: values.get("category"),
          price: Number(values.get("price")),
          subscriptionIncluded: values.get("subscriptionIncluded") === "on",
        }),
      });
      await loadProducts();
      setSelected(result.product.id);
      setTab("Releases");
      setCreateOpen(false);
      form.reset();
      onToast(
        "Draft created. Upload its first original release, then publish it from Product details.",
      );
      onRefresh?.();
    } catch (err) {
      setError(message(err));
    } finally {
      setBusy(false);
    }
  }
  async function publishRelease(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    let session = activeUpload;
    const complete =
      session?.receivedBytes === session?.totalBytes && !!session;
    if (!release && !complete) {
      setError(
        "Choose the same original file to start or resume this release.",
      );
      return;
    }
    if (
      release &&
      (!release.size || release.size > uploadCapabilities.maxBytes)
    ) {
      setError(
        `Choose a nonempty file up to ${bytesLabel(uploadCapabilities.maxBytes)}.`,
      );
      return;
    }
    if (session && session.status !== "uploading") {
      setError(
        session.error ||
          "This upload is being finalized. Refresh its status before continuing.",
      );
      return;
    }
    if (
      session &&
      release &&
      (release.name !== session.filename || release.size !== session.totalBytes)
    ) {
      setError(
        "Reselect the same original file, with the same filename and size, to resume this upload.",
      );
      return;
    }
    setBusy(true);
    setError("");
    const form = e.currentTarget;
    const controller = new AbortController();
    uploadController.current = controller;
    try {
      if (!session && release && release.size <= 100 * 1024 * 1024) {
        const body = new FormData(form);
        body.set("file", release);
        await api(
          `/publisher/products/${encodeURIComponent(selected)}/releases`,
          { method: "POST", body },
        );
      } else {
        if (!complete && release) {
          setUploadPhase("checking");
          setCheckedBytes(0);
          const sha256 = await releaseChecksum(
            release,
            controller.signal,
            setCheckedBytes,
          );
          if (
            session &&
            (!session.expectedSha256 || sha256 !== session.expectedSha256)
          )
            throw new Error(
              "The selected file does not match this upload’s SHA-256 fingerprint. Reselect the original file, or cancel this session to start again.",
            );
          if (!session) {
            session = (
              await api<{ upload: UploadSession }>(
                `/publisher/products/${encodeURIComponent(selected)}/uploads`,
                {
                  method: "POST",
                  body: JSON.stringify({
                    version: releaseVersion,
                    changelog: releaseChangelog,
                    totalBytes: release.size,
                    filename: release.name,
                    sha256,
                  }),
                  signal: controller.signal,
                },
              )
            ).upload;
            setActiveUpload(session);
            setUploads((current) => [session!, ...current]);
          }
        }
        if (!session) throw new Error("Choose an original release file first.");
        session = (
          await api<{ upload: UploadSession }>(
            `/publisher/uploads/${encodeURIComponent(session.id)}`,
          )
        ).upload;
        setActiveUpload(session);
        if (session.status !== "uploading")
          throw new Error(
            session.error ||
              "This upload is not ready to resume. Refresh its status.",
          );
        setUploadPhase("uploading");
        let conflicts = 0;
        while (session.receivedBytes < session.totalBytes) {
          if (controller.signal.aborted)
            throw new DOMException("Upload paused.", "AbortError");
          if (!release)
            throw new Error("Reselect the original release file to continue.");
          const response = await fetch(
            `/api/publisher/uploads/${encodeURIComponent(session.id)}/chunk`,
            {
              method: "PUT",
              credentials: "same-origin",
              signal: controller.signal,
              headers: {
                "Content-Type": "application/octet-stream",
                "Upload-Offset": String(session.receivedBytes),
              },
              body: release.slice(
                session.receivedBytes,
                Math.min(
                  session.totalBytes,
                  session.receivedBytes + session.chunkBytes,
                ),
              ),
            },
          );
          const data = (await response.json()) as {
            upload?: UploadSession;
            error?: string;
          };
          if (
            response.status === 409 &&
            data.upload?.status === "uploading" &&
            conflicts++ < 2
          ) {
            session = data.upload;
            setActiveUpload(session);
            continue;
          }
          if (!response.ok || !data.upload)
            throw new Error(
              data.error ||
                "The chunk could not be saved. Resume to retry from the last confirmed byte.",
            );
          session = data.upload;
          setActiveUpload(session);
          conflicts = 0;
        }
        if (controller.signal.aborted)
          throw new DOMException("Upload paused.", "AbortError");
        setUploadPhase("finalizing");
        await api(
          `/publisher/uploads/${encodeURIComponent(session.id)}/finalize`,
          { method: "POST" },
        );
        setUploads((current) =>
          current.filter((upload) => upload.id !== session!.id),
        );
        setActiveUpload(null);
      }
      await refresh();
      setRelease(null);
      setReleaseVersion("");
      setReleaseChangelog("");
      form.reset();
      onToast(
        "New release published. Existing customers can access the latest file.",
      );
    } catch (err) {
      if (session) {
        try {
          setActiveUpload(
            (
              await api<{ upload: UploadSession }>(
                `/publisher/uploads/${encodeURIComponent(session.id)}`,
              )
            ).upload,
          );
        } catch {
          /* The persisted session remains available when the connection returns. */
        }
      }
      if (err instanceof DOMException && err.name === "AbortError")
        onToast(
          session
            ? "Upload paused. Your confirmed progress is saved; resume whenever you are ready."
            : "File check paused. Your original is ready to select again.",
        );
      else setError(message(err));
    } finally {
      uploadController.current = null;
      setUploadPhase("");
      setBusy(false);
    }
  }
  async function cancelUpload(session: UploadSession) {
    setBusy(true);
    setError("");
    try {
      await api(`/publisher/uploads/${encodeURIComponent(session.id)}`, {
        method: "DELETE",
      });
      setUploads((current) =>
        current.filter((upload) => upload.id !== session.id),
      );
      if (activeUpload?.id === session.id) {
        setActiveUpload(null);
        setRelease(null);
        setReleaseVersion("");
        setReleaseChangelog("");
      }
      onToast("Upload canceled and its private temporary file removed.");
    } catch (err) {
      setError(message(err));
    } finally {
      setBusy(false);
    }
  }
  async function uploadPreview(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    if (!preview) {
      setError("Choose the public preview file first.");
      return;
    }
    setBusy(true);
    setError("");
    const form = e.currentTarget;
    try {
      const body = new FormData();
      body.set("file", preview);
      await api(`/publisher/products/${encodeURIComponent(selected)}/preview`, {
        method: "POST",
        body,
      });
      await refresh();
      setPreview(null);
      form.reset();
      onToast(
        "Public preview saved. Customers can try this product before purchasing.",
      );
    } catch (err) {
      setError(message(err));
    } finally {
      setBusy(false);
    }
  }
  async function removePreview() {
    setBusy(true);
    setError("");
    try {
      await api(`/publisher/products/${encodeURIComponent(selected)}/preview`, {
        method: "DELETE",
      });
      await refresh();
      onToast("Preview removed from the product.");
    } catch (err) {
      setError(message(err));
    } finally {
      setBusy(false);
    }
  }
  async function importKeys(e: FormEvent) {
    e.preventDefault();
    setBusy(true);
    setError("");
    try {
      await api(
        `/publisher/products/${encodeURIComponent(selected)}/licenses`,
        { method: "POST", body: JSON.stringify({ keys }) },
      );
      setKeys("");
      await refresh();
      onToast("License inventory updated. Keys remain private until assigned.");
    } catch (err) {
      setError(message(err));
    } finally {
      setBusy(false);
    }
  }
  async function applyImport(e: FormEvent) {
    e.preventDefault();
    setBusy(true);
    setImportError("");
    try {
      const list = parseImport(importText).map((product) => ({
        ...product,
        creator: SELLER_NAME,
      }));
      await api("/publisher/import", {
        method: "POST",
        body: JSON.stringify({ products: list }),
      });
      setImportText("");
      setImportOpen(false);
      await refresh();
      onToast(`${list.length} product records updated together.`);
    } catch (err) {
      setImportError(message(err));
    } finally {
      setBusy(false);
    }
  }
  async function readImport(file?: File) {
    if (!file) return;
    if (file.size > 512000) {
      setImportError("Choose a CSV or JSON file smaller than 500 KB.");
      return;
    }
    try {
      const data = await file.text();
      parseImport(data);
      setImportText(data);
      setImportError("");
    } catch (err) {
      setImportError(message(err));
    }
  }
  async function moderate(review: ModeratedReview) {
    setBusy(true);
    setError("");
    try {
      await api(`/publisher/reviews/${encodeURIComponent(review.id)}`, {
        method: "PATCH",
        body: JSON.stringify({
          hidden: !review.hidden,
          reason: review.hidden
            ? "Restored after administrator review."
            : "Hidden pending administrator review.",
        }),
      });
      await loadReviews();
      onToast(
        review.hidden
          ? "Review restored to the product."
          : "Review hidden. The original record is preserved.",
      );
    } catch (error) {
      setError(message(error));
    } finally {
      setBusy(false);
    }
  }
  async function resolveReport(reportId: string) {
    setBusy(true);
    setError("");
    try {
      await api(`/publisher/reports/${encodeURIComponent(reportId)}`, {
        method: "PATCH",
        body: JSON.stringify({ status: "resolved" }),
      });
      await loadReviews();
      onToast("Report resolved. Its history remains available for review.");
    } catch (error) {
      setError(message(error));
    } finally {
      setBusy(false);
    }
  }
  if (user?.role !== "admin")
    return (
      <section className="page-width page-shell pub-access">
        <span className="pub-feature-icon">
          <LockKeyhole />
        </span>
        <span className="eyebrow">THE DETAILS BEHIND THE DIGITAL</span>
        <h1>
          Give your good ideas
          <br />a beautiful release.
        </h1>
        <p>
          Metadata, updates, previews, and licenses.
          <br />
          Your digital publishing workspace.
        </p>
        <button className="btn btn-primary" onClick={onSignIn}>
          Sign in as administrator <ArrowUpRight size={17} />
        </button>
      </section>
    );
  const filtered = products.filter((p) =>
    `${p.title} ${p.category} ${p.id}`
      .toLowerCase()
      .includes(query.toLowerCase()),
  );
  return (
    <section className="page-width page-shell publisher-studio">
      <header className="pub-page-heading">
        <div>
          <span className="eyebrow">EVERY DETAIL. EVERY POSSIBILITY.</span>
          <h1>
            The publishing studio<span>.</span>
          </h1>
          <p>
            Manage RTR Digital products, updates, previews, and licenses.
          </p>
        </div>
        <div className="pub-heading-actions">
          <button
            className="btn btn-primary"
            disabled={busy}
            aria-expanded={createOpen}
            aria-controls="pub-create-draft"
            onClick={() => {
              setCreateOpen((current) => !current);
              setError("");
            }}
          >
            <FileUp size={17} /> New product
          </button>
          <button
            className="btn btn-outline"
            disabled={busy}
            onClick={() => {
              setImportOpen(true);
              setImportError("");
            }}
          >
            <FileUp size={17} /> Bulk update
          </button>
        </div>
      </header>
      {createOpen && (
        <section id="pub-create-draft" className="pub-create-draft">
          <div className="pub-section-intro">
            <h3>Start with the story.</h3>
            <p>
              Create a private draft, upload its original file, then publish
              when everything is ready. Prices are in USD for customers in India
              and worldwide.
            </p>
          </div>
          <form className="pub-form" onSubmit={(e) => void createDraft(e)}>
            <div className="pub-form-grid">
              <label>
                Product title
                <input
                  name="title"
                  required
                  minLength={3}
                  maxLength={120}
                  placeholder="Your next digital release"
                  disabled={busy}
                />
              </label>
              <label>
                Seller & licensor
                <input
                  name="creator"
                  aria-label="Seller & licensor"
                  aria-describedby="pub-create-seller-note"
                  value={SELLER_NAME}
                  readOnly
                />
                <small id="pub-create-seller-note">
                  Every product is sold and licensed by RTR Digital.
                </small>
              </label>
              <label>
                Category
                <select name="category" defaultValue="E-books" disabled={busy}>
                  {categories.map((category) => (
                    <option key={category}>{category}</option>
                  ))}
                </select>
              </label>
              <label>
                Price (USD)
                <input
                  name="price"
                  type="number"
                  min="0"
                  max="100000"
                  step="0.01"
                  defaultValue="12"
                  required
                  disabled={busy}
                />
              </label>
            </div>
            <label>
              Description
              <textarea
                name="description"
                rows={3}
                minLength={20}
                maxLength={5000}
                required
                placeholder="What customers will discover in your original work."
                disabled={busy}
              />
            </label>
            <label className="pub-checkbox">
              <input
                type="checkbox"
                name="subscriptionIncluded"
                defaultChecked
                disabled={busy}
              />
              <span>
                <strong>Include in the member collection</strong>
                <small>
                  Members can access this product after it is published.
                </small>
              </span>
            </label>
            {error && (
              <p className="pub-error" role="alert">
                {error}
              </p>
            )}
            <div className="pub-form-actions">
              <span>
                <LockKeyhole size={14} />
                Private until its original is ready
              </span>
              <button className="btn btn-primary" disabled={busy}>
                {busy ? (
                  <Loader2 size={16} className="spin" />
                ) : (
                  <Check size={16} />
                )}{" "}
                Create draft and upload
              </button>
            </div>
          </form>
        </section>
      )}
      <div className="pub-guide">
        <ShieldCheck size={20} />
        <p>
          Create a product draft here, upload its original, then refine its
          story, release a version, or add a public sample.
        </p>
        <span>Original files stay private.</span>
      </div>
      {loading && !products.length ? (
        <div className="pub-loading">
          <Loader2 className="spin" />
          Getting your publishing desk ready…
        </div>
      ) : !products.length ? (
        <div className="empty-state">
          <Layers3 size={37} />
          <h3>Your next release starts here.</h3>
          <p>
            Choose New product above to create a draft and upload its original.
          </p>
        </div>
      ) : (
        <div className="pub-layout">
          <aside className="pub-sidebar">
            <label className="pub-search">
              <Search size={17} />
              <input
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="Find a product"
                aria-label="Find a product to edit"
              />
            </label>
            <div className="pub-product-list">
              {filtered.map((p) => (
                <button
                  className={`pub-product-option ${selected === p.id ? "active" : ""}`}
                  disabled={busy}
                  onClick={() => {
                    setSelected(p.id);
                    setError("");
                  }}
                  key={p.id}
                >
                  <span className="pub-option-art">
                    <ProductArt product={p} />
                  </span>
                  <span>
                    <strong>{p.title}</strong>
                    <small>
                      {p.category} · {money(p.price)}
                    </small>
                    <em className={p.status === "draft" ? "draft" : ""}>
                      {p.status || "published"}
                    </em>
                  </span>
                  <ChevronRight size={14} />
                </button>
              ))}
              {!filtered.length && (
                <p className="pub-no-results">
                  No matching products. Try a shorter search.
                </p>
              )}
            </div>
            <span className="pub-catalog-count">
              {products.length} digital possibilities in your catalog
            </span>
          </aside>
          <div className="pub-editor">
            {loadingDetail || !details || !draft ? (
              <div className="pub-loading">
                <Loader2 className="spin" />
                Opening the details…
              </div>
            ) : (
              <>
                <div className="pub-editor-heading">
                  <div>
                    <span className="pub-product-id">{details.product.id}</span>
                    <h2>{details.product.title}</h2>
                    <span
                      className={`pub-status ${details.product.status === "draft" ? "draft" : ""}`}
                    >
                      <i />
                      {details.product.status || "published"}
                    </span>
                    {details.scheduledAt && (
                      <span className="pub-scheduled">
                        <CalendarClock size={12} />
                        {dateLabel(details.scheduledAt)}
                      </span>
                    )}
                  </div>
                  <button
                    className="pub-text-button"
                    onClick={() => onProduct(details.product)}
                  >
                    View product <ArrowUpRight size={15} />
                  </button>
                </div>
                <nav
                  className="pub-editor-tabs"
                  aria-label="Product publishing sections"
                >
                  {[
                    { name: "Metadata", icon: PencilLine },
                    { name: "Releases", icon: Layers3 },
                    { name: "Preview", icon: Sparkles },
                    { name: "License keys", icon: KeyRound },
                    { name: "Reviews", icon: ShieldCheck },
                  ].map(({ name, icon: Icon }) => (
                    <button
                      className={tab === name ? "active" : ""}
                      disabled={busy}
                      onClick={() => {
                        setTab(name);
                        setError("");
                      }}
                      key={name}
                    >
                      <Icon size={15} />
                      {name}
                    </button>
                  ))}
                </nav>
                {error && (
                  <div className="pub-error" role="alert">
                    <CircleAlert size={17} />
                    {error}
                    <button
                      aria-label="Dismiss publishing error"
                      onClick={() => setError("")}
                    >
                      <X size={15} />
                    </button>
                  </div>
                )}
                {tab === "Metadata" && (
                  <form className="pub-form" onSubmit={(e) => void save(e)}>
                    <div className="pub-section-intro">
                      <h3>Tell its story.</h3>
                      <p>
                        Clear details make a good digital product easier to
                        discover.
                      </p>
                    </div>
                    <label>
                      Product title
                      <input
                        name="title"
                        value={draft.title}
                        onChange={(e) => patchDraft("title", e.target.value)}
                        required
                        minLength={3}
                        maxLength={120}
                      />
                    </label>
                    <label>
                      Description
                      <textarea
                        rows={5}
                        value={draft.description}
                        onChange={(e) =>
                          patchDraft("description", e.target.value)
                        }
                        required
                        minLength={20}
                        maxLength={5000}
                      />
                    </label>
                    <div className="pub-form-grid">
                      <label>
                        Seller & licensor
                        <input
                          aria-label="Seller & licensor"
                          aria-describedby="pub-edit-seller-note"
                          value={SELLER_NAME}
                          readOnly
                        />
                        <small id="pub-edit-seller-note">
                          Fixed for every RTR Digital product.
                        </small>
                      </label>
                      <label>
                        Category
                        <select
                          aria-label="Publishing category"
                          value={draft.category}
                          onChange={(e) =>
                            patchDraft("category", e.target.value)
                          }
                        >
                          {categories.map((c) => (
                            <option key={c}>{c}</option>
                          ))}
                        </select>
                      </label>
                    </div>
                    <div className="pub-form-grid">
                      <label>
                        Price (USD)
                        <input
                          type="number"
                          min="0"
                          max="100000"
                          step="0.01"
                          value={draft.price}
                          onChange={(e) => patchDraft("price", e.target.value)}
                          required
                        />
                      </label>
                      <label>
                        Formats
                        <input
                          value={draft.format}
                          onChange={(e) => patchDraft("format", e.target.value)}
                          maxLength={120}
                          placeholder="PDF, EPUB, WAV…"
                        />
                      </label>
                    </div>
                    <label>
                      Discovery tags
                      <input
                        value={draft.tags}
                        onChange={(e) => patchDraft("tags", e.target.value)}
                        maxLength={500}
                        placeholder="Separate tags with commas"
                      />
                      <small>
                        Keep tags descriptive: format, subject, or creative use.
                      </small>
                    </label>
                    <div className="pub-form-grid">
                      <label>
                        Visibility
                        <select
                          aria-label="Publishing visibility"
                          value={draft.status}
                          onChange={(e) => patchDraft("status", e.target.value)}
                        >
                          <option value="draft">Draft</option>
                          <option value="published">Published</option>
                        </select>
                      </label>
                      <label>
                        Publish at (UTC)
                        <input
                          type="datetime-local"
                          value={draft.scheduledAt}
                          onChange={(e) =>
                            patchDraft("scheduledAt", e.target.value)
                          }
                        />
                        <small>
                          Leave empty to remove a publication schedule.
                        </small>
                      </label>
                    </div>
                    <label className="pub-checkbox">
                      <input
                        type="checkbox"
                        checked={draft.subscriptionIncluded}
                        onChange={(e) =>
                          patchDraft("subscriptionIncluded", e.target.checked)
                        }
                      />
                      <span>
                        <strong>Include with the Digital Pass</strong>
                        <small>
                          Active members can access this product when published.
                        </small>
                      </span>
                      <Sparkles size={18} />
                    </label>
                    <div className="pub-form-actions">
                      <span>
                        <CheckCircle2 size={14} />
                        Server-validated product details
                      </span>
                      <button className="btn btn-primary" disabled={busy}>
                        {busy ? (
                          <Loader2 className="spin" size={16} />
                        ) : (
                          <Check size={16} />
                        )}
                        Save product details
                      </button>
                    </div>
                  </form>
                )}
                {tab === "Releases" && (
                  <div className="pub-tab-content">
                    <div className="pub-section-intro">
                      <h3>Good work keeps growing.</h3>
                      <p>
                        Release an updated file without replacing the customer’s
                        purchase history.
                      </p>
                    </div>
                    <form
                      className="pub-form"
                      onSubmit={(e) => void publishRelease(e)}
                    >
                      <div className="pub-form-grid">
                        <label>
                          Release version
                          <input
                            name="version"
                            value={releaseVersion}
                            onChange={(e) => setReleaseVersion(e.target.value)}
                            disabled={busy || !!activeUpload}
                            required
                            maxLength={40}
                            placeholder="1.1.0"
                          />
                        </label>
                        <label>
                          Original product file
                          <input
                            type="file"
                            onChange={(e) =>
                              setRelease(e.target.files?.[0] || null)
                            }
                            disabled={busy}
                            required={
                              !activeUpload ||
                              activeUpload.receivedBytes <
                                activeUpload.totalBytes
                            }
                            aria-label={
                              activeUpload
                                ? "Reselect the original release file"
                                : "New release file"
                            }
                          />
                        </label>
                      </div>
                      <label>
                        What’s new?
                        <textarea
                          name="changelog"
                          value={releaseChangelog}
                          onChange={(e) => setReleaseChangelog(e.target.value)}
                          disabled={busy || !!activeUpload}
                          rows={3}
                          required
                          minLength={5}
                          maxLength={4000}
                          placeholder="The improvements customers should know about."
                        />
                      </label>
                      <div className="pub-file-note">
                        <LockKeyhole size={16} />
                        <p>
                          The original stays account-protected. Files up to{" "}
                          {bytesLabel(uploadCapabilities.maxBytes)} are
                          supported; files over 100 MB upload in resumable
                          chunks. Reselect the same original after returning to
                          this page. Every release receives a SHA-256 checksum.
                        </p>
                      </div>
                      <button className="btn btn-primary" disabled={busy}>
                        {busy ? (
                          <Loader2 className="spin" size={16} />
                        ) : (
                          <UploadCloud size={16} />
                        )}
                        {uploadPhase === "checking"
                          ? "Checking original file…"
                          : uploadPhase === "finalizing"
                            ? "Verifying and publishing…"
                            : activeUpload
                              ? "Resume and publish release"
                              : "Publish this release"}
                      </button>
                      {uploadPhase && (
                        <div
                          className="pub-upload-progress"
                          role="status"
                          aria-live="polite"
                        >
                          <div>
                            <strong>
                              {uploadPhase === "checking"
                                ? "Checking the original file"
                                : uploadPhase === "finalizing"
                                  ? "Verifying SHA-256 and publishing"
                                  : "Saving your release"}
                            </strong>
                            <span>
                              {uploadPhase === "checking"
                                ? bytesLabel(checkedBytes)
                                : bytesLabel(
                                    activeUpload?.receivedBytes || 0,
                                  )}{" "}
                              /{" "}
                              {bytesLabel(
                                release?.size || activeUpload?.totalBytes || 0,
                              )}
                            </span>
                          </div>
                          <progress
                            aria-label={
                              uploadPhase === "checking"
                                ? "Original file check progress"
                                : "Release upload progress"
                            }
                            max={release?.size || activeUpload?.totalBytes || 1}
                            value={
                              uploadPhase === "checking"
                                ? checkedBytes
                                : activeUpload?.receivedBytes || 0
                            }
                          />
                          {uploadPhase !== "finalizing" && (
                            <button
                              type="button"
                              className="pub-text-button"
                              onClick={() => uploadController.current?.abort()}
                            >
                              Pause upload
                            </button>
                          )}
                          {uploadPhase === "finalizing" && (
                            <small>
                              You can safely leave this page. Publishing
                              finishes on the server.
                            </small>
                          )}
                        </div>
                      )}
                    </form>
                    {(uploads.length > 0 || activeUpload) && (
                      <section
                        className="pub-pending-uploads"
                        aria-label="Saved release uploads"
                      >
                        <h3>Pick up where you left off.</h3>
                        <p>
                          Progress is saved for 48 hours. Choose a saved
                          release, then reselect its original file to resume.
                        </p>
                        {(activeUpload
                          ? [
                              activeUpload,
                              ...uploads.filter(
                                (upload) => upload.id !== activeUpload.id,
                              ),
                            ]
                          : uploads
                        ).map((upload) => (
                          <article
                            key={upload.id}
                            className={
                              activeUpload?.id === upload.id ? "active" : ""
                            }
                          >
                            <div>
                              <strong>
                                {upload.filename} · {upload.version}
                              </strong>
                              <small>
                                {bytesLabel(upload.receivedBytes)} of{" "}
                                {bytesLabel(upload.totalBytes)} ·{" "}
                                {upload.status}
                              </small>
                              {upload.error && (
                                <p role="alert">{upload.error}</p>
                              )}
                            </div>
                            <div className="pub-upload-actions">
                              {upload.status === "uploading" && (
                                <button
                                  type="button"
                                  className="pub-text-button"
                                  disabled={busy}
                                  onClick={() => {
                                    setActiveUpload(upload);
                                    setRelease(null);
                                    setError("");
                                  }}
                                >
                                  {activeUpload?.id === upload.id
                                    ? "Selected"
                                    : "Resume"}
                                </button>
                              )}
                              {upload.status === "finalizing" ? (
                                <button
                                  type="button"
                                  className="pub-text-button"
                                  disabled={busy}
                                  onClick={() =>
                                    void Promise.all([
                                      loadUploads(selected),
                                      refresh(),
                                    ])
                                  }
                                >
                                  Refresh status
                                </button>
                              ) : (
                                upload.status !== "completed" && (
                                  <button
                                    type="button"
                                    className="pub-text-button pub-danger"
                                    disabled={busy}
                                    onClick={() => void cancelUpload(upload)}
                                  >
                                    Cancel upload
                                  </button>
                                )
                              )}
                            </div>
                          </article>
                        ))}
                        {activeUpload && !busy && (
                          <p className="pub-upload-reselect">
                            Selected: {activeUpload.filename}. Choose this same
                            file above; its SHA-256 fingerprint must match
                            before resuming.
                          </p>
                        )}
                      </section>
                    )}
                    <section className="pub-release-history">
                      <h3>Every chapter, kept.</h3>
                      {details.versions.length ? (
                        details.versions.map((v) => (
                          <article key={v.id}>
                            <span className="pub-release-icon">
                              <FileDown size={20} />
                            </span>
                            <div>
                              <strong>Version {v.version}</strong>
                              <small>
                                {dateLabel(v.createdAt)} ·{" "}
                                {(v.bytes / 1024 / 1024).toFixed(2)} MB
                              </small>
                              <p>{v.changelog}</p>
                              <details>
                                <summary>SHA-256 integrity checksum</summary>
                                <code>{v.checksum}</code>
                              </details>
                            </div>
                          </article>
                        ))
                      ) : (
                        <div className="pub-inline-empty">
                          <Layers3 size={24} />
                          <p>
                            No versioned releases yet. Publish an update to
                            begin the history.
                          </p>
                        </div>
                      )}
                    </section>
                  </div>
                )}
                {tab === "Preview" && (
                  <div className="pub-tab-content">
                    <div className="pub-section-intro">
                      <h3>A little taste of what’s inside.</h3>
                      <p>
                        A separate sample helps customers choose with
                        confidence.
                      </p>
                    </div>
                    {details.preview && (
                      <div className="pub-current-preview">
                        <span className="pub-feature-icon">
                          <Sparkles size={21} />
                        </span>
                        <div>
                          <strong>Public {details.preview.kind} preview</strong>
                          <small>{details.preview.mime}</small>
                          <a
                            href={details.preview.url}
                            target="_blank"
                            rel="noreferrer"
                          >
                            Open public preview <ArrowUpRight size={13} />
                          </a>
                        </div>
                        <button
                          className="pub-text-button pub-danger"
                          disabled={busy}
                          onClick={() => void removePreview()}
                        >
                          Remove <X size={14} />
                        </button>
                      </div>
                    )}
                    <form
                      className="pub-form"
                      onSubmit={(e) => void uploadPreview(e)}
                    >
                      <label>
                        Preview file
                        <input
                          type="file"
                          accept="audio/*,video/*,.pdf,.txt,text/plain,application/pdf"
                          required
                          onChange={(e) =>
                            setPreview(e.target.files?.[0] || null)
                          }
                          aria-label="Public product preview file"
                        />
                        <small>
                          Audio, video, PDF, or plain text. Only a separate
                          sample, never the complete paid product.
                        </small>
                      </label>
                      <label className="pub-checkbox pub-public-warning">
                        <input type="checkbox" required />
                        <span>
                          <strong>I understand this preview is public.</strong>
                          <small>
                            Anyone viewing a published product can access this
                            sample without buying. Only upload content you have
                            permission to share publicly.
                          </small>
                        </span>
                        <ShieldCheck size={19} />
                      </label>
                      <button className="btn btn-primary" disabled={busy}>
                        {busy ? (
                          <Loader2 className="spin" size={16} />
                        ) : (
                          <UploadCloud size={16} />
                        )}
                        Save public preview
                      </button>
                    </form>
                  </div>
                )}
                {tab === "License keys" && (
                  <div className="pub-tab-content">
                    <div className="pub-section-intro">
                      <h3>Access, thoughtfully assigned.</h3>
                      <p>
                        Manage RTR Digital activation keys for this product.
                      </p>
                    </div>
                    <div className="pub-license-stats">
                      {[
                        {
                          label: "In inventory",
                          value: details.licenses.total,
                        },
                        { label: "Assigned", value: details.licenses.assigned },
                        {
                          label: "Available",
                          value: details.licenses.available,
                        },
                      ].map((stat) => (
                        <div key={stat.label}>
                          <strong>{stat.value}</strong>
                          <span>{stat.label}</span>
                        </div>
                      ))}
                    </div>
                    <form
                      className="pub-form"
                      onSubmit={(e) => void importKeys(e)}
                    >
                      <label>
                        Private activation keys
                        <textarea
                          value={keys}
                          onChange={(e) => setKeys(e.target.value)}
                          required
                          rows={6}
                          placeholder="One genuine license key per line"
                          autoComplete="off"
                          spellCheck={false}
                        />
                        <small>
                          Keys are assigned individually to entitled customers.
                          Imported keys are not displayed in catalog responses.
                        </small>
                      </label>
                      <div className="pub-file-note">
                        <KeyRound size={16} />
                        <p>
                          Keys are delivered from RTR Digital’s private
                          inventory. Add valid keys for this product before
                          publishing software that requires activation.
                        </p>
                      </div>
                      <button className="btn btn-primary" disabled={busy}>
                        {busy ? (
                          <Loader2 className="spin" size={16} />
                        ) : (
                          <KeyRound size={16} />
                        )}
                        Add private keys
                      </button>
                    </form>
                  </div>
                )}
                {tab === "Reviews" && (
                  <div className="pub-tab-content pub-moderation">
                    <div className="pub-section-intro">
                      <h3>A little trust, thoughtfully tended.</h3>
                      <p>
                        Review customer feedback and reports. Hiding a review
                        preserves its record while removing it from the public
                        product page.
                      </p>
                    </div>
                    {reviews.filter((review) => review.productId === selected)
                      .length ? (
                      reviews
                        .filter((review) => review.productId === selected)
                        .map((review) => (
                          <article className="pub-review" key={review.id}>
                            <div className="pub-review-top">
                              <strong>{review.name}</strong>
                              <span>{review.rating} / 5</span>
                              <small>
                                {new Date(
                                  review.createdAt,
                                ).toLocaleDateString()}
                              </small>
                              <em>{review.hidden ? "Hidden" : "Public"}</em>
                            </div>
                            <p>{review.body}</p>
                            {reports
                              .filter(
                                (report) => report.review_id === review.id,
                              )
                              .map((report) => (
                                <div
                                  className="pub-review-report"
                                  key={report.id}
                                >
                                  <ShieldCheck size={15} />
                                  <div>
                                    <strong>
                                      Customer report · {report.status}
                                    </strong>
                                    <p>{report.reason}</p>
                                  </div>
                                  {report.status === "open" && (
                                    <button
                                      className="pub-text-button"
                                      disabled={busy}
                                      onClick={() =>
                                        void resolveReport(report.id)
                                      }
                                    >
                                      Resolve
                                    </button>
                                  )}
                                </div>
                              ))}
                            {review.moderationReason && (
                              <small className="pub-review-reason">
                                Last moderation note: {review.moderationReason}
                              </small>
                            )}
                            <button
                              className="btn btn-outline"
                              disabled={busy}
                              onClick={() => void moderate(review)}
                            >
                              {busy ? (
                                <Loader2 size={14} className="spin" />
                              ) : (
                                <ShieldCheck size={14} />
                              )}{" "}
                              {review.hidden
                                ? "Restore review"
                                : "Hide review for review"}
                            </button>
                          </article>
                        ))
                    ) : (
                      <div className="pub-inline-empty">
                        <ShieldCheck size={25} />
                        <p>No customer reviews for this product yet.</p>
                      </div>
                    )}
                  </div>
                )}
              </>
            )}
          </div>
        </div>
      )}
      {error && !details && (
        <div className="pub-error" role="alert">
          <CircleAlert size={17} />
          {error}
          <button
            className="pub-text-button"
            onClick={() => void loadProducts()}
          >
            Try again
          </button>
        </div>
      )}
      {importOpen && (
        <div
          className="pub-import-backdrop"
          role="presentation"
          onClick={(e) => {
            if (e.target === e.currentTarget && !busy) setImportOpen(false);
          }}
        >
          <section
            ref={importModal}
            role="dialog"
            aria-modal="true"
            aria-labelledby="pub-import-title"
            className="pub-import-panel"
          >
            <button
              className="pub-import-close"
              aria-label="Close bulk update"
              disabled={busy}
              onClick={() => setImportOpen(false)}
            >
              <X size={20} />
            </button>
            <span className="pub-feature-icon">
              <FileCode2 />
            </span>
            <span className="eyebrow">GOOD DETAILS, AT SCALE</span>
            <h2 id="pub-import-title">Bring the collection up to date.</h2>
            <p>
              Update existing products in one validated transaction. Up to 100
              records per import.
            </p>
            <form className="pub-form" onSubmit={(e) => void applyImport(e)}>
              <label>
                CSV or JSON file
                <input
                  type="file"
                  accept=".json,.csv,application/json,text/csv"
                  onChange={(e) => void readImport(e.target.files?.[0])}
                />
              </label>
              <label>
                Product updates
                <textarea
                  value={importText}
                  onChange={(e) => setImportText(e.target.value)}
                  rows={9}
                  required
                  spellCheck={false}
                  placeholder={
                    '[{"id":"existing-product-id","price":29,"tags":["New release"]}]'
                  }
                />
              </label>
              <details className="pub-import-help">
                <summary>Supported fields and CSV format</summary>
                <p>
                  Each record requires an existing <code>id</code>. Update
                  title, description, category, price, format, tags,
                  subscriptionIncluded, or status. Omit fields you want to
                  preserve. The seller and licensor is always RTR Digital.
                  CSV tags use <code>|</code> separators;
                  subscriptionIncluded uses <code>true</code> or{" "}
                  <code>false</code>. Quoted CSV fields support commas and line
                  breaks.
                </p>
                <code>
                  id,price,status
                  <br />
                  existing-product-id,29,published
                </code>
              </details>
              {importError && (
                <div className="pub-error" role="alert">
                  <CircleAlert size={16} />
                  {importError}
                </div>
              )}
              <button className="btn btn-primary" disabled={busy}>
                {busy ? (
                  <Loader2 className="spin" size={16} />
                ) : (
                  <Check size={16} />
                )}
                Validate & update catalog
              </button>
            </form>
          </section>
        </div>
      )}
    </section>
  );
}
export default PublisherStudio;
