import { useCallback, useEffect, useState } from "react";
import type { FormEvent, ReactNode } from "react";
import {
  ArrowDownToLine,
  ArrowRight,
  ArrowUpRight,
  BarChart3,
  Check,
  CircleAlert,
  CreditCard,
  FileText,
  History,
  Landmark,
  LoaderCircle,
  Percent,
  Plus,
  RefreshCw,
  ShieldCheck,
  Tag,
  Undo2,
  X,
} from "lucide-react";
import { api, money } from "../lib/api";
import { SELLER_NAME } from "../lib/brand";
import type { User } from "../lib/types";
import { PaymentSettings } from "./PaymentSettings";
import "./commerce.css";

type Props = {
  user: User | null;
  onSignIn: () => void;
  onToast: (message: string, kind?: "success" | "error") => void;
};
type Promotion = {
  id: string;
  code: string;
  percent: number;
  startsAt?: string;
  endsAt?: string;
  maxUses?: number;
  perUser?: number;
  minSpend: number;
  scope: string;
  enabled: boolean;
  recurring: boolean;
  uses: number;
};
type Refund = {
  id: string;
  orderId: string;
  name: string;
  email: string;
  reason: string;
  status: string;
  note?: string;
  amount: number;
  mode: string;
  paymentProvider?: string;
  createdAt: string;
};
type Seller = {
  sellerName: string;
  address: string;
  taxId: string;
  supportEmail: string;
  invoicePrefix: string;
};
type Finance = {
  grossRevenue: number;
  refundedRevenue: number;
  netRevenue: number;
  demoTotal: number;
  liveMrr: number;
  liveArr: number;
  activeLiveMembers: number;
  activeDemoMembers: number;
  canceledLiveMembers: number;
  orders: number;
  refundedOrders: number;
  pendingRefunds: number;
  currency: string;
  note: string;
};
type Audit = {
  action: string;
  payload: Record<string, unknown>;
  createdAt: string;
};
type OfficeData = {
  finance: Finance;
  promotions: Promotion[];
  refunds: Refund[];
  audit: Audit[];
  settings: Seller;
  taxConfigured: boolean;
};
type Order = {
  id: string;
  items: { id: string; title: string; price: number }[];
  plan?: string;
  interval?: string;
  total: number;
  subtotal?: number;
  tax?: number;
  status: string;
  mode: string;
  paymentProvider?: string;
  createdAt: string;
  receiptUrl: string;
  refund: { id: string; status: string; reason?: string; note?: string } | null;
};
type OrdersData = { orders: Order[]; seller: Seller; taxConfigured: boolean };
const date = (value?: string) =>
  value && Number.isFinite(Date.parse(value))
    ? new Date(value).toLocaleDateString("en-US", {
        month: "short",
        day: "numeric",
        year: "numeric",
      })
    : "—";
const message = (err: unknown) =>
  err instanceof Error
    ? err.message
    : "Something went wrong. Please try again.";
const displayStatus = (value: string) => value.replaceAll("_", " ");
const paymentLabel = (mode: string) =>
  mode === "demo"
    ? "Demo · no money collected"
    : mode === "wire"
      ? "Bank transfer"
      : mode === "paypal"
        ? "PayPal payment"
        : mode === "razorpay"
          ? "Razorpay payment"
          : "Stripe payment";
function Status({ value }: { value: string }) {
  return (
    <span
      className={`co-status ${/refund|denied|disable|cancel/.test(value) ? "muted" : /processing|requested|pending/.test(value) ? "pending" : ""}`}
    >
      <i />
      {displayStatus(value)}
    </span>
  );
}
function Loading() {
  return (
    <div className="co-empty" role="status">
      <LoaderCircle size={26} className="spin" />
      <p>Bringing the details into focus…</p>
    </div>
  );
}
function ErrorState({
  error,
  onRetry,
}: {
  error: string;
  onRetry: () => void;
}) {
  return (
    <div className="co-error" role="alert">
      <CircleAlert size={21} />
      <div>
        <strong>A little interruption.</strong>
        <p>{error}</p>
      </div>
      <button className="btn btn-outline" onClick={onRetry}>
        Try again <RefreshCw size={14} />
      </button>
    </div>
  );
}
function Access({
  admin,
  onSignIn,
}: {
  admin?: boolean;
  onSignIn: () => void;
}) {
  return (
    <section className="page-width page-shell co-page">
      <div className="co-guest">
        <span className="co-symbol">
          {admin ? <Landmark size={32} /> : <CreditCard size={32} />}
        </span>
        <span className="eyebrow">
          {admin ? "BEHIND EVERY GOOD BUSINESS" : "YOUR CREATIVE INVESTMENTS"}
        </span>
        <h1>
          {admin
            ? "A clear view of the business."
            : "Good decisions. All recorded."}
        </h1>
        <p>
          {admin
            ? "Administrator access protects promotions, refunds, and your financial records."
            : "Sign in to view your orders, open receipts, and request help with a purchase."}
        </p>
        <button className="btn btn-primary" onClick={onSignIn}>
          Sign in to continue <ArrowRight size={17} />
        </button>
        <small>
          <ShieldCheck size={13} />
          {admin
            ? "Administrator account required"
            : "Your records stay private to your account"}
        </small>
      </div>
    </section>
  );
}
function Card({
  title,
  children,
  icon,
}: {
  title: string;
  children: ReactNode;
  icon?: ReactNode;
}) {
  return (
    <section className="co-card">
      <div className="co-card-heading">
        <h2>{title}</h2>
        {icon}
      </div>
      {children}
    </section>
  );
}

export function CommerceOffice({ user, onSignIn, onToast }: Props) {
  const [tab, setTab] = useState<
    "overview" | "promotions" | "refunds" | "payments" | "seller" | "audit"
  >("overview");
  const [data, setData] = useState<OfficeData | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [busy, setBusy] = useState("");
  const [showPromotion, setShowPromotion] = useState(false);
  const [formError, setFormError] = useState("");
  const [review, setReview] = useState<{
    id: string;
    decision: "approve" | "deny";
  } | null>(null);
  const [refundFilter, setRefundFilter] = useState("all");
  const load = useCallback(async () => {
    if (user?.role !== "admin") return;
    setLoading(true);
    setError("");
    try {
      setData(await api<OfficeData>("/admin/commerce"));
    } catch (err) {
      setError(message(err));
    } finally {
      setLoading(false);
    }
  }, [user?.id, user?.role]);
  useEffect(() => {
    void load();
  }, [load]);
  async function createPromotion(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setBusy("promotion");
    setFormError("");
    const fields = new FormData(event.currentTarget);
    const body: Record<string, unknown> = Object.fromEntries(fields);
    body.recurring = fields.get("recurring") === "on";
    for (const key of ["startsAt", "endsAt"])
      body[key] = fields.get(key)
        ? new Date(String(fields.get(key))).toISOString()
        : null;
    for (const key of ["percent", "minSpend", "maxUses", "perUser"])
      body[key] = fields.get(key) === "" ? null : Number(fields.get(key));
    try {
      await api("/admin/commerce/promotions", {
        method: "POST",
        body: JSON.stringify(body),
      });
      setShowPromotion(false);
      await load();
      onToast("Your promotion is ready for its next good find.");
    } catch (err) {
      setFormError(message(err));
    } finally {
      setBusy("");
    }
  }
  async function togglePromotion(p: Promotion) {
    setBusy(p.id);
    try {
      await api(`/admin/commerce/promotions/${encodeURIComponent(p.id)}`, {
        method: "PATCH",
        body: JSON.stringify({ enabled: !p.enabled }),
      });
      await load();
      onToast(
        p.enabled
          ? "Promotion paused."
          : "Promotion enabled. Date and usage limits still apply.",
      );
    } catch (err) {
      onToast(message(err), "error");
    } finally {
      setBusy("");
    }
  }
  async function decide(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!review) return;
    setBusy(review.id);
    setFormError("");
    const fields = new FormData(event.currentTarget);
    const refund = data?.refunds.find((item) => item.id === review.id);
    const body: Record<string, unknown> = { note: fields.get("note") || "" };
    if (
      review.decision === "approve" &&
      (refund?.paymentProvider || refund?.mode) === "wire"
    ) {
      body.password = fields.get("password") || "";
      body.bankReference = fields.get("bankReference");
      body.refundedAmount = Number(fields.get("refundedAmount"));
      body.currency = "USD";
      body.bankRefundConfirmed = fields.get("bankRefundConfirmed") === "on";
    }
    try {
      const result = await api<{ message?: string; pending?: boolean }>(
        `/admin/commerce/refunds/${encodeURIComponent(review.id)}/${review.decision}`,
        {
          method: "POST",
          body: JSON.stringify(body),
        },
      );
      setReview(null);
      await load();
      onToast(
        result.message ||
          (review.decision === "approve"
            ? "Refund decision recorded. Access follows the confirmed payment state."
            : "Refund request declined with your explanation."),
      );
    } catch (err) {
      setFormError(message(err));
    } finally {
      setBusy("");
    }
  }
  async function saveSeller(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setBusy("seller");
    setFormError("");
    try {
      await api("/admin/commerce/settings", {
        method: "PATCH",
        body: JSON.stringify(
          Object.fromEntries(new FormData(event.currentTarget)),
        ),
      });
      await load();
      onToast("Your seller details are saved.");
    } catch (err) {
      setFormError(message(err));
    } finally {
      setBusy("");
    }
  }
  if (user?.role !== "admin") return <Access admin onSignIn={onSignIn} />;
  const refunds = (data?.refunds || []).filter((r) =>
    refundFilter === "all" || refundFilter === "open"
      ? refundFilter === "all" ||
        [
          "requested",
          "processing",
          "provider_refunded_pending_cancel",
        ].includes(r.status)
      : r.status === refundFilter,
  );
  return (
    <section className="page-width page-shell co-page">
      <header className="co-heading">
        <div>
          <span className="eyebrow">THE DETAILS THAT KEEP YOU MOVING</span>
          <h1>
            The commerce office<span>.</span>
          </h1>
          <p>
            Promotions, payment records, and thoughtful resolutions. In one
            clear view.
          </p>
        </div>
        <button
          className="btn btn-outline"
          onClick={() => void load()}
          disabled={loading}
        >
          <RefreshCw size={15} className={loading ? "spin" : ""} />
          Refresh records
        </button>
      </header>
      <nav className="co-tabs" aria-label="Commerce office sections">
        {[
          { id: "overview", label: "Overview", icon: BarChart3 },
          { id: "promotions", label: "Promotions", icon: Tag },
          { id: "refunds", label: "Refund requests", icon: Undo2 },
          { id: "payments", label: "Payment connections", icon: CreditCard },
          { id: "seller", label: "Seller details", icon: Landmark },
          { id: "audit", label: "Audit trail", icon: History },
        ].map(({ id, label, icon: Icon }) => (
          <button
            key={id}
            className={tab === id ? "active" : ""}
            onClick={() => {
              setTab(id as typeof tab);
              setFormError("");
              setReview(null);
            }}
          >
            <Icon size={16} />
            {label}
            {id === "refunds" && Boolean(data?.finance.pendingRefunds) && (
              <span>{data?.finance.pendingRefunds}</span>
            )}
          </button>
        ))}
      </nav>
      {tab === "payments" ? (
        <PaymentSettings user={user} onToast={onToast} />
      ) : loading && !data ? (
        <Loading />
      ) : error ? (
        <ErrorState error={error} onRetry={() => void load()} />
      ) : (
        data && (
          <>
            {tab === "overview" && (
              <>
                <div className="co-stat-grid">
                  {[
                    {
                      title: "Net live revenue",
                      value: money(data.finance.netRevenue),
                      note: "Confirmed receipts less full refunds",
                      icon: CreditCard,
                    },
                    {
                      title: "Live monthly recurring value",
                      value: money(data.finance.liveMrr),
                      note: `${money(data.finance.liveArr)} normalized annually`,
                      icon: BarChart3,
                    },
                    {
                      title: "Live memberships",
                      value: String(data.finance.activeLiveMembers),
                      note: `${data.finance.activeDemoMembers} demo memberships shown separately`,
                      icon: ShieldCheck,
                    },
                    {
                      title: "Open refund requests",
                      value: String(data.finance.pendingRefunds),
                      note: `${data.finance.orders} order records`,
                      icon: Undo2,
                    },
                  ].map(({ title, value, note, icon: Icon }) => (
                    <article className="co-stat" key={title}>
                      <div>
                        <span>{title}</span>
                        <span className="co-stat-icon">
                          <Icon size={18} />
                        </span>
                      </div>
                      <strong>{value}</strong>
                      <p>{note}</p>
                    </article>
                  ))}
                </div>
                <div className="co-overview-grid">
                  <Card
                    title="A clear financial picture."
                    icon={<Landmark size={23} />}
                  >
                    <dl className="co-summary">
                      <div>
                        <dt>Live gross receipts</dt>
                        <dd>{money(data.finance.grossRevenue)}</dd>
                      </div>
                      <div>
                        <dt>Confirmed refunded revenue</dt>
                        <dd>{money(data.finance.refundedRevenue)}</dd>
                      </div>
                      <div>
                        <dt>Net live revenue</dt>
                        <dd>{money(data.finance.netRevenue)}</dd>
                      </div>
                      <div className="demo">
                        <dt>Demo order value · no money collected</dt>
                        <dd>{money(data.finance.demoTotal)}</dd>
                      </div>
                    </dl>
                    <p className="co-footnote">{data.finance.note}</p>
                    <a
                      className="co-text-link"
                      href="/api/admin/commerce/export/orders"
                    >
                      <ArrowDownToLine size={15} />
                      Export order records · CSV
                    </a>
                  </Card>
                  <Card
                    title="Configured with care."
                    icon={<ShieldCheck size={23} />}
                  >
                    <div className="co-operation-note">
                      <span className="co-symbol">
                        <Landmark size={23} />
                      </span>
                      <h3>India to the world. USD by default.</h3>
                      <p>
                        {data.taxConfigured
                          ? "Stripe Automatic Tax is requested at hosted checkout. Registration and applicable tax collection still depend on the merchant configuration."
                          : "Tax collection is not configured. Checkout estimates do not determine GST, VAT, or sales tax."}
                      </p>
                      <p>
                        Payment receipts do not replace statutory invoices or
                        jurisdiction-specific compliance. Keep your legal seller
                        details accurate.
                      </p>
                      <button
                        className="co-text-link"
                        onClick={() => setTab("seller")}
                      >
                        Review seller details <ArrowUpRight size={15} />
                      </button>
                    </div>
                  </Card>
                </div>
              </>
            )}
            {tab === "promotions" && (
              <Card
                title="A little incentive. Clear boundaries."
                icon={<Percent size={22} />}
              >
                <div className="co-section-tools">
                  <p>
                    Promotions are checked on the server against scope, dates,
                    and completed usage.
                  </p>
                  <button
                    className="btn btn-primary"
                    onClick={() => {
                      setShowPromotion(!showPromotion);
                      setFormError("");
                    }}
                  >
                    <Plus size={16} />
                    {showPromotion ? "Close form" : "Create promotion"}
                  </button>
                </div>
                {showPromotion && (
                  <form
                    className="co-promotion-form"
                    onSubmit={(event) => void createPromotion(event)}
                  >
                    <div className="co-form-grid">
                      <label>
                        Promotion code
                        <input
                          name="code"
                          required
                          minLength={3}
                          maxLength={40}
                          pattern="[A-Za-z0-9_-]+"
                          placeholder="CREATE20"
                        />
                      </label>
                      <label>
                        Discount (%)
                        <input
                          name="percent"
                          type="number"
                          min="0.01"
                          max="100"
                          step="0.01"
                          required
                          placeholder="20"
                        />
                      </label>
                      <label>
                        Applies to
                        <select name="scope" defaultValue="all">
                          <option value="all">Products & memberships</option>
                          <option value="products">One-time products</option>
                          <option value="membership">Memberships</option>
                        </select>
                      </label>
                      <label>
                        Minimum subtotal (USD)
                        <input
                          name="minSpend"
                          type="number"
                          min="0"
                          step="0.01"
                          defaultValue="0"
                        />
                      </label>
                      <label>
                        Starts at (your local time)
                        <input name="startsAt" type="datetime-local" />
                      </label>
                      <label>
                        Ends at (your local time)
                        <input name="endsAt" type="datetime-local" />
                      </label>
                      <label>
                        Maximum redemptions
                        <input
                          name="maxUses"
                          type="number"
                          min="1"
                          step="1"
                          placeholder="No limit"
                        />
                      </label>
                      <label>
                        Redemptions per account
                        <input
                          name="perUser"
                          type="number"
                          min="1"
                          step="1"
                          placeholder="No limit"
                        />
                      </label>
                    </div>
                    <label className="co-checkbox">
                      <input type="checkbox" name="recurring" defaultChecked />
                      <span>
                        Allow on memberships. The discounted price applies to
                        every renewal.
                      </span>
                    </label>
                    {formError && (
                      <div className="co-inline-error" role="alert">
                        {formError}
                      </div>
                    )}
                    <div className="co-form-actions">
                      <button
                        className="btn btn-outline"
                        type="button"
                        onClick={() => setShowPromotion(false)}
                      >
                        Cancel
                      </button>
                      <button
                        className="btn btn-primary"
                        disabled={busy === "promotion"}
                      >
                        {busy === "promotion" ? (
                          <LoaderCircle size={15} className="spin" />
                        ) : (
                          <Check size={15} />
                        )}
                        Save promotion
                      </button>
                    </div>
                  </form>
                )}
                <div className="co-table-wrap">
                  <table className="co-table">
                    <thead>
                      <tr>
                        <th>Code</th>
                        <th>Discount</th>
                        <th>Scope</th>
                        <th>Dates</th>
                        <th>Redemptions</th>
                        <th>Status</th>
                        <th>
                          <span className="sr-only">Actions</span>
                        </th>
                      </tr>
                    </thead>
                    <tbody>
                      {data.promotions.map((p) => (
                        <tr key={p.id}>
                          <td>
                            <strong className="co-code">{p.code}</strong>
                            <small>Minimum {money(p.minSpend)}</small>
                          </td>
                          <td>
                            {p.percent}%
                            <small>
                              {p.recurring
                                ? "Recurring eligible"
                                : "One-time only"}
                            </small>
                          </td>
                          <td>
                            {p.scope === "all"
                              ? "Products & memberships"
                              : p.scope}
                          </td>
                          <td>
                            {p.startsAt
                              ? date(p.startsAt)
                              : "Starts immediately"}
                            <small>
                              {p.endsAt
                                ? `Until ${date(p.endsAt)}`
                                : "No expiry"}
                            </small>
                          </td>
                          <td>
                            {p.uses}
                            {p.maxUses ? ` / ${p.maxUses}` : ""}
                            <small>
                              {p.perUser
                                ? `${p.perUser} per account`
                                : "No account limit"}
                            </small>
                          </td>
                          <td>
                            <Status
                              value={p.enabled ? "enabled" : "disabled"}
                            />
                          </td>
                          <td>
                            <button
                              className="co-small-button"
                              disabled={busy === p.id}
                              onClick={() => void togglePromotion(p)}
                            >
                              {p.enabled ? "Pause" : "Enable"}
                              {busy === p.id && (
                                <LoaderCircle size={12} className="spin" />
                              )}
                            </button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </Card>
            )}
            {tab === "refunds" && (
              <Card
                title="A thoughtful way to make it right."
                icon={<Undo2 size={22} />}
              >
                <div className="co-section-tools">
                  <p>
                    Confirm the original payment before reversing access. Every
                    decision is recorded.
                  </p>
                  <label className="co-filter">
                    <span className="sr-only">Filter refund requests</span>
                    <select
                      value={refundFilter}
                      onChange={(event) => setRefundFilter(event.target.value)}
                    >
                      <option value="all">All requests</option>
                      <option value="open">Open requests</option>
                      <option value="approved">Approved</option>
                      <option value="denied">Declined</option>
                    </select>
                  </label>
                </div>
                {refunds.length ? (
                  <div className="co-refund-list">
                    {refunds.map((r) => (
                      <article className="co-refund" key={r.id}>
                        <div className="co-refund-top">
                          <div>
                            <span className="eyebrow">{r.orderId}</span>
                            <h3>{r.name}</h3>
                            <small>
                              {r.email} · {date(r.createdAt)}
                            </small>
                          </div>
                          <div>
                            <strong>{money(r.amount)}</strong>
                            <Status value={r.status} />
                            <small>{paymentLabel(r.mode)}</small>
                          </div>
                        </div>
                        <p className="co-refund-reason">{r.reason}</p>
                        {r.note && (
                          <p className="co-decision-note">
                            <FileText size={14} />
                            {r.note}
                          </p>
                        )}
                        {[
                          "requested",
                          "processing",
                          "provider_refunded_pending_cancel",
                        ].includes(r.status) &&
                          (review?.id === r.id ? (
                            <form
                              className="co-decision-form"
                              onSubmit={(event) => void decide(event)}
                            >
                              <h4>
                                {review.decision === "approve"
                                  ? "Confirm this refund?"
                                  : "Explain the decision."}
                              </h4>
                              <p>
                                {review.decision === "approve"
                                  ? (r.paymentProvider || r.mode) === "wire"
                                    ? "First return the full amount through your bank. This website records your completed bank refund and reverses access after verification. It does not send the money."
                                    : r.mode === "demo" && !r.paymentProvider
                                      ? "This reverses the simulated order and its access grant. No real money moves."
                                      : `This asks ${(r.paymentProvider || r.mode) === "paypal" ? "PayPal" : (r.paymentProvider || r.mode) === "razorpay" ? "Razorpay" : "Stripe"} to refund the original payment. Access is updated after confirmation. A membership refund also requires subscription cancellation.`
                                  : "Your explanation will be visible to the customer with their request."}
                              </p>
                              {review.decision === "approve" &&
                                (r.paymentProvider || r.mode) === "wire" && (
                                  <div className="pay-wire-refund">
                                    <div className="pay-fields pay-fields-two">
                                      <label className="pay-field">
                                        <span>
                                          Amount already refunded (USD)
                                        </span>
                                        <input
                                          name="refundedAmount"
                                          type="number"
                                          step="0.01"
                                          min="0.01"
                                          required
                                          inputMode="decimal"
                                          placeholder={r.amount.toFixed(2)}
                                        />
                                      </label>
                                      <label className="pay-field">
                                        <span>
                                          Bank refund transaction reference
                                        </span>
                                        <input
                                          name="bankReference"
                                          required
                                          minLength={3}
                                          maxLength={200}
                                          autoComplete="off"
                                          placeholder="Reference for the completed bank refund"
                                        />
                                      </label>
                                      <label className="pay-field">
                                        <span>
                                          Current administrator password
                                        </span>
                                        <input
                                          name="password"
                                          type="password"
                                          autoComplete="current-password"
                                          maxLength={128}
                                          required={
                                            user.email !==
                                            "demo-admin@rtr.example"
                                          }
                                          placeholder={
                                            user.email ===
                                            "demo-admin@rtr.example"
                                              ? "Optional for this shared development demo"
                                              : "Verify this sensitive action"
                                          }
                                        />
                                      </label>
                                    </div>
                                    {user.email ===
                                      "demo-admin@rtr.example" && (
                                      <p className="pay-refund-demo-note">
                                        Shared development demo: password
                                        verification is bypassed for this demo
                                        account.
                                      </p>
                                    )}
                                    <label className="pay-verify-checkbox">
                                      <input
                                        name="bankRefundConfirmed"
                                        type="checkbox"
                                        required
                                      />
                                      <span>
                                        I already returned the full{" "}
                                        {money(r.amount)} USD to the customer
                                        through the bank and verified the
                                        completed refund.
                                      </span>
                                    </label>
                                  </div>
                                )}
                              {review.decision === "deny" && (
                                <label>
                                  Decision explanation
                                  <textarea
                                    name="note"
                                    minLength={5}
                                    maxLength={1000}
                                    required
                                    placeholder="A clear, considerate explanation…"
                                  />
                                </label>
                              )}
                              {formError && (
                                <div className="co-inline-error" role="alert">
                                  {formError}
                                </div>
                              )}
                              <div className="co-form-actions">
                                <button
                                  className="btn btn-outline"
                                  type="button"
                                  disabled={busy === r.id}
                                  onClick={() => setReview(null)}
                                >
                                  Keep reviewing
                                </button>
                                <button
                                  className="btn btn-primary"
                                  disabled={busy === r.id}
                                >
                                  {busy === r.id && (
                                    <LoaderCircle size={15} className="spin" />
                                  )}
                                  {review.decision === "approve"
                                    ? "Confirm refund"
                                    : "Record decision"}
                                </button>
                              </div>
                            </form>
                          ) : (
                            <div className="co-refund-actions">
                              <button
                                className="co-small-button"
                                onClick={() => {
                                  setReview({ id: r.id, decision: "approve" });
                                  setFormError("");
                                }}
                              >
                                {r.status === "requested"
                                  ? "Review refund"
                                  : "Retry reconciliation"}
                                <ArrowUpRight size={13} />
                              </button>
                              {r.status === "requested" && (
                                <button
                                  className="co-small-button neutral"
                                  onClick={() => {
                                    setReview({ id: r.id, decision: "deny" });
                                    setFormError("");
                                  }}
                                >
                                  Decline with explanation
                                </button>
                              )}
                            </div>
                          ))}
                      </article>
                    ))}
                  </div>
                ) : (
                  <div className="co-empty">
                    <Undo2 size={31} />
                    <h3>Nothing waiting for a resolution.</h3>
                    <p>New refund requests will appear here.</p>
                  </div>
                )}
              </Card>
            )}
            {tab === "seller" && (
              <Card
                title="The real business behind the possibilities."
                icon={<Landmark size={22} />}
              >
                <div className="co-seller-layout">
                  <div>
                    <h3>Accurate details build trust.</h3>
                    <p>
                      RTR Digital is the sole seller and licensor. Keep its
                      registered address, tax details, and contact information
                      accurate for payment receipts.
                    </p>
                    <div className="co-notice">
                      <ShieldCheck size={20} />
                      <p>
                        Operating from India and charging in USD does not by
                        itself determine GST, export treatment, or overseas tax
                        obligations. Review your invoice requirements with your
                        tax adviser.
                      </p>
                    </div>
                  </div>
                  <form
                    key={JSON.stringify(data.settings)}
                    className="co-seller-form"
                    onSubmit={(event) => void saveSeller(event)}
                  >
                    <label>
                      Seller & licensor
                      <input name="sellerName" value={SELLER_NAME} readOnly />
                    </label>
                    <label>
                      Registered address
                      <textarea
                        name="address"
                        maxLength={500}
                        rows={3}
                        defaultValue={data.settings.address}
                        placeholder="Your actual registered business address"
                      />
                    </label>
                    <label>
                      Tax registration ID / GSTIN
                      <input
                        name="taxId"
                        maxLength={120}
                        defaultValue={data.settings.taxId}
                        placeholder="Only if applicable to your registered entity"
                      />
                    </label>
                    <div className="co-form-grid">
                      <label>
                        Support email
                        <input
                          name="supportEmail"
                          type="email"
                          maxLength={120}
                          defaultValue={data.settings.supportEmail}
                          placeholder="support@your-domain.example"
                        />
                      </label>
                      <label>
                        Receipt prefix
                        <input
                          name="invoicePrefix"
                          maxLength={30}
                          defaultValue={data.settings.invoicePrefix}
                        />
                      </label>
                    </div>
                    {formError && (
                      <div className="co-inline-error" role="alert">
                        {formError}
                      </div>
                    )}
                    <button
                      className="btn btn-primary"
                      disabled={busy === "seller"}
                    >
                      {busy === "seller" && (
                        <LoaderCircle size={15} className="spin" />
                      )}
                      Save seller details <Check size={15} />
                    </button>
                  </form>
                </div>
              </Card>
            )}
            {tab === "audit" && (
              <Card
                title="Every meaningful change, accounted for."
                icon={<History size={22} />}
              >
                <div className="co-section-tools">
                  <p>
                    The latest 150 administrator and account activity records.
                  </p>
                  <a
                    className="co-text-link"
                    href="/api/admin/commerce/export/audit"
                  >
                    <ArrowDownToLine size={15} />
                    Export audit · CSV
                  </a>
                </div>
                {data.audit.length ? (
                  <div className="co-audit-list">
                    {data.audit.map((a, i) => (
                      <article key={`${a.createdAt}-${i}`}>
                        <span className="co-audit-icon">
                          <History size={16} />
                        </span>
                        <div>
                          <strong>
                            {a.action
                              .replaceAll(".", " · ")
                              .replaceAll("_", " ")}
                          </strong>
                          <p>
                            {Object.entries(a.payload)
                              .map(
                                ([k, v]) =>
                                  `${k}: ${typeof v === "object" ? JSON.stringify(v) : String(v)}`,
                              )
                              .join(" · ") || "Activity recorded."}
                          </p>
                        </div>
                        <time>{date(a.createdAt)}</time>
                      </article>
                    ))}
                  </div>
                ) : (
                  <div className="co-empty">
                    <History size={30} />
                    <p>
                      Your audit trail starts with your first meaningful change.
                    </p>
                  </div>
                )}
              </Card>
            )}
          </>
        )
      )}
    </section>
  );
}

export function BillingRecords({ user, onSignIn, onToast }: Props) {
  const [data, setData] = useState<OrdersData | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [open, setOpen] = useState("");
  const [busy, setBusy] = useState(false);
  const [formError, setFormError] = useState("");
  const load = useCallback(async () => {
    if (!user) return;
    setLoading(true);
    setError("");
    try {
      setData(await api<OrdersData>("/billing/orders"));
    } catch (err) {
      setError(message(err));
    } finally {
      setLoading(false);
    }
  }, [user?.id]);
  useEffect(() => {
    void load();
  }, [load]);
  async function requestRefund(event: FormEvent<HTMLFormElement>, id: string) {
    event.preventDefault();
    setBusy(true);
    setFormError("");
    try {
      await api(`/billing/orders/${encodeURIComponent(id)}/refunds`, {
        method: "POST",
        body: JSON.stringify({
          reason: new FormData(event.currentTarget).get("reason"),
        }),
      });
      setOpen("");
      await load();
      onToast("Your refund request is saved for administrator review.");
    } catch (err) {
      setFormError(message(err));
    } finally {
      setBusy(false);
    }
  }
  if (!user) return <Access onSignIn={onSignIn} />;
  return (
    <section className="page-width page-shell co-page">
      <header className="co-heading">
        <div>
          <span className="eyebrow">YOUR GOOD DECISIONS, RECORDED</span>
          <h1>
            A little clarity on every purchase<span>.</span>
          </h1>
          <p>Your orders, payment receipts, and resolutions stay together.</p>
        </div>
        <button
          className="btn btn-outline"
          onClick={() => void load()}
          disabled={loading}
        >
          <RefreshCw size={15} className={loading ? "spin" : ""} />
          Refresh orders
        </button>
      </header>
      {loading && !data ? (
        <Loading />
      ) : error ? (
        <ErrorState error={error} onRetry={() => void load()} />
      ) : (
        data && (
          <>
            <div className="co-customer-assurance">
              <ShieldCheck size={20} />
              <p>
                Receipts show the recorded order total in USD. Demo orders never
                charge money. A payment receipt is not a statutory tax invoice.
              </p>
            </div>
            {data.orders.length ? (
              <div className="co-orders-list">
                {data.orders.map((order) => (
                  <article className="co-order" key={order.id}>
                    <header>
                      <div>
                        <span className="eyebrow">{order.id}</span>
                        <h2>
                          {order.plan
                            ? `${order.plan === "starter" ? "Explorer" : order.plan.charAt(0).toUpperCase() + order.plan.slice(1)} Digital Pass`
                            : order.items.map((item) => item.title).join(", ")}
                        </h2>
                        <p>
                          {date(order.createdAt)} · {paymentLabel(order.mode)}
                          {order.interval ? ` · ${order.interval}` : ""}
                        </p>
                      </div>
                      <div>
                        <strong>{money(order.total)}</strong>
                        <small>USD</small>
                        <Status value={order.status} />
                      </div>
                    </header>
                    {order.refund && (
                      <div className="co-order-refund">
                        <Undo2 size={17} />
                        <div>
                          <strong>
                            Refund request: {displayStatus(order.refund.status)}
                          </strong>
                          {order.refund.reason && <p>{order.refund.reason}</p>}
                          {order.refund.note && (
                            <p>Administrator note: {order.refund.note}</p>
                          )}
                        </div>
                      </div>
                    )}
                    <div className="co-order-bottom">
                      <a
                        className="co-text-link"
                        href={order.receiptUrl}
                        target="_blank"
                        rel="noopener noreferrer"
                      >
                        <FileText size={16} />
                        Open payment receipt <ArrowUpRight size={13} />
                      </a>
                      {!order.refund && order.status !== "refunded" && (
                        <button
                          className="co-text-link"
                          onClick={() => {
                            setOpen(open === order.id ? "" : order.id);
                            setFormError("");
                          }}
                        >
                          {open === order.id ? (
                            <X size={14} />
                          ) : (
                            <Undo2 size={14} />
                          )}
                          Request a refund
                        </button>
                      )}
                    </div>
                    {open === order.id && (
                      <form
                        className="co-refund-request"
                        onSubmit={(event) =>
                          void requestRefund(event, order.id)
                        }
                      >
                        <h3>Tell us what needs a little attention.</h3>
                        <p>
                          Your request goes to the administrator for review.
                          Submission does not guarantee a refund or move money.
                        </p>
                        <label>
                          Reason for refund
                          <textarea
                            name="reason"
                            required
                            minLength={10}
                            maxLength={2000}
                            rows={4}
                            placeholder="Include the details that will help us understand the issue."
                          />
                        </label>
                        {formError && (
                          <div className="co-inline-error" role="alert">
                            {formError}
                          </div>
                        )}
                        <div className="co-form-actions">
                          <button
                            className="btn btn-outline"
                            type="button"
                            onClick={() => setOpen("")}
                            disabled={busy}
                          >
                            Cancel request
                          </button>
                          <button className="btn btn-primary" disabled={busy}>
                            {busy && (
                              <LoaderCircle size={15} className="spin" />
                            )}
                            Submit refund request <ArrowRight size={15} />
                          </button>
                        </div>
                      </form>
                    )}
                  </article>
                ))}
              </div>
            ) : (
              <div className="co-empty co-empty-large">
                <CreditCard size={38} />
                <h2>A little room for your first good find.</h2>
                <p>
                  Purchases and memberships will appear here after checkout.
                </p>
              </div>
            )}
          </>
        )
      )}
    </section>
  );
}
