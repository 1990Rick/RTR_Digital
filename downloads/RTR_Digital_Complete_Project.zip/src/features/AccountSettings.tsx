import { useCallback, useEffect, useState } from "react";
import type { FormEvent } from "react";
import {
  ArrowRight,
  Bell,
  Check,
  CheckCircle2,
  ChevronRight,
  Copy,
  Download,
  Fingerprint,
  KeyRound,
  LoaderCircle,
  LockKeyhole,
  Mail,
  Monitor,
  RefreshCw,
  ShieldCheck,
  Trash2,
  UserRound,
  X,
} from "lucide-react";
import { api } from "../lib/api";
import type { User } from "../lib/types";
import "./identity.css";

type Props = {
  user: User | null;
  onSignIn: () => void;
  onToast: (message: string, kind?: "success" | "error") => void;
  onUserChange: () => void;
};
type Settings = {
  profile: {
    name: string;
    email: string;
    emailVerified: boolean;
    mfaEnabled: boolean;
    backupCodesRemaining: number;
  };
  preferences: {
    productUpdates: boolean;
    renewalReminders: boolean;
    newsletter: boolean;
  };
  sessions: { id: string; current: boolean; expiresAt: string }[];
  notifications: {
    id: string;
    title: string;
    body: string;
    readAt: string | null;
    createdAt: string;
  }[];
  mail: {
    configured: boolean;
    developmentPreview: boolean;
    messages: {
      id: string;
      subject: string;
      status: string;
      createdAt: string;
    }[];
  };
};
type MailPreview = {
  id: string;
  subject: string;
  body: string;
  status: string;
  createdAt: string;
};
const errorText = (error: unknown) =>
  error instanceof Error ? error.message : "Please try again in a moment.";
const dateText = (value: string) =>
  new Date(value).toLocaleString("en-US", {
    dateStyle: "medium",
    timeStyle: "short",
  });

export function AccountSettings({
  user,
  onSignIn,
  onToast,
  onUserChange,
}: Props) {
  const [tab, setTab] = useState("Profile");
  const [data, setData] = useState<Settings | null>(null);
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState("");
  const [error, setError] = useState("");
  const [setup, setSetup] = useState<{ secret: string; uri: string } | null>(
    null,
  );
  const [backupCodes, setBackupCodes] = useState<string[]>([]);
  const [preview, setPreview] = useState<MailPreview | null>(null);
  const load = useCallback(async () => {
    if (!user) {
      setLoading(false);
      return;
    }
    try {
      setData(await api<Settings>("/account/settings"));
      setError("");
    } catch (err) {
      setError(errorText(err));
    } finally {
      setLoading(false);
    }
  }, [user?.id]);
  useEffect(() => {
    void load();
  }, [load]);
  const act = async (
    name: string,
    action: () => Promise<unknown>,
    message?: string,
  ) => {
    setBusy(name);
    setError("");
    try {
      await action();
      await load();
      if (message) onToast(message);
    } catch (err) {
      const text = errorText(err);
      setError(text);
      onToast(text, "error");
    } finally {
      setBusy("");
    }
  };

  async function choosePreference(
    key: keyof Settings["preferences"],
    checked: boolean,
  ) {
    if (!data || busy) return;
    const previous = data.preferences[key];
    setBusy(key);
    setError("");
    setData((current) =>
      current
        ? {
            ...current,
            preferences: { ...current.preferences, [key]: checked },
          }
        : current,
    );
    try {
      await api("/account/preferences", {
        method: "PATCH",
        body: JSON.stringify({ [key]: checked }),
      });
      onToast("Your communication choice has been saved.");
    } catch (error) {
      setData((current) =>
        current
          ? {
              ...current,
              preferences: { ...current.preferences, [key]: previous },
            }
          : current,
      );
      setError(errorText(error));
      onToast(errorText(error), "error");
    } finally {
      setBusy("");
    }
  }
  const submitProfile = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const payload = Object.fromEntries(new FormData(event.currentTarget));
    await act(
      "profile",
      async () => {
        await api("/account/profile", {
          method: "PATCH",
          body: JSON.stringify(payload),
        });
        onUserChange();
      },
      "Your profile has a fresh start.",
    );
  };
  const changePassword = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const form = event.currentTarget;
    const payload = Object.fromEntries(new FormData(form));
    if (payload.newPassword !== payload.confirmPassword) {
      setError("The new passwords do not match.");
      return;
    }
    await act(
      "password",
      async () => {
        await api("/account/password", {
          method: "POST",
          body: JSON.stringify(payload),
        });
        form.reset();
      },
      "Password changed. Your other sessions are signed out.",
    );
  };
  const verifyEmail = () =>
    act("verify", async () => {
      const result = await api<{ message: string }>(
        "/account/verification/send",
        { method: "POST" },
      );
      onToast(result.message);
    });
  const startMfa = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const payload = Object.fromEntries(new FormData(event.currentTarget));
    await act("mfa-setup", async () => {
      setSetup(
        await api("/account/mfa/setup", {
          method: "POST",
          body: JSON.stringify(payload),
        }),
      );
    });
  };
  const confirmMfa = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const payload = Object.fromEntries(new FormData(event.currentTarget));
    await act(
      "mfa-confirm",
      async () => {
        const result = await api<{ backupCodes: string[] }>(
          "/account/mfa/confirm",
          { method: "POST", body: JSON.stringify(payload) },
        );
        setBackupCodes(result.backupCodes);
        setSetup(null);
      },
      "Two-factor authentication is now protecting your account.",
    );
  };
  const disableMfa = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const form = event.currentTarget;
    const payload = Object.fromEntries(new FormData(form));
    await act(
      "mfa-disable",
      async () => {
        await api("/account/mfa/disable", {
          method: "POST",
          body: JSON.stringify(payload),
        });
        form.reset();
      },
      "Two-factor authentication is disabled.",
    );
  };
  const deleteAccount = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const payload = Object.fromEntries(new FormData(event.currentTarget));
    await act(
      "delete",
      async () => {
        await api("/account/delete", {
          method: "POST",
          body: JSON.stringify(payload),
        });
        onUserChange();
      },
      "Your personal profile and account content have been removed.",
    );
  };
  if (!user)
    return (
      <section className="page-width page-shell identity-page">
        <div className="empty-state">
          <UserRound size={42} />
          <h1>A little control. A lot of peace of mind.</h1>
          <p>
            Sign in to manage your profile, security, notifications, and
            privacy.
          </p>
          <button className="btn btn-primary" onClick={onSignIn}>
            Sign in to your account <ArrowRight size={16} />
          </button>
        </div>
      </section>
    );
  const unread = data?.notifications.filter((n) => !n.readAt).length || 0;
  return (
    <section className="page-width page-shell identity-page">
      <header className="identity-heading">
        <div>
          <span className="eyebrow">YOUR ACCOUNT, ON YOUR TERMS</span>
          <h1>A space that’s yours.</h1>
          <p>
            Keep your details current. Your account secure. Your choices clear.
          </p>
        </div>
        <span className="identity-security-label">
          <ShieldCheck size={18} /> Private by design
        </span>
      </header>
      <nav className="identity-tabs" aria-label="Account settings">
        {[
          { name: "Profile", icon: UserRound },
          { name: "Security", icon: Fingerprint },
          { name: "Sessions", icon: Monitor },
          { name: "Notifications", icon: Bell },
          { name: "Privacy", icon: LockKeyhole },
        ].map(({ name, icon: Icon }) => (
          <button
            key={name}
            className={tab === name ? "active" : ""}
            onClick={() => {
              setTab(name);
              setError("");
            }}
          >
            <Icon size={17} />
            {name}
            {name === "Notifications" && unread > 0 && <span>{unread}</span>}
          </button>
        ))}
      </nav>
      {error && (
        <div className="identity-error" role="alert">
          {error}
          <button
            aria-label="Dismiss account error"
            onClick={() => setError("")}
          >
            <X size={15} />
          </button>
        </div>
      )}
      {loading ? (
        <div className="identity-loading">
          <LoaderCircle size={26} className="spin" /> Opening your account…
        </div>
      ) : !data ? (
        <div className="empty-state">
          <h2>Your account is taking a moment.</h2>
          <button className="btn btn-outline" onClick={() => void load()}>
            Try again <RefreshCw size={16} />
          </button>
        </div>
      ) : (
        <>
          {tab === "Profile" && (
            <div className="identity-layout">
              <article className="identity-card">
                <span className="eyebrow">THE EVERYDAY DETAILS</span>
                <h2>Make yourself at home.</h2>
                <p>
                  Your name and email help keep your library connected to you.
                </p>
                <form
                  onSubmit={(event) => void submitProfile(event)}
                  key={`${data.profile.name}-${data.profile.email}`}
                >
                  <label>
                    Your name
                    <input
                      name="name"
                      required
                      minLength={2}
                      maxLength={80}
                      defaultValue={data.profile.name}
                      autoComplete="name"
                    />
                  </label>
                  <label>
                    Email address
                    <input
                      name="email"
                      type="email"
                      required
                      defaultValue={data.profile.email}
                      autoComplete="email"
                    />
                  </label>
                  <div className="identity-inline-note">
                    <LockKeyhole size={15} /> Changing your email requires your
                    current password
                    {data.profile.mfaEnabled
                      ? " and a fresh authenticator or recovery code"
                      : ""}
                    .
                  </div>
                  <label>
                    Current password{" "}
                    <small>(required only for email changes)</small>
                    <input
                      name="password"
                      type="password"
                      autoComplete="current-password"
                    />
                  </label>
                  {data.profile.mfaEnabled && (
                    <label>
                      Authenticator or recovery code
                      <input name="code" autoComplete="one-time-code" />
                    </label>
                  )}
                  <button className="btn btn-primary" disabled={Boolean(busy)}>
                    {busy === "profile" && (
                      <LoaderCircle className="spin" size={16} />
                    )}
                    Save your details <Check size={16} />
                  </button>
                </form>
              </article>
              <aside className="identity-card identity-soft-card">
                <span className="identity-icon">
                  <Mail size={25} />
                </span>
                <h2>
                  {data.profile.emailVerified
                    ? "An email that’s truly yours."
                    : "A little confirmation goes a long way."}
                </h2>
                <p>
                  {data.profile.emailVerified
                    ? "Your email address is verified. It connects your account, purchases, and recovery messages."
                    : "Verify your email address to confirm ownership and keep account recovery trustworthy."}
                </p>
                <span
                  className={`identity-status ${data.profile.emailVerified ? "verified" : ""}`}
                >
                  <span />
                  {data.profile.emailVerified
                    ? "Verified email"
                    : "Not verified yet"}
                </span>
                {!data.profile.emailVerified && (
                  <button
                    className="btn btn-outline"
                    onClick={() => void verifyEmail()}
                    disabled={Boolean(busy)}
                  >
                    {busy === "verify" ? (
                      <LoaderCircle className="spin" size={16} />
                    ) : (
                      <Mail size={16} />
                    )}
                    Send verification
                  </button>
                )}
                <div className="identity-inline-note">
                  {data.mail.configured
                    ? "Account email delivery is configured."
                    : data.mail.developmentPreview
                      ? "Development mode: messages appear in your private mailbox below. No email is sent without a configured provider."
                      : "Email delivery is not configured. The administrator must connect it before verification or recovery messages can be delivered."}
                </div>
              </aside>
            </div>
          )}
          {tab === "Security" && (
            <div className="identity-layout">
              <article className="identity-card">
                <span className="eyebrow">A GOOD HABIT TO KEEP</span>
                <h2>A fresh password.</h2>
                <p>
                  Choose a unique password. Changing it signs out your other
                  sessions.
                </p>
                <form onSubmit={(event) => void changePassword(event)}>
                  <label>
                    Current password
                    <input
                      name="password"
                      type="password"
                      required
                      autoComplete="current-password"
                    />
                  </label>
                  <label>
                    New password
                    <input
                      name="newPassword"
                      type="password"
                      minLength={8}
                      maxLength={128}
                      required
                      autoComplete="new-password"
                    />
                  </label>
                  <label>
                    Confirm new password
                    <input
                      name="confirmPassword"
                      type="password"
                      minLength={8}
                      maxLength={128}
                      required
                      autoComplete="new-password"
                    />
                  </label>
                  {data.profile.mfaEnabled && (
                    <label>
                      Fresh authenticator or recovery code
                      <input
                        name="code"
                        required
                        autoComplete="one-time-code"
                      />
                    </label>
                  )}
                  <button className="btn btn-primary" disabled={Boolean(busy)}>
                    {busy === "password" && (
                      <LoaderCircle className="spin" size={16} />
                    )}
                    Change password <KeyRound size={16} />
                  </button>
                </form>
              </article>
              <article className="identity-card identity-lavender-card">
                <span className="identity-icon">
                  <Fingerprint size={25} />
                </span>
                <h2>An extra layer of you.</h2>
                <p>
                  Add RTR Digital to an authenticator app. Codes change every 30
                  seconds; used codes cannot be reused.
                </p>
                <span
                  className={`identity-status ${data.profile.mfaEnabled ? "verified" : ""}`}
                >
                  <span />
                  {data.profile.mfaEnabled
                    ? "Two-factor authentication enabled"
                    : "Two-factor authentication not enabled"}
                </span>
                {backupCodes.length > 0 && (
                  <div className="identity-recovery-codes">
                    <strong>Save these recovery codes now.</strong>
                    <p>
                      Each code works once. They will not be shown again after
                      you leave this screen.
                    </p>
                    <div>
                      {backupCodes.map((code) => (
                        <code key={code}>{code}</code>
                      ))}
                    </div>
                    <button
                      className="identity-text-button"
                      onClick={() => {
                        void navigator.clipboard
                          .writeText(backupCodes.join("\n"))
                          .then(() =>
                            onToast(
                              "Recovery codes copied. Store them in a safe place.",
                            ),
                          )
                          .catch(() =>
                            onToast(
                              "Select and save the recovery codes manually.",
                              "error",
                            ),
                          );
                      }}
                    >
                      <Copy size={14} />
                      Copy recovery codes
                    </button>
                  </div>
                )}
                {data.profile.mfaEnabled ? (
                  <>
                    <div className="identity-inline-note">
                      {data.profile.backupCodesRemaining} unused recovery codes
                      remain. Use a new authenticator code or an unused recovery
                      code for security changes.
                    </div>
                    <form onSubmit={(event) => void disableMfa(event)}>
                      <label>
                        Current password
                        <input
                          name="password"
                          type="password"
                          required
                          autoComplete="current-password"
                        />
                      </label>
                      <label>
                        Authenticator or recovery code
                        <input
                          name="code"
                          required
                          autoComplete="one-time-code"
                        />
                      </label>
                      <button
                        className="btn btn-outline"
                        disabled={Boolean(busy)}
                      >
                        Disable two-factor authentication
                      </button>
                    </form>
                  </>
                ) : setup ? (
                  <div className="identity-mfa-setup">
                    <strong>Add this setup key to your authenticator.</strong>
                    <code>{setup.secret}</code>
                    <p>
                      Choose a time-based account named RTR Digital. The setup
                      expires after ten minutes. Keep this key private.
                    </p>
                    <a href={setup.uri} className="identity-text-button">
                      Open an authenticator app <ChevronRight size={14} />
                    </a>
                    <form onSubmit={(event) => void confirmMfa(event)}>
                      <label>
                        Six-digit authenticator code
                        <input
                          name="code"
                          inputMode="numeric"
                          pattern="[0-9]{6}"
                          maxLength={6}
                          minLength={6}
                          required
                          autoComplete="one-time-code"
                        />
                      </label>
                      <button
                        className="btn btn-primary"
                        disabled={Boolean(busy)}
                      >
                        Confirm authenticator <Check size={16} />
                      </button>
                    </form>
                  </div>
                ) : (
                  <form onSubmit={(event) => void startMfa(event)}>
                    <label>
                      Confirm your password
                      <input
                        name="password"
                        type="password"
                        required
                        autoComplete="current-password"
                      />
                    </label>
                    <button
                      className="btn btn-primary"
                      disabled={Boolean(busy)}
                    >
                      Set up authenticator <Fingerprint size={16} />
                    </button>
                  </form>
                )}
              </article>
            </div>
          )}
          {tab === "Sessions" && (
            <article className="identity-card">
              <div className="identity-card-header">
                <div>
                  <span className="eyebrow">KNOW WHERE YOU’RE SIGNED IN</span>
                  <h2>Your active sessions.</h2>
                  <p>
                    Review account access and close sessions you no longer need.
                  </p>
                </div>
                <button
                  className="btn btn-outline"
                  disabled={Boolean(busy)}
                  onClick={() =>
                    void act(
                      "sessions",
                      () =>
                        api("/account/sessions/revoke-others", {
                          method: "POST",
                        }),
                      "Your other sessions have been signed out.",
                    )
                  }
                >
                  Sign out other sessions <Monitor size={16} />
                </button>
              </div>
              <div className="identity-session-list">
                {data.sessions.map((session) => (
                  <div key={session.id}>
                    <span className="identity-icon">
                      <Monitor size={22} />
                    </span>
                    <div>
                      <strong>
                        {session.current
                          ? "This browser"
                          : "Another signed-in session"}
                      </strong>
                      <small>Expires {dateText(session.expiresAt)}</small>
                    </div>
                    {session.current ? (
                      <span className="identity-status verified">Current</span>
                    ) : (
                      <button
                        disabled={Boolean(busy)}
                        className="identity-text-button"
                        onClick={() =>
                          void act(
                            session.id,
                            () =>
                              api(`/account/sessions/${session.id}`, {
                                method: "DELETE",
                              }),
                            "Session signed out.",
                          )
                        }
                      >
                        <X size={15} />
                        Revoke
                      </button>
                    )}
                  </div>
                ))}
              </div>
              <p className="identity-caption">
                Session identifiers are opaque references. Your session cookie
                remains HttpOnly and is never displayed here.
              </p>
            </article>
          )}
          {tab === "Notifications" && (
            <div className="identity-layout">
              <article className="identity-card">
                <div className="identity-card-header">
                  <div>
                    <span className="eyebrow">GOOD TO KNOW</span>
                    <h2>Your account updates.</h2>
                  </div>
                  <button
                    className="identity-text-button"
                    disabled={Boolean(busy)}
                    onClick={() =>
                      void act("read-all", () =>
                        api("/account/notifications/read-all", {
                          method: "POST",
                        }),
                      )
                    }
                  >
                    Mark all read <Check size={15} />
                  </button>
                </div>
                <div className="identity-notifications">
                  {data.notifications.length ? (
                    data.notifications.map((item) => (
                      <article
                        key={item.id}
                        className={!item.readAt ? "unread" : ""}
                      >
                        <span className="identity-notification-dot" />
                        <div>
                          <strong>{item.title}</strong>
                          <p>{item.body}</p>
                          <small>{dateText(item.createdAt)}</small>
                        </div>
                        {!item.readAt && (
                          <button
                            aria-label={`Mark ${item.title} as read`}
                            onClick={() =>
                              void act(item.id, () =>
                                api(`/account/notifications/${item.id}`, {
                                  method: "PATCH",
                                }),
                              )
                            }
                          >
                            <Check size={16} />
                          </button>
                        )}
                      </article>
                    ))
                  ) : (
                    <div className="empty-state">
                      <Bell size={32} />
                      <h3>A little quiet is good.</h3>
                      <p>
                        Security updates and account notices will appear here.
                      </p>
                    </div>
                  )}
                </div>
              </article>
              <article className="identity-card identity-soft-card">
                <span className="identity-icon">
                  <Bell size={24} />
                </span>
                <h2>Choose what reaches you.</h2>
                <p>
                  Essential security and billing communications remain
                  necessary. Optional updates are your choice.
                </p>
                {(
                  [
                    {
                      key: "productUpdates",
                      title: "New finds & product updates",
                      text: "Useful release news and updates to products you own.",
                    },
                    {
                      key: "renewalReminders",
                      title: "Membership reminders",
                      text: "A heads-up about your membership and renewal period.",
                    },
                    {
                      key: "newsletter",
                      title: "A little creative inspiration",
                      text: "Optional newsletter updates and curated discoveries.",
                    },
                  ] as const
                ).map((item) => (
                  <label className="identity-preference" key={item.key}>
                    <span>
                      <strong>{item.title}</strong>
                      <small>{item.text}</small>
                    </span>
                    <input
                      aria-label={item.title}
                      type="checkbox"
                      checked={data.preferences[item.key]}
                      disabled={Boolean(busy)}
                      onChange={(event) => {
                        void choosePreference(item.key, event.target.checked);
                      }}
                    />
                  </label>
                ))}
                <div className="identity-inline-note">
                  Your preferences are saved with a timestamp. Turning off the
                  newsletter removes your email from its sign-up list.
                </div>
              </article>
            </div>
          )}
          {tab === "Privacy" && (
            <div className="identity-layout">
              <article className="identity-card">
                <span className="identity-icon">
                  <Download size={24} />
                </span>
                <span className="eyebrow">YOUR INFORMATION, YOUR CHOICE</span>
                <h2>Take your records with you.</h2>
                <p>
                  Download your profile, orders, preferences, wishlist, support
                  records, reviews, and account notices. It excludes passwords,
                  session cookies, authenticator secrets, and recovery codes.
                </p>
                <a className="btn btn-outline" href="/api/account/export">
                  Download account data <Download size={16} />
                </a>
                <div className="identity-inline-note">
                  <ShieldCheck size={17} /> Financial records may need to be
                  retained after account removal. Personal profile fields are
                  anonymized and sessions revoked.
                </div>
              </article>
              <article className="identity-card identity-danger-card">
                <span className="eyebrow">A CONSIDERED GOODBYE</span>
                <h2>Close your account.</h2>
                <p>
                  This permanently removes your personal profile, saved
                  preferences, sessions, reviews, and private messages. Your
                  library access is lost. Any Studio workspace you own is closed
                  and its members lose team access. Personal learning notes and
                  invitations are removed. Financial records retain an
                  anonymized reference; a hashed trial-eligibility marker may
                  remain for abuse prevention. A live subscription must end
                  first.
                </p>
                <form onSubmit={(event) => void deleteAccount(event)}>
                  <label>
                    Current password
                    <input
                      name="password"
                      type="password"
                      required
                      autoComplete="current-password"
                    />
                  </label>
                  {data.profile.mfaEnabled && (
                    <label>
                      Fresh authenticator or recovery code
                      <input
                        name="code"
                        required
                        autoComplete="one-time-code"
                      />
                    </label>
                  )}
                  <label>
                    Type DELETE to confirm
                    <input
                      name="confirmation"
                      required
                      pattern="DELETE"
                      autoComplete="off"
                      placeholder="DELETE"
                    />
                  </label>
                  <button
                    className="btn identity-delete-button"
                    disabled={Boolean(busy)}
                  >
                    <Trash2 size={16} />
                    Permanently close account
                  </button>
                </form>
              </article>
            </div>
          )}
          {data.mail.developmentPreview && (
            <section className="identity-mailbox identity-card">
              <div className="identity-card-header">
                <div>
                  <span className="eyebrow">PRIVATE DEVELOPMENT MAILBOX</span>
                  <h2>Messages with a clear destination.</h2>
                  <p>
                    Only you and an administrator can inspect these account
                    messages. This preview is disabled in production.
                  </p>
                </div>
                <Mail size={25} />
              </div>
              {data.mail.messages.length ? (
                <div className="identity-mail-list">
                  {data.mail.messages.map((message) => (
                    <button
                      key={message.id}
                      onClick={() =>
                        void act(`mail-${message.id}`, async () => {
                          const result = await api<{ message: MailPreview }>(
                            `/account/mail/${message.id}`,
                          );
                          setPreview(result.message);
                        })
                      }
                    >
                      <span>
                        <strong>{message.subject}</strong>
                        <small>
                          {dateText(message.createdAt)} · {message.status}
                        </small>
                      </span>
                      <ChevronRight size={16} />
                    </button>
                  ))}
                </div>
              ) : (
                <p className="identity-caption">
                  Request email verification above, or request a password reset
                  from sign-in, to inspect the generated message.
                </p>
              )}
              {preview && (
                <div className="identity-mail-preview">
                  <div>
                    <strong>{preview.subject}</strong>
                    <button
                      aria-label="Close mail preview"
                      onClick={() => setPreview(null)}
                    >
                      <X size={16} />
                    </button>
                  </div>
                  <pre>{preview.body}</pre>
                  {(preview.body.match(/https?:\/\/\S+/g) || []).map((link) => {
                    const parsed = new URL(link);
                    return (
                      <a
                        className="identity-text-button"
                        href={`${parsed.pathname}${parsed.search}`}
                        key={link}
                      >
                        Open account action <ArrowRight size={15} />
                      </a>
                    );
                  })}
                </div>
              )}
            </section>
          )}
        </>
      )}
    </section>
  );
}

export function RecoveryForm({
  kind,
  token = "",
  onDone,
}: {
  kind: "forgot" | "reset" | "verify";
  token?: string;
  onDone?: () => void;
}) {
  const [busy, setBusy] = useState(false),
    [message, setMessage] = useState(""),
    [error, setError] = useState("");
  const submit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const form = event.currentTarget;
    const body = Object.fromEntries(new FormData(form));
    if (kind === "reset" && body.password !== body.confirmPassword) {
      setError("The new passwords do not match.");
      return;
    }
    setBusy(true);
    setError("");
    try {
      const route =
        kind === "forgot"
          ? "/auth/forgot-password"
          : kind === "reset"
            ? "/auth/reset-password"
            : "/auth/verify-email";
      const result = await api<{ message?: string }>(route, {
        method: "POST",
        body: JSON.stringify({ ...body, token }),
      });
      setMessage(
        result.message ||
          (kind === "verify"
            ? "Your email is verified. A little more peace of mind."
            : "Your password has been reset. Sign in with the new password."),
      );
      form.reset();
    } catch (err) {
      setError(errorText(err));
    } finally {
      setBusy(false);
    }
  };
  return (
    <div className="identity-recovery-form">
      <span className="identity-icon">
        {kind === "verify" ? <Mail size={26} /> : <KeyRound size={26} />}
      </span>
      <span className="eyebrow">A LITTLE HELP GETTING HOME</span>
      <h2>
        {kind === "forgot"
          ? "Find your way back."
          : kind === "reset"
            ? "A fresh start. A new password."
            : "Confirm it’s really you."}
      </h2>
      <p>
        {kind === "forgot"
          ? "Request a private, time-limited recovery link for your account."
          : kind === "reset"
            ? "Choose a new password. This link works once and all existing sessions will be signed out."
            : "Confirm ownership of the email address connected to your creative world."}
      </p>
      {message ? (
        <div className="identity-recovery-success">
          <CheckCircle2 size={30} />
          <p>{message}</p>
          {onDone && (
            <button className="btn btn-primary" onClick={onDone}>
              Back to sign in <ArrowRight size={16} />
            </button>
          )}
        </div>
      ) : (
        <form onSubmit={(event) => void submit(event)}>
          {kind === "forgot" && (
            <label>
              Email address
              <input
                name="email"
                type="email"
                autoComplete="email"
                required
                placeholder="you@example.com"
              />
            </label>
          )}
          {kind === "reset" && (
            <>
              <label>
                New password
                <input
                  name="password"
                  type="password"
                  minLength={8}
                  maxLength={128}
                  required
                  autoComplete="new-password"
                />
              </label>
              <label>
                Confirm new password
                <input
                  name="confirmPassword"
                  type="password"
                  minLength={8}
                  maxLength={128}
                  required
                  autoComplete="new-password"
                />
              </label>
            </>
          )}
          {error && (
            <div className="identity-error" role="alert">
              {error}
            </div>
          )}
          <button className="btn btn-primary" disabled={busy}>
            {busy && <LoaderCircle size={16} className="spin" />}
            {kind === "forgot"
              ? "Request recovery link"
              : kind === "reset"
                ? "Save new password"
                : "Verify email address"}
            <ArrowRight size={16} />
          </button>
          {onDone && (
            <button
              type="button"
              className="identity-text-button"
              onClick={onDone}
            >
              Return to sign in
            </button>
          )}
        </form>
      )}
    </div>
  );
}
