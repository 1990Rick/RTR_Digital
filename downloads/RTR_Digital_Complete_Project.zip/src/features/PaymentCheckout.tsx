import { useCallback, useEffect, useRef, useState } from "react";
import type { FormEvent } from "react";
import {
  ArrowLeft,
  ArrowRight,
  ArrowUpRight,
  Check,
  CheckCircle2,
  CreditCard,
  Landmark,
  Loader2,
  LockKeyhole,
  RefreshCw,
  ShieldCheck,
  Sparkles,
  X,
} from "lucide-react";
import { api, money } from "../lib/api";
import type { Product, User } from "../lib/types";
import "./checkout-payments.css";

type Provider = "stripe" | "paypal" | "razorpay" | "wire";
type Method = {
  id: Provider;
  name: string;
  available: boolean;
  recurring: boolean;
  description: string;
};
type Payment = {
  id: string;
  provider: Exclude<Provider, "stripe">;
  status: string;
  total: number;
  currency: string;
  approvalUrl?: string;
  bank?: Record<string, string | number>;
  reference: string;
  expiresAt?: string;
  createdAt?: string;
  plan?: string;
  interval?: string;
  recurring: boolean;
  description?: string;
  orderId?: string;
  customerReference?: string;
  customerNote?: string;
  membershipReviewRequired?: boolean;
};
type Quote = {
  subtotal: number;
  discount: number;
  total: number;
  promotion: { code: string | null; percent: number; recurring: boolean };
  tax: { mode: string; message: string };
};
const providerNames: Record<string, string> = {
  stripe: "Stripe",
  paypal: "PayPal",
  razorpay: "Razorpay",
  wire: "Bank transfer",
};
const liveMethods: Provider[] = ["stripe", "paypal", "razorpay", "wire"];

function safeApprovalUrl(url: string, provider: Provider): string {
  const parsed = new URL(url);
  const domains: Record<Provider, string[]> = {
    stripe: ["checkout.stripe.com"],
    paypal: [
      "www.paypal.com",
      "paypal.com",
      "www.sandbox.paypal.com",
      "sandbox.paypal.com",
    ],
    razorpay: [
      "rzp.io",
      "rzp.co",
      "rzp.to",
      "razorpay.com",
      "www.razorpay.com",
      "checkout.razorpay.com",
      "pages.razorpay.com",
    ],
    wire: [],
  };
  if (
    parsed.protocol !== "https:" ||
    parsed.username ||
    parsed.password ||
    (parsed.port && parsed.port !== "443") ||
    !domains[provider].includes(parsed.hostname)
  )
    throw new Error(
      "The payment provider returned an invalid payment link. Please contact support.",
    );
  return parsed.href;
}

// Keep the same request key across dialog closes, reloads, and uncertain network retries.
function paymentRequestKey(
  userId: string,
  body: object,
): { key: string; storageKey: string } {
  const storageKey = `rtr-payment-request:${userId}:${JSON.stringify(body)}`;
  try {
    const existing = localStorage.getItem(storageKey);
    if (existing) {
      const saved = JSON.parse(existing) as { key: string };
      if (typeof saved.key === "string" && saved.key)
        return { key: saved.key, storageKey };
    }
    const key = crypto.randomUUID();
    localStorage.setItem(storageKey, JSON.stringify({ key }));
    return { key, storageKey };
  } catch {
    throw new Error(
      "Allow browser storage to start a payment safely, then try again.",
    );
  }
}

function rememberPayment(
  request: { key: string; storageKey: string },
  payment: Payment,
) {
  localStorage.setItem(
    request.storageKey,
    JSON.stringify({ key: request.key, paymentId: payment.id }),
  );
  clearSettledRequests([payment]);
}

function clearSettledRequests(payments: Payment[]) {
  const settled = new Set(
    payments
      .filter((p) =>
        [
          "completed",
          "refunded",
          "rejected",
          "expired",
          "cancelled",
          "canceled",
        ].includes(p.status),
      )
      .map((p) => p.id),
  );
  if (!settled.size) return;
  try {
    const keys = Array.from({ length: localStorage.length }, (_, i) =>
      localStorage.key(i),
    );
    for (const key of keys) {
      if (!key?.startsWith("rtr-payment-request:")) continue;
      try {
        const saved = JSON.parse(localStorage.getItem(key) || "{}");
        if (settled.has(saved.paymentId)) localStorage.removeItem(key);
      } catch {
        /* An unrelated damaged entry must not block a payment status update. */
      }
    }
  } catch {
    /* The authoritative status remains usable when storage is unavailable. */
  }
}

export function CheckoutForm({
  user,
  products,
  plan,
  config,
  onBack,
  onToast,
  onSuccess,
  onPaymentPending,
}: {
  user: User | null;
  products: Product[];
  plan: { id: string; interval: string } | null;
  config: { demoMode: boolean; stripeConfigured: boolean };
  onBack: () => void;
  onToast: (m: string, k?: string) => void;
  onSuccess: () => Promise<void>;
  onPaymentPending: (id: string) => void;
}) {
  const [mode, setMode] = useState<Provider | "demo">(
    config.demoMode ? "demo" : "stripe",
  );
  const [coupon, setCoupon] = useState("");
  const [applied, setApplied] = useState("");
  const [busy, setBusy] = useState(false);
  const [agreed, setAgreed] = useState(false);
  const [error, setError] = useState("");
  const [methods, setMethods] = useState<Method[]>([]);
  const [methodsBusy, setMethodsBusy] = useState(true);
  const [methodsError, setMethodsError] = useState("");
  const idem = useRef(crypto.randomUUID());
  const plans: Record<
    string,
    { name: string; monthly: number; yearly: number }
  > = {
    starter: { name: "Explorer", monthly: 9, yearly: 84 },
    creator: { name: "Creator", monthly: 19, yearly: 180 },
    studio: { name: "Studio", monthly: 39, yearly: 372 },
  };
  const [quote, setQuote] = useState<Quote | null>(null);
  const [quoteBusy, setQuoteBusy] = useState(true);
  const prepaid = mode !== "stripe" && mode !== "demo";
  const quoteBody = {
    productIds: plan ? [] : products.map((p) => p.id),
    ...(plan ? { plan: plan.id, interval: plan.interval } : {}),
  };
  const quoteKey = JSON.stringify(quoteBody);
  const loadMethods = useCallback(async () => {
    setMethodsBusy(true);
    setMethodsError("");
    try {
      const data = await api<{ methods: Method[] }>("/payments/methods");
      setMethods(data.methods);
    } catch (err) {
      setMethods([]);
      setMethodsError((err as Error).message);
    } finally {
      setMethodsBusy(false);
    }
  }, []);
  useEffect(() => {
    void loadMethods();
  }, [loadMethods]);
  useEffect(() => {
    let active = true;
    setQuoteBusy(true);
    void api<Quote>("/checkout/quote", {
      method: "POST",
      body: JSON.stringify({ ...JSON.parse(quoteKey), coupon: "" }),
    })
      .then((data) => {
        if (active) setQuote(data);
      })
      .catch((err) => {
        if (active) setError(err.message);
      })
      .finally(() => {
        if (active) setQuoteBusy(false);
      });
    return () => {
      active = false;
    };
  }, [quoteKey]);
  async function applyCoupon() {
    setQuoteBusy(true);
    setError("");
    const code = coupon.trim().toUpperCase();
    try {
      const data = await api<Quote>("/checkout/quote", {
        method: "POST",
        body: JSON.stringify({ ...quoteBody, coupon: code }),
      });
      setQuote(data);
      setApplied(code);
      idem.current = crypto.randomUUID();
    } catch (err) {
      setError((err as Error).message);
    } finally {
      setQuoteBusy(false);
    }
  }
  const subtotal =
    quote?.subtotal ??
    (plan
      ? plans[plan.id][plan.interval as "monthly" | "yearly"]
      : products.reduce((sum, p) => sum + p.price, 0));
  const discount = (quote?.promotion.percent || 0) / 100;
  const finalTotal = quote?.total ?? subtotal;
  const selectedMethod = methods.find((method) => method.id === mode);
  const available =
    mode === "demo"
      ? config.demoMode
      : Boolean(
          selectedMethod?.available &&
          (mode !== "stripe" || config.stripeConfigured),
        );
  async function submit(e: FormEvent) {
    e.preventDefault();
    if (busy || !agreed || !available || quoteBusy || !quote || !user) return;
    setBusy(true);
    setError("");
    try {
      if (mode !== "demo" && mode !== "stripe") {
        const body = { ...quoteBody, provider: mode, coupon: applied };
        const request = paymentRequestKey(user.id, body);
        const data = await api<Payment>("/payments/checkout", {
          method: "POST",
          headers: { "Idempotency-Key": request.key },
          body: JSON.stringify(body),
        });
        rememberPayment(request, data);
        if (data.approvalUrl && data.status !== "completed") {
          const url = safeApprovalUrl(data.approvalUrl, mode);
          location.assign(url);
          return;
        }
        onPaymentPending(data.id);
        return;
      }
      const data = await api<{ url?: string; orderId?: string }>("/checkout", {
        method: "POST",
        headers: { "Idempotency-Key": idem.current },
        body: JSON.stringify({ ...quoteBody, mode, coupon: applied }),
      });
      if (data.url) {
        location.assign(safeApprovalUrl(data.url, "stripe"));
        return;
      }
      onToast(
        `Your demo order ${data.orderId} is ready. No payment was collected.`,
      );
      await onSuccess();
    } catch (err) {
      setError((err as Error).message);
    } finally {
      setBusy(false);
    }
  }
  return (
    <div className="checkout-form">
      <button className="text-link back-link" onClick={onBack}>
        <ArrowLeft size={15} />
        Back to your collection
      </button>
      <span className="eyebrow">GOOD THINGS ARE JUST A STEP AWAY</span>
      <h2>
        {plan
          ? "A pass to your possibilities."
          : "Make a little room for great things."}
      </h2>
      <p>
        Signed in as <strong>{user?.email}</strong>
      </p>
      <div className="checkout-summary">
        {plan ? (
          <div className="checkout-plan">
            <span className="plan-icon">
              <Sparkles />
            </span>
            <div>
              <strong>The {plans[plan.id].name} Digital Pass</strong>
              <small>
                {prepaid
                  ? plan.interval === "yearly"
                    ? "Yearly membership · prepaid for one year"
                    : "Monthly membership · prepaid for one month"
                  : plan.interval === "yearly"
                    ? "Yearly membership · billed once per year"
                    : "Monthly membership · billed each month"}
              </small>
              <small>
                {prepaid
                  ? "Fixed term. No automatic renewal or automatic charges."
                  : "Renews until cancelled. Manage in your library."}
              </small>
            </div>
            <strong>{money(subtotal)}</strong>
          </div>
        ) : (
          products.map((p) => (
            <div key={p.id}>
              <span>
                {p.title}
                <small>{p.format} · Digital download</small>
              </span>
              <strong>{money(p.price)}</strong>
            </div>
          ))
        )}
      </div>
      <div className="coupon-row">
        <input
          aria-label="Promo code"
          placeholder="Have a little promo code?"
          value={coupon}
          onChange={(e) => setCoupon(e.target.value)}
          disabled={busy}
        />
        <button onClick={() => void applyCoupon()} disabled={quoteBusy || busy}>
          {quoteBusy ? "Checking…" : "Apply"}
        </button>
      </div>
      {applied && (
        <span className="coupon-applied">
          <Check size={13} />
          {applied} · {discount * 100}% off
          {plan && !prepaid ? " each renewal" : ""}
        </span>
      )}
      <div className="checkout-total">
        <span>
          Total
          {plan && (
            <small>
              {" "}
              / {plan.interval === "yearly" ? "year" : "month"}
              {prepaid ? " prepaid" : ""}
            </small>
          )}
        </span>
        <strong>
          {money(finalTotal)}
          <small> USD</small>
        </strong>
      </div>
      <p className="checkout-tax-note">
        RTR Digital · India-based digital business · All prices in USD.{" "}
        {quote?.tax.message}
      </p>
      <form onSubmit={(e) => void submit(e)}>
        <fieldset className="payment-options payment-methods" disabled={busy}>
          <legend>Choose your payment method</legend>
          {config.demoMode && (
            <label className={mode === "demo" ? "selected" : ""}>
              <input
                type="radio"
                name="payment"
                value="demo"
                checked={mode === "demo"}
                onChange={() => {
                  setMode("demo");
                  setAgreed(false);
                }}
              />
              <div>
                <strong>Explore with demo checkout</strong>
                <small>
                  No card. No charge. Sample content and test access only.
                </small>
              </div>
              <Sparkles size={20} />
            </label>
          )}
          {liveMethods.map((id) => {
            const method = methods.find((item) => item.id === id);
            const ready = Boolean(
              method?.available && (id !== "stripe" || config.stripeConfigured),
            );
            return (
              <label
                key={id}
                className={`${mode === id ? "selected" : ""} ${!ready ? "payment-unavailable" : ""}`}
              >
                <input
                  type="radio"
                  name="payment"
                  value={id}
                  checked={mode === id}
                  disabled={id !== "stripe" && !ready}
                  onChange={() => {
                    setMode(id);
                    setAgreed(false);
                  }}
                />
                <div>
                  <strong>
                    {id === "stripe"
                      ? "Pay securely with Stripe"
                      : id === "wire"
                        ? "Pay by bank transfer"
                        : `Pay with ${providerNames[id]}`}
                  </strong>
                  <small>
                    {methodsBusy
                      ? "Checking availability…"
                      : !ready
                        ? id === "stripe"
                          ? "Live payment setup is required before charging."
                          : "Not available. Payment setup is required."
                        : plan && id !== "stripe"
                          ? "Prepaid fixed term membership. No automatic charges."
                          : id === "wire"
                            ? "Bank wire / SWIFT. Access after cleared funds are verified."
                            : method?.description ||
                              `Continue to ${providerNames[id]}’s secure payment page.`}
                  </small>
                  {!methodsBusy && !ready && (
                    <span className="payment-setup-label">Unavailable</span>
                  )}
                </div>
                {id === "wire" ? (
                  <Landmark size={20} />
                ) : (
                  <CreditCard size={20} />
                )}
              </label>
            );
          })}
        </fieldset>
        {methodsError && (
          <div className="payment-availability-error">
            <span>Live payment options could not be checked.</span>
            <button
              type="button"
              className="text-link"
              onClick={() => void loadMethods()}
            >
              Try again
            </button>
          </div>
        )}
        {plan && prepaid && (
          <p className="payment-notice">
            <ShieldCheck size={17} />
            <span>
              This payment purchases one{" "}
              {plan.interval === "yearly" ? "year" : "month"} of membership
              after confirmed payment. It does not set up a recurring charge.
            </span>
          </p>
        )}
        <label className="checkbox-label checkout-terms">
          <input
            type="checkbox"
            required
            checked={agreed}
            onChange={(e) => setAgreed(e.target.checked)}
            disabled={busy}
          />
          <span>
            I agree to the digital-content license and terms.{" "}
            {plan
              ? prepaid
                ? "I understand this is a prepaid fixed term membership with no automatic renewal. Access begins after payment is verified."
                : "I understand this membership renews until cancelled. Any applied discount affects each renewal at the displayed price."
              : "I understand access is delivered digitally after confirmed payment."}
          </span>
        </label>
        {error && (
          <div className="form-error" role="alert">
            {error}
          </div>
        )}
        <button
          className="btn btn-primary"
          disabled={busy || quoteBusy || !quote || !agreed || !available}
        >
          {busy ? (
            <Loader2 className="spin" size={17} />
          ) : (
            <LockKeyhole size={16} />
          )}{" "}
          {mode === "demo"
            ? "Complete demo checkout"
            : mode === "wire"
              ? "Get bank transfer instructions"
              : mode === "stripe"
                ? "Continue to secure payment"
                : `Continue to ${providerNames[mode]}`}
          <ArrowRight size={17} />
        </button>
        <small className="checkout-assurance">
          <ShieldCheck size={14} />
          {mode === "demo"
            ? "This is a demonstration. No money will be charged."
            : mode === "wire"
              ? "Your payment remains pending until cleared funds are verified."
              : `Payment information is handled securely by ${providerNames[mode]}.`}
        </small>
      </form>
    </div>
  );
}

const bankFields: [string, string][] = [
  ["beneficiary", "Beneficiary"],
  ["bankName", "Bank name"],
  ["accountNumber", "Account number"],
  ["swift", "SWIFT / BIC"],
  ["ifsc", "IFSC"],
  ["iban", "IBAN"],
  ["routingNumber", "Routing number"],
  ["bankAddress", "Bank address"],
  ["beneficiaryAddress", "Beneficiary address"],
  ["intermediaryBank", "Intermediary bank"],
  ["instructions", "Transfer instructions"],
];
const pendingStatuses = ["pending", "creating"];
function paymentStatus(payment: Payment): string {
  if (payment.status === "completed") return "Paid";
  if (payment.status === "refunded") return "Refunded";
  if (payment.status === "pending" && payment.provider === "wire")
    return "Awaiting cleared funds";
  if (payment.status === "pending") return "Awaiting payment";
  if (payment.status === "creating") return "Preparing payment";
  if (payment.status === "creation_failed") return "Payment setup failed";
  if (payment.status === "rejected") return "Rejected";
  if (["cancelled", "canceled"].includes(payment.status)) return "Cancelled";
  if (payment.status === "expired") return "Expired";
  return "Payment under review";
}
function dateLabel(value?: string) {
  if (!value) return "";
  const date = new Date(value);
  return Number.isNaN(date.valueOf()) ? "" : date.toLocaleString();
}

export function PaymentActivity({
  user,
  refreshKey,
  onToast,
  onConfirmed,
  onLibrary,
}: {
  user: User | null;
  refreshKey: number;
  onToast: (message: string, kind?: string) => void;
  onConfirmed: () => void;
  onLibrary: () => void;
}) {
  const [payments, setPayments] = useState<Payment[]>([]);
  const [selectedId, setSelectedId] = useState<string | null>(() =>
    new URLSearchParams(location.search).get("payment"),
  );
  const [detail, setDetail] = useState<Payment | null>(null);
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [report, setReport] = useState(false);
  const [reference, setReference] = useState("");
  const [note, setNote] = useState("");
  const [reported, setReported] = useState(false);
  const returned = useRef("");
  const detailRef = useRef(detail);
  const confirmedRef = useRef(onConfirmed);
  detailRef.current = detail;
  confirmedRef.current = onConfirmed;
  const returnNotice = new URLSearchParams(location.search).get("status");
  const load = useCallback(async () => {
    setLoading(true);
    setError("");
    try {
      const data = await api<{ payments: Payment[] }>("/payments/orders");
      setPayments(data.payments);
      setDetail((current) =>
        current
          ? data.payments.find((payment) => payment.id === current.id) ||
            current
          : null,
      );
      clearSettledRequests(data.payments);
      const previous = detailRef.current;
      if (
        previous &&
        pendingStatuses.includes(previous.status) &&
        data.payments.some(
          (payment) =>
            payment.id === previous.id && payment.status === "completed",
        )
      ) {
        confirmedRef.current();
      }
    } catch (err) {
      setError((err as Error).message);
    } finally {
      setLoading(false);
    }
  }, []);
  useEffect(() => {
    if (user) void load();
  }, [user?.id, refreshKey, load]);
  useEffect(() => {
    if (!user) return;
    const id = new URLSearchParams(location.search).get("payment");
    if (id) setSelectedId(id);
  }, [refreshKey, user?.id]);
  useEffect(() => {
    if (!selectedId || !user) return;
    let active = true;
    setDetail(null);
    setBusy(false);
    setReport(false);
    setReported(false);
    setError("");
    void api<Payment>(`/payments/orders/${encodeURIComponent(selectedId)}`)
      .then(async (data) => {
        if (!active) return;
        setDetail(data);
        clearSettledRequests([data]);
        setReference(data.customerReference || "");
        setNote(data.customerNote || "");
        const params = new URLSearchParams(location.search);
        if (
          params.get("status") === "return" &&
          data.provider !== "wire" &&
          pendingStatuses.includes(data.status) &&
          returned.current !== data.id
        ) {
          returned.current = data.id;
          setBusy(true);
          try {
            const verified = await api<Payment>(
              `/payments/orders/${encodeURIComponent(data.id)}/verify`,
              { method: "POST" },
            );
            if (!active) return;
            setDetail(verified);
            clearSettledRequests([verified]);
            setPayments((list) =>
              list.map((p) => (p.id === verified.id ? verified : p)),
            );
            if (verified.status === "completed") onConfirmed();
          } catch (err) {
            if (active) setError((err as Error).message);
          } finally {
            if (active) setBusy(false);
          }
        }
      })
      .catch((err) => {
        if (active) setError((err as Error).message);
      });
    return () => {
      active = false;
    };
  }, [selectedId, user?.id, refreshKey]);
  async function verify() {
    if (!detail || busy) return;
    setBusy(true);
    setError("");
    try {
      const data = await api<Payment>(
        `/payments/orders/${encodeURIComponent(detail.id)}/verify`,
        { method: "POST" },
      );
      setDetail(data);
      clearSettledRequests([data]);
      setPayments((list) => list.map((p) => (p.id === data.id ? data : p)));
      if (data.status === "completed") {
        onConfirmed();
        onToast(
          data.membershipReviewRequired
            ? "Payment confirmed. Your membership requires a review by RTR Digital."
            : "Payment confirmed. Your paid order has been recorded.",
        );
      } else
        onToast(
          "Payment status refreshed. Access follows verified payment confirmation.",
        );
    } catch (err) {
      setError((err as Error).message);
    } finally {
      setBusy(false);
    }
  }
  async function notifyTransfer(e: FormEvent) {
    e.preventDefault();
    if (!detail || busy) return;
    setBusy(true);
    setError("");
    try {
      const data = await api<Payment>(
        `/payments/orders/${encodeURIComponent(detail.id)}/notify`,
        {
          method: "POST",
          body: JSON.stringify({
            reference: reference.trim(),
            note: note.trim(),
          }),
        },
      );
      setDetail(data);
      setPayments((list) => list.map((p) => (p.id === data.id ? data : p)));
      setReported(true);
      setReport(false);
    } catch (err) {
      setError((err as Error).message);
    } finally {
      setBusy(false);
    }
  }
  function openPayment(payment: Payment) {
    setSelectedId(payment.id);
    const url = new URL(location.href);
    url.searchParams.set("payment", payment.id);
    url.searchParams.delete("status");
    history.replaceState({}, "", `${url.pathname}${url.search}`);
  }
  function closeDetail() {
    setSelectedId(null);
    setDetail(null);
    setError("");
    const url = new URL(location.href);
    url.searchParams.delete("payment");
    url.searchParams.delete("status");
    history.replaceState({}, "", `${url.pathname}${url.search}`);
  }
  if (!user) return null;
  return (
    <section
      className="page-width pay-activity"
      aria-labelledby="payment-activity-title"
    >
      <div className="pay-section-heading">
        <div>
          <span className="eyebrow">EVERY PAYMENT, IN ONE PLACE</span>
          <h2 id="payment-activity-title">Payment activity</h2>
          <p>
            Track pending payments and bank transfers. Confirmed purchases
            appear in your orders and library.
          </p>
        </div>
        <button
          className="btn btn-outline"
          onClick={() => void load()}
          disabled={loading || busy}
        >
          <RefreshCw size={15} className={loading ? "spin" : ""} />
          Refresh payments
        </button>
      </div>
      {error && (
        <div className="form-error" role="alert">
          {error}
        </div>
      )}
      {selectedId && (
        <div
          className="pay-detail"
          aria-labelledby="payment-detail-title"
          aria-live="polite"
        >
          <div className="pay-detail-heading">
            <h3 id="payment-detail-title">
              {detail
                ? `${providerNames[detail.provider]} payment`
                : "Payment details"}
            </h3>
            <button
              className="icon-button"
              aria-label="Close payment details"
              onClick={closeDetail}
            >
              <X size={18} />
            </button>
          </div>
          {!detail ? (
            <p className="pay-muted">
              {error
                ? "Payment details are unavailable."
                : "Loading your payment…"}
            </p>
          ) : (
            <>
              {returnNotice === "cancel" && (
                <p className="payment-notice">
                  You returned from the payment provider. Your payment status
                  below is the verified store record; no new access has been
                  granted by this return.
                </p>
              )}
              {returnNotice === "return" && (
                <p className="payment-notice">
                  Payment is confirmed with the provider before access is
                  released. Returning to this page does not confirm payment.
                </p>
              )}
              <div className="pay-detail-summary">
                <span className={`pay-status pay-status-${detail.status}`}>
                  {paymentStatus(detail)}
                </span>
                <strong>
                  {money(detail.total)} <small>{detail.currency}</small>
                </strong>
              </div>
              <dl className="pay-detail-fields">
                <div>
                  <dt>Payment reference</dt>
                  <dd>
                    <code>{detail.reference}</code>
                  </dd>
                </div>
                <div>
                  <dt>Payment ID</dt>
                  <dd>{detail.id}</dd>
                </div>
                {detail.description && (
                  <div>
                    <dt>Purchase</dt>
                    <dd>{detail.description}</dd>
                  </div>
                )}
                {detail.plan && (
                  <div>
                    <dt>Membership</dt>
                    <dd>
                      Prepaid{" "}
                      {detail.interval === "yearly" ? "one year" : "one month"}{" "}
                      · no automatic renewal
                    </dd>
                  </div>
                )}
                {dateLabel(detail.expiresAt) &&
                  pendingStatuses.includes(detail.status) && (
                    <div>
                      <dt>Payment expires</dt>
                      <dd>{dateLabel(detail.expiresAt)}</dd>
                    </div>
                  )}
              </dl>
              {detail.provider === "wire" &&
                detail.bank &&
                pendingStatuses.includes(detail.status) && (
                  <div className="pay-bank-instructions">
                    <h4>
                      <Landmark size={19} />
                      Bank transfer instructions
                    </h4>
                    <p>
                      Send exactly{" "}
                      <strong>
                        {money(detail.total)} {detail.currency}
                      </strong>{" "}
                      using payment reference{" "}
                      <strong>{detail.reference}</strong>. These bank details
                      were saved for this payment. Your bank may charge transfer
                      or intermediary fees.
                    </p>
                    <dl className="pay-detail-fields">
                      {bankFields.map(([key, label]) =>
                        detail.bank?.[key] ? (
                          <div key={key}>
                            <dt>{label}</dt>
                            <dd>{detail.bank[key]}</dd>
                          </div>
                        ) : null,
                      )}
                    </dl>
                    <p className="payment-notice">
                      <ShieldCheck size={17} />
                      <span>
                        Awaiting cleared funds. Reporting a transfer does not
                        confirm payment or unlock access. RTR Digital must
                        verify the funds received.
                      </span>
                    </p>
                  </div>
                )}
              {reported && pendingStatuses.includes(detail.status) && (
                <p className="pay-reported" role="status">
                  <CheckCircle2 size={18} />
                  Transfer details reported. Your payment remains pending until
                  cleared funds are verified.
                </p>
              )}
              {detail.customerReference &&
                !reported &&
                pendingStatuses.includes(detail.status) && (
                  <p className="pay-muted">
                    Reported transfer reference:{" "}
                    <strong>{detail.customerReference}</strong>. Cleared funds
                    still require verification.
                  </p>
                )}
              {pendingStatuses.includes(detail.status) && (
                <div className="pay-detail-actions">
                  <button
                    className="btn btn-outline"
                    onClick={() => void verify()}
                    disabled={busy}
                  >
                    {busy ? (
                      <Loader2 className="spin" size={16} />
                    ) : (
                      <RefreshCw size={16} />
                    )}
                    {detail.provider === "wire"
                      ? "Refresh transfer status"
                      : "Refresh provider payment"}
                  </button>
                  {detail.provider === "wire" ? (
                    <button
                      className="btn btn-primary"
                      disabled={busy}
                      onClick={() => setReport(!report)}
                    >
                      Report a bank transfer
                      <ArrowRight size={15} />
                    </button>
                  ) : (
                    detail.approvalUrl && (
                      <button
                        className="btn btn-primary"
                        disabled={busy}
                        onClick={() => {
                          try {
                            location.assign(
                              safeApprovalUrl(
                                detail.approvalUrl!,
                                detail.provider,
                              ),
                            );
                          } catch (err) {
                            setError((err as Error).message);
                          }
                        }}
                      >
                        Continue to {providerNames[detail.provider]}
                        <ArrowUpRight size={15} />
                      </button>
                    )
                  )}
                </div>
              )}
              {report &&
                detail.provider === "wire" &&
                pendingStatuses.includes(detail.status) && (
                  <form
                    className="pay-transfer-form"
                    onSubmit={(e) => void notifyTransfer(e)}
                  >
                    <h4>Tell us about your transfer</h4>
                    <p>
                      Use your bank’s transfer reference. Do not include
                      passwords or card details.
                    </p>
                    <label>
                      Bank transfer reference
                      <input
                        required
                        minLength={3}
                        maxLength={150}
                        value={reference}
                        onChange={(e) => setReference(e.target.value)}
                        disabled={busy}
                      />
                    </label>
                    <label>
                      Transfer note <span>(optional)</span>
                      <textarea
                        maxLength={1000}
                        rows={3}
                        value={note}
                        onChange={(e) => setNote(e.target.value)}
                        disabled={busy}
                      />
                    </label>
                    <button
                      className="btn btn-primary"
                      disabled={busy || reference.trim().length < 3}
                    >
                      {busy && <Loader2 size={16} className="spin" />}Submit
                      transfer details
                      <ArrowRight size={15} />
                    </button>
                  </form>
                )}
              {detail.status === "completed" && (
                <p className="pay-completed">
                  <CheckCircle2 size={19} />
                  <span>
                    Payment confirmed.
                    {detail.orderId && (
                      <>
                        {" "}
                        Paid order: <strong>{detail.orderId}</strong>.
                      </>
                    )}{" "}
                    {detail.membershipReviewRequired ? (
                      "Your membership needs a review because another paid membership is active. Contact RTR Digital with this payment reference; membership access from this payment awaits review."
                    ) : (
                      <button className="text-link" onClick={onLibrary}>
                        Open your library <ArrowRight size={14} />
                      </button>
                    )}
                  </span>
                </p>
              )}
              {detail.status === "refunded" && (
                <p className="payment-notice">
                  This payment was refunded. See the order receipt above for the
                  recorded refund.
                </p>
              )}
              {[
                "rejected",
                "expired",
                "creation_failed",
                "cancelled",
                "canceled",
              ].includes(detail.status) && (
                <p className="payment-notice">
                  This payment has not granted access. Contact support with the
                  payment reference if you have already sent funds.
                </p>
              )}
            </>
          )}
        </div>
      )}
      {loading && payments.length === 0 ? (
        <p className="pay-empty">
          <Loader2 size={18} className="spin" />
          Loading your payments…
        </p>
      ) : payments.length === 0 ? (
        <p className="pay-empty">
          No international payments or bank transfers yet. Your completed
          purchases are listed above.
        </p>
      ) : (
        <div className="pay-list">
          {payments.map((payment) => (
            <button
              key={payment.id}
              className={`pay-payment-row ${selectedId === payment.id ? "selected" : ""}`}
              onClick={() => openPayment(payment)}
              aria-label={`View payment ${payment.reference}`}
            >
              <span className="pay-method-icon">
                {payment.provider === "wire" ? (
                  <Landmark size={21} />
                ) : (
                  <CreditCard size={21} />
                )}
              </span>
              <span className="pay-row-description">
                <strong>{providerNames[payment.provider]}</strong>
                <small>{payment.reference}</small>
              </span>
              <span className={`pay-status pay-status-${payment.status}`}>
                {paymentStatus(payment)}
              </span>
              <strong className="pay-row-amount">
                {money(payment.total)} <small>{payment.currency}</small>
              </strong>
              <ArrowRight size={16} />
            </button>
          ))}
        </div>
      )}
    </section>
  );
}
