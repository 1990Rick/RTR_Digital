import { ArrowUpRight, Check, GitCompareArrows, Plus, X } from "lucide-react";
import { useState } from "react";
import type { Product } from "../lib/types";
import { money } from "../lib/api";
import { SELLER_NAME } from "../lib/brand";
import { ProductArt } from "../components/Brand";
export function Comparison({
  products,
  onProduct,
  onExplore,
}: {
  products: Product[];
  onProduct: (p: Product) => void;
  onExplore: () => void;
}) {
  const [ids, setIds] = useState<string[]>(() => {
    try {
      const saved = JSON.parse(localStorage.getItem("rtr-comparison") || "[]");
      return Array.isArray(saved)
        ? saved.filter((x) => typeof x === "string").slice(0, 3)
        : [];
    } catch {
      return [];
    }
  });
  const selected = ids
    .map((id) => products.find((p) => p.id === id))
    .filter((p): p is Product => Boolean(p));
  function change(next: string[]) {
    setIds(next);
    localStorage.setItem("rtr-comparison", JSON.stringify(next));
  }
  const fields = [
    { title: "Category", value: (p: Product) => p.category },
    { title: "Price · one-time", value: (p: Product) => money(p.price) },
    { title: "Digital formats", value: (p: Product) => p.format },
    { title: "Download size", value: (p: Product) => p.size },
    { title: "Seller & licensor", value: () => SELLER_NAME },
    {
      title: "Digital Pass access",
      value: (p: Product) =>
        p.subscriptionIncluded
          ? "Included while your plan is active"
          : "Individual purchase only",
    },
    { title: "What’s inside", value: (p: Product) => p.description },
  ];
  return (
    <section className="page-width page-shell comparison-page">
      <div className="page-intro">
        <span className="eyebrow">A LITTLE PERSPECTIVE GOES A LONG WAY</span>
        <h1>Find your kind of extraordinary.</h1>
        <p>
          Compare up to three digital finds, side by side. Every detail in its
          right place.
        </p>
      </div>
      <div className="comparison-selector">
        <span>
          <GitCompareArrows size={18} /> YOUR SHORTLIST{" "}
          <small>{selected.length} / 3</small>
        </span>
        <label>
          <span className="sr-only">Add a product to compare</span>
          <select
            aria-label="Add a product to compare"
            value=""
            disabled={ids.length === 3}
            onChange={(e) => {
              if (e.target.value) change([...ids, e.target.value]);
            }}
          >
            <option value="">
              {ids.length === 3
                ? "Your shortlist is full"
                : "Choose a digital product…"}
            </option>
            {products
              .filter((p) => !ids.includes(p.id))
              .map((p) => (
                <option key={p.id} value={p.id}>
                  {p.title} · {money(p.price)}
                </option>
              ))}
          </select>
        </label>
        {ids.length > 0 && (
          <button className="text-link" onClick={() => change([])}>
            Start fresh <X size={14} />
          </button>
        )}
      </div>
      {selected.length ? (
        <div className="comparison-scroll">
          <div
            className="comparison-table"
            style={{
              gridTemplateColumns: `150px repeat(${selected.length},minmax(220px,1fr))`,
            }}
          >
            <div className="comparison-corner">
              <span>
                Good decisions
                <br />
                start with good details.
              </span>
            </div>
            {selected.map((p) => (
              <div className="comparison-product" key={p.id}>
                <button
                  className="comparison-remove"
                  aria-label={`Remove ${p.title} from comparison`}
                  onClick={() => change(ids.filter((id) => id !== p.id))}
                >
                  <X size={15} />
                </button>
                <button
                  className="comparison-art"
                  onClick={() => onProduct(p)}
                  aria-label={`View ${p.title}`}
                >
                  <ProductArt product={p} />
                </button>
                <small>{p.category}</small>
                <h2>{p.title}</h2>
                <button className="text-link" onClick={() => onProduct(p)}>
                  A closer look <ArrowUpRight size={15} />
                </button>
              </div>
            ))}
            {fields.map((field) => (
              <div className="comparison-row" key={field.title}>
                <strong>{field.title}</strong>
                {selected.map((p) => (
                  <div key={p.id}>
                    {field.title === "Digital Pass access" &&
                      p.subscriptionIncluded && <Check size={14} />}
                    <span>{field.value(p)}</span>
                  </div>
                ))}
              </div>
            ))}
          </div>
        </div>
      ) : (
        <div className="empty-state">
          <GitCompareArrows size={44} strokeWidth={1} />
          <h3>A little clarity. A better choice.</h3>
          <p>
            Add a few things that catch your eye. We’ll bring their details
            together.
          </p>
          <button className="btn btn-primary" onClick={onExplore}>
            Explore the collection <Plus size={16} />
          </button>
        </div>
      )}
      <p className="comparison-note">
        Prices are in USD. Product-specific licenses and access terms still
        apply. Comparing formats does not imply software compatibility with
        every device.
      </p>
    </section>
  );
}
