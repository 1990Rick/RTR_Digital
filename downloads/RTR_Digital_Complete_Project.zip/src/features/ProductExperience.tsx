import { useEffect, useRef, useState } from "react";
import {
  ArrowDownToLine,
  BookOpen,
  Check,
  CheckCircle2,
  Clipboard,
  FileClock,
  FileText,
  KeyRound,
  Loader2,
  Save,
  ShieldCheck,
} from "lucide-react";
import type { Product, User } from "../lib/types";
import { api } from "../lib/api";
import "./publishing.css";

type Props = {
  product: Product;
  user: User | null;
  onToast: (message: string, kind?: "success" | "error") => void;
};
type Release = {
  id: string;
  version: string;
  changelog: string;
  checksum: string;
  bytes: number;
  createdAt: string;
};
type Experience = {
  preview: null | { kind: string; mime: string; url: string };
  versions: Release[];
  canAccess: boolean;
  licenseRequired: boolean;
  latestVersion: string | null;
  checksum: string | null;
  licenseAssigned: null | { id: string; claimedAt: string };
};
type OriginalContent = {
  available: boolean;
  kind?: string;
  mime?: string;
  url?: string;
  bytes?: number;
  message?: string;
};
type Progress = {
  position: number;
  total: number;
  completed: boolean | number;
  note: string;
  updatedAt?: string;
};
export function ProductExperience({ product, user, onToast }: Props) {
  const [info, setInfo] = useState<Experience | null>(null);
  const [error, setError] = useState("");
  const [text, setText] = useState("");
  const [original, setOriginal] = useState<OriginalContent | null>(null);
  const [contentMode, setContentMode] = useState<"original" | "preview">(
    "preview",
  );
  const [textError, setTextError] = useState("");
  const [textLoading, setTextLoading] = useState(false);
  const [progress, setProgress] = useState<Progress>({
    position: 0,
    total: 0,
    completed: false,
    note: "",
  });
  const [busy, setBusy] = useState(false);
  const [key, setKey] = useState("");
  const media = useRef<HTMLMediaElement | null>(null);
  const restored = useRef(false);
  useEffect(() => {
    let active = true;
    setInfo(null);
    setOriginal(null);
    setError("");
    setKey("");
    setText("");
    setTextError("");
    setProgress({ position: 0, total: 0, completed: false, note: "" });
    setContentMode("preview");
    restored.current = false;
    void api<Experience>(
      `/products/${encodeURIComponent(product.id)}/experience`,
    )
      .then(async (experience) => {
        let originalContent: OriginalContent | null = null;
        let savedProgress: Progress = {
          position: 0,
          total: 0,
          completed: false,
          note: "",
        };
        if (experience.canAccess && user) {
          const [content, saved] = await Promise.all([
            api<OriginalContent>(
              `/products/${encodeURIComponent(product.id)}/content-info`,
            ),
            api<{ progress: Progress }>(
              `/products/${encodeURIComponent(product.id)}/progress`,
            ),
          ]);
          originalContent = content;
          savedProgress = saved.progress;
        }
        if (!active) return;
        setOriginal(originalContent);
        setProgress(savedProgress);
        setInfo(experience);
        setContentMode(originalContent?.available ? "original" : "preview");
      })
      .catch((err) => {
        if (active) setError((err as Error).message);
      });
    return () => {
      active = false;
    };
  }, [product.id, user?.id]);
  const fullContent =
    contentMode === "original" && Boolean(original?.available);
  const source =
    fullContent && original?.url
      ? { kind: original.kind!, url: original.url, mime: original.mime! }
      : info?.preview || null;
  useEffect(() => {
    restored.current = false;
    setText("");
    setTextError("");
    setTextLoading(source?.kind === "text");
    if (source?.kind !== "text") return;
    let active = true;
    void fetch(source.url, { credentials: "same-origin" })
      .then(async (response) => {
        if (!response.ok)
          throw new Error(
            "This content is not currently available. Please check your library access.",
          );
        const value = await response.text();
        if (active) {
          setText(value);
          setTextLoading(false);
        }
      })
      .catch((err) => {
        if (active) {
          setTextError((err as Error).message);
          setTextLoading(false);
        }
      });
    return () => {
      active = false;
    };
  }, [source?.url, source?.kind]);
  async function save(current: Progress = progress) {
    setBusy(true);
    try {
      await api(`/products/${encodeURIComponent(product.id)}/progress`, {
        method: "PUT",
        body: JSON.stringify({
          ...current,
          completed: Boolean(current.completed),
        }),
      });
      onToast("Your place is saved. Pick up wherever inspiration finds you.");
    } catch (e) {
      onToast((e as Error).message, "error");
    } finally {
      setBusy(false);
    }
  }
  async function claim() {
    setBusy(true);
    try {
      const d = await api<{ key: string }>(
        `/products/${encodeURIComponent(product.id)}/license`,
        { method: "POST" },
      );
      setKey(d.key);
      onToast("Your personal license key is ready. Keep it private.");
    } catch (e) {
      onToast((e as Error).message, "error");
    } finally {
      setBusy(false);
    }
  }
  const setMedia = (element: HTMLMediaElement | null) => {
    media.current = element;
  };
  const restoreMedia = () => {
    const el = media.current;
    if (fullContent && el && !restored.current) {
      el.currentTime = Math.min(
        progress.position,
        Number.isFinite(el.duration) ? el.duration : progress.position,
      );
      restored.current = true;
    }
  };
  const updatePosition = () => {
    const el = media.current;
    if (fullContent && el)
      setProgress((p) => ({
        ...p,
        position: Math.floor(el.currentTime),
        total: Number.isFinite(el.duration) ? Math.floor(el.duration) : p.total,
      }));
  };
  if (error)
    return (
      <div className="exp-error" role="status">
        {error}
      </div>
    );
  if (!info)
    return (
      <div className="exp-loading">
        <Loader2 size={16} className="spin" /> Preparing product extras…
      </div>
    );
  const learning =
    info.canAccess &&
    ["Courses", "Video", "Audio & music", "E-books"].includes(product.category);
  return (
    <section
      className="product-experience"
      aria-label="Product previews and access"
    >
      <div className="exp-heading">
        <BookOpen size={18} />
        <div>
          <h3>A closer look.</h3>
          <p>Preview what’s inside. Save your place. Keep creating.</p>
        </div>
      </div>
      {info.canAccess && original?.available && info.preview && (
        <div
          className="exp-content-mode"
          role="group"
          aria-label="Choose original content or public preview"
        >
          <button
            className={fullContent ? "active" : ""}
            onClick={() => setContentMode("original")}
          >
            Your full content
          </button>
          <button
            className={!fullContent ? "active" : ""}
            onClick={() => setContentMode("preview")}
          >
            Public preview
          </button>
        </div>
      )}
      {info.canAccess && original && !original.available && (
        <p className="exp-original-note">
          {original.message ||
            "This format opens from your download. Find the original file in your library."}
        </p>
      )}
      {source ? (
        <div className="exp-preview">
          {source.kind === "audio" ? (
            <audio
              key={source.url}
              ref={setMedia}
              controls
              preload="metadata"
              src={source.url}
              onLoadedMetadata={restoreMedia}
              onTimeUpdate={updatePosition}
              aria-label={`${product.title} ${fullContent ? "full audio" : "audio preview"}`}
            />
          ) : source.kind === "video" ? (
            <video
              key={source.url}
              ref={setMedia}
              controls
              playsInline
              preload="metadata"
              src={source.url}
              onLoadedMetadata={restoreMedia}
              onTimeUpdate={updatePosition}
              aria-label={`${product.title} ${fullContent ? "full video" : "video preview"}`}
            />
          ) : source.kind === "pdf" ? (
            <div className="exp-pdf">
              <iframe
                src={source.url}
                title={`${product.title} ${fullContent ? "full PDF" : "PDF preview"}`}
              />
              <a href={source.url} target="_blank" rel="noreferrer">
                <FileText size={15} />
                {fullContent ? "Open your full PDF" : "Open PDF preview"}
              </a>
            </div>
          ) : (
            <pre className="exp-text-preview">
              {textError ||
                (textLoading
                  ? fullContent
                    ? "Opening your full content…"
                    : "Loading preview…"
                  : text || "This text file is empty.")}
            </pre>
          )}
          <span className="exp-preview-label">
            {fullContent
              ? "YOUR FULL CONTENT · ACCESS PROTECTED BY YOUR ACCOUNT"
              : "PUBLIC PREVIEW · ORIGINAL DOWNLOADS REMAIN IN YOUR LIBRARY"}
          </span>
        </div>
      ) : (
        <div className="exp-preview-empty">
          <FileText size={21} />
          <div>
            <strong>A little more to discover.</strong>
            <p>
              This product has no public media preview yet. Its description,
              formats, and file size appear above.
            </p>
          </div>
        </div>
      )}
      {learning && (
        <div className="exp-progress">
          <div className="exp-subheading">
            <CheckCircle2 size={16} />
            <h4>Your place in the story.</h4>
            {progress.updatedAt && (
              <small>
                Saved {new Date(progress.updatedAt).toLocaleDateString()}
              </small>
            )}
          </div>
          {fullContent &&
            source &&
            ["audio", "video"].includes(source.kind) && (
              <div className="exp-playback-progress">
                <progress value={progress.position} max={progress.total || 1} />
                <span>
                  {Math.floor(progress.position / 60)}:
                  {String(Math.floor(progress.position % 60)).padStart(2, "0")}{" "}
                  saved position
                </span>
              </div>
            )}
          <label>
            Your notes
            <textarea
              value={progress.note}
              maxLength={10000}
              onChange={(e) =>
                setProgress({ ...progress, note: e.target.value })
              }
              placeholder="Ideas, a bookmark, or a little note for your future self…"
              rows={3}
            />
          </label>
          <div className="exp-progress-actions">
            <label className="checkbox-label">
              <input
                type="checkbox"
                checked={Boolean(progress.completed)}
                onChange={(e) =>
                  setProgress({ ...progress, completed: e.target.checked })
                }
              />
              Mark as completed
            </label>
            <button
              className="btn btn-outline"
              disabled={busy}
              onClick={() => void save()}
            >
              {busy ? (
                <Loader2 size={15} className="spin" />
              ) : (
                <Save size={15} />
              )}
              Save my place
            </button>
          </div>
        </div>
      )}
      {info.licenseRequired && (
        <div className="exp-license">
          <KeyRound size={21} />
          <div>
            <h4>Your license. Your possibilities.</h4>
            <p>
              {info.canAccess
                ? "Claim your unique RTR Digital license key. Keys are private and assigned once to your account."
                : "Purchase this product or activate an eligible membership to claim a license key."}
            </p>
            {key && (
              <div className="exp-license-value">
                <code>{key}</code>
                <button
                  aria-label="Copy license key"
                  onClick={() =>
                    void navigator.clipboard
                      .writeText(key)
                      .then(() => onToast("License key copied."))
                      .catch(() =>
                        onToast("Select and copy your key manually.", "error"),
                      )
                  }
                >
                  <Clipboard size={16} />
                </button>
              </div>
            )}
          </div>
          {info.canAccess && !key && (
            <button
              className="btn btn-outline"
              disabled={busy}
              onClick={() => void claim()}
            >
              {busy ? (
                <Loader2 size={15} className="spin" />
              ) : (
                <KeyRound size={15} />
              )}
              {info.licenseAssigned ? "Show my key" : "Claim my key"}
            </button>
          )}
        </div>
      )}
      {info.versions.length > 0 && (
        <div className="exp-releases">
          <div className="exp-subheading">
            <FileClock size={16} />
            <h4>Good things keep getting better.</h4>
          </div>
          {info.versions.map((version, index) => (
            <article key={version.id}>
              <div>
                <strong>Version {version.version}</strong>
                {index === 0 && (
                  <span>
                    <Check size={10} />
                    Latest release
                  </span>
                )}
                <small>
                  {new Date(version.createdAt).toLocaleDateString()} ·{" "}
                  {(version.bytes / 1048576).toFixed(2)} MB
                </small>
              </div>
              {version.changelog && <p>{version.changelog}</p>}
              <details>
                <summary>
                  <ShieldCheck size={13} />
                  SHA-256 file integrity
                </summary>
                <code>{version.checksum}</code>
              </details>
              {info.canAccess && (
                <a
                  className="exp-version-download"
                  href={`/api/products/${encodeURIComponent(product.id)}/releases/${encodeURIComponent(version.id)}/download`}
                >
                  <ArrowDownToLine size={13} /> Download version{" "}
                  {version.version}
                </a>
              )}
            </article>
          ))}
          {info.canAccess && (
            <a
              className="btn btn-primary"
              href={`/api/download/${encodeURIComponent(product.id)}`}
            >
              <ArrowDownToLine size={15} />
              Download the latest release
            </a>
          )}
        </div>
      )}
    </section>
  );
}
