import { useCallback, useEffect, useState } from "react";
import type { FormEvent, ReactNode } from "react";
import {
  ArrowDownLeft,
  ArrowUpRight,
  Check,
  CheckCheck,
  CircleAlert,
  CreditCard,
  Globe2,
  KeyRound,
  Landmark,
  LoaderCircle,
  LockKeyhole,
  RefreshCw,
  ShieldCheck,
  WalletCards,
  X,
} from "lucide-react";
import { api, money } from "../lib/api";
import type { User } from "../lib/types";
import "./payments.css";

type Provider = {
  id: string;
  name: string;
  enabled: boolean;
  configured: boolean;
  available?: boolean;
  environment?: string;
  clientId?: string;
  clientSecret?: string;
  merchantId?: string;
  keyId?: string;
  keySecret?: string;
  hasClientId?: boolean;
  hasClientSecret?: boolean;
  hasMerchantId?: boolean;
  hasKeyId?: boolean;
  hasKeySecret?: boolean;
  description?: string;
};
type Bank = {
  enabled: boolean;
  version: number;
  beneficiary: string;
  bankName: string;
  accountNumber: string;
  swift: string;
  ifsc: string;
  iban: string;
  routingNumber: string;
  bankAddress: string;
  beneficiaryAddress: string;
  intermediaryBank: string;
  instructions: string;
};
type Transfer = {
  id: string;
  status: string;
  total: number;
  currency?: string;
  createdAt: string;
  customerName?: string;
  customerEmail?: string;
  reference?: string;
  customerReference?: string;
  customerNote?: string;
  expiresAt?: string;
  bankVersion?: number;
  bank?: {
    bankName?: string;
    accountLast4?: string;
    ibanLast4?: string;
    beneficiary?: string;
    version?: number;
  };
};
type PaymentData = {
  providers: Provider[];
  bank: Bank;
  transfers: Transfer[];
  passwordRequired?: boolean;
  demoReauthentication?: boolean;
};
type Props = {
  user: User;
  onToast: (message: string, kind?: "success" | "error") => void;
};
const message = (err: unknown) =>
  err instanceof Error ? err.message : "Please try again in a moment.";
const readable = (value: string) => value.replaceAll("_", " ");
const date = (value: string) =>
  Number.isFinite(Date.parse(value))
    ? new Date(value).toLocaleString("en-US", {
        month: "short",
        day: "numeric",
        year: "numeric",
        hour: "numeric",
        minute: "2-digit",
      })
    : "—";
const value = (fields: FormData, name: string) =>
  String(fields.get(name) || "").trim();

function Field({
  label,
  name,
  initial,
  placeholder,
  secret,
  multiline,
  required,
  help,
}: {
  label: string;
  name: string;
  initial?: string;
  placeholder?: string;
  secret?: boolean;
  multiline?: boolean;
  required?: boolean;
  help?: string;
}) {
  return (
    <label className={multiline ? "pay-field pay-field-wide" : "pay-field"}>
      <span>{label}</span>
      {multiline ? (
        <textarea
          name={name}
          defaultValue={initial || ""}
          placeholder={placeholder}
          rows={3}
          maxLength={2000}
        />
      ) : (
        <input
          name={name}
          type={secret ? "password" : "text"}
          defaultValue={secret ? "" : initial || ""}
          placeholder={placeholder}
          autoComplete={secret ? "new-password" : "off"}
          required={required}
          maxLength={secret ? 2048 : 500}
          spellCheck={false}
        />
      )}
      {help && <small>{help}</small>}
    </label>
  );
}

function Switch({
  name,
  enabled,
  label,
}: {
  name: string;
  enabled: boolean;
  label: string;
}) {
  return (
    <label className="pay-switch">
      <input type="checkbox" name={name} defaultChecked={enabled} />
      <span aria-hidden="true" />
      <b>{label}</b>
    </label>
  );
}

function ProviderCard({
  provider,
  id,
  name,
  icon,
  link,
  children,
}: {
  provider?: Provider;
  id: string;
  name: string;
  icon: ReactNode;
  link: string;
  children?: ReactNode;
}) {
  const configured = Boolean(provider?.configured);
  return (
    <article className={`pay-provider pay-provider-${id}`}>
      <header>
        <span className="pay-provider-icon">{icon}</span>
        <div>
          <h3>{name}</h3>
          <span className={`pay-status ${configured ? "configured" : ""}`}>
            <i />
            {configured ? "Credentials configured" : "Setup required"}
          </span>
        </div>
        <span className="pay-environment">
          {provider?.environment === "live"
            ? "Live"
            : provider?.environment === "sandbox" ||
                provider?.environment === "test"
              ? "Test / sandbox"
              : "Server managed"}
        </span>
      </header>
      {children}
      <a
        className="pay-dashboard"
        href={link}
        target="_blank"
        rel="noopener noreferrer"
      >
        Open {name} dashboard <ArrowUpRight size={14} />
      </a>
    </article>
  );
}

export function PaymentSettings({ user, onToast }: Props) {
  const [data, setData] = useState<PaymentData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [saveError, setSaveError] = useState("");
  const [reviewError, setReviewError] = useState("");
  const [busy, setBusy] = useState("");
  const [revision, setRevision] = useState(0);
  const [revealedBank, setRevealedBank] = useState<Bank | null>(null);
  const [review, setReview] = useState<{
    id: string;
    action: "confirm" | "reject";
  } | null>(null);
  const load = useCallback(async () => {
    setRevealedBank(null);
    setLoading(true);
    setError("");
    try {
      setData(await api<PaymentData>("/admin/payments"));
      setRevision((previous) => previous + 1);
    } catch (err) {
      setError(message(err));
    } finally {
      setLoading(false);
    }
  }, []);
  useEffect(() => {
    void load();
  }, [load]);
  useEffect(() => {
    setRevealedBank(null);
  }, [user.id]);
  useEffect(() => {
    if (!revealedBank) return;
    const timeout = window.setTimeout(() => setRevealedBank(null), 60_000);
    return () => window.clearTimeout(timeout);
  }, [revealedBank]);

  const sharedDemo = user.email === "demo-admin@rtr.example";
  const passwordRequired = data?.passwordRequired ?? !sharedDemo;

  async function save(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const fields = new FormData(event.currentTarget);
    const paypal: Record<string, unknown> = {
      enabled: fields.has("paypal.enabled"),
      environment: value(fields, "paypal.environment"),
    };
    const razorpay: Record<string, unknown> = {
      enabled: fields.has("razorpay.enabled"),
    };
    for (const name of ["clientId", "clientSecret", "merchantId"])
      if (value(fields, `paypal.${name}`))
        paypal[name] = value(fields, `paypal.${name}`);
    for (const name of ["keyId", "keySecret"])
      if (value(fields, `razorpay.${name}`))
        razorpay[name] = value(fields, `razorpay.${name}`);
    const bank: Record<string, unknown> = {
      enabled: fields.has("bank.enabled"),
    };
    for (const name of [
      "beneficiary",
      "bankName",
      "swift",
      "ifsc",
      "bankAddress",
      "beneficiaryAddress",
      "intermediaryBank",
      "instructions",
    ])
      bank[name] = value(fields, `bank.${name}`);
    for (const name of ["accountNumber", "iban", "routingNumber"])
      if (value(fields, `bank.${name}`))
        bank[name] = value(fields, `bank.${name}`);
    if (fields.has("paypal.remove")) {
      paypal.enabled = false;
      paypal.removeFields = ["clientId", "clientSecret", "merchantId"];
    }
    if (fields.has("razorpay.remove")) {
      razorpay.enabled = false;
      razorpay.removeFields = ["keyId", "keySecret"];
    }
    if (fields.has("bank.remove")) {
      bank.enabled = false;
      bank.removeFields = ["accountNumber", "iban", "routingNumber"];
    }
    setBusy("settings");
    setSaveError("");
    try {
      await api("/admin/payments/settings", {
        method: "PATCH",
        body: JSON.stringify({
          password: value(fields, "password"),
          providers: { paypal, razorpay },
          bank,
        }),
      });
      await load();
      onToast(
        "Payment settings saved. Existing wire orders keep their original bank instructions.",
      );
    } catch (err) {
      setSaveError(message(err));
    } finally {
      setBusy("");
    }
  }

  async function revealBank(form: HTMLFormElement | null) {
    if (revealedBank) {
      setRevealedBank(null);
      return;
    }
    if (!form) return;
    setBusy("reveal");
    setSaveError("");
    try {
      const result = await api<{ bank: Bank }>("/admin/payments/bank/reveal", {
        method: "POST",
        body: JSON.stringify({
          password: value(new FormData(form), "password"),
        }),
      });
      setRevealedBank(result.bank);
    } catch (err) {
      setSaveError(message(err));
    } finally {
      setBusy("");
    }
  }

  async function reconcile(
    event: FormEvent<HTMLFormElement>,
    transfer: Transfer,
  ) {
    event.preventDefault();
    if (!review) return;
    const fields = new FormData(event.currentTarget);
    const action = review.action;
    if (action === "confirm" && !fields.has("cleared")) {
      setReviewError(
        "Confirm that you checked the cleared funds in your bank statement.",
      );
      return;
    }
    setBusy(transfer.id);
    setReviewError("");
    try {
      await api(
        `/admin/payments/orders/${encodeURIComponent(transfer.id)}/${action}`,
        {
          method: "POST",
          body: JSON.stringify(
            action === "confirm"
              ? {
                  password: value(fields, "password"),
                  bankReference: value(fields, "bankReference"),
                  receivedAmount: Number(value(fields, "receivedAmount")),
                  currency: "USD",
                  cleared: true,
                }
              : {
                  password: value(fields, "password"),
                  note: value(fields, "note"),
                },
          ),
        },
      );
      setReview(null);
      await load();
      onToast(
        action === "confirm"
          ? sharedDemo
            ? "Demo transfer recorded. No live purchase access was granted."
            : "Cleared bank payment recorded. Order access is now available."
          : "Transfer rejected. No purchase access was granted.",
      );
    } catch (err) {
      setReviewError(message(err));
    } finally {
      setBusy("");
    }
  }

  if (!data && loading)
    return (
      <div className="co-empty" role="status">
        <LoaderCircle size={26} className="spin" />
        <p>Preparing your payment connections…</p>
      </div>
    );
  if (!data)
    return (
      <div className="co-error" role="alert">
        <CircleAlert size={21} />
        <p>{error || "Payment settings could not be loaded."}</p>
        <button className="btn btn-outline" onClick={() => void load()}>
          Try again <RefreshCw size={14} />
        </button>
      </div>
    );
  const paypal = data.providers.find((provider) => provider.id === "paypal");
  const razorpay = data.providers.find(
    (provider) => provider.id === "razorpay",
  );
  const stripe = data.providers.find((provider) => provider.id === "stripe");
  const transfers = data.transfers.filter((transfer) =>
    ["pending", "reported", "payment_reported", "expired"].includes(
      transfer.status,
    ),
  );

  function PasswordField() {
    return (
      <label className="pay-field pay-password">
        <span>
          <LockKeyhole size={13} />
          Current administrator password
        </span>
        <input
          name="password"
          type="password"
          autoComplete="current-password"
          maxLength={128}
          required={passwordRequired}
          placeholder={
            passwordRequired
              ? "Verify this sensitive change"
              : "Optional for this shared demo account"
          }
        />
      </label>
    );
  }

  return (
    <div className="pay-hub">
      <header className="pay-intro">
        <div className="pay-intro-copy">
          <span className="pay-kicker">
            <Globe2 size={13} /> INDIA → WORLDWIDE · USD
          </span>
          <h2>
            A clear path from purchase to payment<span>.</span>
          </h2>
          <p>
            Connect checkout providers and publish bank transfer instructions
            for RTR Digital, the seller and licensor of every product.
          </p>
        </div>
        <div className="pay-intro-note">
          <ShieldCheck size={23} />
          <strong>Your bank. Your provider.</strong>
          <p>
            Manage payout bank accounts, KYC, settlement schedules, and
            withdrawals in each provider’s dashboard.
          </p>
        </div>
      </header>
      <div className="pay-toolbar">
        <p>
          <LockKeyhole size={13} />
          Credentials stay on the server. Saved secrets are never returned.
        </p>
        <button
          className="pay-refresh"
          onClick={() => void load()}
          disabled={loading || Boolean(busy)}
        >
          <RefreshCw size={14} className={loading ? "spin" : ""} />
          Refresh connections
        </button>
      </div>
      {error && (
        <div className="co-inline-error" role="alert">
          {error}
        </div>
      )}
      {!passwordRequired && (
        <div className="pay-demo">
          <CircleAlert size={16} />
          <p>
            <strong>Shared development demo:</strong> password verification is
            bypassed for this demo account. Use a private administrator account
            and current password for a live store.
          </p>
        </div>
      )}

      <form key={revision} onSubmit={(event) => void save(event)}>
        <div className="pay-section-heading">
          <div>
            <span className="pay-kicker">01 / CHECKOUT CONNECTIONS</span>
            <h2>Choose how customers pay.</h2>
          </div>
          <span className="pay-small-tag">Single seller · RTR Digital</span>
        </div>
        <div className="pay-provider-grid">
          <ProviderCard
            provider={stripe}
            id="stripe"
            name="Stripe"
            icon={<CreditCard size={23} />}
            link="https://dashboard.stripe.com/settings/payouts"
          >
            <div className="pay-managed">
              <span>
                <KeyRound size={13} />
                Server configuration
              </span>
              <p>
                Stripe keys and webhooks are managed through deployment
                environment variables. Available payment methods depend on your
                Stripe account, buyer location, and checkout currency.
              </p>
            </div>
            <div className="pay-provider-facts">
              <span>Hosted checkout</span>
              <span>Recurring memberships</span>
            </div>
          </ProviderCard>
          <ProviderCard
            provider={paypal}
            id="paypal"
            name="PayPal"
            icon={<WalletCards size={23} />}
            link="https://www.paypal.com/businessmanage/account/money"
          >
            <div className="pay-provider-controls">
              <Switch
                name="paypal.enabled"
                enabled={Boolean(paypal?.enabled)}
                label="Offer PayPal"
              />
              <label className="pay-environment-select">
                <span className="sr-only">PayPal environment</span>
                <select
                  name="paypal.environment"
                  defaultValue={
                    paypal?.environment === "live" ? "live" : "sandbox"
                  }
                >
                  <option value="sandbox">Sandbox</option>
                  <option value="live">Live</option>
                </select>
              </label>
            </div>
            <div className="pay-fields">
              <Field
                label="Client ID"
                name="paypal.clientId"
                secret
                placeholder={
                  paypal?.clientId ||
                  (paypal?.hasClientId
                    ? "Saved · leave blank to keep"
                    : "Enter client ID")
                }
              />
              <Field
                label="Client secret"
                name="paypal.clientSecret"
                secret
                placeholder={
                  paypal?.hasClientSecret
                    ? "Saved securely · leave blank to keep"
                    : "Enter client secret"
                }
              />
              <Field
                label="Merchant ID"
                name="paypal.merchantId"
                secret
                placeholder={
                  paypal?.merchantId ||
                  (paypal?.hasMerchantId
                    ? "Saved · leave blank to keep"
                    : "Required for payee verification")
                }
                help="Use the merchant ID for the RTR Digital business account."
              />
            </div>
            <p className="pay-provider-help">
              One-time purchases. The environment and credentials must match.
              Blank fields keep saved values.
            </p>
            <label className="pay-remove-option">
              <input type="checkbox" name="paypal.remove" /> Remove saved PayPal
              credentials when I save
            </label>
          </ProviderCard>
          <ProviderCard
            provider={razorpay}
            id="razorpay"
            name="Razorpay"
            icon={<ArrowUpRight size={23} />}
            link="https://dashboard.razorpay.com/app/settlements"
          >
            <div className="pay-provider-controls">
              <Switch
                name="razorpay.enabled"
                enabled={Boolean(razorpay?.enabled)}
                label="Offer Razorpay"
              />
            </div>
            <div className="pay-fields">
              <Field
                label="Key ID"
                name="razorpay.keyId"
                secret
                placeholder={
                  razorpay?.keyId ||
                  (razorpay?.hasKeyId
                    ? "Saved · leave blank to keep"
                    : "rzp_test_… or rzp_live_…")
                }
              />
              <Field
                label="Key secret"
                name="razorpay.keySecret"
                secret
                placeholder={
                  razorpay?.hasKeySecret
                    ? "Saved securely · leave blank to keep"
                    : "Enter key secret"
                }
              />
            </div>
            <p className="pay-provider-help">
              One-time purchases. Test or live mode follows your Key ID. USD and
              international payments require approval on your merchant account.
              Blank fields keep saved values.
            </p>
            <label className="pay-remove-option">
              <input type="checkbox" name="razorpay.remove" /> Remove saved
              Razorpay credentials when I save
            </label>
          </ProviderCard>
        </div>
        <div className="pay-disclosure">
          <CircleAlert size={16} />
          <p>
            Configured credentials do not verify a bank account or guarantee
            merchant approval. Cards, wallets, local methods, currency
            conversion, fees, and settlement depend on each provider’s
            eligibility and settings.
          </p>
        </div>

        <section className="pay-bank-section">
          <div className="pay-section-heading">
            <div>
              <span className="pay-kicker">02 / DIRECT BANK TRANSFERS</span>
              <h2>The details that bring funds home.</h2>
            </div>
            <span className="pay-small-tag">
              {data.bank.version
                ? `Instructions version ${data.bank.version}`
                : "Instructions not published"}
            </span>
          </div>
          <div className="pay-bank-card">
            <aside>
              <span className="pay-bank-symbol">
                <Landmark size={29} />
              </span>
              <h3>Your receiving account.</h3>
              <p>
                These instructions appear at bank transfer checkout. Use an
                account permitted to receive USD international payments for RTR
                Digital.
              </p>
              <Switch
                name="bank.enabled"
                enabled={Boolean(data.bank.enabled)}
                label="Offer bank transfer"
              />
              <div className="pay-snapshot-note">
                <ShieldCheck size={17} />
                <p>
                  Pending transfers keep the bank instructions saved when the
                  order was created. Changes apply to new orders.
                </p>
              </div>
              <button
                type="button"
                className="btn btn-outline"
                disabled={Boolean(busy)}
                onClick={(event) => void revealBank(event.currentTarget.form)}
              >
                {revealedBank
                  ? "Hide saved bank details"
                  : "Reveal saved bank details"}
              </button>
              <p>
                Enter your administrator password in the save bar to reveal the
                saved account. Details hide after one minute.
              </p>
              {revealedBank && (
                <dl
                  className="pay-bank-reveal"
                  aria-label="Saved receiving account"
                >
                  {(["accountNumber", "iban", "routingNumber"] as const)
                    .filter((name) => revealedBank[name])
                    .map((name) => (
                      <div key={name}>
                        <dt>
                          {name === "accountNumber"
                            ? "Account number"
                            : name === "iban"
                              ? "IBAN"
                              : "Routing number"}
                        </dt>
                        <dd>{revealedBank[name]}</dd>
                      </div>
                    ))}
                </dl>
              )}
              <label className="pay-remove-option">
                <input type="checkbox" name="bank.remove" /> Remove saved
                receiving account and disable bank checkout when I save
              </label>
            </aside>
            <div className="pay-bank-fields">
              <div className="pay-fields pay-fields-two">
                <Field
                  label="Beneficiary / account holder"
                  name="bank.beneficiary"
                  initial={data.bank.beneficiary}
                  placeholder="Registered beneficiary name"
                />
                <Field
                  label="Bank name"
                  name="bank.bankName"
                  initial={data.bank.bankName}
                  placeholder="Receiving bank"
                />
                <Field
                  label="Account number"
                  name="bank.accountNumber"
                  secret
                  placeholder={
                    data.bank.accountNumber || "Enter receiving account number"
                  }
                  help="Leave blank to keep the saved account number."
                />
                <Field
                  label="SWIFT / BIC"
                  name="bank.swift"
                  initial={data.bank.swift}
                  placeholder="International SWIFT / BIC"
                />
                <Field
                  label="IFSC"
                  name="bank.ifsc"
                  initial={data.bank.ifsc}
                  placeholder="For an Indian receiving account"
                />
                <Field
                  label="IBAN (if applicable)"
                  name="bank.iban"
                  secret
                  placeholder={data.bank.iban || "Enter IBAN"}
                  help="Leave blank to keep the saved IBAN."
                />
                <Field
                  label="Routing number (if applicable)"
                  name="bank.routingNumber"
                  secret
                  placeholder={
                    data.bank.routingNumber || "Enter routing number"
                  }
                  help="Leave blank to keep the saved routing number."
                />
                <Field
                  label="Intermediary / correspondent bank"
                  name="bank.intermediaryBank"
                  initial={data.bank.intermediaryBank}
                  placeholder="Bank, SWIFT, and any routing details"
                />
                <Field
                  label="Bank address"
                  name="bank.bankAddress"
                  initial={data.bank.bankAddress}
                  multiline
                  placeholder="Branch address, city, country, postal code"
                />
                <Field
                  label="Beneficiary address"
                  name="bank.beneficiaryAddress"
                  initial={data.bank.beneficiaryAddress}
                  multiline
                  placeholder="Registered address associated with the account"
                />
                <Field
                  label="Additional transfer instructions"
                  name="bank.instructions"
                  initial={data.bank.instructions}
                  multiline
                  placeholder="Reference requirements, fee instructions, or bank-specific details"
                />
              </div>
            </div>
          </div>
        </section>
        <div className="pay-save-bar">
          <div>
            <span className="pay-save-icon">
              <LockKeyhole size={19} />
            </span>
            <div>
              <strong>Review. Verify. Save.</strong>
              <p>Saving changes checkout settings and bank instructions.</p>
            </div>
          </div>
          <PasswordField />
          <button
            className="btn btn-primary"
            disabled={Boolean(busy) || loading}
          >
            {busy === "settings" ? (
              <LoaderCircle size={15} className="spin" />
            ) : (
              <Check size={16} />
            )}
            Save payment settings
          </button>
        </div>
        {saveError && (
          <div className="co-inline-error" role="alert">
            {saveError}
          </div>
        )}
      </form>

      <section className="pay-reconciliation">
        <div className="pay-section-heading">
          <div>
            <span className="pay-kicker">03 / BANK RECONCILIATION</span>
            <h2>Clear funds. Then grant access.</h2>
            <p>
              A customer’s payment report is a claim. Match cleared USD funds in
              your bank before confirming an order.
            </p>
          </div>
          <span className="pay-queue-count">
            {transfers.length} awaiting review
          </span>
        </div>
        {transfers.length ? (
          <div className="pay-transfer-list">
            {transfers.map((transfer) => {
              const selected = review?.id === transfer.id;
              const reportedReference = transfer.customerReference;
              const reported = Boolean(
                reportedReference || /reported/.test(transfer.status),
              );
              const expired = Boolean(
                transfer.expiresAt &&
                Date.parse(transfer.expiresAt) <= Date.now(),
              );
              return (
                <article className="pay-transfer" key={transfer.id}>
                  <header>
                    <span className="pay-transfer-icon">
                      <ArrowDownLeft size={22} />
                    </span>
                    <div className="pay-transfer-main">
                      <div>
                        <h3>
                          {transfer.customerName || "Bank transfer order"}
                        </h3>
                        <span
                          className={`pay-status ${reported ? "reported" : ""}`}
                        >
                          <i />
                          {expired
                            ? "Expired · manual review"
                            : reported
                              ? "Customer reported payment"
                              : readable(transfer.status)}
                        </span>
                      </div>
                      <p>
                        {transfer.customerEmail && (
                          <>{transfer.customerEmail} · </>
                        )}
                        {date(transfer.createdAt)}
                      </p>
                      <code>{transfer.id}</code>
                    </div>
                    <div className="pay-transfer-amount">
                      <strong>{money(transfer.total)}</strong>
                      <span>USD expected</span>
                    </div>
                    <button
                      type="button"
                      className="btn btn-outline"
                      disabled={Boolean(busy)}
                      onClick={() => {
                        setReview(
                          selected
                            ? null
                            : {
                                id: transfer.id,
                                action: expired ? "reject" : "confirm",
                              },
                        );
                        setReviewError("");
                      }}
                    >
                      {selected ? "Close review" : "Review transfer"}
                      {selected ? <X size={14} /> : <ArrowUpRight size={14} />}
                    </button>
                  </header>
                  <dl className="pay-transfer-meta">
                    <div>
                      <dt>Order reference</dt>
                      <dd>{transfer.reference || transfer.id}</dd>
                    </div>
                    <div>
                      <dt>Original receiving account</dt>
                      <dd>
                        {transfer.bank?.bankName ||
                          "See order bank instructions"}
                        {transfer.bank?.accountLast4
                          ? ` · •••• ${transfer.bank.accountLast4}`
                          : transfer.bank?.ibanLast4
                            ? ` · IBAN •••• ${transfer.bank.ibanLast4}`
                            : ""}
                        {transfer.bank?.version || transfer.bankVersion
                          ? ` · v${transfer.bank?.version || transfer.bankVersion}`
                          : ""}
                      </dd>
                    </div>
                    {reportedReference && (
                      <div>
                        <dt>Customer-supplied reference · unverified</dt>
                        <dd>{reportedReference}</dd>
                      </div>
                    )}
                    {transfer.expiresAt && (
                      <div>
                        <dt>Transfer deadline</dt>
                        <dd>{date(transfer.expiresAt)}</dd>
                      </div>
                    )}
                  </dl>
                  {transfer.customerNote && (
                    <p className="pay-customer-note">
                      Customer note: {transfer.customerNote}
                    </p>
                  )}
                  {expired && (
                    <p className="pay-expired-note">
                      This order’s transfer deadline has passed. Reconcile any
                      late funds directly with the customer; this order cannot
                      grant access automatically.
                    </p>
                  )}
                  {selected && review && (
                    <form
                      className="pay-review-form"
                      onSubmit={(event) => void reconcile(event, transfer)}
                    >
                      <div className="pay-review-heading">
                        <h4>
                          {review.action === "confirm"
                            ? "Confirm a cleared payment"
                            : "Reject this transfer"}
                        </h4>
                        {!expired && (
                          <button
                            type="button"
                            className="pay-text-button"
                            onClick={() => {
                              setReview({
                                id: transfer.id,
                                action:
                                  review.action === "confirm"
                                    ? "reject"
                                    : "confirm",
                              });
                              setReviewError("");
                            }}
                          >
                            {review.action === "confirm"
                              ? "Reject transfer instead"
                              : "Return to confirmation"}
                          </button>
                        )}
                      </div>
                      {review.action === "confirm" ? (
                        <>
                          <p>
                            Use the bank’s statement reference. Each reference
                            can confirm only one order. The received amount must
                            match {money(transfer.total)} USD.
                          </p>
                          <div className="pay-fields pay-review-fields">
                            <label className="pay-field">
                              <span>Cleared amount received (USD)</span>
                              <input
                                name="receivedAmount"
                                type="number"
                                step="0.01"
                                min="0.01"
                                required
                                placeholder={transfer.total.toFixed(2)}
                                inputMode="decimal"
                              />
                            </label>
                            <label className="pay-field">
                              <span>Unique bank statement reference</span>
                              <input
                                name="bankReference"
                                required
                                minLength={3}
                                maxLength={200}
                                autoComplete="off"
                                placeholder="Reference from your bank statement"
                              />
                            </label>
                            <PasswordField />
                          </div>
                          <label className="pay-verify-checkbox">
                            <input type="checkbox" name="cleared" required />
                            <span>
                              I checked RTR Digital’s bank statement and
                              verified that this exact USD amount has cleared
                              into the original receiving account.
                            </span>
                          </label>
                          {sharedDemo && (
                            <p className="pay-refund-demo-note">
                              This shared development demo records a simulated
                              order and does not grant live purchase access.
                            </p>
                          )}
                        </>
                      ) : (
                        <>
                          <p>
                            This records a rejection and keeps the order unpaid.
                          </p>
                          <div className="pay-fields pay-review-fields">
                            <Field
                              label="Reason / note (optional)"
                              name="note"
                              multiline
                              placeholder="Record why this transfer cannot be accepted"
                            />
                            <PasswordField />
                          </div>
                        </>
                      )}
                      {reviewError && (
                        <div className="co-inline-error" role="alert">
                          {reviewError}
                        </div>
                      )}
                      <div className="pay-review-actions">
                        <button
                          type="button"
                          className="btn btn-outline"
                          onClick={() => setReview(null)}
                          disabled={Boolean(busy)}
                        >
                          Cancel
                        </button>
                        <button
                          className={`btn ${review.action === "confirm" ? "btn-primary" : "btn-outline pay-reject"}`}
                          disabled={
                            Boolean(busy) ||
                            (review.action === "confirm" && expired)
                          }
                        >
                          {busy === transfer.id ? (
                            <LoaderCircle size={15} className="spin" />
                          ) : review.action === "confirm" ? (
                            <CheckCheck size={16} />
                          ) : (
                            <X size={16} />
                          )}
                          {review.action === "confirm"
                            ? sharedDemo
                              ? "Record demo cleared payment"
                              : "Confirm cleared payment & grant access"
                            : "Reject transfer"}
                        </button>
                      </div>
                    </form>
                  )}
                </article>
              );
            })}
          </div>
        ) : (
          <div className="pay-empty">
            <span>
              <CheckCheck size={29} />
            </span>
            <div>
              <h3>Everything is accounted for.</h3>
              <p>
                Pending bank transfer orders will appear here for your review.
              </p>
            </div>
          </div>
        )}
      </section>
    </div>
  );
}
