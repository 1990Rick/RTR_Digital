import { useEffect, useMemo, useRef, useState } from "react";
import type { CSSProperties, FormEvent, PointerEvent } from "react";
import {
  ArrowDown,
  ArrowRight,
  ArrowUpRight,
  AudioLines,
  BookOpen,
  Check,
  ChevronLeft,
  ChevronRight,
  Code2,
  Command,
  Download,
  Film,
  Grid2X2,
  LayoutTemplate,
  MousePointer2,
  Palette,
  Pause,
  Play,
  Search,
  ShieldCheck,
  SlidersHorizontal,
  Sparkles,
  Zap,
} from "lucide-react";
import type { CatalogProps } from "./Storefront";
import { ProductCard } from "./Storefront";
import { money } from "../lib/api";

const categories = [
  { name: "All products", icon: Grid2X2 },
  { name: "Design assets", icon: Palette },
  { name: "E-books", icon: BookOpen },
  { name: "Audio & music", icon: AudioLines },
  { name: "Courses", icon: Sparkles },
  { name: "Software", icon: Code2 },
  { name: "Templates", icon: LayoutTemplate },
  { name: "Video", icon: Film },
];
const scenes = [
  {
    name: "Design",
    category: "Design assets",
    label: "A fresh perspective.",
    number: "01",
  },
  {
    name: "Listen",
    category: "Audio & music",
    label: "Find your frequency.",
    number: "02",
  },
  {
    name: "Build",
    category: "Software",
    label: "Ideas into action.",
    number: "03",
  },
];
const plans = [
  {
    name: "Explorer",
    monthly: 9,
    yearly: 84,
    description: "For a curious mind.",
    feature: "Included digital products",
  },
  {
    name: "Creator",
    monthly: 19,
    yearly: 180,
    description: "For your next big thing.",
    feature: "Included digital products",
  },
  {
    name: "Studio",
    monthly: 39,
    yearly: 372,
    description: "For making it together.",
    feature: "A workspace for 5 people",
  },
];

function StudioAsterisk() {
  return (
    <svg viewBox="-50 -50 100 100" aria-hidden="true">
      {[0, 45, 90, 135].map((angle) => (
        <rect
          key={angle}
          x="-5"
          y="-45"
          width="10"
          height="90"
          rx="5"
          transform={`rotate(${angle})`}
        />
      ))}
    </svg>
  );
}

type StudioHomeProps = CatalogProps & { onSearch?: (query: string) => void };

export function HomePage(props: StudioHomeProps) {
  const [sceneIndex, setSceneIndex] = useState(0);
  const [reducedMotion, setReducedMotion] = useState(
    () => window.matchMedia("(prefers-reduced-motion: reduce)").matches,
  );
  const [autoPlay, setAutoPlay] = useState(
    () => !window.matchMedia("(prefers-reduced-motion: reduce)").matches,
  );
  const [stageHovered, setStageHovered] = useState(false);
  const [stageFocused, setStageFocused] = useState(false);
  const [pageVisible, setPageVisible] = useState(() => !document.hidden);
  const [activeCategory, setActiveCategory] = useState("All products");
  const [sort, setSort] = useState("Curated picks");
  const [offset, setOffset] = useState(0);
  const [yearly, setYearly] = useState(false);
  const [query, setQuery] = useState("");
  const stageRef = useRef<HTMLDivElement>(null);
  useEffect(() => {
    const preference = window.matchMedia("(prefers-reduced-motion: reduce)");
    const updatePreference = () => {
      setReducedMotion(preference.matches);
      if (preference.matches) setAutoPlay(false);
    };
    const updateVisibility = () => setPageVisible(!document.hidden);
    preference.addEventListener("change", updatePreference);
    document.addEventListener("visibilitychange", updateVisibility);
    return () => {
      preference.removeEventListener("change", updatePreference);
      document.removeEventListener("visibilitychange", updateVisibility);
    };
  }, []);

  useEffect(() => {
    if (
      !autoPlay ||
      reducedMotion ||
      stageHovered ||
      stageFocused ||
      !pageVisible
    )
      return;
    const interval = window.setInterval(
      () => setSceneIndex((index) => (index + 1) % scenes.length),
      8000,
    );
    return () => window.clearInterval(interval);
  }, [autoPlay, reducedMotion, stageHovered, stageFocused, pageVisible]);

  const scene = scenes[sceneIndex];
  const spotlight =
    props.products.find((product) => product.category === scene.category) ??
    props.products[sceneIndex % Math.max(1, props.products.length)];
  const items = useMemo(() => {
    const filtered = props.products.filter(
      (product) =>
        activeCategory === "All products" ||
        product.category === activeCategory,
    );
    if (sort === "Price: low to high")
      return [...filtered].sort((a, b) => a.price - b.price);
    if (sort === "New arrivals") return [...filtered].reverse();
    return [...filtered].sort(
      (a, b) => Number(Boolean(b.featured)) - Number(Boolean(a.featured)),
    );
  }, [props.products, activeCategory, sort]);
  const shown = items.slice(offset, offset + 4);

  function moveSpotlight(event: PointerEvent<HTMLDivElement>) {
    if (
      event.pointerType !== "mouse" ||
      window.matchMedia("(prefers-reduced-motion: reduce)").matches
    )
      return;
    const bounds = event.currentTarget.getBoundingClientRect();
    const x = (event.clientX - bounds.left) / bounds.width;
    const y = (event.clientY - bounds.top) / bounds.height;
    event.currentTarget.style.setProperty(
      "--studio-move-x",
      `${(x - 0.5) * 9}px`,
    );
    event.currentTarget.style.setProperty(
      "--studio-move-y",
      `${(y - 0.5) * 9}px`,
    );
    event.currentTarget.style.setProperty("--studio-pointer-x", `${x * 100}%`);
    event.currentTarget.style.setProperty("--studio-pointer-y", `${y * 100}%`);
  }

  function resetSpotlight() {
    stageRef.current?.style.setProperty("--studio-move-x", "0px");
    stageRef.current?.style.setProperty("--studio-move-y", "0px");
  }

  function search(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (props.onSearch && query.trim()) props.onSearch(query.trim());
    else props.onExplore();
  }

  return (
    <div className="studio-home">
      <section
        className="studio-hero studio-wrap"
        aria-labelledby="studio-hero-title"
      >
        <div className="studio-hero-copy">
          <div className="studio-eyebrow">
            <span className="studio-status-dot" /> THE DIGITAL GOOD STUFF.
          </div>
          <h1 id="studio-hero-title">
            Your next
            <br />
            big idea.
            <br />
            <span>Starts here.</span>
            <span className="studio-title-star" aria-hidden="true">
              <StudioAsterisk />
            </span>
          </h1>
          <p className="studio-hero-description">
            Distinctive assets. Useful tools. Fresh perspectives.
            <br className="studio-desktop-break" /> Digital finds for whatever
            you’re making next.
          </p>
          <div className="studio-hero-actions">
            <button
              className="studio-button studio-button-dark"
              onClick={() => props.onExplore()}
            >
              Find your next thing <ArrowUpRight size={19} />
            </button>
            <a className="studio-quiet-link" href="#studio-discover">
              Take a look around <ArrowDown size={16} />
            </a>
          </div>
          <form className="studio-search" role="search" onSubmit={search}>
            <Search size={18} aria-hidden="true" />
            <input
              value={query}
              onChange={(event) => setQuery(event.target.value)}
              aria-label="Search digital products"
              placeholder="What are you working on?"
            />
            <button type="submit" aria-label="Search digital collection">
              <ArrowRight size={19} />
            </button>
          </form>
          <div className="studio-search-suggestions">
            <span>A little inspiration:</span>
            <button onClick={() => props.onExplore("Templates")}>
              Templates
            </button>
            <button onClick={() => props.onExplore("Audio & music")}>
              Soundtracks
            </button>
            <button onClick={() => props.onExplore("Design assets")}>
              Brand kits
            </button>
          </div>
        </div>
        <div
          className="studio-visual-shell"
          onPointerEnter={(event) => {
            if (event.pointerType === "mouse") setStageHovered(true);
          }}
          onPointerLeave={() => setStageHovered(false)}
          onFocusCapture={() => setStageFocused(true)}
          onBlurCapture={(event) => {
            if (
              !event.currentTarget.contains(event.relatedTarget as Node | null)
            )
              setStageFocused(false);
          }}
        >
          <div
            className="studio-stage"
            data-scene={sceneIndex}
            ref={stageRef}
            onPointerMove={moveSpotlight}
            onPointerLeave={resetSpotlight}
          >
            <div className="studio-stage-header">
              <span>
                <span /> THE CREATIVE PLAYGROUND
              </span>
              <div className="studio-stage-controls">
                <button
                  className="studio-autoplay"
                  disabled={reducedMotion}
                  onClick={() => setAutoPlay((playing) => !playing)}
                  aria-label={
                    reducedMotion
                      ? "Automatic showcase disabled for reduced motion"
                      : autoPlay
                        ? "Pause showcase"
                        : "Play showcase"
                  }
                  title={
                    reducedMotion
                      ? "Respects your reduced motion preference"
                      : autoPlay
                        ? "Pause automatic scene changes"
                        : "Resume automatic scene changes"
                  }
                >
                  {autoPlay && !reducedMotion ? (
                    <Pause size={9} />
                  ) : (
                    <Play size={9} />
                  )}
                  <span>
                    {reducedMotion ? "Still" : autoPlay ? "Pause" : "Play"}
                  </span>
                </button>
                <span>{scene.number} / 03</span>
              </div>
            </div>
            <div className="studio-scene" key={sceneIndex}>
              {sceneIndex === 0 && (
                <div className="studio-design-scene">
                  <img
                    src="/images/rtr-digital-signal-hero.webp"
                    alt="A chrome ribbon, cobalt glass arch, chartreuse book and vinyl record arranged on sculptural ivory plinths."
                    fetchPriority="high"
                  />
                  <div className="studio-design-word" aria-hidden="true">
                    MAKE
                    <br />
                    <span>it happen.</span>
                  </div>
                  <div className="studio-design-stamp" aria-hidden="true">
                    <span>
                      INFINITE
                      <br />
                      POSSIBILITY
                    </span>
                    <ArrowUpRight size={25} />
                  </div>
                </div>
              )}
              {sceneIndex === 1 && (
                <div className="studio-audio-scene">
                  <div className="studio-audio-orbit" aria-hidden="true" />
                  <div className="studio-record" aria-hidden="true">
                    <div>
                      <AudioLines size={40} />
                      <span>
                        RTR DIGITAL
                        <br />
                        VOLUME 001
                      </span>
                    </div>
                  </div>
                  <div className="studio-audio-copy">
                    <span>GOOD THINGS SOUND DIFFERENT.</span>
                    <strong>
                      Set the
                      <br />
                      <em>frequency.</em>
                    </strong>
                    <div className="studio-waveform" aria-hidden="true">
                      {Array.from({ length: 33 }, (_, i) => (
                        <i
                          key={i}
                          style={
                            {
                              "--bar-height": `${12 + Math.abs(Math.sin(i * 1.4)) * 36}px`,
                              "--bar-delay": `${i * -0.07}s`,
                            } as CSSProperties
                          }
                        />
                      ))}
                    </div>
                  </div>
                </div>
              )}
              {sceneIndex === 2 && (
                <div className="studio-build-scene">
                  <div className="studio-build-grid" aria-hidden="true" />
                  <div className="studio-code-window">
                    <div className="studio-code-toolbar">
                      <span>
                        <i />
                        <i />
                        <i />
                      </span>
                      <span>next-big-idea.js</span>
                      <Command size={14} />
                    </div>
                    <div className="studio-code-body">
                      <span className="studio-code-comment">
                        // Make something that matters.
                      </span>
                      <p>
                        <em>const</em> nextBigIdea = &#123;
                      </p>
                      <p>
                        &nbsp;&nbsp;inspiration: <b>"unlimited"</b>,
                      </p>
                      <p>
                        &nbsp;&nbsp;possibilities: <b>Infinity</b>,
                      </p>
                      <p>
                        &nbsp;&nbsp;readyToCreate: <b>true</b>
                      </p>
                      <p>&#125;;</p>
                      <span className="studio-code-result">
                        <Check size={13} /> Ready when you are.
                      </span>
                    </div>
                  </div>
                  <div className="studio-build-label">
                    <span>
                      LESS SETUP.
                      <br />
                      <strong>More doing.</strong>
                    </span>
                    <div aria-hidden="true">
                      <Code2 size={40} />
                    </div>
                  </div>
                  <span className="studio-code-pointer" aria-hidden="true">
                    <MousePointer2 size={26} fill="currentColor" />
                    <small>You, building something great.</small>
                  </span>
                </div>
              )}
            </div>
            <div className="studio-stage-bottom">
              <div
                className="studio-scene-tabs"
                aria-label="Explore a creative discipline"
              >
                {scenes.map((item, index) => (
                  <button
                    key={item.name}
                    className={sceneIndex === index ? "is-active" : ""}
                    onClick={() => {
                      setSceneIndex(index);
                      setAutoPlay(false);
                    }}
                    aria-pressed={sceneIndex === index}
                  >
                    {item.name}
                    {index === sceneIndex && <ArrowUpRight size={14} />}
                  </button>
                ))}
              </div>
              <span className="studio-scene-caption">{scene.label}</span>
            </div>
          </div>
          <button
            className="studio-spotlight"
            onClick={() =>
              spotlight
                ? props.onProduct(spotlight)
                : props.onExplore(scene.category)
            }
          >
            <span className="studio-spotlight-icon">
              {sceneIndex === 0 ? (
                <Palette size={20} />
              ) : sceneIndex === 1 ? (
                <AudioLines size={20} />
              ) : (
                <Code2 size={20} />
              )}
            </span>
            <span className="studio-spotlight-copy">
              <small>
                {spotlight
                  ? "YOUR NEXT GREAT FIND"
                  : "EXPLORE THE POSSIBILITIES"}
              </small>
              <strong>{spotlight?.title ?? scene.category}</strong>
            </span>
            {spotlight && (
              <span className="studio-spotlight-price">
                {money(spotlight.price)}
              </span>
            )}
            <span className="studio-spotlight-arrow">
              <ArrowUpRight size={21} />
            </span>
          </button>
          <div className="studio-stage-footnote">
            <span>TOOLS FOR THE WAY YOU THINK.</span>
            <span>MADE FOR YOUR NEXT.</span>
          </div>
        </div>
      </section>
      <div className="studio-benefits studio-wrap" aria-label="The essentials">
        <span className="studio-benefits-intro">
          Good ideas deserve good tools.
        </span>
        <span>
          <Download size={16} /> Instant digital delivery
        </span>
        <span>
          <ShieldCheck size={16} /> Clear product licenses
        </span>
        <span>
          <Zap size={16} /> Ready for your workflow
        </span>
      </div>

      <section
        className="studio-discover studio-wrap"
        id="studio-discover"
        aria-labelledby="studio-discover-title"
      >
        <div className="studio-section-heading">
          <div>
            <span className="studio-eyebrow">01 / THE COLLECTION</span>
            <h2 id="studio-discover-title">
              A better place to start<span>.</span>
            </h2>
          </div>
          <button
            className="studio-text-link"
            onClick={() => props.onExplore()}
          >
            Explore all products <ArrowUpRight size={19} />
          </button>
        </div>
        <div
          className="studio-categories"
          aria-label="Filter products by category"
        >
          {categories.map(({ name, icon: Icon }) => (
            <button
              key={name}
              onClick={() => {
                setActiveCategory(name);
                setOffset(0);
              }}
              className={activeCategory === name ? "is-active" : ""}
              aria-pressed={activeCategory === name}
            >
              <Icon size={16} />
              {name}
            </button>
          ))}
        </div>
        <div className="studio-catalog-toolbar">
          <div className="studio-sort-tabs" aria-label="Sort products">
            {["Curated picks", "New arrivals", "Price: low to high"].map(
              (item) => (
                <button
                  key={item}
                  className={sort === item ? "is-active" : ""}
                  aria-pressed={sort === item}
                  onClick={() => {
                    setSort(item);
                    setOffset(0);
                  }}
                >
                  {item}
                </button>
              ),
            )}
          </div>
          <span>
            <SlidersHorizontal size={14} /> A little less ordinary.
          </span>
        </div>
        <div className="studio-product-grid">
          {shown.map((product) => (
            <ProductCard
              key={product.id}
              product={product}
              wished={props.wishlist.includes(product.id)}
              onWish={() => props.onWish(product)}
              onProduct={() => props.onProduct(product)}
            />
          ))}
        </div>
        {items.length === 0 && (
          <div className="studio-empty">
            <Sparkles size={28} />
            <h3>Something good is on its way.</h3>
            <p>Try another category to find your next starting point.</p>
            <button
              className="studio-text-link"
              onClick={() => {
                setActiveCategory("All products");
                setOffset(0);
              }}
            >
              See all products <ArrowRight size={16} />
            </button>
          </div>
        )}
        <div className="studio-catalog-bottom">
          <span>
            {items.length > 0
              ? `${offset + 1}–${Math.min(offset + 4, items.length)} of ${items.length} good finds`
              : "A fresh perspective is one click away."}
          </span>
          <div>
            <button
              className="studio-round-button"
              aria-label="Previous products"
              disabled={offset === 0}
              onClick={() => setOffset(Math.max(0, offset - 4))}
            >
              <ChevronLeft size={18} />
            </button>
            <button
              className="studio-round-button"
              aria-label="Next products"
              disabled={offset + 4 >= items.length}
              onClick={() => setOffset(offset + 4)}
            >
              <ChevronRight size={18} />
            </button>
          </div>
        </div>
      </section>

      <section
        className="studio-collections studio-wrap"
        aria-labelledby="studio-collections-title"
      >
        <div className="studio-section-heading">
          <div>
            <span className="studio-eyebrow">02 / FOLLOW YOUR CURIOSITY</span>
            <h2 id="studio-collections-title">
              Pick a direction. Find your thing.
            </h2>
          </div>
          <button className="studio-text-link" onClick={props.onCollection}>
            All collections <ArrowUpRight size={19} />
          </button>
        </div>
        <div className="studio-collection-grid">
          <button
            className="studio-collection studio-collection-design"
            onClick={() => props.onExplore("Design assets")}
          >
            <div className="studio-collection-top">
              <span>FOR THE VISUAL THINKERS</span>
              <ArrowUpRight size={23} />
            </div>
            <div className="studio-collection-art" aria-hidden="true">
              <span className="studio-type-sheet">
                Aa
                <span>
                  Every idea
                  <br />
                  has a shape.
                </span>
              </span>
              <span className="studio-color-sheet">
                <span />
                <span />
                <span />
              </span>
              <span className="studio-collection-flower">
                <StudioAsterisk />
              </span>
            </div>
            <div className="studio-collection-copy">
              <h3>Make your mark.</h3>
              <p>Design assets with a point of view.</p>
              <span>
                Explore design <ArrowRight size={17} />
              </span>
            </div>
          </button>
          <button
            className="studio-collection studio-collection-audio"
            onClick={() => props.onExplore("Audio & music")}
          >
            <div className="studio-collection-top">
              <span>FOR THE DEEP-FOCUS DAYS</span>
              <ArrowUpRight size={23} />
            </div>
            <div className="studio-collection-sound" aria-hidden="true">
              <div />
              <div />
              <div />
              <div />
              <div />
              <div />
              <div />
              <div />
              <div />
            </div>
            <div className="studio-collection-copy">
              <h3>Find your flow.</h3>
              <p>A soundtrack for the work you love.</p>
              <span>
                Explore audio <ArrowRight size={17} />
              </span>
            </div>
          </button>
          <button
            className="studio-collection studio-collection-template"
            onClick={() => props.onExplore("Templates")}
          >
            <div className="studio-collection-top">
              <span>FOR THE DOERS & DREAMERS</span>
              <ArrowUpRight size={23} />
            </div>
            <div className="studio-collection-browser" aria-hidden="true">
              <div>
                <i />
                <i />
                <i />
              </div>
              <span>
                YOUR NEXT
                <br />
                <strong>starts now.</strong>
              </span>
              <div>
                <i />
                <i />
                <i />
              </div>
            </div>
            <div className="studio-collection-copy">
              <h3>Skip the blank page.</h3>
              <p>Smart templates. A running start.</p>
              <span>
                Explore templates <ArrowRight size={17} />
              </span>
            </div>
          </button>
        </div>
      </section>

      <section
        className="studio-membership"
        aria-labelledby="studio-membership-title"
      >
        <div className="studio-wrap">
          <div className="studio-membership-top">
            <div>
              <span className="studio-eyebrow">
                <span className="studio-status-dot" /> THE RTR DIGITAL PASS
              </span>
              <h2 id="studio-membership-title">
                More possibilities.
                <br />
                <span>One good decision.</span>
              </h2>
              <p>
                Keep your next idea within reach. Get access to
                <br className="studio-desktop-break" /> included products with a
                plan that fits your flow.
              </p>
            </div>
            <div className="studio-billing">
              <span>YOUR IDEAS DON’T HAVE AN OFF SEASON.</span>
              <div role="group" aria-label="Membership billing interval">
                <button
                  aria-pressed={!yearly}
                  className={!yearly ? "is-active" : ""}
                  onClick={() => setYearly(false)}
                >
                  Monthly
                </button>
                <button
                  aria-pressed={yearly}
                  className={yearly ? "is-active" : ""}
                  onClick={() => setYearly(true)}
                >
                  Yearly <span>Save up to 22%</span>
                </button>
              </div>
              <small>
                {yearly
                  ? "One payment. A full year of possibility."
                  : "A little room for your next big thing."}
              </small>
            </div>
          </div>
          <div className="studio-plan-grid">
            {plans.map((plan, index) => (
              <div
                className={`studio-plan ${index === 1 ? "studio-plan-featured" : ""}`}
                key={plan.name}
              >
                <div className="studio-plan-heading">
                  <span>{plan.name}</span>
                  <span>
                    {index === 1 ? "THE CREATIVE SWEET SPOT" : `0${index + 1}`}
                  </span>
                </div>
                <p>{plan.description}</p>
                <div className="studio-plan-price">
                  <strong>${yearly ? plan.yearly : plan.monthly}</strong>
                  <span>/ {yearly ? "year" : "month"}</span>
                </div>
                <div className="studio-plan-feature">
                  <Check size={14} />
                  {plan.feature}
                </div>
                <button onClick={props.onMembership}>
                  Explore {plan.name} <ArrowUpRight size={18} />
                </button>
              </div>
            ))}
          </div>
          <div className="studio-membership-bottom">
            <span>
              <ShieldCheck size={14} /> Choose your plan and review the details
              before checkout.
            </span>
            <button onClick={props.onMembership}>
              Compare the plans <ArrowRight size={16} />
            </button>
          </div>
        </div>
      </section>

      <section
        className="studio-how studio-wrap"
        aria-labelledby="studio-how-title"
      >
        <div className="studio-how-intro">
          <span className="studio-eyebrow">LESS FRICTION. MORE MOMENTUM.</span>
          <h2 id="studio-how-title">
            From “what if”
            <br />
            to what’s next
            <ArrowUpRight aria-hidden="true" />
          </h2>
        </div>
        <div className="studio-how-steps">
          <div>
            <span>01</span>
            <div>
              <h3>Find your spark.</h3>
              <p>
                Browse the collection. Check the previews, formats and license
                to find your fit.
              </p>
            </div>
          </div>
          <div>
            <span>02</span>
            <div>
              <h3>Make it yours.</h3>
              <p>
                Buy a one-time favorite or unlock included products with a
                Digital Pass.
              </p>
            </div>
          </div>
          <div>
            <span>03</span>
            <div>
              <h3>Get straight to it.</h3>
              <p>
                Your digital products live in your library, ready to download
                when you are.
              </p>
            </div>
          </div>
        </div>
      </section>
      <div className="studio-last-word studio-wrap">
        <span>GOOD THINGS START WITH A LITTLE CURIOSITY.</span>
        <button onClick={() => props.onExplore()}>
          What’s your next?
          <ArrowUpRight aria-hidden="true" />
        </button>
      </div>
    </div>
  );
}
