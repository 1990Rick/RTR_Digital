import { useEffect, useMemo, useRef, useState } from "react";
import {
  ArrowDown,
  ArrowRight,
  ArrowUpRight,
  Check,
  Globe2,
  MoveUpRight,
  Plus,
  X,
} from "lucide-react";
import type { CatalogProps } from "./Storefront";
import { categoryList, ProductCard } from "./Storefront";
import type { Product } from "../lib/types";

const edits = [
  {
    id: "design",
    number: "01",
    eyebrow: "FOR A STRONG FIRST IMPRESSION",
    title: "Make your mark.",
    description: "A considered starting point for your next visual identity.",
    categories: ["Design assets"],
    label: "The design edit",
  },
  {
    id: "learn",
    number: "02",
    eyebrow: "FOR A DIFFERENT PERSPECTIVE",
    title: "Stay a little curious.",
    description: "Fresh thinking. Practical knowledge. Something to build on.",
    categories: ["E-books", "Courses"],
    label: "The learning edit",
  },
  {
    id: "sound",
    number: "03",
    eyebrow: "FOR THE RIGHT ATMOSPHERE",
    title: "Set the frequency.",
    description: "Sound and music to give your next project its own world.",
    categories: ["Audio & music"],
    label: "The audio edit",
  },
  {
    id: "build",
    number: "04",
    eyebrow: "FOR MAKING IT HAPPEN",
    title: "Get a head start.",
    description: "Useful software and templates that move an idea forward.",
    categories: ["Software", "Templates"],
    label: "The building edit",
  },
] as const;

function useEditorialReveal() {
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    if (
      !ref.current ||
      !window.IntersectionObserver ||
      window.matchMedia("(prefers-reduced-motion: reduce)").matches
    )
      return;
    const nodes = ref.current.querySelectorAll<HTMLElement>("[data-se-reveal]");
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (!entry.isIntersecting) return;
          (entry.target as HTMLElement).dataset.seVisible = "true";
          observer.unobserve(entry.target);
        });
      },
      { threshold: 0.08, rootMargin: "0px 0px 40px 0px" },
    );
    nodes.forEach((node) => {
      node.dataset.seReady = "true";
      observer.observe(node);
    });
    return () => observer.disconnect();
  }, []);
  return ref;
}

function EditArtwork({ kind }: { kind: (typeof edits)[number]["id"] }) {
  return (
    <div className={`se-edit-art se-edit-art-${kind}`} aria-hidden="true">
      {kind === "design" && (
        <>
          <div className="se-design-sheet">
            <span>
              FORM
              <br />& FEEL.
            </span>
            <div>
              <i />
              <i />
              <i />
              <i />
            </div>
            <small>A DIFFERENT KIND OF IDENTITY</small>
          </div>
          <div className="se-type-sheet">
            <span>Aa</span>
            <small>
              TYPE WITH
              <br />
              CHARACTER.
            </small>
          </div>
          <span className="se-design-dot" />
        </>
      )}
      {kind === "learn" && (
        <>
          <span className="se-learn-circle" />
          <div className="se-book se-book-back">
            <span>
              AN OPEN
              <br />
              MIND.
            </span>
            <small>THE NEXT CHAPTER</small>
          </div>
          <div className="se-book se-book-front">
            <span>
              What
              <br />
              comes
              <br />
              <em>next?</em>
            </span>
            <small>NEW WAYS TO THINK.</small>
            <ArrowUpRight size={40} />
          </div>
          <span className="se-learn-note">
            A little knowledge.
            <br />A new possibility.
          </span>
        </>
      )}
      {kind === "sound" && (
        <>
          <div className="se-record-sleeve">
            <span>
              SOUND
              <br />
              IN GOOD
              <br />
              <em>COMPANY.</em>
            </span>
            <small>THE RTR DIGITAL AUDIO EDIT</small>
          </div>
          <div className="se-record">
            <div>
              <span>RTR</span>
              <i />
              <small>SIDE A / DIGITAL</small>
            </div>
          </div>
          <div className="se-sound-bars">
            {Array.from({ length: 25 }, (_, index) => (
              <i
                key={index}
                style={{
                  height: `${16 + Math.abs(Math.sin(index * 1.15)) * 47}px`,
                }}
              />
            ))}
          </div>
        </>
      )}
      {kind === "build" && (
        <>
          <div className="se-build-window">
            <div className="se-window-top">
              <span>
                <i />
                <i />
                <i />
              </span>
              <small>YOUR NEXT PROJECT</small>
              <Plus size={12} />
            </div>
            <div className="se-window-content">
              <span>Less setup.</span>
              <strong>
                More
                <br />
                momentum.
              </strong>
              <div>
                <i />
                <i />
                <i />
              </div>
            </div>
          </div>
          <span className="se-build-tile">
            <MoveUpRight size={57} strokeWidth={1.3} />
          </span>
          <span className="se-build-note">
            <Check size={13} /> A better starting point.
          </span>
        </>
      )}
    </div>
  );
}

function balancedPicks(products: Product[]) {
  const groups = [
    ["Design assets"],
    ["E-books", "Courses"],
    ["Audio & music"],
    ["Software", "Templates"],
  ];
  const chosen: Product[] = [];
  groups.forEach((categories) => {
    const product = products.find(
      (item) =>
        categories.includes(item.category) &&
        !chosen.some((pick) => pick.id === item.id),
    );
    if (product) chosen.push(product);
  });
  return [
    ...chosen,
    ...products.filter((item) => !chosen.some((pick) => pick.id === item.id)),
  ].slice(0, 4);
}

export function StudioCollectionsPage(props: CatalogProps) {
  const pageRef = useEditorialReveal();
  const selectionRef = useRef<HTMLElement>(null);
  const [activeEdit, setActiveEdit] = useState<string | null>(null);
  const [activeCategory, setActiveCategory] = useState("All products");
  const edit = edits.find((item) => item.id === activeEdit);
  const editCategories: readonly string[] | undefined = edit?.categories;
  const available = useMemo(
    () =>
      props.products.filter(
        (product) =>
          !editCategories || editCategories.includes(product.category),
      ),
    [props.products, editCategories],
  );
  const filtered = available.filter(
    (product) =>
      activeCategory === "All products" || product.category === activeCategory,
  );
  const shown =
    activeCategory === "All products" && !edit
      ? balancedPicks(filtered)
      : filtered.slice(0, 4);
  const categories = categoryList.filter(
    (item) =>
      item.name !== "All products" &&
      available.some((product) => product.category === item.name),
  );
  const browseCategory =
    activeCategory !== "All products"
      ? activeCategory
      : editCategories?.length === 1
        ? editCategories[0]
        : undefined;

  function selectEdit(id: string) {
    setActiveEdit(id);
    setActiveCategory("All products");
    selectionRef.current?.scrollIntoView({
      behavior: window.matchMedia("(prefers-reduced-motion: reduce)").matches
        ? "instant"
        : "smooth",
      block: "start",
    });
  }

  return (
    <div className="se-page se-collections-page" ref={pageRef}>
      <section
        className="se-wrap se-collections-intro"
        aria-labelledby="se-collections-title"
      >
        <div className="se-eyebrow">
          <span className="se-status-dot" /> THE RTR DIGITAL EDITS
        </div>
        <div className="se-intro-grid">
          <h1 id="se-collections-title">
            Good things.
            <br />
            <span>Better together.</span>
          </h1>
          <div>
            <p>
              A fresh direction for whatever you’re making. Explore digital
              products, collected around the way you think and work.
            </p>
            <a href="#se-edit-selection" className="se-text-link">
              Find your starting point <ArrowDown size={17} />
            </a>
          </div>
        </div>
        <div className="se-intro-rule">
          <span>A LITTLE DIRECTION. A LOT OF POSSIBILITY.</span>
          <span>
            CURATED BY RTR DIGITAL <ArrowUpRight size={13} />
          </span>
        </div>
      </section>

      <section
        className="se-wrap se-edit-grid"
        aria-label="Curated product collections"
      >
        {edits.map((item) => (
          <article
            className={`se-edit se-edit-${item.id} ${activeEdit === item.id ? "se-edit-selected" : ""}`}
            key={item.id}
            data-se-reveal
          >
            <button
              className="se-edit-main"
              onClick={() => selectEdit(item.id)}
              aria-label={`View ${item.label.toLowerCase()}`}
              aria-pressed={activeEdit === item.id}
            >
              <div className="se-edit-top">
                <span>
                  {item.number} / {item.eyebrow}
                </span>
                <span className="se-edit-arrow">
                  <ArrowUpRight size={21} />
                </span>
              </div>
              <EditArtwork kind={item.id} />
              <div className="se-edit-copy">
                <div>
                  <span className="se-eyebrow">
                    {item.categories.join(" / ")}
                  </span>
                  <h2>{item.title}</h2>
                  <p>{item.description}</p>
                </div>
                <span className="se-view-edit">
                  View the edit <ArrowRight size={17} />
                </span>
              </div>
            </button>
            <div className="se-edit-category-links">
              {item.categories.map((category) => (
                <button
                  key={category}
                  onClick={() => props.onExplore(category)}
                >
                  Browse {category.toLowerCase()} <ArrowUpRight size={14} />
                </button>
              ))}
            </div>
          </article>
        ))}
      </section>

      <section
        className="se-wrap se-selection"
        id="se-edit-selection"
        ref={selectionRef}
        aria-labelledby="se-selection-title"
        data-se-reveal
      >
        <div className="se-section-heading">
          <div>
            <span className="se-eyebrow">A CLOSER LOOK</span>
            <h2 id="se-selection-title">
              {edit ? edit.title : "A few good starting points."}
            </h2>
          </div>
          <button
            className="se-text-link"
            onClick={() => props.onExplore(browseCategory)}
          >
            Explore{" "}
            {browseCategory ? browseCategory.toLowerCase() : "all products"}{" "}
            <ArrowUpRight size={18} />
          </button>
        </div>
        {edit && (
          <div className="se-active-edit">
            <span>Viewing {edit.label.toLowerCase()}</span>
            <button
              onClick={() => {
                setActiveEdit(null);
                setActiveCategory("All products");
              }}
            >
              All collections <X size={14} />
            </button>
          </div>
        )}
        <div
          className="se-category-tabs"
          role="group"
          aria-label="Filter selected products by category"
        >
          <button
            className={activeCategory === "All products" ? "se-is-active" : ""}
            aria-pressed={activeCategory === "All products"}
            onClick={() => setActiveCategory("All products")}
          >
            All picks
          </button>
          {categories.map(({ name, icon: Icon }) => (
            <button
              key={name}
              className={activeCategory === name ? "se-is-active" : ""}
              aria-pressed={activeCategory === name}
              onClick={() => setActiveCategory(name)}
            >
              <Icon size={15} />
              {name}
            </button>
          ))}
        </div>
        <div className="se-selection-status" role="status">
          <span>
            {shown.length
              ? `${shown.length} selected / ${filtered.length} ${filtered.length === 1 ? "product" : "products"} in this view`
              : "No products in this edit just yet."}
          </span>
          <span>ONE BRAND. A WORLD OF POSSIBILITIES.</span>
        </div>
        <div className="se-product-grid">
          {shown.map((product) => (
            <ProductCard
              key={product.id}
              product={product}
              wished={props.wishlist.includes(product.id)}
              onWish={() => props.onWish(product)}
              onProduct={() => props.onProduct(product)}
            />
          ))}
        </div>
        {shown.length === 0 && (
          <div className="se-empty">
            <h3>Your next find is a little further along.</h3>
            <p>Explore the complete collection for another starting point.</p>
            <button
              className="se-button se-button-dark"
              onClick={() => props.onExplore()}
            >
              Browse all products <ArrowUpRight size={17} />
            </button>
          </div>
        )}
      </section>

      <section className="se-wrap se-collection-close" data-se-reveal>
        <div>
          <span className="se-eyebrow">FOLLOW MORE THAN ONE INTEREST.</span>
          <h2>Curiosity looks good on you.</h2>
          <p>
            The Digital Pass gives you access to included products while your
            plan is active.
          </p>
        </div>
        <button
          className="se-button se-button-dark"
          onClick={props.onMembership}
        >
          Meet the Digital Pass <ArrowUpRight size={18} />
        </button>
      </section>
    </div>
  );
}

export function StudioAboutPage({
  onExplore,
  onMembership,
}: {
  onExplore: () => void;
  onMembership: () => void;
}) {
  const pageRef = useEditorialReveal();
  return (
    <div className="se-page se-about-page" ref={pageRef}>
      <section
        className="se-wrap se-about-hero"
        aria-labelledby="se-about-title"
      >
        <div className="se-about-hero-copy">
          <div className="se-eyebrow">
            <span className="se-status-dot" /> THE IDEA BEHIND RTR DIGITAL
          </div>
          <h1 id="se-about-title">
            Ideas deserve
            <br />
            <span>better tools.</span>
          </h1>
          <p>
            For a fresh perspective. A stronger starting point. A project that’s
            been waiting for you.
          </p>
          <button className="se-button se-button-dark" onClick={onExplore}>
            Find your next thing <ArrowUpRight size={19} />
          </button>
          <div className="se-about-origin">
            <Globe2 size={15} />
            <span>BASED IN INDIA. MADE FOR WHAT’S NEXT.</span>
          </div>
        </div>
        <div
          className="se-manifesto-art"
          role="img"
          aria-label="A sculptural silver loop, cobalt sphere and chartreuse plinth in an ivory space, representing an idea taking shape."
        >
          <div className="se-art-caption">
            <span>RTR DIGITAL / A STUDY IN POSSIBILITY</span>
            <ArrowUpRight size={16} />
          </div>
          <div className="se-art-grid" />
          <span className="se-sculpture-shadow" />
          <span className="se-sculpture-plinth" />
          <span className="se-sculpture-ring" />
          <span className="se-sculpture-orb" />
          <div className="se-art-word">
            Ideas.
            <br />
            <span>In motion.</span>
          </div>
          <div className="se-art-foot">
            <span>
              A CONTINUOUS LINE FROM
              <br />
              CURIOSITY TO CREATION.
            </span>
            <span>R / 01</span>
          </div>
        </div>
      </section>

      <div className="se-wrap se-about-ticker" aria-label="Our focus">
        <span>DIGITAL BY NATURE.</span>
        <span>CONSIDERED BY DESIGN.</span>
        <span>READY FOR YOUR NEXT.</span>
        <ArrowUpRight size={20} />
      </div>

      <section
        className="se-wrap se-manifesto"
        aria-labelledby="se-manifesto-title"
        data-se-reveal
      >
        <div>
          <span className="se-eyebrow">WHY WE’RE HERE</span>
          <h2 id="se-manifesto-title">
            Less searching.
            <br />
            <span>More making.</span>
          </h2>
        </div>
        <div className="se-manifesto-copy">
          <p className="se-lead">
            The right digital product can change how a project begins.
          </p>
          <p>
            A design asset that gives an idea its identity. A book that opens a
            new direction. A soundtrack that brings the whole thing together. We
            believe useful things can be distinctive, too.
          </p>
          <p>
            RTR Digital brings those starting points into one place. A
            collection of tools, assets and perspectives, with one clear source
            for your purchase and product license.
          </p>
          <span className="se-manifesto-signature">
            A little less friction. A little more forward.
          </span>
        </div>
      </section>

      <section
        className="se-wrap se-principles"
        aria-label="What guides RTR Digital"
        data-se-reveal
      >
        <article>
          <div className="se-principle-number">
            <span>01 / CLEAR BY DESIGN</span>
            <div
              className="se-principle-symbol se-symbol-source"
              aria-hidden="true"
            >
              <i />
              <i />
              <i />
            </div>
          </div>
          <h3>
            One brand.
            <br />
            Every product.
          </h3>
          <p>
            RTR Digital is the sole seller and licensor of every product in the
            collection. Your purchase, your license and your point of contact
            come from us.
          </p>
        </article>
        <article>
          <div className="se-principle-number">
            <span>02 / OPEN TO POSSIBILITY</span>
            <div
              className="se-principle-symbol se-symbol-toolkit"
              aria-hidden="true"
            >
              <i />
              <i />
              <i />
              <i />
            </div>
          </div>
          <h3>
            Many interests.
            <br />
            One starting point.
          </h3>
          <p>
            Design assets, books, audio, courses, software, templates and video.
            Explore across disciplines and find the tools that fit the way you
            work.
          </p>
        </article>
        <article>
          <div className="se-principle-number">
            <span>03 / A WIDER PERSPECTIVE</span>
            <div
              className="se-principle-symbol se-symbol-world"
              aria-hidden="true"
            >
              <Globe2 size={48} strokeWidth={1} />
            </div>
          </div>
          <h3>
            From India.
            <br />
            For everywhere.
          </h3>
          <p>
            An India-based digital business with a global outlook. Our
            storefront lists prices in USD so you can compare your next find in
            one currency.
          </p>
        </article>
      </section>

      <section
        className="se-access"
        aria-labelledby="se-access-title"
        data-se-reveal
      >
        <div className="se-wrap se-access-inner">
          <div className="se-access-intro">
            <span className="se-eyebrow">A WAY IN THAT WORKS FOR YOU</span>
            <h2 id="se-access-title">
              One good find.
              <br />
              <span>Or room for more.</span>
            </h2>
            <button className="se-button se-button-acid" onClick={onMembership}>
              Explore the Digital Pass <ArrowUpRight size={18} />
            </button>
          </div>
          <div className="se-access-options">
            <div>
              <span>01</span>
              <div>
                <h3>Choose a single product.</h3>
                <p>
                  Purchase a specific product and keep access in your library.
                  Each product’s license explains how you can use it.
                </p>
              </div>
            </div>
            <div>
              <span>02</span>
              <div>
                <h3>Follow your curiosity.</h3>
                <p>
                  A Digital Pass unlocks included products while your membership
                  is active. Products you purchase individually remain in your
                  library.
                </p>
              </div>
            </div>
            <p className="se-access-note">
              Check the product format, license and plan details before you
              choose.
            </p>
          </div>
        </div>
      </section>

      <section className="se-wrap se-about-close" data-se-reveal>
        <span className="se-eyebrow">THE NEXT GOOD IDEA IS YOURS.</span>
        <button onClick={onExplore}>
          Make what’s next.
          <ArrowUpRight aria-hidden="true" />
        </button>
        <p>
          The collection includes illustrative sample listings. Product pages
          explain sample availability and the details of each product.
        </p>
      </section>
    </div>
  );
}
