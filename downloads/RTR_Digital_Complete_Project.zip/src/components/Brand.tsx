import type { CSSProperties } from "react";
import {
  ArrowUpRight,
  AudioLines,
  BookOpen,
  Code2,
  Command,
  Diamond,
  Flower2,
  Layers3,
  MousePointer2,
  Play,
  Sparkles,
  Triangle,
  Workflow,
} from "lucide-react";
import type { Product } from "../lib/types";
import { SELLER_NAME } from "../lib/brand";
export function Brand({ small = false }: { small?: boolean }) {
  return (
    <span className={`brand ${small ? "brand-small" : ""}`}>
      <svg className="brand-mark" viewBox="0 0 46 46" aria-hidden="true">
        <rect width="46" height="46" rx="13" fill="currentColor" />
        <path
          d="M12 34V12h13c13 0 14 15 3 17l10 8H27L16 27h9c7 0 7-7 0-7h-4v14z"
          fill="#d9edbc"
        />
        <path d="m12 34 9-7v7z" fill="#b9adee" />
      </svg>
      <span>
        RTR
        <span className="brand-digital">
          digital<span className="brand-dot">.</span>
        </span>
      </span>
    </span>
  );
}
export function ProductArt({
  product,
  large = false,
}: {
  product: Product;
  large?: boolean;
}) {
  const kind = product.art;
  return (
    <div
      className={`product-art art-${kind} ${large ? "art-large" : ""}`}
      style={{ "--art-bg": product.accent } as CSSProperties}
    >
      {product.image ? (
        <img src={product.image} alt={product.title} />
      ) : (
        <>
          {kind === "studio" && (
            <>
              <div className="art-orbit" />
              <div className="brand-paper back-paper">
                <span>
                  made
                  <br />
                  to matter.
                </span>
                <Flower2 size={48} strokeWidth={1} />
                <small>THE BRAND COLLECTION</small>
              </div>
              <div className="brand-paper front-paper">
                <span>
                  RTR<span className="tiny-star">✺</span>
                </span>
                <div className="paper-flower">
                  <Flower2 size={85} strokeWidth={1.2} />
                </div>
                <small>RTR DIGITAL · THE BRAND COLLECTION</small>
              </div>
              <div className="floating-swatch">
                <i />
                <i />
                <i />
                <i />
              </div>
            </>
          )}
          {kind === "book" && (
            <>
              <div className="book-shadow" />
              <div className="book-object">
                <small>A LITTLE MORE FOCUS.</small>
                <strong>
                  {product.id === "focus-deep-work" ? (
                    <>
                      The art
                      <br />
                      of deep
                      <br />
                      <em>work.</em>
                    </>
                  ) : (
                    <>
                      Creative
                      <br />
                      <em>by nature.</em>
                    </>
                  )}
                </strong>
                <div className="book-orb" />
                <span>{SELLER_NAME.toUpperCase()}</span>
              </div>
              <span className="art-caption">READ. RETHINK. REIMAGINE.</span>
            </>
          )}
          {kind === "audio" && (
            <>
              <div className="audio-record">
                <div />
                <span>{SELLER_NAME.toUpperCase()}</span>
              </div>
              <div className="audio-sleeve">
                <small>SOUNDS FOR YOUR SPACE</small>
                <strong>
                  {product.id === "mindful-mornings" ? (
                    <>
                      mindful
                      <br />
                      <em>mornings.</em>
                    </>
                  ) : (
                    <>
                      ambient
                      <br />
                      <em>essentials.</em>
                    </>
                  )}
                </strong>
                <div className="audio-lines">
                  {Array.from({ length: 24 }, (_, i) => (
                    <i
                      key={i}
                      style={{
                        height: `${20 + Math.sin(i * 0.8) * 16 + (i % 5) * 6}%`,
                      }}
                    />
                  ))}
                </div>
                <span>VOLUME 01 →</span>
              </div>
            </>
          )}
          {(kind === "dashboard" || kind === "code") && (
            <>
              <div className="mini-window">
                <div className="window-top">
                  <i />
                  <i />
                  <i />
                  <span>
                    {SELLER_NAME}
                  </span>
                </div>
                <div className="window-body">
                  <div className="window-sidebar">
                    <span>✺</span>
                    <i />
                    <i />
                    <i />
                    <i />
                  </div>
                  <div className="window-content">
                    <small>GOOD THINGS TAKE SHAPE</small>
                    <strong>
                      {kind === "code"
                        ? "Hello, possibility."
                        : "A little more life."}
                    </strong>
                    <div className="window-banner">
                      <span>{kind === "code" ? "{ }" : "✺"}</span>
                    </div>
                    <div className="window-blocks">
                      <i />
                      <i />
                      <i />
                    </div>
                    <div className="window-lines">
                      <i />
                      <i />
                    </div>
                  </div>
                </div>
              </div>
              <div className="app-tile">
                {kind === "code" ? <Code2 /> : <Workflow />}
              </div>
            </>
          )}
          {kind === "film" && (
            <>
              <div className="film-frame">
                <div className="film-mountains">
                  <i />
                  <i />
                  <i />
                </div>
                <div className="film-title">
                  <span>{SELLER_NAME.toUpperCase()}</span>
                  <strong>
                    Make it
                    <br />
                    <em>cinematic.</em>
                  </strong>
                  <small>THE COLOR COLLECTION</small>
                </div>
              </div>
              <div className="film-palette">
                <i />
                <i />
                <i />
                <i />
                <i />
              </div>
            </>
          )}
          {kind === "motion" && (
            <>
              <div className="motion-shapes">
                <div className="motion-circle" />
                <div className="motion-asterisk">✺</div>
                <div className="motion-arch" />
              </div>
              <span className="motion-title">
                a little <em>motion.</em>
              </span>
            </>
          )}
          {kind === "course" && (
            <>
              <div className="course-browser">
                <div>
                  <i />
                  <i />
                  <i />
                </div>
                <span>
                  Ideas into
                  <br />
                  <em>interfaces.</em>
                </span>
                <span className="course-play">
                  <Play size={22} fill="currentColor" />
                </span>
                <small>MAKE SOMETHING FOR THE WEB</small>
              </div>
            </>
          )}
          {kind === "icons" && (
            <>
              <div className="icon-board">
                {[
                  Sparkles,
                  Flower2,
                  Command,
                  Layers3,
                  Diamond,
                  Triangle,
                  MousePointer2,
                  BookOpen,
                  AudioLines,
                ].map((Icon, i) => (
                  <span key={i}>
                    <Icon strokeWidth={1.3} />
                  </span>
                ))}
              </div>
              <span className="icons-label">
                Small things. Big possibilities. <ArrowUpRight size={14} />
              </span>
            </>
          )}
        </>
      )}
    </div>
  );
}
