import { useCallback, useEffect, useRef, useState } from "react";
import type { FormEvent } from "react";
import {
  ArrowDownToLine,
  ArrowRight,
  ArrowUpRight,
  BookOpen,
  Check,
  CheckCircle2,
  ChevronRight,
  CircleAlert,
  CreditCard,
  Crown,
  Headphones,
  Mail,
  FileArchive,
  FolderOpen,
  LayoutGrid,
  LoaderCircle,
  LockKeyhole,
  Music2,
  Package,
  Plus,
  RefreshCw,
  Search,
  ShieldCheck,
  Sparkles,
  TrendingUp,
  UploadCloud,
  Users,
  Video,
  X,
} from "lucide-react";
import { api, money } from "../lib/api";
import { SELLER_NAME } from "../lib/brand";
import type { Product, Subscription, User } from "../lib/types";
import { ProductArt } from "./Brand";
import "../account.css";

type PanelProps = {
  user: User | null;
  onSignIn: () => void;
  onToast: (message: string, kind?: "success" | "error") => void;
  onExplore: () => void;
  onProduct: (product: Product) => void;
  refreshKey: number;
  onUserChange?: () => void;
  onMembership?: () => void;
  onMembershipHub?: () => void;
};
type Order = {
  id: string;
  total: number;
  status: string;
  createdAt?: string;
  created_at?: string;
  items?: Array<{ title?: string; productId?: string }>;
  plan?: string;
  mode?: string;
};
type LibraryData = {
  products: Product[];
  orders: Order[];
  subscription: Subscription | null;
};
type SupportTicket = {
  id: string;
  email: string;
  subject: string;
  message: string;
  status: string;
  created_at: string;
};
type AdminStats = {
  tickets?: SupportTicket[];
  newsletterSubscribers?: number;
  customers?: number;
  revenue: number;
  demoRevenue?: number;
  orders: number;
  subscribers: number;
  products: number;
  recentOrders?: Order[];
};
const errorMessage = (error: unknown) =>
  error instanceof Error
    ? error.message
    : "Something went wrong. Please try again.";
const categories = [
  "Design assets",
  "E-books",
  "Audio & music",
  "Courses",
  "Software",
  "Templates",
  "Video",
];
const displayDate = (date?: string) =>
  date
    ? new Date(date).toLocaleDateString("en-US", {
        month: "short",
        day: "numeric",
        year: "numeric",
      })
    : "—";
const planLabel = (plan?: string) =>
  plan === "starter"
    ? "Explorer"
    : plan
      ? `${plan.charAt(0).toUpperCase()}${plan.slice(1)}`
      : "Free explorer";

function FormatIcon({
  category,
  size = 24,
}: {
  category: string;
  size?: number;
}) {
  if (category === "Audio & music") return <Music2 size={size} />;
  if (category === "E-books" || category === "Courses")
    return <BookOpen size={size} />;
  if (category === "Video") return <Video size={size} />;
  return <LayoutGrid size={size} />;
}
function PanelLoading() {
  return (
    <div className="account-loading" role="status">
      <LoaderCircle className="account-spin" size={25} />
      <span>Getting everything ready for you…</span>
    </div>
  );
}
function PanelError({
  message,
  onRetry,
}: {
  message: string;
  onRetry: () => void;
}) {
  return (
    <div className="account-error" role="alert">
      <CircleAlert size={22} />
      <div>
        <strong>We couldn’t load this just yet.</strong>
        <p>{message}</p>
      </div>
      <button className="btn btn-outline" onClick={onRetry}>
        Try again <RefreshCw size={15} />
      </button>
    </div>
  );
}
function OrdersTable({
  orders,
  admin = false,
}: {
  orders: Order[];
  admin?: boolean;
}) {
  if (!orders.length)
    return (
      <div className="account-quiet-empty">
        <CreditCard size={29} />
        <h3>No orders yet</h3>
        <p>
          {admin
            ? "New purchases and memberships will appear here."
            : "Your purchases and membership receipts will live here."}
        </p>
      </div>
    );
  return (
    <div className="account-table-wrap">
      <table className="account-table">
        <thead>
          <tr>
            <th>Order</th>
            <th>{admin ? "Purchase" : "What you picked"}</th>
            <th>Date</th>
            <th>Status</th>
            <th className="account-align-right">Total</th>
          </tr>
        </thead>
        <tbody>
          {orders.map((order) => (
            <tr key={order.id}>
              <td>
                <span className="account-order-id">
                  #{order.id.slice(-8).toUpperCase()}
                </span>
                {order.mode === "demo" && <small>Demo order</small>}
              </td>
              <td>
                {order.plan
                  ? `${planLabel(order.plan)} membership`
                  : order.items
                      ?.map((item) => item.title)
                      .filter(Boolean)
                      .join(", ") || "Digital products"}
              </td>
              <td>{displayDate(order.createdAt || order.created_at)}</td>
              <td>
                <span
                  className={`account-status ${/fail|refund|cancel/.test(order.status) ? "account-status-muted" : ""}`}
                >
                  <span />
                  {order.status?.replaceAll("_", " ") || "Complete"}
                </span>
              </td>
              <td className="account-align-right account-table-price">
                {money(order.total || 0)}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export function LibraryPage({
  user,
  onSignIn,
  onToast,
  onExplore,
  onProduct,
  refreshKey,
  onUserChange,
  onMembership,
  onMembershipHub,
}: PanelProps) {
  const [tab, setTab] = useState<"products" | "orders" | "membership">(
    "products",
  );
  const [data, setData] = useState<LibraryData | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [search, setSearch] = useState("");
  const [downloadId, setDownloadId] = useState<string | null>(null);
  const [subscriptionBusy, setSubscriptionBusy] = useState(false);
  const [billingBusy, setBillingBusy] = useState(false);
  const [planBusy, setPlanBusy] = useState(false);
  const [chosenPlan, setChosenPlan] = useState(
    user?.subscription?.plan || "creator",
  );
  const [chosenInterval, setChosenInterval] = useState(
    user?.subscription?.interval || "monthly",
  );
  const load = useCallback(async () => {
    if (!user) return;
    setLoading(true);
    setError("");
    try {
      const library = await api<LibraryData>("/library");
      setData(library);
      if (library.subscription) {
        setChosenPlan(library.subscription.plan);
        setChosenInterval(library.subscription.interval);
      }
    } catch (err) {
      setError(errorMessage(err));
    } finally {
      setLoading(false);
    }
  }, [user]);
  useEffect(() => {
    void load();
  }, [load, refreshKey]);
  const download = async (product: Product) => {
    setDownloadId(product.id);
    try {
      const response = await fetch(
        `/api/download/${encodeURIComponent(product.id)}`,
        { credentials: "same-origin" },
      );
      if (!response.ok) {
        const body = await response.json();
        throw new Error(body.error || "This download is not available yet.");
      }
      const blob = await response.blob();
      const url = URL.createObjectURL(blob);
      const link = document.createElement("a");
      link.href = url;
      const disposition = response.headers.get("Content-Disposition");
      link.download =
        disposition?.match(/filename="?([^";]+)"?/)?.[1] ||
        `${product.id}.${product.format?.toLowerCase().includes("pdf") ? "pdf" : "txt"}`;
      document.body.append(link);
      link.click();
      link.remove();
      window.setTimeout(() => URL.revokeObjectURL(url), 1000);
      onToast("Your download is ready. Happy creating!");
    } catch (err) {
      onToast(errorMessage(err), "error");
    } finally {
      setDownloadId(null);
    }
  };
  const changeSubscription = async () => {
    setSubscriptionBusy(true);
    try {
      const resume = Boolean(data?.subscription?.cancelAtPeriodEnd);
      await api(`/subscription/${resume ? "resume" : "cancel"}`, {
        method: "POST",
      });
      await load();
      onUserChange?.();
      onToast(
        resume
          ? "Your membership will renew as usual."
          : "Renewal canceled. Your access continues until the end of this billing period.",
      );
    } catch (err) {
      onToast(errorMessage(err), "error");
    } finally {
      setSubscriptionBusy(false);
    }
  };
  const changePlan = async (event: FormEvent) => {
    event.preventDefault();
    setPlanBusy(true);
    try {
      const result = await api<{ url?: string; message?: string }>(
        "/subscription/change",
        {
          method: "POST",
          body: JSON.stringify({ plan: chosenPlan, interval: chosenInterval }),
        },
      );
      if (result.url) {
        window.location.assign(result.url);
        return;
      }
      await load();
      onUserChange?.();
      onToast(result.message || "Your membership plan has been updated.");
    } catch (err) {
      onToast(errorMessage(err), "error");
    } finally {
      setPlanBusy(false);
    }
  };
  const openBillingPortal = async () => {
    setBillingBusy(true);
    try {
      const result = await api<{ url: string }>("/billing/portal", {
        method: "POST",
      });
      window.location.assign(result.url);
    } catch (err) {
      onToast(errorMessage(err), "error");
    } finally {
      setBillingBusy(false);
    }
  };
  if (!user)
    return (
      <section className="page-width page-shell account-page">
        <div className="account-welcome-empty">
          <div className="account-empty-symbol">
            <FolderOpen size={39} />
          </div>
          <span className="eyebrow">YOUR CREATIVE CORNER</span>
          <h1>
            A little space.
            <br />
            For your next big thing.
          </h1>
          <p>
            All your downloads, favorite finds, and membership perks.
            <br />
            Sign in and make yourself at home.
          </p>
          <button className="btn btn-primary" onClick={onSignIn}>
            Sign in to your library <ArrowRight size={17} />
          </button>
          <button className="account-text-link" onClick={onExplore}>
            Or explore the collection <ArrowUpRight size={14} />
          </button>
        </div>
      </section>
    );
  const products = (data?.products || []).filter((product) =>
    `${product.title} ${product.category} ${product.creator}`
      .toLowerCase()
      .includes(search.toLowerCase()),
  );
  const subscription = (data?.subscription || user.subscription) as
    (Subscription & { mode?: string }) | null;
  return (
    <section className="page-width page-shell account-page">
      <header className="account-page-heading">
        <div>
          <span className="eyebrow">A PLACE FOR YOUR POSSIBILITIES</span>
          <h1>
            Your creative library<span>.</span>
          </h1>
          <p>
            Welcome back, {user.name.split(" ")[0]}. Your next idea is in good
            company.
          </p>
        </div>
        <button className="btn btn-outline" onClick={onExplore}>
          Find your next favorite <ArrowUpRight size={16} />
        </button>
      </header>
      <div className="account-library-banner">
        <div className="account-banner-icon">
          <Crown size={26} />
        </div>
        <div>
          <span className="account-tiny-label">YOUR MEMBERSHIP</span>
          <h3>
            {subscription && subscription.status !== "canceled"
              ? `${planLabel(subscription.plan)} looks good on you.`
              : "More possibilities. One membership."}
          </h3>
          <p>
            {subscription && subscription.status !== "canceled"
              ? `Your ${subscription.interval || "monthly"} plan keeps your creativity moving.`
              : "Get more from your creative world with an all-access plan."}
          </p>
        </div>
        <button
          className="account-banner-action"
          onClick={() => setTab("membership")}
        >
          Manage membership <ArrowUpRight size={17} />
        </button>
        <div className="account-banner-orbit" aria-hidden="true" />
      </div>
      <nav className="account-tabs" aria-label="Library sections">
        <button
          className={tab === "products" ? "active" : ""}
          onClick={() => setTab("products")}
        >
          <FolderOpen size={17} />
          My products <span>{data?.products.length || 0}</span>
        </button>
        <button
          className={tab === "orders" ? "active" : ""}
          onClick={() => setTab("orders")}
        >
          <CreditCard size={17} />
          Order history
        </button>
        <button
          className={tab === "membership" ? "active" : ""}
          onClick={() => setTab("membership")}
        >
          <Crown size={17} />
          Membership
        </button>
      </nav>
      {loading ? (
        <PanelLoading />
      ) : error ? (
        <PanelError message={error} onRetry={() => void load()} />
      ) : tab === "products" ? (
        <section className="account-products-section">
          <div className="account-section-toolbar">
            <div>
              <h2>Made yours.</h2>
              <p>Good things, ready when you are.</p>
            </div>
            <label className="account-search">
              <Search size={17} />
              <input
                value={search}
                onChange={(event) => setSearch(event.target.value)}
                placeholder="Search your library"
                aria-label="Search your library"
              />
            </label>
          </div>
          {products.length ? (
            <div className="account-library-grid">
              {products.map((product) => (
                <article className="account-library-card" key={product.id}>
                  <button
                    className={`account-product-art art-${product.art}`}
                    style={{ backgroundColor: product.accent || "#dce8d7" }}
                    onClick={() => onProduct(product)}
                    aria-label={`View ${product.title}`}
                  >
                    <ProductArt product={product} />
                    <span className="account-owned-badge">
                      <Check size={12} /> In your library
                    </span>
                    <ArrowUpRight size={19} className="account-art-arrow" />
                  </button>
                  <div className="account-library-card-body">
                    <span className="account-card-category">
                      {product.category}
                    </span>
                    <button
                      className="account-product-title"
                      onClick={() => onProduct(product)}
                    >
                      {product.title}
                    </button>
                    <p>{SELLER_NAME}</p>
                    <div className="account-download-row">
                      <span>
                        {product.format} <i>·</i> {product.size}
                      </span>
                      <button
                        onClick={() => void download(product)}
                        disabled={downloadId === product.id}
                        aria-label={`Download ${product.title}`}
                      >
                        {downloadId === product.id ? (
                          <LoaderCircle size={16} className="account-spin" />
                        ) : (
                          <ArrowDownToLine size={17} />
                        )}
                        <span>Download</span>
                      </button>
                    </div>
                  </div>
                </article>
              ))}
            </div>
          ) : (
            <div className="account-quiet-empty">
              <FolderOpen size={38} />
              <h3>
                {search
                  ? "No matching finds yet."
                  : "Your collection starts here."}
              </h3>
              <p>
                {search
                  ? "Try a different title or category."
                  : "Buy a product or activate a membership to fill this space with possibilities."}
              </p>
              <button className="btn btn-primary" onClick={onExplore}>
                Explore digital products <ArrowRight size={16} />
              </button>
            </div>
          )}
        </section>
      ) : tab === "orders" ? (
        <section className="account-content-card">
          <div className="account-card-heading">
            <div>
              <h2>Your good decisions.</h2>
              <p>A record of every creative investment.</p>
            </div>
            <CreditCard size={23} />
          </div>
          <OrdersTable orders={data?.orders || []} />
        </section>
      ) : (
        <section className="account-membership-grid">
          <div className="account-current-plan">
            <div className="account-plan-topline">
              <span className="eyebrow">YOUR CURRENT PLAN</span>
              <Crown size={24} />
            </div>
            <h2>{planLabel(subscription?.plan)}</h2>
            <span
              className={`account-status ${subscription?.cancelAtPeriodEnd ? "account-status-muted" : ""}`}
            >
              <span />
              {subscription?.isTrial
                ? "Free preview · no automatic renewal"
                : subscription?.isPrepaid
                  ? "Prepaid membership · no automatic renewal"
                  : subscription?.cancelAtPeriodEnd
                    ? "Ends after this billing period"
                    : subscription?.status || "No active membership"}
            </span>
            <p>
              {subscription
                ? `${planLabel(subscription.plan)} gives you space to explore, learn, and create with digital products from the membership collection.`
                : "One membership. A whole world of digital possibility. Pick your plan to bring more ideas to life."}
            </p>
            {subscription?.currentPeriodEnd && (
              <dl className="account-plan-facts">
                <div>
                  <dt>Billing cycle</dt>
                  <dd>
                    {subscription.isTrial
                      ? "Seven-day free preview · no charge"
                      : subscription.isPrepaid
                        ? `${planLabel(subscription.interval)} · paid once`
                        : planLabel(subscription.interval)}
                  </dd>
                </div>
                <div>
                  <dt>
                    {subscription.isTrial || subscription.cancelAtPeriodEnd
                      ? "Access until"
                      : "Next renewal"}
                  </dt>
                  <dd>{displayDate(subscription.currentPeriodEnd)}</dd>
                </div>
              </dl>
            )}
            {subscription?.isTrial ? (
              <button
                className="btn btn-outline"
                onClick={onMembershipHub || onMembership || onExplore}
              >
                Manage free preview <ArrowUpRight size={15} />
              </button>
            ) : subscription?.isPrepaid ? (
              <p>
                Your purchased term expires automatically on{" "}
                {displayDate(subscription.currentPeriodEnd)}. Choose a new term
                after it ends; there is no recurring charge.
              </p>
            ) : subscription && subscription.status !== "canceled" ? (
              <button
                className="btn btn-outline"
                disabled={subscriptionBusy}
                onClick={() => void changeSubscription()}
              >
                {subscriptionBusy ? (
                  <LoaderCircle size={16} className="account-spin" />
                ) : (
                  <RefreshCw size={15} />
                )}
                {subscription.cancelAtPeriodEnd
                  ? "Keep my membership"
                  : "Cancel renewal"}
              </button>
            ) : (
              <button
                className="btn btn-primary"
                onClick={onMembership || onExplore}
              >
                Choose your membership <ArrowRight size={16} />
              </button>
            )}
            {subscription?.mode === "stripe" && (
              <button
                className="account-billing-button"
                disabled={billingBusy}
                onClick={() => void openBillingPortal()}
              >
                {billingBusy ? (
                  <LoaderCircle size={15} className="account-spin" />
                ) : (
                  <CreditCard size={15} />
                )}
                Payment methods & invoices <ArrowUpRight size={14} />
              </button>
            )}
            {subscription &&
              !subscription.isTrial &&
              !subscription.isPrepaid &&
              subscription.status !== "canceled" && (
                <form
                  className="account-change-plan"
                  onSubmit={(event) => void changePlan(event)}
                >
                  <h3>A different pace?</h3>
                  <p>Find the membership that fits your next chapter.</p>
                  <div>
                    <label>
                      Plan
                      <select
                        aria-label="Change membership plan"
                        value={chosenPlan}
                        onChange={(event) => setChosenPlan(event.target.value)}
                      >
                        <option value="starter">Explorer</option>
                        <option value="creator">Creator</option>
                        <option value="studio">Studio</option>
                      </select>
                    </label>
                    <label>
                      Billing cycle
                      <select
                        aria-label="Change billing cycle"
                        value={chosenInterval}
                        onChange={(event) =>
                          setChosenInterval(event.target.value)
                        }
                      >
                        <option value="monthly">Monthly billing</option>
                        <option value="yearly">Yearly billing</option>
                      </select>
                    </label>
                  </div>
                  <small>
                    {subscription.mode === "demo"
                      ? "Demo only: applies immediately and restarts the test period. No payment is collected."
                      : "Review your new plan and any billing adjustments securely in Stripe before confirming."}
                  </small>
                  <button
                    className="btn btn-outline"
                    type="submit"
                    disabled={
                      planBusy ||
                      (chosenPlan === subscription.plan &&
                        chosenInterval === subscription.interval)
                    }
                  >
                    {planBusy ? (
                      <LoaderCircle size={15} className="account-spin" />
                    ) : (
                      <RefreshCw size={14} />
                    )}
                    {subscription.mode === "demo"
                      ? "Change demo plan"
                      : "Review plan change"}
                  </button>
                </form>
              )}
          </div>
          <div className="account-membership-perks">
            <span className="account-feature-icon">
              <Sparkles size={24} />
            </span>
            <h2>
              Less friction.
              <br />
              More making.
            </h2>
            <p>Consider this your permission to explore.</p>
            <ul>
              <li>
                <CheckCircle2 size={18} /> Instant access to included digital
                products
              </li>
              <li>
                <CheckCircle2 size={18} /> A personal library that goes where
                you do
              </li>
              <li>
                <CheckCircle2 size={18} /> Simple billing and self-service
                cancellation
              </li>
              <li>
                <CheckCircle2 size={18} /> Every purchase securely saved to your
                account
              </li>
            </ul>
            <div className="account-small-note">
              <ShieldCheck size={16} />
              Your membership, on your terms.
            </div>
          </div>
        </section>
      )}
      <div className="account-data-tools">
        <div>
          <ShieldCheck size={17} />
          <span>Your account. Your data.</span>
        </div>
        <a href="/api/account/export" download="rtr-digital-account.json">
          Export my account data <ArrowDownToLine size={15} />
        </a>
      </div>
    </section>
  );
}

function SupportInbox({
  tickets,
  onToggle,
  ticketBusy,
}: {
  tickets: SupportTicket[];
  onToggle: (ticket: SupportTicket) => void;
  ticketBusy: string | null;
}) {
  const [filter, setFilter] = useState("open");
  const [search, setSearch] = useState("");
  const filtered = tickets.filter(
    (ticket) =>
      (filter === "all" || ticket.status === filter) &&
      `${ticket.email} ${ticket.subject} ${ticket.message}`
        .toLowerCase()
        .includes(search.toLowerCase()),
  );
  return (
    <section className="account-support-inbox">
      <div className="account-section-toolbar">
        <div>
          <h2>A little help goes a long way.</h2>
          <p>Customer questions, ready for your attention.</p>
        </div>
        <label className="account-search">
          <Search size={17} />
          <input
            placeholder="Search support requests"
            aria-label="Search support requests"
            value={search}
            onChange={(event) => setSearch(event.target.value)}
          />
        </label>
      </div>
      <div
        className="account-ticket-filters"
        aria-label="Filter support requests"
      >
        {["open", "resolved", "all"].map((status) => (
          <button
            key={status}
            className={filter === status ? "active" : ""}
            onClick={() => setFilter(status)}
          >
            {status === "all"
              ? "All requests"
              : status === "open"
                ? "Needs attention"
                : "Resolved"}
            <span>
              {
                tickets.filter(
                  (ticket) => status === "all" || ticket.status === status,
                ).length
              }
            </span>
          </button>
        ))}
      </div>
      {filtered.length ? (
        <div className="account-ticket-list">
          {filtered.map((ticket) => (
            <article className="account-ticket" key={ticket.id}>
              <div className="account-ticket-top">
                <div>
                  <span
                    className={`account-status ${ticket.status === "open" ? "account-status-muted" : ""}`}
                  >
                    <span />
                    {ticket.status}
                  </span>
                  <span className="account-ticket-date">
                    {displayDate(ticket.created_at)}
                  </span>
                </div>
                <span className="account-ticket-number">
                  #{ticket.id.slice(-8).toUpperCase()}
                </span>
              </div>
              <h3>{ticket.subject}</h3>
              <p className="account-ticket-message">{ticket.message}</p>
              <div className="account-ticket-footer">
                <span>
                  <Mail size={13} />
                  {ticket.email}
                </span>
                <button
                  className="account-table-action"
                  disabled={ticketBusy === ticket.id}
                  onClick={() => onToggle(ticket)}
                >
                  {ticketBusy === ticket.id ? (
                    <LoaderCircle size={14} className="account-spin" />
                  ) : ticket.status === "resolved" ? (
                    <RefreshCw size={13} />
                  ) : (
                    <CheckCircle2 size={13} />
                  )}
                  {ticket.status === "resolved"
                    ? "Reopen request"
                    : "Mark resolved"}
                </button>
              </div>
            </article>
          ))}
        </div>
      ) : (
        <div className="account-quiet-empty">
          <Headphones size={32} />
          <h3>
            {search
              ? "No matching conversations."
              : filter === "open"
                ? "All caught up."
                : "No requests here yet."}
          </h3>
          <p>
            {search
              ? "Try another email address or subject."
              : filter === "open"
                ? "You’re giving your customers room to keep creating."
                : "Customer support messages will appear in this inbox."}
          </p>
        </div>
      )}
    </section>
  );
}

export function AdminPage({
  user,
  onSignIn,
  onToast,
  onProduct,
  refreshKey,
}: PanelProps) {
  const [tab, setTab] = useState<"products" | "orders" | "support">("products");
  const [stats, setStats] = useState<AdminStats | null>(null);
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [search, setSearch] = useState("");
  const [uploadOpen, setUploadOpen] = useState(false);
  const [file, setFile] = useState<File | null>(null);
  const [cover, setCover] = useState<File | null>(null);
  const [uploadBusy, setUploadBusy] = useState(false);
  const [uploadError, setUploadError] = useState("");
  const [productBusy, setProductBusy] = useState<string | null>(null);
  const [ticketBusy, setTicketBusy] = useState<string | null>(null);
  const formRef = useRef<HTMLFormElement>(null);
  const fileRef = useRef<HTMLInputElement>(null);
  const modalRef = useRef<HTMLElement>(null);
  const load = useCallback(async () => {
    if (user?.role !== "admin") return;
    setLoading(true);
    setError("");
    try {
      const [summary, catalog] = await Promise.all([
        api<AdminStats>("/admin/stats"),
        api<{ products: Product[] }>("/admin/products"),
      ]);
      setStats(summary);
      setProducts(catalog.products);
    } catch (err) {
      setError(errorMessage(err));
    } finally {
      setLoading(false);
    }
  }, [user]);
  useEffect(() => {
    void load();
  }, [load, refreshKey]);
  useEffect(() => {
    if (!uploadOpen) return;
    const previousFocus =
      document.activeElement instanceof HTMLElement
        ? document.activeElement
        : null;
    const previousOverflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    const keyboard = (event: KeyboardEvent) => {
      if (event.key === "Escape" && !uploadBusy) setUploadOpen(false);
      if (event.key !== "Tab") return;
      const focusable = Array.from(
        modalRef.current?.querySelectorAll<HTMLElement>(
          'button:not(:disabled), input:not(:disabled):not([type=file]), select:not(:disabled), textarea:not(:disabled), [tabindex="0"]',
        ) || [],
      );
      const first = focusable[0];
      const last = focusable.at(-1);
      if (event.shiftKey && document.activeElement === first) {
        event.preventDefault();
        last?.focus();
      } else if (!event.shiftKey && document.activeElement === last) {
        event.preventDefault();
        first?.focus();
      }
    };
    document.addEventListener("keydown", keyboard);
    return () => {
      document.removeEventListener("keydown", keyboard);
      document.body.style.overflow = previousOverflow;
      previousFocus?.focus();
    };
  }, [uploadOpen, uploadBusy]);
  const upload = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setUploadError("");
    if (!file) {
      setUploadError("Choose a digital product file to continue.");
      return;
    }
    if (file.size > 100 * 1024 * 1024) {
      setUploadError(
        "This file is too large. Please upload a file under 100 MB.",
      );
      return;
    }
    setUploadBusy(true);
    try {
      const body = new FormData(event.currentTarget);
      body.set("file", file);
      if (cover) body.set("cover", cover);
      body.set(
        "subscriptionIncluded",
        body.get("subscriptionIncluded") ? "true" : "false",
      );
      await api("/admin/products", { method: "POST", body });
      setUploadOpen(false);
      setFile(null);
      setCover(null);
      formRef.current?.reset();
      await load();
      onToast("Your digital product has been added to the catalog.");
    } catch (err) {
      setUploadError(errorMessage(err));
    } finally {
      setUploadBusy(false);
    }
  };
  const toggleStatus = async (product: Product) => {
    setProductBusy(product.id);
    try {
      await api(`/admin/products/${encodeURIComponent(product.id)}`, {
        method: "PATCH",
        body: JSON.stringify({
          status: product.status === "draft" ? "published" : "draft",
        }),
      });
      await load();
      onToast(
        product.status === "draft"
          ? "Product published to the storefront."
          : "Product moved to drafts.",
      );
    } catch (err) {
      onToast(errorMessage(err), "error");
    } finally {
      setProductBusy(null);
    }
  };
  const updateTicket = async (ticket: SupportTicket) => {
    const status = ticket.status === "resolved" ? "open" : "resolved";
    setTicketBusy(ticket.id);
    try {
      await api(`/admin/tickets/${encodeURIComponent(ticket.id)}`, {
        method: "PATCH",
        body: JSON.stringify({ status }),
      });
      setStats((current) =>
        current
          ? {
              ...current,
              tickets: current.tickets?.map((item) =>
                item.id === ticket.id ? { ...item, status } : item,
              ),
            }
          : current,
      );
      onToast(
        status === "resolved"
          ? "Support request marked as resolved."
          : "Support request reopened.",
      );
    } catch (err) {
      onToast(errorMessage(err), "error");
    } finally {
      setTicketBusy(null);
    }
  };
  if (user?.role !== "admin")
    return (
      <section className="page-width page-shell account-page">
        <div className="account-welcome-empty">
          <div className="account-empty-symbol">
            <LockKeyhole size={37} />
          </div>
          <span className="eyebrow">BEHIND THE POSSIBILITIES</span>
          <h1>
            RTR Digital’s
            <br />
            control room.
          </h1>
          <p>
            Manage your digital catalog, publish products,
            <br />
            and keep your business in view.
          </p>
          <button className="btn btn-primary" onClick={onSignIn}>
            Sign in as administrator <ArrowRight size={17} />
          </button>
          <span className="account-access-note">
            <ShieldCheck size={15} /> Administrator access required
          </span>
        </div>
      </section>
    );
  const filtered = products.filter((product) =>
    `${product.title} ${product.category}`
      .toLowerCase()
      .includes(search.toLowerCase()),
  );
  return (
    <section className="page-width page-shell account-page account-admin">
      <header className="account-page-heading">
        <div>
          <span className="eyebrow">YOUR DIGITAL BUSINESS, AT A GLANCE</span>
          <h1>
            The control room<span>.</span>
          </h1>
          <p>Big ideas out front. Everything you need behind the scenes.</p>
        </div>
        <button
          className="btn btn-primary"
          onClick={() => {
            setUploadError("");
            setUploadOpen(true);
          }}
        >
          <Plus size={18} /> Upload a product
        </button>
      </header>
      {loading && !stats ? (
        <PanelLoading />
      ) : error ? (
        <PanelError message={error} onRetry={() => void load()} />
      ) : (
        <>
          <section className="account-stats" aria-label="Store statistics">
            {[
              {
                label: "Total revenue",
                value: money(stats?.revenue || 0),
                caption: stats?.demoRevenue
                  ? `${money(stats.demoRevenue)} in demo purchases (not charged)`
                  : "Live payments only",
                icon: TrendingUp,
                color: "mint",
              },
              {
                label: "Orders",
                value: String(stats?.orders || 0),
                caption: "Creative possibilities unlocked",
                icon: CreditCard,
                color: "lavender",
              },
              {
                label: "Subscribers",
                value: String(stats?.subscribers || 0),
                caption: "Active memberships",
                icon: Users,
                color: "peach",
              },
              {
                label: "Digital products",
                value: String(stats?.products || 0),
                caption: "In your growing catalog",
                icon: Package,
                color: "blue",
              },
            ].map((item) => (
              <article className="account-stat-card" key={item.label}>
                <div>
                  <span>{item.label}</span>
                  <span className={`account-stat-icon ${item.color}`}>
                    <item.icon size={19} />
                  </span>
                </div>
                <strong>{item.value}</strong>
                <p>{item.caption}</p>
              </article>
            ))}
          </section>
          <div className="account-community-note">
            <span>
              <Users size={14} />
              <strong>{stats?.customers || 0}</strong> customer accounts
            </span>
            <span>
              <Mail size={14} />
              <strong>{stats?.newsletterSubscribers || 0}</strong> newsletter
              subscribers
            </span>
            <span>
              <Headphones size={14} />
              <strong>
                {stats?.tickets?.filter((ticket) => ticket.status === "open")
                  .length || 0}
              </strong>{" "}
              open support requests
            </span>
          </div>
          <section className="account-content-card account-admin-catalog">
            <div className="account-admin-card-top">
              <nav className="account-tabs" aria-label="Administrator sections">
                <button
                  className={tab === "products" ? "active" : ""}
                  onClick={() => setTab("products")}
                >
                  <Package size={17} />
                  Product catalog <span>{products.length}</span>
                </button>
                <button
                  className={tab === "orders" ? "active" : ""}
                  onClick={() => setTab("orders")}
                >
                  <CreditCard size={17} />
                  Recent orders
                </button>
                <button
                  className={tab === "support" ? "active" : ""}
                  onClick={() => setTab("support")}
                >
                  <Headphones size={17} />
                  Support inbox{" "}
                  <span>
                    {stats?.tickets?.filter(
                      (ticket) => ticket.status === "open",
                    ).length || 0}
                  </span>
                </button>
              </nav>
              <button
                className="account-icon-button"
                aria-label="Refresh dashboard"
                onClick={() => void load()}
                disabled={loading}
              >
                <RefreshCw
                  size={17}
                  className={loading ? "account-spin" : ""}
                />
              </button>
            </div>
            {tab === "products" ? (
              <>
                <div className="account-section-toolbar">
                  <div>
                    <h2>Your ideas, on the shelf.</h2>
                    <p>Publish something worth discovering.</p>
                  </div>
                  <label className="account-search">
                    <Search size={17} />
                    <input
                      value={search}
                      onChange={(event) => setSearch(event.target.value)}
                      placeholder="Search products"
                      aria-label="Search product catalog"
                    />
                  </label>
                </div>
                <div className="account-table-wrap">
                  <table className="account-table account-admin-table">
                    <thead>
                      <tr>
                        <th>Product</th>
                        <th>Category</th>
                        <th>Price</th>
                        <th>Membership</th>
                        <th>Status</th>
                        <th>
                          <span className="account-sr-only">Actions</span>
                        </th>
                      </tr>
                    </thead>
                    <tbody>
                      {filtered.map((product) => (
                        <tr key={product.id}>
                          <td>
                            <button
                              className="account-table-product"
                              onClick={() => onProduct(product)}
                            >
                              <span
                                style={{
                                  backgroundColor: product.accent || "#dce8d7",
                                }}
                              >
                                <FormatIcon
                                  category={product.category}
                                  size={21}
                                />
                              </span>
                              <div>
                                <strong>{product.title}</strong>
                                <small>
                                  {product.format} · {product.size}
                                </small>
                              </div>
                            </button>
                          </td>
                          <td>{product.category}</td>
                          <td className="account-table-price">
                            {money(product.price)}
                          </td>
                          <td>
                            {product.subscriptionIncluded ? (
                              <span className="account-included">
                                <Crown size={13} /> Included
                              </span>
                            ) : (
                              <span className="account-muted">
                                Purchase only
                              </span>
                            )}
                          </td>
                          <td>
                            <span
                              className={`account-status ${product.status === "draft" ? "account-status-muted" : ""}`}
                            >
                              <span />
                              {product.status || "Published"}
                            </span>
                          </td>
                          <td className="account-align-right">
                            <button
                              className="account-table-action"
                              onClick={() => void toggleStatus(product)}
                              disabled={productBusy === product.id}
                            >
                              {productBusy === product.id ? (
                                <LoaderCircle
                                  size={15}
                                  className="account-spin"
                                />
                              ) : product.status === "draft" ? (
                                "Publish"
                              ) : (
                                "Unpublish"
                              )}
                              <ChevronRight size={14} />
                            </button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                  {!filtered.length && (
                    <div className="account-quiet-empty">
                      <Search size={28} />
                      <h3>No products found.</h3>
                      <p>
                        Try a different search or upload your first digital
                        product.
                      </p>
                    </div>
                  )}
                </div>
              </>
            ) : tab === "orders" ? (
              <OrdersTable orders={stats?.recentOrders || []} admin />
            ) : (
              <SupportInbox
                tickets={stats?.tickets || []}
                onToggle={(ticket) => void updateTicket(ticket)}
                ticketBusy={ticketBusy}
              />
            )}
          </section>
          <div className="account-admin-footer-note">
            <ShieldCheck size={17} />
            <p>
              Files are delivered through account-protected downloads. Only
              administrators can publish or manage your catalog.
            </p>
          </div>
        </>
      )}
      {uploadOpen && (
        <div
          className="account-modal-backdrop"
          onClick={(event) => {
            if (event.target === event.currentTarget && !uploadBusy)
              setUploadOpen(false);
          }}
        >
          <section
            className="account-upload-modal"
            ref={modalRef}
            role="dialog"
            aria-modal="true"
            aria-labelledby="upload-title"
          >
            <button
              className="account-modal-close"
              aria-label="Close upload form"
              onClick={() => setUploadOpen(false)}
              disabled={uploadBusy}
            >
              <X size={20} />
            </button>
            <div className="account-upload-heading">
              <span className="account-feature-icon">
                <UploadCloud size={24} />
              </span>
              <span className="eyebrow">FROM YOUR DESK TO THE WORLD</span>
              <h2 id="upload-title">Publish a possibility.</h2>
              <p>Give your digital product a home in the collection.</p>
            </div>
            <form
              onSubmit={(event) => void upload(event)}
              ref={formRef}
              className="account-upload-form"
            >
              <label>
                Product name
                <input
                  name="title"
                  placeholder="A name worth remembering"
                  required
                  maxLength={160}
                  autoFocus
                />
              </label>
              <label>
                Description
                <textarea
                  name="description"
                  placeholder="What makes it special? Tell your customers what’s inside."
                  required
                  rows={3}
                  maxLength={4000}
                />
              </label>
              <div className="account-form-row">
                <label>
                  Category
                  <select
                    aria-label="Category"
                    name="category"
                    required
                    defaultValue="Design assets"
                  >
                    {categories.map((category) => (
                      <option key={category}>{category}</option>
                    ))}
                  </select>
                </label>
                <label>
                  Price (USD)
                  <input
                    type="number"
                    name="price"
                    min="0"
                    max="99999"
                    step="0.01"
                    required
                    placeholder="29.00"
                  />
                </label>
              </div>
              <label>
                Visibility
                <select
                  aria-label="Visibility"
                  name="status"
                  defaultValue="draft"
                >
                  <option value="draft">Save as draft</option>
                  <option value="published">Publish to storefront</option>
                </select>
              </label>
              <div className="account-upload-field">
                <span className="account-field-label">
                  Digital product file
                </span>
                <div
                  className={`account-file-drop ${file ? "has-file" : ""}`}
                  onDragOver={(event) => event.preventDefault()}
                  onDrop={(event) => {
                    event.preventDefault();
                    const next = event.dataTransfer.files[0];
                    if (next) setFile(next);
                  }}
                >
                  <input
                    type="file"
                    id="admin-product-file"
                    ref={fileRef}
                    onChange={(event) =>
                      setFile(event.target.files?.[0] || null)
                    }
                    aria-label="Choose digital product file"
                  />
                  <label htmlFor="admin-product-file">
                    {file ? (
                      <FileArchive size={28} />
                    ) : (
                      <UploadCloud size={30} />
                    )}
                    <strong>
                      {file ? file.name : "Drop your file here, or browse"}
                    </strong>
                    <span>
                      {file
                        ? `${(file.size / 1024 / 1024).toFixed(2)} MB · Click to replace`
                        : "E-books, audio, video, software, archives · up to 100 MB"}
                    </span>
                  </label>
                </div>
              </div>
              <label className="account-cover-field">
                <span>
                  Cover image <small>(optional)</small>
                </span>
                <input
                  type="file"
                  accept="image/png,image/jpeg,image/webp"
                  onChange={(event) =>
                    setCover(event.target.files?.[0] || null)
                  }
                />
              </label>
              <label className="account-checkbox-label">
                <input
                  type="checkbox"
                  name="subscriptionIncluded"
                  defaultChecked
                />
                <span>
                  <strong>Include in membership</strong>
                  <small>
                    Let members discover this product with their subscription.
                  </small>
                </span>
                <Crown size={18} />
              </label>
              {uploadError && (
                <div className="account-form-error" role="alert">
                  <CircleAlert size={16} />
                  {uploadError}
                </div>
              )}
              <div className="account-upload-actions">
                <button
                  type="button"
                  className="btn btn-outline"
                  onClick={() => setUploadOpen(false)}
                  disabled={uploadBusy}
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="btn btn-primary"
                  disabled={uploadBusy}
                >
                  {uploadBusy ? (
                    <>
                      <LoaderCircle size={17} className="account-spin" />
                      Uploading…
                    </>
                  ) : (
                    <>
                      <Plus size={17} />
                      Add to catalog
                    </>
                  )}
                </button>
              </div>
              <p className="account-file-disclaimer">
                <LockKeyhole size={12} />
                Your original file stays protected behind account access.
              </p>
            </form>
          </section>
        </div>
      )}
    </section>
  );
}
