import {
  ArrowRight,
  ArrowUpRight,
  AudioLines,
  BadgeCheck,
  BookOpen,
  Check,
  ChevronDown,
  ChevronLeft,
  ChevronRight,
  Code2,
  Download,
  Film,
  Grid2X2,
  Heart,
  Infinity as InfinityIcon,
  Layers3,
  LayoutTemplate,
  LockKeyhole,
  Palette,
  Play,
  Search,
  ShieldCheck,
  SlidersHorizontal,
  Sparkles,
  Star,
  X,
} from "lucide-react";
import { useState } from "react";
import type { Product } from "../lib/types";
import { money } from "../lib/api";
import { SELLER_NAME } from "../lib/brand";
import { ProductArt } from "./Brand";
export const categoryList = [
  { name: "All products", icon: Grid2X2 },
  { name: "Design assets", icon: Palette },
  { name: "E-books", icon: BookOpen },
  { name: "Audio & music", icon: AudioLines },
  { name: "Courses", icon: Play },
  { name: "Software", icon: Code2 },
  { name: "Templates", icon: LayoutTemplate },
  { name: "Video", icon: Film },
];
export interface CatalogProps {
  products: Product[];
  wishlist: string[];
  onWish: (p: Product) => void;
  onProduct: (p: Product) => void;
  onExplore: (category?: string) => void;
  onMembership: () => void;
  onCollection: () => void;
}
export function ProductCard({
  product,
  wished,
  onWish,
  onProduct,
}: {
  product: Product;
  wished: boolean;
  onWish: () => void;
  onProduct: () => void;
}) {
  return (
    <article className="product-card">
      <div className="product-picture">
        <button
          className="art-link"
          onClick={onProduct}
          aria-label={`View ${product.title}`}
        >
          <ProductArt product={product} />
        </button>
        <span className="product-category">{product.category}</span>
        <button
          className={`wish-button ${wished ? "is-wished" : ""}`}
          onClick={onWish}
          aria-label={`${wished ? "Remove" : "Save"} ${product.title} ${wished ? "from" : "to"} wishlist`}
        >
          <Heart size={17} fill={wished ? "currentColor" : "none"} />
        </button>
        {product.tags.includes("Bestseller") && (
          <span className="bestseller">Bestseller</span>
        )}
      </div>
      <div className="product-meta">
        <span>{SELLER_NAME.toUpperCase()}</span>
        <span>
          <Star size={11} fill="currentColor" /> {product.rating}{" "}
          <small>({product.reviewCount})</small>
        </span>
      </div>
      <button className="product-title" onClick={onProduct}>
        {product.title}
      </button>
      <div className="product-bottom">
        <div>
          <strong>{money(product.price)}</strong>
          {product.originalPrice && <del>{money(product.originalPrice)}</del>}
        </div>
        {product.subscriptionIncluded && (
          <button className="included" onClick={onProduct}>
            <span>✺</span> Included with Pass
          </button>
        )}
      </div>
    </article>
  );
}
export function HomePage(props: CatalogProps) {
  const [activeCat, setActiveCat] = useState("All products");
  const [tab, setTab] = useState("Trending now");
  const [offset, setOffset] = useState(0);
  let items = props.products.filter(
    (p) => activeCat === "All products" || p.category === activeCat,
  );
  if (tab === "Top rated")
    items = [...items].sort(
      (a, b) => b.rating - a.rating || b.reviewCount - a.reviewCount,
    );
  if (tab === "New arrivals") items = [...items].reverse();
  const shown = items.slice(offset, offset + 4);
  return (
    <>
      <section className="hero page-width">
        <div className="hero-copy">
          <div className="hero-eyebrow">
            <span /> A WORLD OF DIGITAL POSSIBILITIES
          </div>
          <h1>
            Big ideas.
            <br />
            Limitless{" "}
            <span>
              possibilities.
              <svg viewBox="0 0 470 20" aria-hidden="true">
                <path
                  d="M3 15C136 2 304 3 464 12"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="6"
                  strokeLinecap="round"
                />
              </svg>
            </span>
          </h1>
          <p>
            The tools to create. The inspiration to grow.
            <br className="desktop-break" /> Discover extraordinary digital
            products, all in one place.
          </p>
          <div className="hero-actions">
            <button
              className="btn btn-primary"
              onClick={() => props.onExplore()}
            >
              Explore the collection <ArrowUpRight size={18} />
            </button>
            <button className="hero-pass" onClick={props.onMembership}>
              <span>
                <Play size={11} fill="currentColor" />
              </span>{" "}
              Meet the Digital Pass
            </button>
          </div>
          <div className="hero-proof">
            <div className="member-avatars">
              <span>AJ</span>
              <span>MC</span>
              <span>OS</span>
              <span>EK</span>
            </div>
            <div>
              <div className="proof-stars">★★★★★</div>
              <span>Made for curious minds & creative souls</span>
            </div>
          </div>
        </div>
        <div className="hero-visual">
          <div className="hero-image-wrap">
            <img
              src="/images/rtr-digital-hero.webp"
              alt="Lavender book, charcoal headphones, and a tablet arranged with glass arches and chrome sculptures in a mint studio."
            />
            <span className="visual-label">
              <span /> A LITTLE INSPIRATION GOES A LONG WAY
            </span>
          </div>
          <div className="floating-label top-label">
            <span className="floating-icon">
              <Sparkles size={20} />
            </span>
            <div>
              Good things. Digital.<small>Extraordinary by design.</small>
            </div>
            <span className="label-star">✺</span>
          </div>
          <button
            className="floating-label bottom-label"
            onClick={props.onMembership}
          >
            <span className="floating-icon green">
              <InfinityIcon size={25} />
            </span>
            <div>
              One pass. Endless potential.
              <small>Your next chapter starts at $9/month.</small>
            </div>
            <ArrowUpRight size={18} />
          </button>
          <span className="hero-spark spark-one">✺</span>
          <span className="hero-spark spark-two">✦</span>
        </div>
      </section>
      <section className="benefit-bar page-width" aria-label="Store benefits">
        <span>
          <BadgeCheck /> Thoughtfully curated
        </span>
        <span>
          <Download /> Yours in an instant
        </span>
        <span>
          <ShieldCheck /> Safe & secure checkout
        </span>
        <span>
          <InfinityIcon /> One membership. More possibilities.
        </span>
      </section>
      <section className="discovery page-width" id="discovery">
        <div className="section-heading">
          <div>
            <span className="eyebrow">FIND YOUR NEXT FAVORITE</span>
            <h2>
              A little of everything.
              <br className="mobile-only" /> A lot of possibility.
            </h2>
          </div>
          <button className="text-link" onClick={() => props.onExplore()}>
            Explore all products <ArrowUpRight size={17} />
          </button>
        </div>
        <div className="category-row">
          {categoryList.map(({ name, icon: Icon }) => (
            <button
              key={name}
              className={`category-pill ${activeCat === name ? "active" : ""}`}
              onClick={() => {
                setActiveCat(name);
                setOffset(0);
              }}
            >
              <Icon size={17} />
              {name}
            </button>
          ))}
        </div>
        <div className="catalog-toolbar">
          <div className="catalog-tabs">
            {["Trending now", "New arrivals", "Top rated"].map((t) => (
              <button
                className={tab === t ? "active" : ""}
                key={t}
                onClick={() => {
                  setTab(t);
                  setOffset(0);
                }}
              >
                {t === "Trending now" && <span>↗</span>}
                {t}
              </button>
            ))}
          </div>
          <span className="curation-note">
            <span /> Handpicked. Never ordinary.
          </span>
        </div>
        <div className="product-grid">
          {shown.map((p) => (
            <ProductCard
              key={p.id}
              product={p}
              wished={props.wishlist.includes(p.id)}
              onWish={() => props.onWish(p)}
              onProduct={() => props.onProduct(p)}
            />
          ))}
        </div>
        {items.length === 0 && (
          <div className="empty-state">
            Something new is on its way. Explore another category.
          </div>
        )}
        <div className="catalog-bottom">
          <span>Less searching. More creating.</span>
          <div>
            <button
              className="round-button"
              aria-label="Previous products"
              disabled={offset === 0}
              onClick={() => setOffset(Math.max(0, offset - 4))}
            >
              <ChevronLeft size={17} />
            </button>
            <button
              className="round-button"
              aria-label="Next products"
              disabled={offset + 4 >= items.length}
              onClick={() => setOffset(offset + 4)}
            >
              <ChevronRight size={17} />
            </button>
          </div>
        </div>
      </section>
      <section className="pass-banner page-width">
        <div className="pass-pattern" aria-hidden="true">
          ✺
        </div>
        <div className="pass-banner-copy">
          <span className="eyebrow">THE RTR DIGITAL PASS</span>
          <h2>
            Less limits.
            <br />
            <span>More you.</span>
          </h2>
          <p>
            Your ideas deserve room to grow. Unlock a world of digital
            <br className="desktop-break" /> essentials with one beautifully
            simple membership.
          </p>
          <div className="pass-perks">
            <span>
              <Check size={14} /> Every category, one pass
            </span>
            <span>
              <Check size={14} /> New finds, all the time
            </span>
            <span>
              <Check size={14} /> Cancel anytime
            </span>
          </div>
        </div>
        <div className="pass-banner-card">
          <span className="pass-card-top">
            YOUR ALL-ACCESS ADVANTAGE <Sparkles size={17} />
          </span>
          <div className="pass-price">
            <span>From</span>
            <strong>
              $9<small>/ month</small>
            </strong>
          </div>
          <button className="btn btn-lime" onClick={props.onMembership}>
            Find your perfect pass <ArrowUpRight size={18} />
          </button>
          <small>A little investment. A world of possibility.</small>
        </div>
      </section>
      <section className="collections-section page-width">
        <div className="section-heading">
          <div>
            <span className="eyebrow">GOOD THINGS, BROUGHT TOGETHER</span>
            <h2>Curated for your next chapter.</h2>
          </div>
          <button className="text-link" onClick={props.onCollection}>
            All collections <ArrowUpRight size={17} />
          </button>
        </div>
        <div className="collection-grid">
          <button
            className="collection-card creator-collection"
            onClick={() => props.onExplore("Design assets")}
          >
            <div>
              <span>THE CREATOR'S TOOLKIT</span>
              <h3>
                A head start on
                <br />
                your next big idea.
              </h3>
              <p>Design assets, templates & a little creative magic.</p>
              <span className="collection-link">
                Find your flow <ArrowRight size={17} />
              </span>
            </div>
            <div className="collection-art">
              <span>✺</span>
              <i />
              <b>abc.</b>
            </div>
          </button>
          <button
            className="collection-card calm-collection"
            onClick={() => props.onExplore("Audio & music")}
          >
            <div>
              <span>A LITTLE SPACE TO GROW</span>
              <h3>
                Tune out the noise.
                <br />
                Tune into you.
              </h3>
              <p>Read, listen, learn. At your own pace.</p>
              <span className="collection-link">
                Explore the collection <ArrowRight size={17} />
              </span>
            </div>
            <div className="calm-art">
              <span />
              <i />
              <AudioLines size={70} strokeWidth={1} />
            </div>
          </button>
        </div>
      </section>
      <section className="why-section page-width">
        <span className="eyebrow">DIGITAL FINDS. HUMAN TOUCH.</span>
        <h2>
          Thoughtfully made.
          <br />
          Endlessly <span>yours.</span>
        </h2>
        <div className="why-grid">
          {[
            {
              icon: Layers3,
              title: "One home for every possibility.",
              text: "Books, beats, tools, templates, and everything in between. Your creative world, connected.",
            },
            {
              icon: Sparkles,
              title: "Quality you can feel.",
              text: "Original resources with clear previews, useful details, and transparent license information.",
            },
            {
              icon: LockKeyhole,
              title: "Good to go. Yours to keep.",
              text: "Simple checkout. Instant library access. One-time purchases stay in your library.",
            },
          ].map(({ icon: Icon, title, text }) => (
            <div key={title}>
              <span className="why-icon">
                <Icon size={23} />
              </span>
              <h3>{title}</h3>
              <p>{text}</p>
            </div>
          ))}
        </div>
      </section>
    </>
  );
}
export function ExplorePage(
  props: CatalogProps & {
    initialCategory: string;
    search: string;
    onSearch: (s: string) => void;
    wishlistOnly: boolean;
  },
) {
  const [category, setCategory] = useState(
    props.initialCategory || "All products",
  );
  const [sort, setSort] = useState("popular");
  const [maxPrice, setMaxPrice] = useState(150);
  const [included, setIncluded] = useState(false);
  const [filters, setFilters] = useState(false);
  let products = props.products.filter(
    (p) =>
      (category === "All products" || p.category === category) &&
      (!props.wishlistOnly || props.wishlist.includes(p.id)) &&
      p.price <= maxPrice &&
      (!included || p.subscriptionIncluded) &&
      `${p.title} ${p.creator} ${p.category} ${p.tags.join(" ")}`
        .toLowerCase()
        .includes(props.search.toLowerCase()),
  );
  products = [...products].sort((a, b) =>
    sort === "low"
      ? a.price - b.price
      : sort === "high"
        ? b.price - a.price
        : sort === "rating"
          ? b.rating - a.rating
          : (b.downloads || 0) - (a.downloads || 0),
  );
  return (
    <section className="page-width page-shell explore-page">
      <div className="page-intro">
        <span className="eyebrow">YOUR NEXT GREAT FIND IS HERE</span>
        <h1>
          {props.wishlistOnly
            ? "Your little list of possibilities."
            : "A world worth exploring."}
        </h1>
        <p>
          {props.wishlistOnly
            ? "Keep the things that spark something. Come back whenever you’re ready."
            : "Discover the tools, stories, and sounds that move you forward."}
        </p>
      </div>
      <div className="explore-search">
        <Search size={21} />
        <input
          aria-label="Search the collection"
          placeholder="What will you create next?"
          value={props.search}
          onChange={(e) => props.onSearch(e.target.value)}
        />
        {props.search && (
          <button
            className="icon-button"
            aria-label="Clear search"
            onClick={() => props.onSearch("")}
          >
            <X size={17} />
          </button>
        )}
        <span>Search the collection</span>
      </div>
      <div className="category-row">
        {categoryList.map(({ name, icon: Icon }) => (
          <button
            key={name}
            className={`category-pill ${category === name ? "active" : ""}`}
            onClick={() => setCategory(name)}
          >
            <Icon size={16} />
            {name}
          </button>
        ))}
      </div>
      <div className="explore-toolbar">
        <span>
          <strong>{products.length}</strong>{" "}
          {props.wishlistOnly ? "saved favorites" : "extraordinary finds"}
        </span>
        <div>
          <button
            className={`filter-button ${filters ? "active" : ""}`}
            onClick={() => setFilters(!filters)}
          >
            <SlidersHorizontal size={15} /> Filters
          </button>
          <label className="sort-select">
            <span>Sort by:</span>
            <select
              aria-label="Sort products"
              value={sort}
              onChange={(e) => setSort(e.target.value)}
            >
              <option value="popular">Most popular</option>
              <option value="rating">Top rated</option>
              <option value="low">Price: low to high</option>
              <option value="high">Price: high to low</option>
            </select>
            <ChevronDown size={13} />
          </label>
        </div>
      </div>
      {filters && (
        <div className="filter-panel">
          <label>
            Maximum price: {money(maxPrice)}
            <input
              aria-label="Maximum price"
              type="range"
              min="0"
              max="150"
              step="5"
              value={maxPrice}
              onChange={(e) => setMaxPrice(Number(e.target.value))}
            />
          </label>
          <label className="checkbox-label">
            <input
              type="checkbox"
              checked={included}
              onChange={(e) => setIncluded(e.target.checked)}
            />{" "}
            Included with Digital Pass
          </label>
          <button
            className="text-link"
            onClick={() => {
              setCategory("All products");
              setMaxPrice(150);
              setIncluded(false);
              props.onSearch("");
            }}
          >
            Reset filters
          </button>
        </div>
      )}
      <div className="product-grid explore-grid">
        {products.map((p) => (
          <ProductCard
            key={p.id}
            product={p}
            wished={props.wishlist.includes(p.id)}
            onWish={() => props.onWish(p)}
            onProduct={() => props.onProduct(p)}
          />
        ))}
      </div>
      {!products.length && (
        <div className="empty-state">
          <Search size={35} />
          <h3>No finds just yet.</h3>
          <p>
            Try another search or loosen your filters. Your next favorite is out
            there.
          </p>
          <button
            className="btn btn-outline"
            onClick={() => {
              props.onSearch("");
              setCategory("All products");
              setMaxPrice(150);
              setIncluded(false);
            }}
          >
            Explore everything
          </button>
        </div>
      )}
    </section>
  );
}
const planData = [
  {
    id: "starter",
    name: "The Explorer",
    label: "A little curiosity goes a long way.",
    monthly: 9,
    yearly: 7,
    features: [
      "The complete digital collection",
      "Personal-use license",
      "Instant library access",
      "Fresh finds as they arrive",
      "Access throughout your paid period",
    ],
  },
  {
    id: "creator",
    name: "The Creator",
    label: "For the things you’re ready to make.",
    monthly: 19,
    yearly: 15,
    features: [
      "Everything in Explorer",
      "Commercial-use license",
      "Use assets in client projects",
      "Cancel or resume renewal",
      "Switch plans as you grow",
    ],
  },
  {
    id: "studio",
    name: "The Studio",
    label: "Good things happen together.",
    monthly: 39,
    yearly: 31,
    features: [
      "Everything in Creator",
      "Project license for a team of 5",
      "Shared project usage rights",
      "Account-linked support requests",
      "All categories, one membership",
    ],
  },
];
export function MembershipPage({
  onChoose,
  onExplore,
  onManage,
}: {
  onChoose: (plan: string, interval: string) => void;
  onExplore: () => void;
  onManage?: () => void;
}) {
  const [yearly, setYearly] = useState(true);
  const [faq, setFaq] = useState<number | null>(0);
  return (
    <section className="page-width page-shell membership-page">
      <div className="page-intro centered">
        <span className="eyebrow">ONE PASS. ALL THE POSSIBILITIES.</span>
        <h1>
          Make room for
          <br />
          your <em>next big thing.</em>
        </h1>
        <p>
          One simple membership. A whole world of digital inspiration.
          <br />
          Find your perfect fit, and let your ideas take it from there.
        </p>
        <div className="billing-switch">
          <button
            className={!yearly ? "active" : ""}
            onClick={() => setYearly(false)}
          >
            Monthly
          </button>
          <button
            className={yearly ? "active" : ""}
            onClick={() => setYearly(true)}
          >
            Yearly <span>Save up to 26%</span>
          </button>
        </div>
      </div>
      <div className="pricing-grid">
        {planData.map((p) => (
          <article
            className={`pricing-card ${p.id === "creator" ? "recommended" : ""}`}
            key={p.id}
          >
            {p.id === "creator" && (
              <div className="popular-ribbon">
                <Sparkles size={13} /> THE CREATIVE SWEET SPOT
              </div>
            )}
            <span className="plan-icon">
              {p.id === "starter" ? (
                <Search />
              ) : p.id === "creator" ? (
                <Sparkles />
              ) : (
                <Layers3 />
              )}
            </span>
            <h2>{p.name}</h2>
            <p>{p.label}</p>
            <div className="plan-price">
              <strong>${yearly ? p.yearly : p.monthly}</strong>
              <span>/ month</span>
            </div>
            <small>
              {yearly
                ? `$${p.yearly * 12} billed yearly`
                : "Billed monthly. Your pace, your choice."}
            </small>
            <button
              className={`btn ${p.id === "creator" ? "btn-primary" : "btn-outline"}`}
              onClick={() => onChoose(p.id, yearly ? "yearly" : "monthly")}
            >
              Choose {p.name.replace("The ", "")} <ArrowUpRight size={17} />
            </button>
            <div className="plan-features">
              {p.features.map((f) => (
                <span key={f}>
                  <Check size={16} />
                  {f}
                </span>
              ))}
            </div>
          </article>
        ))}
      </div>
      <div className="pricing-assurance">
        <ShieldCheck size={17} /> Secure checkout <span>·</span> No hidden fees{" "}
        <span>·</span> Cancel renewal anytime
      </div>
      {onManage && (
        <div className="membership-management-link">
          <button className="text-link" onClick={onManage}>
            Manage your membership, team & trial eligibility{" "}
            <ArrowUpRight size={15} />
          </button>
        </div>
      )}
      <div className="membership-explainer">
        <span>✺</span>
        <div>
          <h3>Great on your own. Extraordinary with a pass.</h3>
          <p>
            Prefer a single find? Every product is available to purchase
            individually, too.
          </p>
        </div>
        <button className="text-link" onClick={onExplore}>
          Browse the collection <ArrowUpRight size={17} />
        </button>
      </div>
      <section className="faq-section">
        <span className="eyebrow">A LITTLE CLARITY</span>
        <h2>Good questions. Straight answers.</h2>
        {[
          {
            q: "What’s included in the Digital Pass?",
            a: "Every product marked “Included with Pass” is available in your library while your membership is active. Browse design assets, e-books, audio, video, courses, templates, and software. Each product lists its formats and usage details.",
          },
          {
            q: "Can I cancel my membership?",
            a: "Yes. You can cancel renewal from your Library → Membership at any time. Your access continues until the end of the period you have already paid for. You can resume renewal before that date.",
          },
          {
            q: "Can I use products for commercial projects?",
            a: "Every product is sold and licensed by RTR Digital. The Creator plan includes a commercial-use license for client projects. The Studio plan covers a team of up to five seats. The Explorer plan is for personal use. Third-party trademarks and redistribution of original assets are not included.",
          },
          {
            q: "What happens to my individual purchases?",
            a: "Individual purchases stay in your library independently of a subscription. You can return to download them anytime. Subscription-only access ends when your membership expires.",
          },
          {
            q: "How does checkout work in this preview?",
            a: "In demo mode, checkout is clearly labeled and no payment is collected. Live payments require the site owner to configure Stripe and its signed webhook. The sample downloads are explicitly labeled preview files.",
          },
        ].map((item, i) => (
          <div className="faq-item" key={item.q}>
            <button
              onClick={() => setFaq(faq === i ? null : i)}
              aria-expanded={faq === i}
            >
              {item.q}
              <span>{faq === i ? "−" : "+"}</span>
            </button>
            {faq === i && <p>{item.a}</p>}
          </div>
        ))}
      </section>
    </section>
  );
}
