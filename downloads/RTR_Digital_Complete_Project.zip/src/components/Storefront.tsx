import {
  ArrowDownRight,
  ArrowUpRight,
  Asterisk,
  AudioLines,
  BookOpen,
  Check,
  ChevronDown,
  Code2,
  Film,
  Eye,
  Grid2X2,
  Heart,
  LayoutTemplate,
  Palette,
  Play,
  Search,
  ShieldCheck,
  SlidersHorizontal,
  X,
} from "lucide-react";
import { useState } from "react";
import type { Product } from "../lib/types";
import { money } from "../lib/api";
import { SELLER_NAME } from "../lib/brand";
import { ProductArt } from "./Brand";
export const categoryList = [
  { name: "All products", icon: Grid2X2 },
  { name: "Design assets", icon: Palette },
  { name: "E-books", icon: BookOpen },
  { name: "Audio & music", icon: AudioLines },
  { name: "Courses", icon: Play },
  { name: "Software", icon: Code2 },
  { name: "Templates", icon: LayoutTemplate },
  { name: "Video", icon: Film },
];
export interface CatalogProps {
  products: Product[];
  wishlist: string[];
  onWish: (p: Product) => void;
  onProduct: (p: Product) => void;
  onExplore: (category?: string) => void;
  onMembership: () => void;
  onCollection: () => void;
  onSearch?: (query: string) => void;
}
export function ProductCard({
  product,
  wished,
  onWish,
  onProduct,
}: {
  product: Product;
  wished: boolean;
  onWish: () => void;
  onProduct: () => void;
}) {
  return (
    <article
      className={`product-card studio-product-card studio-product-${product.art}`}
    >
      <div className="product-picture">
        <button
          className="art-link"
          onClick={onProduct}
          aria-label={`View ${product.title}`}
        >
          <ProductArt product={product} />
        </button>
        <span className="product-category">{product.category}</span>
        <button
          className={`wish-button ${wished ? "is-wished" : ""}`}
          onClick={onWish}
          aria-pressed={wished}
          aria-label={`${wished ? "Remove" : "Save"} ${product.title} ${wished ? "from" : "to"} wishlist`}
        >
          <Heart size={17} fill={wished ? "currentColor" : "none"} />
        </button>
        <button
          className="studio-quick-view"
          onClick={onProduct}
          aria-label={`Quick view ${product.title}`}
        >
          <Eye size={14} /> Quick view <ArrowUpRight size={14} />
        </button>
      </div>
      <div className="product-meta">
        <span>{product.format}</span>
        <span>{product.size}</span>
      </div>
      <button className="product-title" onClick={onProduct}>
        {product.title}
      </button>
      <div className="product-bottom">
        <div>
          <strong>{money(product.price)}</strong>
          {product.originalPrice && <del>{money(product.originalPrice)}</del>}
          <span className="studio-price-unit">USD</span>
        </div>
        {product.subscriptionIncluded && (
          <button className="included" onClick={onProduct}>
            <span aria-hidden="true">
              <Asterisk size={12} />
            </span>{" "}
            Included with Pass
          </button>
        )}
      </div>
      <span className="studio-product-seller">By {SELLER_NAME}</span>
    </article>
  );
}
export function ExplorePage(
  props: CatalogProps & {
    initialCategory: string;
    search: string;
    onSearch: (s: string) => void;
    wishlistOnly: boolean;
  },
) {
  const [category, setCategory] = useState(
    props.initialCategory || "All products",
  );
  const [sort, setSort] = useState("popular");
  const [maxPrice, setMaxPrice] = useState(150);
  const [included, setIncluded] = useState(false);
  const [filters, setFilters] = useState(false);
  const resetFilters = () => {
    setCategory("All products");
    setMaxPrice(150);
    setIncluded(false);
    props.onSearch("");
  };
  const hasFilters =
    category !== "All products" || maxPrice < 150 || included || !!props.search;
  let products = props.products.filter(
    (p) =>
      (category === "All products" || p.category === category) &&
      (!props.wishlistOnly || props.wishlist.includes(p.id)) &&
      p.price <= maxPrice &&
      (!included || p.subscriptionIncluded) &&
      `${p.title} ${SELLER_NAME} ${p.category} ${p.format} ${p.description} ${p.tags.join(" ")}`
        .toLowerCase()
        .includes(props.search.toLowerCase()),
  );
  products = [...products].sort((a, b) =>
    sort === "low"
      ? a.price - b.price
      : sort === "high"
        ? b.price - a.price
        : sort === "rating"
          ? b.rating - a.rating
          : (b.downloads || 0) - (a.downloads || 0),
  );
  return (
    <section className="page-width page-shell explore-page studio-catalog studio-explore">
      <header className="studio-catalog-intro">
        <div>
          <span className="studio-section-label">
            <span />{" "}
            {props.wishlistOnly
              ? "YOUR SAVED COLLECTION"
              : "THE DIGITAL COLLECTION"}
          </span>
          <h1>
            {props.wishlistOnly ? (
              "Your little list of possibilities."
            ) : (
              <>
                Good tools.
                <br />
                Great starting points<span>.</span>
              </>
            )}
          </h1>
          <p>
            {props.wishlistOnly
              ? "The ones worth coming back to. Keep your next project within reach."
              : "Original assets, practical tools, and fresh perspectives. Find the right piece for whatever comes next."}
          </p>
        </div>
        <div className="studio-catalog-index" aria-hidden="true">
          <span>
            {props.wishlistOnly ? "SAVED FOR LATER" : "CURATED BY RTR DIGITAL"}
          </span>
          <strong>
            {String(
              props.wishlistOnly
                ? props.wishlist.length
                : props.products.length,
            ).padStart(2, "0")}
            <ArrowDownRight />
          </strong>
          <small>
            {props.wishlistOnly
              ? "Ideas, on standby."
              : "Digital products. Ready when you are."}
          </small>
        </div>
      </header>
      <div className="explore-search">
        <Search size={21} aria-hidden="true" />
        <input
          aria-label="Search the collection"
          placeholder="Search assets, ideas, formats…"
          value={props.search}
          onChange={(e) => props.onSearch(e.target.value)}
        />
        {props.search ? (
          <button
            className="icon-button"
            aria-label="Clear search"
            onClick={() => props.onSearch("")}
          >
            <X size={17} />
          </button>
        ) : (
          <span className="studio-search-hint">
            FIND YOUR NEXT THING <ArrowUpRight size={15} />
          </span>
        )}
      </div>
      <div className="category-row" aria-label="Product categories">
        {categoryList.map(({ name, icon: Icon }) => (
          <button
            key={name}
            className={`category-pill ${category === name ? "active" : ""}`}
            onClick={() => setCategory(name)}
            aria-pressed={category === name}
          >
            <Icon size={16} />
            {name}
          </button>
        ))}
      </div>
      <div className="explore-toolbar">
        <span role="status" aria-live="polite">
          <strong>{products.length}</strong>{" "}
          {props.wishlistOnly ? "saved favorites" : "products"}
          <span className="studio-results-category">
            {" "}
            / {category === "All products" ? "All categories" : category}
          </span>
        </span>
        <div>
          <button
            className={`filter-button ${filters ? "active" : ""}`}
            onClick={() => setFilters(!filters)}
            aria-expanded={filters}
            aria-controls="catalog-filters"
          >
            <SlidersHorizontal size={15} /> Filters
            {(included || maxPrice < 150) && (
              <span className="studio-filter-dot" aria-hidden="true" />
            )}
          </button>
          <label className="sort-select">
            <span>Sort by</span>
            <select
              aria-label="Sort products"
              value={sort}
              onChange={(e) => setSort(e.target.value)}
            >
              <option value="popular">Most popular</option>
              <option value="rating">Top rated</option>
              <option value="low">Price: low to high</option>
              <option value="high">Price: high to low</option>
            </select>
            <ChevronDown size={14} aria-hidden="true" />
          </label>
        </div>
      </div>
      {filters && (
        <div className="filter-panel" id="catalog-filters">
          <label className="studio-price-filter">
            <span>
              Maximum price <strong>{money(maxPrice)} USD</strong>
            </span>
            <input
              aria-label="Maximum price"
              type="range"
              min="0"
              max="150"
              step="5"
              value={maxPrice}
              onChange={(e) => setMaxPrice(Number(e.target.value))}
            />
          </label>
          <label className="checkbox-label">
            <input
              type="checkbox"
              checked={included}
              onChange={(e) => setIncluded(e.target.checked)}
            />{" "}
            Included with Digital Pass
          </label>
          <button className="text-link" onClick={resetFilters}>
            Reset filters <X size={14} />
          </button>
        </div>
      )}
      {hasFilters && !filters && (
        <div className="studio-active-filters">
          {category !== "All products" && (
            <button
              onClick={() => setCategory("All products")}
              aria-label={`Remove ${category} filter`}
            >
              {category}
              <X size={12} />
            </button>
          )}
          {props.search && (
            <button
              onClick={() => props.onSearch("")}
              aria-label="Remove search filter"
            >
              “{props.search}”<X size={12} />
            </button>
          )}
          {maxPrice < 150 && (
            <button
              onClick={() => setMaxPrice(150)}
              aria-label="Remove maximum price filter"
            >
              Up to {money(maxPrice)}
              <X size={12} />
            </button>
          )}
          {included && (
            <button onClick={() => setIncluded(false)}>
              Included with Pass
              <X size={12} />
            </button>
          )}
          <button className="studio-clear-filters" onClick={resetFilters}>
            Clear all
          </button>
        </div>
      )}
      <div className="product-grid explore-grid">
        {products.map((p) => (
          <ProductCard
            key={p.id}
            product={p}
            wished={props.wishlist.includes(p.id)}
            onWish={() => props.onWish(p)}
            onProduct={() => props.onProduct(p)}
          />
        ))}
      </div>
      {!products.length && (
        <div className="empty-state studio-empty-state">
          <span>
            <Search size={28} />
          </span>
          <h3>No finds just yet.</h3>
          <p>
            {props.wishlistOnly && !hasFilters
              ? "Save a product with the heart button and it will be waiting here."
              : "Try a different search or adjust your filters. A good starting point is closer than you think."}
          </p>
          <button
            className="btn btn-outline"
            onClick={
              props.wishlistOnly && !hasFilters
                ? () => props.onExplore()
                : resetFilters
            }
          >
            {props.wishlistOnly && !hasFilters
              ? "Browse the collection"
              : "Explore everything"}
            <ArrowUpRight size={16} />
          </button>
        </div>
      )}
      {!!products.length && (
        <div className="studio-catalog-end">
          <span>THE END OF THE SCROLL. THE START OF SOMETHING.</span>
          <ArrowUpRight size={20} />
          <p>All products sold and licensed by {SELLER_NAME}. Prices in USD.</p>
        </div>
      )}
    </section>
  );
}
const planData = [
  {
    id: "starter",
    name: "The Explorer",
    label: "Room to explore your own ideas.",
    monthly: 9,
    yearly: 7,
    audience: "FOR PERSONAL PROJECTS",
    features: [
      "Products marked Included with Pass",
      "Personal-use license",
      "Instant access to your library",
      "Access for your paid membership period",
      "Individual account",
    ],
  },
  {
    id: "creator",
    name: "The Creator",
    label: "A dependable toolkit for your work.",
    monthly: 19,
    yearly: 15,
    audience: "FOR INDEPENDENT CREATORS",
    features: [
      "Everything in Explorer",
      "Commercial-use license",
      "Use assets in client projects",
      "One creator, many projects",
      "Cancel or resume Stripe renewal",
    ],
  },
  {
    id: "studio",
    name: "The Studio",
    label: "A shared foundation for your team.",
    monthly: 39,
    yearly: 31,
    audience: "FOR SMALL TEAMS",
    features: [
      "Everything in Creator",
      "Project license for a team of 5",
      "Shared project usage rights",
      "Account-linked support requests",
      "One membership for your team",
    ],
  },
];
export function MembershipPage({
  onChoose,
  onExplore,
  onManage,
}: {
  onChoose: (plan: string, interval: string) => void;
  onExplore: () => void;
  onManage?: () => void;
}) {
  const [yearly, setYearly] = useState(true);
  const [faq, setFaq] = useState<number | null>(0);
  const faqs = [
    {
      q: "What’s included in the Digital Pass?",
      a: "Every product marked “Included with Pass” is available in your library while your membership is active. Explore design assets, e-books, audio, video, courses, templates, and software. Check each product for formats and usage details.",
    },
    {
      q: "Can I cancel my membership?",
      a: "You can cancel Stripe renewal from your Library → Membership at any time. Access continues until the end of your paid period. You can resume renewal before that date. Prepaid memberships do not renew automatically.",
    },
    {
      q: "Can I use products for commercial projects?",
      a: "Every product is sold and licensed by RTR Digital. Creator includes a commercial-use license for client projects. Studio covers a team of up to five seats. Explorer is for personal use. Third-party trademarks and redistribution of original assets are not included.",
    },
    {
      q: "What happens to my individual purchases?",
      a: "Individual purchases stay in your library independently of a subscription. You can return to download them. Subscription-only access ends when your membership expires.",
    },
    {
      q: "Which payment methods renew automatically?",
      a: "Stripe memberships renew monthly or yearly until you cancel. PayPal, Razorpay, and bank transfer cover one prepaid period with no automatic renewal. Available payment methods appear at checkout. Bank transfer access starts after cleared funds are verified.",
    },
  ];
  return (
    <section className="page-width page-shell membership-page studio-catalog studio-pass-page">
      <header className="studio-membership-intro">
        <div>
          <span className="studio-section-label">
            <span /> THE RTR DIGITAL PASS
          </span>
          <h1>
            Make room for
            <br />
            your next <span>big thing.</span>
          </h1>
        </div>
        <div className="studio-membership-summary">
          <span className="studio-pass-mark" aria-hidden="true">
            <Asterisk size={63} strokeWidth={1.4} />
          </span>
          <p>
            More of what moves you forward.
            <br />
            One membership for the tools, assets, and ideas behind your next
            project.
          </p>
          <button className="text-link" onClick={onExplore}>
            Explore what’s included <ArrowUpRight size={16} />
          </button>
        </div>
      </header>
      <div className="studio-plan-toolbar">
        <p>A plan for the way you create.</p>
        <div className="billing-switch" aria-label="Billing interval">
          <button
            className={!yearly ? "active" : ""}
            onClick={() => setYearly(false)}
            aria-pressed={!yearly}
          >
            Monthly
          </button>
          <button
            className={yearly ? "active" : ""}
            onClick={() => setYearly(true)}
            aria-pressed={yearly}
          >
            Yearly <span>Save up to 22%</span>
          </button>
        </div>
        <span className="studio-currency-note">ALL PRICES IN USD</span>
      </div>
      <div className="pricing-grid">
        {planData.map((p, i) => (
          <article
            className={`pricing-card ${p.id === "creator" ? "recommended" : ""}`}
            key={p.id}
          >
            <div className="studio-plan-top">
              <span>
                0{i + 1} / {p.audience}
              </span>
              {p.id === "creator" && (
                <span className="studio-recommendation">
                  OUR PICK <ArrowUpRight size={13} />
                </span>
              )}
            </div>
            <h2>{p.name.replace("The ", "")}</h2>
            <p>{p.label}</p>
            <div className="plan-price">
              <strong>${yearly ? p.yearly : p.monthly}</strong>
              <span>/ month</span>
            </div>
            <small>
              {yearly
                ? `$${p.yearly * 12} billed yearly`
                : `$${p.monthly} billed monthly`}
            </small>
            <button
              className={`btn ${p.id === "creator" ? "btn-primary" : "btn-outline"}`}
              onClick={() => onChoose(p.id, yearly ? "yearly" : "monthly")}
            >
              Choose {p.name.replace("The ", "")} <ArrowUpRight size={17} />
            </button>
            <div className="plan-features">
              {p.features.map((f) => (
                <span key={f}>
                  <Check size={16} />
                  {f}
                </span>
              ))}
            </div>
            <span className="studio-plan-license">
              {p.id === "starter"
                ? "YOUR CURIOSITY, COVERED."
                : p.id === "creator"
                  ? "FROM IDEA TO CLIENT DELIVERY."
                  : "GOOD WORK HAPPENS TOGETHER."}
            </span>
          </article>
        ))}
      </div>
      <div className="studio-billing-note">
        <ShieldCheck size={22} />
        <div>
          <strong>Clear terms. A considered choice.</strong>
          <p>
            Stripe memberships renew until you cancel. Other available payment
            methods cover one prepaid period without automatic renewal. Review
            the method and total at checkout.
          </p>
        </div>
        <span>
          YOUR WORK.
          <br />
          YOUR PACE.
        </span>
      </div>
      {onManage && (
        <div className="membership-management-link">
          <button className="text-link" onClick={onManage}>
            Manage your membership, team & trial eligibility{" "}
            <ArrowUpRight size={15} />
          </button>
        </div>
      )}
      <div className="membership-explainer">
        <span aria-hidden="true">
          <ArrowUpRight size={30} strokeWidth={1.4} />
        </span>
        <div>
          <h3>Just here for one good thing?</h3>
          <p>Every product is also available as an individual purchase.</p>
        </div>
        <button className="text-link" onClick={onExplore}>
          Browse the collection <ArrowUpRight size={17} />
        </button>
      </div>
      <section className="faq-section">
        <div className="studio-faq-heading">
          <span className="studio-section-label">THE DETAILS</span>
          <h2>
            A little clarity.
            <br />A lot less guesswork.
          </h2>
          <p>Know what’s included before you choose.</p>
        </div>
        <div className="studio-faq-list">
          {faqs.map((item, i) => (
            <div
              className={`faq-item ${faq === i ? "is-open" : ""}`}
              key={item.q}
            >
              <button
                onClick={() => setFaq(faq === i ? null : i)}
                aria-expanded={faq === i}
                aria-controls={`membership-faq-${i}`}
              >
                <span className="studio-faq-number">0{i + 1}</span>
                {item.q}
                <span className="studio-faq-plus">{faq === i ? "−" : "+"}</span>
              </button>
              {faq === i && <p id={`membership-faq-${i}`}>{item.a}</p>}
            </div>
          ))}
        </div>
      </section>
    </section>
  );
}
