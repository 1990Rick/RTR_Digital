export const SELLER_NAME = "RTR Digital";
