export interface Product {
  id: string;
  title: string;
  creator: string;
  category: string;
  description: string;
  price: number;
  originalPrice?: number;
  rating: number;
  reviewCount: number;
  format: string;
  size: string;
  accent: string;
  art: string;
  tags: string[];
  featured?: boolean;
  subscriptionIncluded: boolean;
  downloads?: number;
  status?: string;
  image?: string;
  isSample?: boolean;
  ratingIsSample?: boolean;
}
export interface Subscription {
  plan: string;
  status: string;
  interval: string;
  currentPeriodEnd?: string;
  cancelAtPeriodEnd?: boolean;
  isTrial?: boolean;
  isPrepaid?: boolean;
  autoRenew?: boolean;
  mode?: string;
}
export interface User {
  id: string;
  name: string;
  email: string;
  role: string;
  subscription: Subscription | null;
}
export type Page =
  | "home"
  | "explore"
  | "membership"
  | "collections"
  | "library"
  | "admin"
  | "about"
  | "support"
  | "legal"
  | "compare"
  | "account"
  | "members"
  | "publisher"
  | "operations"
  | "billing";
export interface ToastMessage {
  message: string;
  kind?: "success" | "error";
}
