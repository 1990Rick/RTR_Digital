import express from "express";
import { brandProduct } from "../brand.mjs";
import { createHash, randomUUID, randomBytes } from "node:crypto";
import {
  closeSync,
  constants,
  createReadStream,
  existsSync,
  fstatSync,
  fsyncSync,
  ftruncateSync,
  lstatSync,
  mkdirSync,
  openSync,
  renameSync,
  statfsSync,
  unlinkSync,
  writeSync,
} from "node:fs";
import { basename, extname, resolve } from "node:path";

const safeInteger = (value, fallback) =>
  Number.isSafeInteger(Number(value)) && Number(value) > 0
    ? Number(value)
    : fallback;
const validVersion = (value) =>
  typeof value === "string" && /^[A-Za-z0-9][A-Za-z0-9.+_-]{0,49}$/.test(value);
const remove = (path) => {
  try {
    unlinkSync(path);
  } catch (error) {
    if (error.code !== "ENOENT") throw error;
  }
};
const openPrivate = (path, flags = constants.O_RDONLY) => {
  const fd = openSync(path, flags | constants.O_NOFOLLOW);
  if (!fstatSync(fd).isFile() || fstatSync(fd).nlink !== 1) {
    closeSync(fd);
    throw new Error("Unsafe upload file.");
  }
  return fd;
};
const fileChecksum = async (path) => {
  const hash = createHash("sha256");
  for await (const chunk of createReadStream(path, {
    fd: openPrivate(path),
    autoClose: true,
  }))
    hash.update(chunk);
  return hash.digest("hex");
};

export function registerResumablePublishing(app, ctx, { notifyRelease }) {
  const { db, dataDir, requireAdmin, fail, product, audit, now, rateLimit } =
    ctx;
  const chunkBytes = Math.min(
    safeInteger(
      ctx.options?.publishingUploadChunkBytes ?? process.env.UPLOAD_CHUNK_BYTES,
      8 * 1024 * 1024,
    ),
    32 * 1024 * 1024,
  );
  const maxBytes = safeInteger(
    ctx.options?.publishingMaxUploadBytes ??
      process.env.MAX_DIGITAL_UPLOAD_BYTES,
    5 * 1024 * 1024 * 1024,
  );
  const maxReservedBytes = safeInteger(
    ctx.options?.publishingMaxReservedBytes ??
      process.env.MAX_PENDING_UPLOAD_BYTES,
    Math.min(Number.MAX_SAFE_INTEGER, maxBytes * 2),
  );
  const staging = resolve(dataDir, "upload-sessions");
  mkdirSync(staging, { recursive: true, mode: 0o700 });
  for (const directory of [staging, resolve(dataDir, "uploads")]) {
    if (
      !lstatSync(directory).isDirectory() ||
      lstatSync(directory).isSymbolicLink()
    )
      throw new Error("Upload storage must be a private directory.");
  }
  const privateFile = (row) => {
    if (
      row.file_path !== `${row.id}.part` ||
      basename(row.file_path) !== row.file_path
    )
      throw new Error("Invalid upload path.");
    return resolve(staging, row.file_path);
  };
  const releasedFile = (name) => resolve(dataDir, "uploads", basename(name));
  const extension = (row) =>
    extname(row.filename)
      .toLowerCase()
      .replace(/[^.a-z0-9]/g, "")
      .slice(0, 12);
  // A deterministic private destination makes a rename interrupted by a process crash recoverable.
  const releaseName = (row) => `release-${row.id}${extension(row)}`;
  const find = (id) =>
    db.prepare("SELECT * FROM product_upload_sessions WHERE id=?").get(id);
  const view = (row) => ({
    id: row.id,
    productId: row.product_id,
    filename: row.filename,
    version: row.version,
    changelog: row.changelog,
    totalBytes: row.expected_bytes,
    receivedBytes: row.received_bytes,
    expectedSha256: row.expected_sha256,
    status: row.status,
    error: row.error,
    createdAt: row.created_at,
    updatedAt: row.updated_at,
    chunkBytes,
  });
  const owned = (req, res) => {
    const row = find(req.params.uploadId);
    if (!row || row.user_id !== req.user.id) {
      fail(res, 404, "Upload session not found.");
      return null;
    }
    return row;
  };
  const failed = (row, message) =>
    db
      .prepare(
        "UPDATE product_upload_sessions SET status='failed',error=?,updated_at=? WHERE id=?",
      )
      .run(message, now(), row.id);
  function expire() {
    const cutoff = new Date(Date.now() - 48 * 60 * 60 * 1000).toISOString();
    for (const row of db
      .prepare(
        "SELECT * FROM product_upload_sessions WHERE status IN ('uploading','failed') AND updated_at<?",
      )
      .all(cutoff)) {
      remove(privateFile(row));
      db.prepare(
        "UPDATE product_upload_sessions SET status='expired',error='Upload expired after 48 hours without activity.',updated_at=? WHERE id=?",
      ).run(now(), row.id);
    }
  }
  // SQLite and chunk files survive a restart. Discard any tail written before its offset committed.
  for (const row of db
    .prepare(
      "SELECT * FROM product_upload_sessions WHERE status IN ('uploading','finalizing')",
    )
    .all()) {
    try {
      const path = privateFile(row);
      if (row.status === "finalizing" && !existsSync(path)) {
        const destination = releasedFile(releaseName(row));
        if (existsSync(destination)) {
          const fd = openPrivate(destination);
          closeSync(fd);
          renameSync(destination, path);
        }
      }
      const fd = openPrivate(path, constants.O_RDWR);
      try {
        if (fstatSync(fd).size < row.received_bytes)
          throw new Error("Stored bytes are missing.");
        if (fstatSync(fd).size > row.received_bytes) {
          ftruncateSync(fd, row.received_bytes);
          fsyncSync(fd);
        }
      } finally {
        closeSync(fd);
      }
      if (row.status === "finalizing")
        db.prepare(
          "UPDATE product_upload_sessions SET status='uploading',error=NULL WHERE id=?",
        ).run(row.id);
    } catch {
      failed(
        row,
        "The stored upload is missing or unsafe. Cancel this session and upload the original file again.",
      );
    }
  }
  expire();

  // Create the catalog draft first so its first original can use the same resumable release path.
  app.post(
    "/api/publisher/products",
    requireAdmin,
    rateLimit("publisher-create", 30, 60000),
    (req, res) => {
      const {
        title,
        description,
        category,
        price,
        subscriptionIncluded = true,
        status = "draft",
      } = req.body || {};
      const categories = [
        "Design assets",
        "E-books",
        "Audio & music",
        "Courses",
        "Software",
        "Templates",
        "Video",
      ];
      if (
        typeof title !== "string" ||
        title.trim().length < 3 ||
        title.length > 120 ||
        typeof description !== "string" ||
        description.trim().length < 20 ||
        description.length > 5000 ||
        !categories.includes(category) ||
        typeof price !== "number" ||
        !Number.isFinite(price) ||
        price < 0 ||
        price > 100000 ||
        typeof subscriptionIncluded !== "boolean" ||
        status !== "draft"
      )
        return fail(
          res,
          400,
          "Provide a title, description (20+ characters), category, USD price, and optional member inclusion. New products start as drafts.",
        );
      const id = `${
        title
          .toLowerCase()
          .replace(/[^a-z0-9]+/g, "-")
          .replace(/^-|-$/g, "")
          .slice(0, 60) || "product"
      }-${randomBytes(6).toString("hex")}`;
      const amount = Math.round(price * 100) / 100;
      const metadata = brandProduct({
        id,
        title: title.trim(),
        description: description.trim(),
        category,
        price: amount,
        originalPrice: amount,
        rating: 0,
        reviewCount: 0,
        format: "Digital file",
        size: "Original pending",
        accent: "#e7dff4",
        art:
          {
            "E-books": "book",
            "Audio & music": "audio",
            Software: "code",
            Video: "film",
            Courses: "course",
            Templates: "dashboard",
          }[category] || "studio",
        tags: ["New release"],
        featured: false,
        subscriptionIncluded,
        downloads: 0,
        isSample: false,
        status: "draft",
      });
      db.prepare(
        "INSERT INTO products (id,payload,status,created_at) VALUES (?,?,?,?)",
      ).run(id, JSON.stringify(metadata), "draft", now());
      audit(req.user.id, "publisher.draft_created", { productId: id });
      res.status(201).json({
        success: true,
        product: product(
          db.prepare("SELECT * FROM products WHERE id=?").get(id),
        ),
      });
    },
  );
  app.get("/api/publisher/upload-capabilities", requireAdmin, (_req, res) =>
    res.json({
      chunkBytes,
      maxBytes,
      maxReservedBytes,
      activeSessionLimit: 3,
      expiresAfterHours: 48,
      storage: "private local disk",
    }),
  );
  app.get("/api/publisher/uploads", requireAdmin, (req, res) => {
    expire();
    let rows = db
      .prepare(
        "SELECT * FROM product_upload_sessions WHERE user_id=? AND status IN ('uploading','finalizing','failed') ORDER BY created_at DESC",
      )
      .all(req.user.id);
    if (typeof req.query.productId === "string")
      rows = rows.filter((row) => row.product_id === req.query.productId);
    res.json({ uploads: rows.map(view), chunkBytes, maxBytes });
  });
  app.post(
    "/api/publisher/products/:id/uploads",
    requireAdmin,
    rateLimit("upload-init", 30, 60000),
    (req, res) => {
      expire();
      const original = db
        .prepare("SELECT * FROM products WHERE id=?")
        .get(req.params.id);
      if (!original) return fail(res, 404, "Product not found.");
      const {
        version,
        changelog = "",
        totalBytes,
        filename,
        sha256,
      } = req.body || {};
      if (
        !validVersion(version) ||
        typeof changelog !== "string" ||
        changelog.length > 5000 ||
        !Number.isSafeInteger(totalBytes) ||
        totalBytes < 1 ||
        totalBytes > maxBytes ||
        typeof filename !== "string" ||
        filename.length > 200 ||
        filename !== basename(filename) ||
        /[\\/\x00-\x1f]/.test(filename) ||
        !filename.trim() ||
        (sha256 !== undefined &&
          sha256 !== null &&
          (typeof sha256 !== "string" || !/^[a-fA-F0-9]{64}$/.test(sha256)))
      )
        return fail(
          res,
          400,
          `Provide a valid version, filename, byte count (maximum ${maxBytes}), and optional SHA-256 checksum.`,
        );
      if (
        db
          .prepare(
            "SELECT 1 FROM product_versions WHERE product_id=? AND version=?",
          )
          .get(original.id, version)
      )
        return fail(res, 409, "That version already exists.");
      const existing = db
        .prepare(
          "SELECT count(*) AS count FROM product_upload_sessions WHERE user_id=? AND status IN ('uploading','finalizing','failed')",
        )
        .get(req.user.id);
      const reserved = db
        .prepare(
          "SELECT COALESCE(sum(expected_bytes-received_bytes),0) AS remaining,COALESCE(sum(expected_bytes),0) AS bytes FROM product_upload_sessions WHERE status IN ('uploading','finalizing','failed')",
        )
        .get();
      if (existing.count >= 3)
        return fail(
          res,
          409,
          "Finish or cancel an existing upload before starting another (three active uploads per administrator).",
        );
      if (totalBytes > maxReservedBytes - reserved.bytes)
        return fail(
          res,
          413,
          "Pending uploads exceed the configured storage reservation limit. Finish or cancel an existing upload.",
        );
      const disk = statfsSync(dataDir);
      if (totalBytes + reserved.remaining > disk.bavail * disk.bsize)
        return fail(
          res,
          507,
          "There is not enough available disk space for this upload.",
        );
      const id = randomUUID(),
        createdAt = now(),
        name = `${id}.part`,
        path = resolve(staging, name);
      const fd = openSync(
        path,
        constants.O_CREAT |
          constants.O_EXCL |
          constants.O_WRONLY |
          constants.O_NOFOLLOW,
        0o600,
      );
      closeSync(fd);
      try {
        db.prepare(
          "INSERT INTO product_upload_sessions (id,product_id,user_id,version,changelog,filename,expected_bytes,expected_sha256,file_path,created_at,updated_at) VALUES (?,?,?,?,?,?,?,?,?,?,?)",
        ).run(
          id,
          original.id,
          req.user.id,
          version,
          changelog,
          filename,
          totalBytes,
          sha256?.toLowerCase() || null,
          name,
          createdAt,
          createdAt,
        );
      } catch (error) {
        remove(path);
        throw error;
      }
      audit(req.user.id, "publisher.upload_started", {
        uploadId: id,
        productId: original.id,
        version,
        bytes: totalBytes,
      });
      res.status(201).json({ upload: view(find(id)) });
    },
  );
  app.get("/api/publisher/uploads/:uploadId", requireAdmin, (req, res) => {
    expire();
    const row = owned(req, res);
    if (row) {
      res.set("Upload-Offset", String(row.received_bytes));
      res.json({ upload: view(row) });
    }
  });
  const rawChunk = express.raw({
    type: "application/octet-stream",
    limit: chunkBytes,
  });
  app.put(
    "/api/publisher/uploads/:uploadId/chunk",
    requireAdmin,
    rateLimit("upload-chunk", 2000, 60000),
    (req, res, next) => {
      if (!owned(req, res)) return;
      rawChunk(req, res, next);
    },
    (req, res) => {
      const row = owned(req, res);
      if (!row) return;
      if (row.status !== "uploading")
        return fail(res, 409, "This upload is not accepting chunks.");
      const header = req.get("Upload-Offset");
      if (
        !/^(0|[1-9][0-9]*)$/.test(header || "") ||
        !Number.isSafeInteger(Number(header)) ||
        Number(header) !== row.received_bytes
      )
        return res
          .status(409)
          .set("Upload-Offset", String(row.received_bytes))
          .json({
            error:
              "Upload offset does not match. Refresh the upload session before resuming.",
            upload: view(row),
          });
      if (
        !Buffer.isBuffer(req.body) ||
        !req.body.length ||
        req.body.length > chunkBytes
      )
        return fail(
          res,
          400,
          "Send a nonempty application/octet-stream chunk within the configured chunk limit.",
        );
      if (row.received_bytes + req.body.length > row.expected_bytes)
        return fail(res, 400, "This chunk exceeds the declared file size.");
      let fd;
      try {
        fd = openPrivate(privateFile(row), constants.O_RDWR);
        const size = fstatSync(fd).size;
        if (size < row.received_bytes)
          throw new Error("Stored bytes are missing.");
        if (size > row.received_bytes) ftruncateSync(fd, row.received_bytes);
        // Persist the data before advancing the durable offset. One bounded chunk is held in memory.
        let written = 0;
        while (written < req.body.length)
          written += writeSync(
            fd,
            req.body,
            written,
            req.body.length - written,
            row.received_bytes + written,
          );
        fsyncSync(fd);
      } catch (error) {
        if (error.code === "ENOSPC")
          return fail(
            res,
            507,
            "Upload storage is full. Free space before resuming this upload.",
          );
        failed(
          row,
          "The stored upload is missing or unsafe. Cancel this session and start again.",
        );
        return fail(
          res,
          409,
          "The stored upload is missing or unsafe. Cancel this session and start again.",
        );
      } finally {
        if (fd !== undefined) closeSync(fd);
      }
      db.prepare(
        "UPDATE product_upload_sessions SET received_bytes=?,updated_at=? WHERE id=? AND received_bytes=?",
      ).run(
        row.received_bytes + req.body.length,
        now(),
        row.id,
        row.received_bytes,
      );
      const updated = find(row.id);
      res
        .set("Upload-Offset", String(updated.received_bytes))
        .json({ upload: view(updated) });
    },
  );
  app.delete("/api/publisher/uploads/:uploadId", requireAdmin, (req, res) => {
    const row = owned(req, res);
    if (!row) return;
    if (["completed", "finalizing"].includes(row.status))
      return fail(
        res,
        409,
        "A completed or finalizing release cannot be canceled.",
      );
    remove(privateFile(row));
    db.prepare(
      "UPDATE product_upload_sessions SET status='canceled',updated_at=? WHERE id=?",
    ).run(now(), row.id);
    audit(req.user.id, "publisher.upload_canceled", { uploadId: row.id });
    res.json({ success: true });
  });
  app.post(
    "/api/publisher/uploads/:uploadId/finalize",
    requireAdmin,
    async (req, res, next) => {
      const row = owned(req, res);
      if (!row) return;
      if (row.status === "completed") {
        const version = db
          .prepare(
            "SELECT id,version,changelog,checksum,bytes,created_at AS createdAt FROM product_versions WHERE product_id=? AND version=?",
          )
          .get(row.product_id, row.version);
        return res.json({ success: true, version, upload: view(row) });
      }
      if (
        row.status !== "uploading" ||
        row.received_bytes !== row.expected_bytes
      )
        return fail(
          res,
          409,
          "Upload every declared byte before finalizing this release.",
        );
      if (
        db
          .prepare(
            "SELECT 1 FROM product_upload_sessions WHERE product_id=? AND status='finalizing'",
          )
          .get(row.product_id)
      )
        return fail(
          res,
          409,
          "Another release for this product is being finalized.",
        );
      const path = privateFile(row);
      try {
        const fd = openPrivate(path);
        try {
          if (fstatSync(fd).size !== row.expected_bytes)
            throw new Error("Wrong size.");
        } finally {
          closeSync(fd);
        }
      } catch {
        failed(row, "Stored upload is missing or unsafe.");
        return fail(
          res,
          409,
          "Stored upload size does not match the declared file, or the upload is unsafe.",
        );
      }
      db.prepare(
        "UPDATE product_upload_sessions SET status='finalizing',updated_at=? WHERE id=?",
      ).run(now(), row.id);
      let movedPath = null;
      try {
        const checksum = await fileChecksum(path);
        if (row.expected_sha256 && checksum !== row.expected_sha256) {
          failed(
            row,
            "SHA-256 checksum mismatch. Cancel this session and upload the original file again.",
          );
          return fail(
            res,
            422,
            "The uploaded bytes do not match the supplied SHA-256 checksum. No product release was published.",
          );
        }
        let original, oldRelease;
        // Hash only an unversioned original; retry if another publishing path changes it while hashing.
        for (;;) {
          original = db
            .prepare("SELECT * FROM products WHERE id=?")
            .get(row.product_id);
          if (!original) throw new Error("Product no longer exists.");
          oldRelease = null;
          if (
            original.file_path &&
            existsSync(releasedFile(original.file_path)) &&
            !db
              .prepare(
                "SELECT 1 FROM product_versions WHERE product_id=? AND file_path=?",
              )
              .get(original.id, original.file_path)
          ) {
            const oldPath = releasedFile(original.file_path),
              fd = openPrivate(oldPath);
            let bytes;
            try {
              bytes = fstatSync(fd).size;
            } finally {
              closeSync(fd);
            }
            oldRelease = {
              path: original.file_path,
              bytes,
              checksum: await fileChecksum(oldPath),
              createdAt: original.created_at,
            };
            if (
              db
                .prepare("SELECT file_path FROM products WHERE id=?")
                .get(row.product_id)?.file_path !== original.file_path
            )
              continue;
          }
          original = db
            .prepare("SELECT * FROM products WHERE id=?")
            .get(row.product_id);
          break;
        }
        const filename = releaseName(row),
          destination = releasedFile(filename),
          createdAt = now(),
          releaseId = randomUUID();
        if (existsSync(destination))
          throw new Error("Release destination already exists.");
        db.exec("BEGIN IMMEDIATE");
        try {
          if (
            db
              .prepare(
                "SELECT 1 FROM product_versions WHERE product_id=? AND version=?",
              )
              .get(row.product_id, row.version)
          )
            throw new Error(
              "That release version was published while this upload was in progress.",
            );
          if (oldRelease) {
            const label =
              row.version === "original" ||
              db
                .prepare(
                  "SELECT 1 FROM product_versions WHERE product_id=? AND version='original'",
                )
                .get(row.product_id)
                ? `original-${randomBytes(3).toString("hex")}`
                : "original";
            db.prepare(
              "INSERT INTO product_versions VALUES (?,?,?,?,?,?,?,?)",
            ).run(
              randomUUID(),
              row.product_id,
              label,
              "Original uploaded release",
              oldRelease.path,
              oldRelease.checksum,
              oldRelease.bytes,
              oldRelease.createdAt,
            );
          }
          renameSync(path, destination);
          movedPath = destination;
          db.prepare(
            "INSERT INTO product_versions VALUES (?,?,?,?,?,?,?,?)",
          ).run(
            releaseId,
            row.product_id,
            row.version,
            row.changelog,
            filename,
            checksum,
            row.expected_bytes,
            createdAt,
          );
          const metadata = {
            ...product(original),
            isSample: false,
            latestVersion: row.version,
            checksum,
            format:
              extension(row).slice(1).toUpperCase() || product(original).format,
            size:
              row.expected_bytes >= 1073741824
                ? `${(row.expected_bytes / 1073741824).toFixed(2)} GB`
                : `${(row.expected_bytes / 1048576).toFixed(1)} MB`,
          };
          db.prepare(
            "UPDATE products SET payload=?,file_path=? WHERE id=?",
          ).run(JSON.stringify(metadata), filename, row.product_id);
          db.prepare(
            "UPDATE product_upload_sessions SET status='completed',error=NULL,updated_at=? WHERE id=?",
          ).run(createdAt, row.id);
          notifyRelease(row.product_id, row.version);
          audit(req.user.id, "publisher.resumable_release_completed", {
            uploadId: row.id,
            productId: row.product_id,
            version: row.version,
            checksum,
            bytes: row.expected_bytes,
          });
          db.exec("COMMIT");
          movedPath = null;
        } catch (error) {
          db.exec("ROLLBACK");
          if (movedPath && existsSync(movedPath)) {
            renameSync(movedPath, path);
            movedPath = null;
          }
          throw error;
        }
        res.status(201).json({
          success: true,
          version: {
            id: releaseId,
            version: row.version,
            changelog: row.changelog,
            checksum,
            bytes: row.expected_bytes,
            createdAt,
          },
          upload: view(find(row.id)),
        });
      } catch (error) {
        failed(
          row,
          "Release finalization failed. Your uploaded bytes remain private; cancel this session or contact the administrator.",
        );
        next(error);
      }
    },
  );
  return { fileChecksum };
}
