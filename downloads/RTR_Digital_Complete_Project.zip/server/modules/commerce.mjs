import { randomUUID } from "node:crypto";
import { SELLER_NAME } from "../brand.mjs";
import { isPaidMode } from "../payment-policy.mjs";

const cents = (value) => Math.round(value * 100);
const cleanCode = (value) =>
  typeof value === "string" ? value.trim().toUpperCase() : "";
const error = (message, status = 400) =>
  Object.assign(new Error(message), { status });
const escapeHtml = (value) =>
  String(value ?? "").replace(
    /[&<>"']/g,
    (ch) =>
      ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[
        ch
      ],
  );
const csvValue = (value) => {
  const str = String(value ?? "");
  return `"${(/^[\s]*[=+@\-\t\r]/.test(str) ? "'" : "") + str.replaceAll('"', '""')}"`;
};
const asDate = (value) =>
  !value
    ? null
    : Number.isFinite(Date.parse(value))
      ? new Date(value).toISOString()
      : false;
const money = (n) =>
  new Intl.NumberFormat("en-US", { style: "currency", currency: "USD" }).format(
    n,
  );

export function registerCommerce(app, ctx) {
  const {
    db,
    requireAuth,
    requireAdmin,
    fail,
    audit,
    products,
    product,
    plans,
    subscription,
    activeSubscription,
    stripe,
    publicBaseUrl,
    production,
    now,
  } = ctx;
  db.exec(`
    CREATE TABLE IF NOT EXISTS commerce_promotions (id TEXT PRIMARY KEY, code TEXT UNIQUE NOT NULL, percent REAL NOT NULL, starts_at TEXT, ends_at TEXT, max_uses INTEGER, per_user INTEGER, min_spend REAL NOT NULL DEFAULT 0, scope TEXT NOT NULL DEFAULT 'all', enabled INTEGER NOT NULL DEFAULT 1, recurring INTEGER NOT NULL DEFAULT 1, created_at TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS commerce_reservations (intent_id TEXT PRIMARY KEY, promotion_id TEXT NOT NULL, user_id TEXT NOT NULL, expires_at INTEGER NOT NULL);
    CREATE TABLE IF NOT EXISTS commerce_redemptions (order_id TEXT PRIMARY KEY, promotion_id TEXT NOT NULL, user_id TEXT NOT NULL, created_at TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS commerce_refunds (id TEXT PRIMARY KEY, order_id TEXT UNIQUE NOT NULL, user_id TEXT NOT NULL, reason TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'requested', note TEXT, provider_refund_id TEXT, payment_intent TEXT, created_at TEXT NOT NULL, updated_at TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS commerce_payments (order_id TEXT PRIMARY KEY, payment_intent TEXT, subscription_id TEXT, session_id TEXT, created_at TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS commerce_events (id TEXT PRIMARY KEY, type TEXT NOT NULL, order_id TEXT, payload TEXT NOT NULL, created_at TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS commerce_settings (id INTEGER PRIMARY KEY CHECK(id=1), payload TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS commerce_wire_refunds (refund_id TEXT PRIMARY KEY, order_id TEXT UNIQUE NOT NULL, bank_reference TEXT UNIQUE NOT NULL, amount_cents INTEGER NOT NULL, currency TEXT NOT NULL, admin_id TEXT NOT NULL, created_at TEXT NOT NULL);
  `);
  db.prepare("INSERT OR IGNORE INTO commerce_settings VALUES (1,?)").run(
    JSON.stringify({
      sellerName: SELLER_NAME,
      licensor: SELLER_NAME,
      address: "",
      taxId: "",
      supportEmail: "",
      invoicePrefix: "RTR",
      country: "IN",
      currency: "USD",
    }),
  );
  for (const [code, percent] of [
    ["WELCOME10", 10],
    ["RTR20", 20],
  ])
    db.prepare(
      "INSERT OR IGNORE INTO commerce_promotions VALUES (?,?,?,?,?,?,?,?,?,?,?,?)",
    ).run(
      randomUUID(),
      code,
      percent,
      null,
      null,
      null,
      null,
      0,
      "all",
      1,
      1,
      now(),
    );
  const settings = () => ({
    country: "IN",
    currency: "USD",
    ...JSON.parse(
      db.prepare("SELECT payload FROM commerce_settings WHERE id=1").get()
        .payload,
    ),
    sellerName: SELLER_NAME,
    licensor: SELLER_NAME,
  });
  // Seller identity is fixed even for a catalog configured before this policy.
  // Historical order snapshots deliberately remain untouched.
  db.prepare("UPDATE commerce_settings SET payload=? WHERE id=1").run(
    JSON.stringify(settings()),
  );
  const event = (type, orderId, payload = {}, eventId = randomUUID()) =>
    db
      .prepare("INSERT OR IGNORE INTO commerce_events VALUES (?,?,?,?,?)")
      .run(eventId, type, orderId, JSON.stringify(payload), now());
  const allPromotions = () =>
    db
      .prepare(
        `SELECT p.*, (SELECT COUNT(*) FROM commerce_redemptions r WHERE r.promotion_id=p.id) AS uses FROM commerce_promotions p ORDER BY p.created_at DESC`,
      )
      .all()
      .map((p) => ({
        id: p.id,
        code: p.code,
        percent: p.percent,
        startsAt: p.starts_at,
        endsAt: p.ends_at,
        maxUses: p.max_uses,
        perUser: p.per_user,
        minSpend: p.min_spend,
        scope: p.scope,
        enabled: Boolean(p.enabled),
        recurring: Boolean(p.recurring),
        uses: p.uses,
      }));
  function resolvePromotion(
    user,
    { code: rawCode, plan, selected = [], subtotal, reservationId = null },
  ) {
    const code = cleanCode(rawCode);
    if (!code) return { discount: 0, code: null, recurring: false };
    const row = db
      .prepare("SELECT * FROM commerce_promotions WHERE code=?")
      .get(code);
    if (!row || !row.enabled) throw error("This promo code is not available.");
    const stamp = Date.now();
    if (row.starts_at && Date.parse(row.starts_at) > stamp)
      throw error("This promotion has not started yet.");
    if (row.ends_at && Date.parse(row.ends_at) <= stamp)
      throw error("This promotion has expired.");
    if (
      (row.scope === "membership" && !plan) ||
      (row.scope === "products" && plan)
    )
      throw error("This promotion does not apply to this purchase.");
    if (plan && !row.recurring)
      throw error("This promotion is for one-time purchases only.");
    if (cents(subtotal) < cents(row.min_spend))
      throw error(
        `This promotion requires a minimum purchase of ${money(row.min_spend)}.`,
      );
    const uses =
      db
        .prepare(
          "SELECT COUNT(*) AS n FROM commerce_redemptions WHERE promotion_id=?",
        )
        .get(row.id).n +
      db
        .prepare(
          "SELECT COUNT(*) AS n FROM commerce_reservations WHERE promotion_id=? AND expires_at>? AND intent_id!=?",
        )
        .get(row.id, Date.now(), reservationId || "").n;
    if (row.max_uses !== null && uses >= row.max_uses)
      throw error("This promotion has reached its redemption limit.", 409);
    if (row.per_user !== null) {
      if (!user) throw error("Sign in to check this promotion.");
      const ownUses =
        db
          .prepare(
            "SELECT COUNT(*) AS n FROM commerce_redemptions WHERE promotion_id=? AND user_id=?",
          )
          .get(row.id, user.id).n +
        db
          .prepare(
            "SELECT COUNT(*) AS n FROM commerce_reservations WHERE promotion_id=? AND user_id=? AND expires_at>? AND intent_id!=?",
          )
          .get(row.id, user.id, Date.now(), reservationId || "").n;
      if (ownUses >= row.per_user)
        throw error(
          "You have already used this promotion the maximum number of times.",
          409,
        );
    }
    if (!plan && !selected.length)
      throw error("Add a product before using a promotion.");
    return {
      discount: row.percent / 100,
      code,
      recurring: Boolean(plan && row.recurring),
      promotionId: row.id,
    };
  }
  function reservePromotion(
    userId,
    intentId,
    rawCode,
    expiresAt = Date.now() + 31 * 60 * 1000,
    maxLifetimeMs = 3600000,
  ) {
    const code = cleanCode(rawCode);
    if (!code) return;
    const row = db
      .prepare("SELECT * FROM commerce_promotions WHERE code=?")
      .get(code);
    if (!row || !row.enabled)
      throw error("This promotion is no longer available.", 409);
    if (
      !Number.isFinite(expiresAt) ||
      expiresAt <= Date.now() ||
      expiresAt > Date.now() + maxLifetimeMs
    )
      throw error("Promotion reservation expiry is invalid.");
    db.exec("BEGIN IMMEDIATE");
    try {
      db.prepare("DELETE FROM commerce_reservations WHERE expires_at<=?").run(
        Date.now(),
      );
      const existing = db
        .prepare("SELECT * FROM commerce_reservations WHERE intent_id=?")
        .get(intentId);
      if (existing) {
        if (existing.user_id !== userId || existing.promotion_id !== row.id)
          throw error("Checkout reservation conflicts.", 409);
        db.exec("COMMIT");
        return;
      }
      const used = db
        .prepare(
          "SELECT COUNT(*) AS n FROM commerce_redemptions WHERE promotion_id=?",
        )
        .get(row.id).n;
      const held = db
        .prepare(
          "SELECT COUNT(*) AS n FROM commerce_reservations WHERE promotion_id=?",
        )
        .get(row.id).n;
      const ownUsed = db
        .prepare(
          "SELECT COUNT(*) AS n FROM commerce_redemptions WHERE promotion_id=? AND user_id=?",
        )
        .get(row.id, userId).n;
      const ownHeld = db
        .prepare(
          "SELECT COUNT(*) AS n FROM commerce_reservations WHERE promotion_id=? AND user_id=?",
        )
        .get(row.id, userId).n;
      if (row.max_uses !== null && used + held >= row.max_uses)
        throw error("This promotion has reached its redemption limit.", 409);
      if (row.per_user !== null && ownUsed + ownHeld >= row.per_user)
        throw error(
          "This promotion is already reserved or used by your account.",
          409,
        );
      if (row.ends_at && Date.parse(row.ends_at) <= Date.now())
        throw error("This promotion has expired.");
      db.prepare("INSERT INTO commerce_reservations VALUES (?,?,?,?)").run(
        intentId,
        row.id,
        userId,
        expiresAt,
      );
      db.exec("COMMIT");
    } catch (err) {
      db.exec("ROLLBACK");
      throw err;
    }
  }
  const reserveWirePromotion = (userId, intentId, code, expiresAt) =>
    reservePromotion(userId, intentId, code, expiresAt, 7 * 86400000);
  const releasePromotion = (intentId) =>
    db
      .prepare("DELETE FROM commerce_reservations WHERE intent_id=?")
      .run(intentId);
  function recordPromotion(userId, orderId, code, intentId = null) {
    if (!code) return;
    const p = db
      .prepare("SELECT id FROM commerce_promotions WHERE code=?")
      .get(cleanCode(code));
    if (
      !p ||
      !db
        .prepare("SELECT id FROM orders WHERE id=? AND user_id=?")
        .get(orderId, userId)
    )
      return;
    db.prepare(
      "INSERT OR IGNORE INTO commerce_redemptions VALUES (?,?,?,?)",
    ).run(orderId, p.id, userId, now());
    if (intentId)
      db.prepare(
        "DELETE FROM commerce_reservations WHERE intent_id=? AND user_id=? AND promotion_id=?",
      ).run(intentId, userId, p.id);
  }
  function stripeTaxOptions() {
    return process.env.STRIPE_AUTOMATIC_TAX === "true"
      ? {
          automatic_tax: { enabled: true },
          billing_address_collection: "required",
        }
      : {};
  }
  function orderRecord(row) {
    return row ? { ...JSON.parse(row.payload), userId: row.user_id } : null;
  }
  function findOrder(req, id) {
    const row = db.prepare("SELECT * FROM orders WHERE id=?").get(id);
    if (!row || (row.user_id !== req.user.id && req.user.role !== "admin"))
      throw error("Order not found.", 404);
    if (production && !isPaidMode(row.mode))
      throw error("Order not found.", 404);
    return row;
  }
  function financials() {
    const rows = db
      .prepare("SELECT * FROM orders ORDER BY created_at DESC")
      .all();
    let grossRevenue = 0,
      refundedRevenue = 0,
      demoTotal = 0;
    for (const row of rows) {
      const p = orderRecord(row);
      if (isPaidMode(row.mode)) {
        grossRevenue += row.amount;
        if (p.status === "refunded") refundedRevenue += row.amount;
      } else if (row.mode === "demo" && p.status !== "refunded")
        demoTotal += row.amount;
    }
    const users = db
      .prepare("SELECT * FROM users WHERE subscription IS NOT NULL")
      .all();
    const active = users.filter(activeSubscription);
    const live = active.filter((u) => isPaidMode(subscription(u)?.mode));
    const recurringLive = live.filter((u) => {
      const s = subscription(u);
      return s.mode === "stripe" && !s.isPrepaid;
    });
    const liveMrr = recurringLive.reduce((sum, user) => {
      const s = subscription(user);
      const last = db
        .prepare(
          "SELECT payload FROM orders WHERE user_id=? AND mode='stripe' AND json_extract(payload,'$.plan') IS NOT NULL AND json_extract(payload,'$.status') != 'refunded' AND COALESCE(json_extract(payload,'$.isPrepaid'),0)=0 ORDER BY created_at DESC,rowid DESC LIMIT 1",
        )
        .get(user.id);
      const order = last ? JSON.parse(last.payload) : null;
      return (
        sum +
        (order
          ? (order.subtotal ?? order.total - (order.tax || 0)) /
            (order.interval === "yearly" ? 12 : 1)
          : 0)
      );
    }, 0);
    const refunded = db
      .prepare(
        "SELECT COUNT(*) AS n FROM commerce_refunds WHERE status='approved'",
      )
      .get().n;
    const pendingRefunds = db
      .prepare(
        "SELECT COUNT(*) AS n FROM commerce_refunds WHERE status IN ('requested','processing','provider_refunded_pending_cancel')",
      )
      .get().n;
    const canceledLive = users.filter((u) => {
      const s = subscription(u);
      return isPaidMode(s?.mode) && ["canceled", "unpaid"].includes(s.status);
    }).length;
    return {
      grossRevenue: Math.round(grossRevenue * 100) / 100,
      refundedRevenue: Math.round(refundedRevenue * 100) / 100,
      netRevenue: Math.round((grossRevenue - refundedRevenue) * 100) / 100,
      demoTotal: Math.round(demoTotal * 100) / 100,
      liveMrr: Math.round(liveMrr * 100) / 100,
      liveArr: Math.round(liveMrr * 1200) / 100,
      activeLiveMembers: live.length,
      activeDemoMembers: active.filter((u) => subscription(u)?.mode === "demo")
        .length,
      activeNoCardTrials: active.filter(
        (u) => subscription(u)?.mode === "trial",
      ).length,
      canceledLiveMembers: canceledLive,
      orders: rows.length,
      refundedOrders: refunded,
      pendingRefunds,
      currency: "USD",
      note: "MRR is the recorded recurring Stripe contract value normalized monthly, not cash received or a forecast. Prepaid memberships and demo activity are separate.",
    };
  }
  app.post("/api/checkout/quote", (req, res) => {
    try {
      const {
        productIds = [],
        plan,
        interval = "monthly",
        coupon = "",
      } = req.body || {};
      if (
        !Array.isArray(productIds) ||
        productIds.length > 50 ||
        !productIds.every((x) => typeof x === "string")
      )
        throw error("Your collection is invalid.");
      if (
        !["monthly", "yearly"].includes(interval) ||
        (plan && (typeof plan !== "string" || !Object.hasOwn(plans, plan)))
      )
        throw error("Choose a valid plan and interval.");
      const selected = [...new Set(productIds)].map((id) =>
        product(
          db
            .prepare("SELECT * FROM products WHERE id=? AND status='published'")
            .get(id),
        ),
      );
      if (
        selected.some((p) => !p) ||
        (plan && selected.length) ||
        (!plan && !selected.length)
      )
        throw error("Choose available products or one membership.");
      const subtotal = plan
        ? plans[plan][interval]
        : selected.reduce((sum, p) => sum + p.price, 0);
      const promotion = resolvePromotion(req.user, {
        code: coupon,
        plan,
        selected,
        subtotal,
      });
      const total = plan
        ? Math.round(subtotal * (1 - promotion.discount) * 100) / 100
        : selected.reduce(
            (sum, p) =>
              sum + Math.round(p.price * (1 - promotion.discount) * 100),
            0,
          ) / 100;
      res.json({
        subtotal: Math.round(subtotal * 100) / 100,
        discount: Math.round((subtotal - total) * 100) / 100,
        total,
        currency: "USD",
        promotion: {
          code: promotion.code,
          percent: promotion.discount * 100,
          recurring: promotion.recurring,
        },
        tax: {
          mode:
            process.env.STRIPE_AUTOMATIC_TAX === "true"
              ? "stripe"
              : "not_configured",
          message:
            process.env.STRIPE_AUTOMATIC_TAX === "true"
              ? "Stripe calculates applicable tax at hosted checkout."
              : "Tax collection is not configured. This estimate is not a tax determination.",
        },
      });
    } catch (e) {
      fail(res, e.status || 400, e.message);
    }
  });
  app.get("/api/billing/orders", requireAuth, (req, res) =>
    res.json({
      orders: db
        .prepare(
          "SELECT * FROM orders WHERE user_id=? ORDER BY created_at DESC",
        )
        .all(req.user.id)
        .filter((row) => !production || isPaidMode(row.mode))
        .map((row) => ({
          ...orderRecord(row),
          receiptUrl: `/api/billing/orders/${encodeURIComponent(row.id)}/receipt`,
          refund:
            db
              .prepare(
                "SELECT id,status,reason,note,created_at AS createdAt FROM commerce_refunds WHERE order_id=?",
              )
              .get(row.id) || null,
        })),
      seller: settings(),
      taxConfigured: process.env.STRIPE_AUTOMATIC_TAX === "true",
    }),
  );
  app.get("/api/billing/orders/:id/receipt", requireAuth, (req, res) => {
    try {
      const row = findOrder(req, req.params.id),
        o = orderRecord(row),
        s = o.seller || settings();
      const user = db
        .prepare("SELECT name,email FROM users WHERE id=?")
        .get(row.user_id);
      const title =
        row.mode === "demo" ? "Demonstration receipt" : "Payment receipt";
      const lines = o.plan
        ? [
            {
              title: `${plans[o.plan]?.name || o.plan} membership · ${o.interval}`,
              price: o.total,
            },
          ]
        : o.items || [];
      const html = `<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width"><title>${escapeHtml(title)} ${escapeHtml(o.id)}</title><style>body{font:15px/1.7 system-ui;color:#193c34;max-width:800px;margin:60px auto;padding:25px}header{display:flex;justify-content:space-between;border-bottom:2px solid #193c34;padding-bottom:25px}h1{font-size:32px}small{color:#667760}table{border-collapse:collapse;width:100%;margin:30px 0}td,th{text-align:left;padding:14px 5px;border-bottom:1px solid #dce3d5}td:last-child,th:last-child{text-align:right}.total{text-align:right;font-size:24px}.note{padding:20px;background:#edf1e5;margin:30px 0}.status{text-transform:uppercase;letter-spacing:2px;font-size:12px}@media print{body{margin:0;max-width:none}}</style></head><body><header><div><strong>Seller: ${escapeHtml(s.sellerName)}</strong>${s.licensor ? `<br>Licensor: ${escapeHtml(s.licensor)}` : ""}<br>${escapeHtml(s.address)}<br>India · International digital sales · USD${s.taxId ? `<br>Tax ID: ${escapeHtml(s.taxId)}` : ""}</div><div><strong>${escapeHtml(title)}</strong><br>${escapeHtml(String(o.id).startsWith(`${s.invoicePrefix || "RTR"}-`) ? o.id : `${s.invoicePrefix || "RTR"}-${o.id}`)}</div></header><h1>A good decision, recorded.</h1><p class="status">${escapeHtml(o.status)} · ${escapeHtml(o.mode)}</p><p>Issued ${escapeHtml(o.createdAt)}<br>Customer: ${escapeHtml(user?.name || "Account holder")}<br>${escapeHtml(user?.email || "")}</p><table><thead><tr><th>Digital item</th><th>Reference price</th></tr></thead><tbody>${lines.map((i) => `<tr><td>${escapeHtml(i.title)}</td><td>${money(i.price)}</td></tr>`).join("")}</tbody></table>${o.subtotal !== undefined ? `<p>After promotions: ${money(o.subtotal)} USD<br>Tax collected: ${money(o.tax || 0)} USD</p>` : ""}<p class="total">Total ${money(o.total)} USD</p><p>Payment total is the immutable order total. Reference prices above may precede an applied promotion.</p><div class="note">${row.mode === "demo" ? "DEMONSTRATION — no money was charged. This receipt is not a tax invoice." : "India-based seller · International digital sale in USD. This payment receipt is not a GST/export tax invoice. Obtain applicable GST, export, and place-of-supply documents from the merchant or configured tax provider."}</div><p>Digital delivery through your authenticated RTR Digital library.${s.supportEmail ? ` Questions? ${escapeHtml(s.supportEmail)}` : ""}</p></body></html>`;
      res.setHeader("Content-Type", "text/html; charset=utf-8");
      res.setHeader(
        "Content-Security-Policy",
        "default-src 'none'; style-src 'unsafe-inline'; frame-ancestors 'none'",
      );
      res.setHeader("Cache-Control", "private, no-store");
      res.send(html);
    } catch (e) {
      fail(res, e.status || 400, e.message);
    }
  });
  app.post("/api/billing/orders/:id/refunds", requireAuth, (req, res) => {
    try {
      const row = findOrder(req, req.params.id);
      const order = orderRecord(row);
      if (order.status === "refunded")
        throw error("This order has already been refunded.", 409);
      const reason = req.body?.reason;
      if (
        typeof reason !== "string" ||
        reason.trim().length < 10 ||
        reason.length > 2000
      )
        throw error("Explain the issue in 10–2,000 characters.");
      const existing = db
        .prepare("SELECT id,status FROM commerce_refunds WHERE order_id=?")
        .get(row.id);
      if (existing)
        return res.json({ refund: existing, alreadyRequested: true });
      const id = randomUUID();
      db.prepare(
        "INSERT INTO commerce_refunds (id,order_id,user_id,reason,status,created_at,updated_at) VALUES (?,?,?,?,?,?,?)",
      ).run(id, row.id, row.user_id, reason.trim(), "requested", now(), now());
      audit(req.user.id, "refund.requested", { orderId: row.id, refundId: id });
      res.status(201).json({ refund: { id, status: "requested" } });
    } catch (e) {
      fail(res, e.status || 400, e.message);
    }
  });
  function applyRefund(row, refund) {
    const order = orderRecord(row);
    if (order.status === "refunded") return;
    const updated = {
      ...order,
      status: "refunded",
      refundedAt: now(),
      refundId: refund.id,
    };
    delete updated.userId;
    db.prepare("UPDATE orders SET payload=? WHERE id=?").run(
      JSON.stringify(updated),
      row.id,
    );
    for (const item of order.items || []) {
      const other = db
        .prepare(
          "SELECT payload,mode FROM orders WHERE user_id=? AND id!=? AND json_extract(payload,'$.status')!='refunded'",
        )
        .all(row.user_id, row.id)
        .find(
          (r) =>
            (!production || isPaidMode(r.mode)) &&
            JSON.parse(r.payload).items?.some((i) => i.id === item.id),
        );
      if (!other)
        db.prepare(
          "DELETE FROM entitlements WHERE user_id=? AND product_id=?",
        ).run(row.user_id, item.id);
      else
        db.prepare(
          "UPDATE entitlements SET mode=? WHERE user_id=? AND product_id=?",
        ).run(other.mode, row.user_id, item.id);
    }
    if (order.plan) {
      const latest = db
        .prepare(
          "SELECT id FROM orders WHERE user_id=? AND json_extract(payload,'$.plan') IS NOT NULL ORDER BY created_at DESC,rowid DESC LIMIT 1",
        )
        .get(row.user_id);
      if (latest?.id === row.id) {
        const user = db
          .prepare("SELECT * FROM users WHERE id=?")
          .get(row.user_id);
        const s = subscription(user);
        if (s && s.mode === row.mode)
          db.prepare("UPDATE users SET subscription=? WHERE id=?").run(
            JSON.stringify({
              ...s,
              status: "canceled",
              cancelAtPeriodEnd: false,
              currentPeriodEnd: now(),
            }),
            row.user_id,
          );
      }
    }
    event("refund.completed", row.id, {
      refundId: refund.id,
      mode: row.mode,
      amount: row.amount,
    });
  }
  function recordPayment(orderId, session) {
    const pi =
      typeof session.payment_intent === "string"
        ? session.payment_intent
        : session.payment_intent?.id;
    const sid =
      typeof session.subscription === "string"
        ? session.subscription
        : session.subscription?.id;
    db.prepare(
      "INSERT INTO commerce_payments VALUES (?,?,?,?,?) ON CONFLICT(order_id) DO UPDATE SET payment_intent=COALESCE(excluded.payment_intent,commerce_payments.payment_intent),subscription_id=COALESCE(excluded.subscription_id,commerce_payments.subscription_id)",
    ).run(orderId, pi || null, sid || null, session.id || orderId, now());
  }
  async function cancelSubscription(id) {
    const current = stripe.subscriptions.retrieve
      ? await stripe.subscriptions.retrieve(id)
      : null;
    if (current?.status !== "canceled") await stripe.subscriptions.cancel(id);
  }
  function confirmWireRefund(row, admin, confirmation) {
    const sharedDevelopmentAdmin =
      !production &&
      ctx.demoMode === true &&
      admin.email === "demo-admin@rtr.example";
    if (
      !sharedDevelopmentAdmin &&
      (typeof confirmation.password !== "string" ||
        confirmation.password.length > 128 ||
        !ctx.verifyPassword?.(confirmation.password, admin.password))
    )
      throw error(
        "Confirm your administrator password to record a bank refund.",
        403,
      );
    const amount = Number(confirmation.refundedAmount);
    const bankReference =
      typeof confirmation.bankReference === "string"
        ? confirmation.bankReference.trim().toUpperCase()
        : "";
    if (
      confirmation.bankRefundConfirmed !== true ||
      confirmation.currency !== "USD" ||
      !["number", "string"].includes(typeof confirmation.refundedAmount) ||
      !Number.isFinite(amount) ||
      amount <= 0 ||
      amount !== row.amount ||
      !/^[A-Z0-9][A-Z0-9 ./_-]{4,119}$/.test(bankReference)
    )
      throw error(
        "First complete the external bank refund, then confirm its unique bank reference and the exact original positive amount in USD.",
      );
    if (
      db
        .prepare(
          "SELECT refund_id FROM commerce_wire_refunds WHERE bank_reference=?",
        )
        .get(bankReference)
    )
      throw error("This bank refund reference has already been recorded.", 409);
    return { bankReference, amount, currency: "USD" };
  }
  async function approveRefund(refund, admin, confirmation = {}) {
    const adminId = admin.id;
    const row = db
      .prepare("SELECT * FROM orders WHERE id=?")
      .get(refund.order_id);
    if (!row) throw error("Order no longer exists.", 404);
    const paymentMode = orderRecord(row).paymentProvider || row.mode;
    if (refund.status === "approved") return { alreadyProcessed: true };
    if (
      !["requested", "processing", "provider_refunded_pending_cancel"].includes(
        refund.status,
      )
    )
      throw error("Only an open request can be approved.", 409);
    const wireConfirmation =
      paymentMode === "wire"
        ? confirmWireRefund(row, admin, confirmation)
        : null;
    if (!isPaidMode(paymentMode) && paymentMode !== "demo")
      throw error(
        "This payment method requires a separate verified refund.",
        409,
      );
    db.prepare(
      "UPDATE commerce_refunds SET status='processing',updated_at=? WHERE id=?",
    ).run(now(), refund.id);
    let providerId = refund.provider_refund_id;
    let subId = null;
    let pi = refund.payment_intent;
    try {
      if (paymentMode === "stripe") {
        if (!stripe)
          throw error("Stripe is not configured. No refund was issued.", 503);
        let payment = db
          .prepare("SELECT * FROM commerce_payments WHERE order_id=?")
          .get(row.id);
        if (!payment?.payment_intent) {
          const session = await stripe.checkout.sessions.retrieve(row.id, {
            expand: ["payment_intent", "invoice"],
          });
          recordPayment(row.id, session);
          payment = db
            .prepare("SELECT * FROM commerce_payments WHERE order_id=?")
            .get(row.id);
          if (!payment.payment_intent && session.invoice) {
            let invoice =
              typeof session.invoice === "string"
                ? await stripe.invoices.retrieve(session.invoice, {
                    expand: ["payments.data.payment.payment_intent"],
                  })
                : session.invoice;
            const invoicePi =
              typeof invoice.payment_intent === "string"
                ? invoice.payment_intent
                : invoice.payment_intent?.id ||
                  invoice.payments?.data
                    ?.map((p) => p.payment?.payment_intent)
                    .find(Boolean);
            if (invoicePi)
              db.prepare(
                "UPDATE commerce_payments SET payment_intent=? WHERE order_id=?",
              ).run(
                typeof invoicePi === "string" ? invoicePi : invoicePi.id,
                row.id,
              );
            payment = db
              .prepare("SELECT * FROM commerce_payments WHERE order_id=?")
              .get(row.id);
          }
        }
        pi = payment?.payment_intent;
        subId = payment?.subscription_id;
        if (!pi)
          throw error(
            "The original Stripe payment cannot yet be resolved. No refund was issued.",
            503,
          );
        if (providerId && refund.status === "processing") {
          if (!stripe.refunds.retrieve)
            throw error(
              "The payment provider refund is awaiting confirmation.",
              503,
            );
          const existingRefund = await stripe.refunds.retrieve(providerId);
          if (
            existingRefund.status === "pending" ||
            existingRefund.status === "requires_action"
          )
            return {
              pending: true,
              message:
                "Stripe is still processing this refund. Access remains until confirmation.",
            };
          if (existingRefund.status !== "succeeded")
            throw error(
              "The provider has not confirmed a successful refund.",
              502,
            );
        }
        if (
          !providerId &&
          refund.status !== "provider_refunded_pending_cancel"
        ) {
          const result = await stripe.refunds.create(
            {
              payment_intent: pi,
              reason: "requested_by_customer",
              metadata: { rtrOrderId: row.id, rtrRefundId: refund.id },
            },
            { idempotencyKey: `rtr-refund-${refund.id}` },
          );
          if (result.status === "failed" || result.status === "canceled")
            throw error(
              "The payment provider could not complete this refund.",
              502,
            );
          providerId = result.id;
          db.prepare(
            "UPDATE commerce_refunds SET provider_refund_id=?,payment_intent=?,updated_at=? WHERE id=?",
          ).run(providerId, pi, now(), refund.id);
          if (result.status === "pending") {
            db.prepare(
              "UPDATE commerce_refunds SET status='processing' WHERE id=?",
            ).run(refund.id);
            return {
              pending: true,
              message:
                "Stripe is processing this refund. Access remains until confirmation.",
            };
          }
        }
        if (orderRecord(row).plan && subId) {
          try {
            await cancelSubscription(subId);
          } catch {
            db.prepare(
              "UPDATE commerce_refunds SET status='provider_refunded_pending_cancel',note=?,updated_at=? WHERE id=?",
            ).run(
              "Refund issued. Subscription cancellation must be retried before completion.",
              now(),
              refund.id,
            );
            return {
              pending: true,
              message:
                "Refund issued; subscription cancellation is pending. Retry to reconcile.",
            };
          }
        }
      } else if (paymentMode === "paypal" || paymentMode === "razorpay") {
        if (!ctx.payments?.refund)
          throw error(
            "The payment provider is unavailable. No refund was issued.",
            503,
          );
        const result = await ctx.payments.refund(
          orderRecord(row),
          `rtr-refund-${refund.id}`,
        );
        providerId = result?.providerRefundId || providerId;
        if (providerId)
          db.prepare(
            "UPDATE commerce_refunds SET provider_refund_id=?,updated_at=? WHERE id=?",
          ).run(providerId, now(), refund.id);
        if (result?.pending) {
          const message = String(
            result.message ||
              "The provider is processing this refund. Access remains until confirmation.",
          ).slice(0, 500);
          db.prepare(
            "UPDATE commerce_refunds SET status='processing',note=?,updated_at=? WHERE id=?",
          ).run(message, now(), refund.id);
          return { pending: true, providerRefundId: providerId, message };
        }
        if (result?.success !== true)
          throw error(
            "The provider has not confirmed a successful refund.",
            502,
          );
      } else if (wireConfirmation) {
        providerId = `wire:${wireConfirmation.bankReference}`;
      }
      db.exec("BEGIN IMMEDIATE");
      try {
        if (wireConfirmation) {
          db.prepare(
            "INSERT INTO commerce_wire_refunds VALUES (?,?,?,?,?,?,?)",
          ).run(
            refund.id,
            row.id,
            wireConfirmation.bankReference,
            cents(wireConfirmation.amount),
            wireConfirmation.currency,
            adminId,
            now(),
          );
          event("wire.refund_confirmed", row.id, {
            refundId: refund.id,
            bankReference: wireConfirmation.bankReference,
            amount: wireConfirmation.amount,
            currency: wireConfirmation.currency,
            adminId,
          });
        }
        applyRefund(row, refund);
        db.prepare(
          "UPDATE commerce_refunds SET status='approved',provider_refund_id=?,payment_intent=?,updated_at=? WHERE id=?",
        ).run(providerId || null, pi || null, now(), refund.id);
        audit(adminId, "refund.approved", {
          refundId: refund.id,
          orderId: row.id,
          mode: row.mode,
        });
        db.exec("COMMIT");
      } catch (e) {
        db.exec("ROLLBACK");
        throw e;
      }
      return { success: true, mode: row.mode };
    } catch (e) {
      db.prepare(
        "UPDATE commerce_refunds SET status=CASE WHEN provider_refund_id IS NULL THEN 'requested' ELSE status END,note=?,updated_at=? WHERE id=?",
      ).run(String(e.message).slice(0, 500), now(), refund.id);
      throw e;
    }
  }
  async function onBillingEvent(e) {
    if (e.type === "checkout.session.expired") {
      if (e.data.object.metadata?.intentId)
        releasePromotion(e.data.object.metadata.intentId);
      return;
    }
    if (!["charge.refunded", "refund.updated"].includes(e.type)) return;
    const obj = e.data.object;
    if (e.type === "refund.updated" && obj.status !== "succeeded") return;
    const pi =
      typeof obj.payment_intent === "string"
        ? obj.payment_intent
        : obj.payment_intent?.id;
    if (!pi) return;
    const payment = db
      .prepare("SELECT * FROM commerce_payments WHERE payment_intent=?")
      .get(pi);
    if (!payment) return;
    const row = db
      .prepare("SELECT * FROM orders WHERE id=?")
      .get(payment.order_id);
    if (!row) return;
    if (
      e.type === "charge.refunded" &&
      (!obj.refunded ||
        !Number.isInteger(obj.amount) ||
        !Number.isInteger(obj.amount_refunded) ||
        obj.amount_refunded < obj.amount ||
        obj.amount < cents(row.amount))
    )
      return;
    if (
      e.type === "refund.updated" &&
      (!Number.isInteger(obj.amount) || obj.amount < cents(row.amount))
    )
      return;
    let refund = db
      .prepare("SELECT * FROM commerce_refunds WHERE order_id=?")
      .get(row.id);
    if (!refund) {
      const id = randomUUID();
      db.prepare(
        "INSERT INTO commerce_refunds (id,order_id,user_id,reason,status,provider_refund_id,payment_intent,created_at,updated_at) VALUES (?,?,?,?,?,?,?,?,?)",
      ).run(
        id,
        row.id,
        row.user_id,
        "Refund confirmed by payment provider",
        "processing",
        e.type === "refund.updated" ? obj.id : null,
        pi,
        now(),
        now(),
      );
      refund = db.prepare("SELECT * FROM commerce_refunds WHERE id=?").get(id);
    }
    if (orderRecord(row).plan && payment.subscription_id) {
      try {
        if (!stripe) throw new Error("Billing unavailable");
        await cancelSubscription(payment.subscription_id);
      } catch {
        db.prepare(
          "UPDATE commerce_refunds SET status='provider_refunded_pending_cancel',note=?,updated_at=? WHERE id=?",
        ).run(
          "Provider confirmed the refund. Subscription cancellation requires an administrator retry.",
          now(),
          refund.id,
        );
        return;
      }
    }
    db.exec("BEGIN IMMEDIATE");
    try {
      applyRefund(row, refund);
      db.prepare(
        "UPDATE commerce_refunds SET status='approved',updated_at=? WHERE id=?",
      ).run(now(), refund.id);
      event("provider.refund", row.id, { eventId: e.id }, e.id);
      db.exec("COMMIT");
    } catch (err) {
      db.exec("ROLLBACK");
      throw err;
    }
  }
  app.get("/api/admin/commerce", requireAdmin, (_req, res) =>
    res.json({
      finance: financials(),
      promotions: allPromotions(),
      refunds: db
        .prepare(
          "SELECT r.*,u.name,u.email,o.amount,o.mode,json_extract(o.payload,'$.paymentProvider') AS payment_provider FROM commerce_refunds r JOIN users u ON u.id=r.user_id JOIN orders o ON o.id=r.order_id ORDER BY r.created_at DESC",
        )
        .all()
        .map((r) => ({
          id: r.id,
          orderId: r.order_id,
          userId: r.user_id,
          name: r.name,
          email: r.email,
          reason: r.reason,
          status: r.status,
          note: r.note,
          amount: r.amount,
          mode: r.mode,
          paymentProvider: r.payment_provider || r.mode,
          createdAt: r.created_at,
        })),
      audit: db
        .prepare(
          "SELECT action,payload,created_at AS createdAt FROM audit_log ORDER BY created_at DESC LIMIT 150",
        )
        .all()
        .map((a) => ({ ...a, payload: JSON.parse(a.payload || "{}") })),
      settings: settings(),
      taxConfigured: process.env.STRIPE_AUTOMATIC_TAX === "true",
    }),
  );
  app.post("/api/admin/commerce/promotions", requireAdmin, (req, res) => {
    try {
      const b = req.body || {},
        code = cleanCode(b.code),
        percent = Number(b.percent),
        minSpend = Number(b.minSpend || 0),
        starts = asDate(b.startsAt),
        ends = asDate(b.endsAt);
      if (
        !/^[A-Z0-9_-]{3,40}$/.test(code) ||
        !Number.isFinite(percent) ||
        percent <= 0 ||
        percent > 100 ||
        !Number.isFinite(minSpend) ||
        minSpend < 0 ||
        minSpend > 100000 ||
        starts === false ||
        ends === false ||
        (starts && ends && starts >= ends) ||
        !["all", "products", "membership"].includes(b.scope || "all")
      )
        throw error("Provide a valid code, percentage, scope, and date range.");
      for (const v of [b.maxUses, b.perUser])
        if (
          v !== undefined &&
          v !== null &&
          v !== "" &&
          (!Number.isInteger(Number(v)) || Number(v) < 1 || Number(v) > 1000000)
        )
          throw error("Redemption limits must be positive whole numbers.");
      if (
        db.prepare("SELECT id FROM commerce_promotions WHERE code=?").get(code)
      )
        throw error("This promotion code already exists.", 409);
      const id = randomUUID();
      db.prepare(
        "INSERT INTO commerce_promotions VALUES (?,?,?,?,?,?,?,?,?,?,?,?)",
      ).run(
        id,
        code,
        percent,
        starts,
        ends,
        b.maxUses ? Number(b.maxUses) : null,
        b.perUser ? Number(b.perUser) : null,
        minSpend,
        b.scope || "all",
        1,
        b.recurring === false ? 0 : 1,
        now(),
      );
      audit(req.user.id, "promotion.created", { code });
      res
        .status(201)
        .json({ promotion: allPromotions().find((p) => p.id === id) });
    } catch (e) {
      fail(res, e.status || 400, e.message);
    }
  });
  app.patch("/api/admin/commerce/promotions/:id", requireAdmin, (req, res) => {
    if (typeof req.body?.enabled !== "boolean")
      return fail(res, 400, "Choose the promotion enabled state.");
    const row = db
      .prepare("UPDATE commerce_promotions SET enabled=? WHERE id=?")
      .run(req.body.enabled ? 1 : 0, req.params.id);
    if (!row.changes) return fail(res, 404, "Promotion not found.");
    audit(req.user.id, "promotion.state_changed", {
      id: req.params.id,
      enabled: req.body.enabled,
    });
    res.json({ success: true });
  });
  app.post(
    "/api/admin/commerce/refunds/:id/approve",
    requireAdmin,
    async (req, res) => {
      try {
        const r = db
          .prepare("SELECT * FROM commerce_refunds WHERE id=?")
          .get(req.params.id);
        if (!r) throw error("Refund request not found.", 404);
        res.json(await approveRefund(r, req.user, req.body || {}));
      } catch (e) {
        fail(res, e.status || 502, e.message);
      }
    },
  );
  app.post("/api/admin/commerce/refunds/:id/deny", requireAdmin, (req, res) => {
    const note = req.body?.note;
    if (
      typeof note !== "string" ||
      note.trim().length < 5 ||
      note.length > 1000
    )
      return fail(res, 400, "Explain the decision in 5–1,000 characters.");
    const r = db
      .prepare(
        "UPDATE commerce_refunds SET status='denied',note=?,updated_at=? WHERE id=? AND status='requested'",
      )
      .run(note.trim(), now(), req.params.id);
    if (!r.changes)
      return fail(res, 409, "Only a new refund request can be declined.");
    audit(req.user.id, "refund.denied", { id: req.params.id });
    res.json({ success: true });
  });
  app.patch("/api/admin/commerce/settings", requireAdmin, (req, res) => {
    const b = req.body || {},
      s = settings();
    for (const key of ["address", "taxId", "supportEmail", "invoicePrefix"])
      if (b[key] !== undefined) {
        if (
          typeof b[key] !== "string" ||
          b[key].length > (key === "address" ? 500 : 120)
        )
          return fail(res, 400, "Seller details are too long.");
        s[key] = b[key].trim();
      }
    if (s.supportEmail && !ctx.validEmail(s.supportEmail))
      return fail(res, 400, "Enter a valid support email.");
    db.prepare("UPDATE commerce_settings SET payload=? WHERE id=1").run(
      JSON.stringify(s),
    );
    audit(req.user.id, "seller.details_updated");
    res.json({ settings: s });
  });
  app.get("/api/admin/commerce/export/:type", requireAdmin, (req, res) => {
    let header, rows;
    if (req.params.type === "orders") {
      header = ["Order", "Date", "Mode", "Status", "Customer ID", "Total USD"];
      rows = db
        .prepare("SELECT * FROM orders ORDER BY created_at DESC")
        .all()
        .map((r) => {
          const o = orderRecord(r);
          return [r.id, r.created_at, r.mode, o.status, r.user_id, r.amount];
        });
    } else if (req.params.type === "audit") {
      header = ["Date", "Action", "Details"];
      rows = db
        .prepare(
          "SELECT action,payload,created_at FROM audit_log ORDER BY created_at DESC",
        )
        .all()
        .map((r) => [r.created_at, r.action, r.payload]);
    } else return fail(res, 404, "Export not found.");
    res.setHeader(
      "Content-Disposition",
      `attachment; filename="rtr-${req.params.type}.csv"`,
    );
    res
      .type("text/csv")
      .send(
        [header, ...rows]
          .map((row) => row.map(csvValue).join(","))
          .join("\r\n"),
      );
  });
  return {
    resolvePromotion,
    recordPromotion,
    reservePromotion,
    reserveWirePromotion,
    releasePromotion,
    stripeTaxOptions,
    recordPayment,
    onBillingEvent,
    financials,
    sellerSnapshot: settings,
  };
}
