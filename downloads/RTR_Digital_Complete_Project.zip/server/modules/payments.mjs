import {
  randomBytes,
  randomUUID,
  createCipheriv,
  createDecipheriv,
} from "node:crypto";
import { readFileSync, writeFileSync, chmodSync } from "node:fs";
import { resolve } from "node:path";
import { SELLER_NAME } from "../brand.mjs";

const problem = (message, status = 400) =>
  Object.assign(new Error(message), { status });
const cents = (value) => Math.round(Number(value) * 100);
const exactUsd = (value, total) =>
  typeof value === "string" &&
  /^\d+(?:\.\d{1,2})?$/.test(value) &&
  Number(value) === total;
const exactAmount = (value, total) =>
  typeof value === "number" && Number.isFinite(value) && value === total;
const bankFields = [
  "beneficiary",
  "bankName",
  "accountNumber",
  "swift",
  "ifsc",
  "iban",
  "routingNumber",
  "bankAddress",
  "beneficiaryAddress",
  "intermediaryBank",
  "instructions",
];
const providerFields = {
  paypal: ["clientId", "clientSecret", "merchantId"],
  razorpay: ["keyId", "keySecret"],
};
const mask = (value) => (value ? `••••${String(value).slice(-4)}` : "");
const idPattern = /^[A-Za-z0-9_-]{1,100}$/;

// Payment credentials and bank snapshots never enter public product/order payloads.
// Keeping the encryption key next to (rather than inside) the database also makes
// database-only backups and exports safe to inspect. Back up this key separately.
export function registerPayments(app, ctx) {
  const {
    db,
    dataDir,
    requireAuth,
    requireAdmin,
    fail,
    audit,
    plans,
    product,
    products,
    visibleSubscription,
    activeSubscription,
    now,
    hash,
    verifyPassword,
    production,
    demoMode,
    publicBaseUrl,
    options = {},
    fulfill,
    liveProductAvailable,
    rateLimit,
  } = ctx;
  const commerce = ctx.commerce || {};
  const keyPath = resolve(dataDir, ".payment-encryption-key");
  let encryptionKey;
  try {
    encryptionKey = readFileSync(keyPath);
  } catch (e) {
    if (e.code !== "ENOENT") throw e;
    const fresh = randomBytes(32);
    try {
      writeFileSync(keyPath, fresh, { flag: "wx", mode: 0o600 });
    } catch (writeError) {
      if (writeError.code !== "EEXIST") throw writeError;
    }
    encryptionKey = readFileSync(keyPath);
  }
  if (encryptionKey.length !== 32)
    throw new Error(
      "Invalid payment encryption key; restore the original 32-byte key.",
    );
  chmodSync(keyPath, 0o600);
  const encrypt = (value) => {
    const iv = randomBytes(12),
      cipher = createCipheriv("aes-256-gcm", encryptionKey, iv);
    const data = Buffer.concat([
      cipher.update(JSON.stringify(value), "utf8"),
      cipher.final(),
    ]);
    return [iv, cipher.getAuthTag(), data]
      .map((b) => b.toString("base64"))
      .join(".");
  };
  const decrypt = (payload) => {
    const [iv, tag, data] = payload
      .split(".")
      .map((s) => Buffer.from(s, "base64"));
    const decipher = createDecipheriv("aes-256-gcm", encryptionKey, iv);
    decipher.setAuthTag(tag);
    return JSON.parse(
      Buffer.concat([decipher.update(data), decipher.final()]).toString("utf8"),
    );
  };
  db.exec(`
    CREATE TABLE IF NOT EXISTS payment_settings (id INTEGER PRIMARY KEY CHECK(id=1), payload TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS payment_bank_versions (version INTEGER PRIMARY KEY, payload TEXT NOT NULL, created_at TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS payment_orders (
      id TEXT PRIMARY KEY, user_id TEXT NOT NULL REFERENCES users(id), provider TEXT NOT NULL,
      status TEXT NOT NULL, total REAL NOT NULL, currency TEXT NOT NULL DEFAULT 'USD',
      idempotency_key TEXT UNIQUE NOT NULL, request_hash TEXT NOT NULL, snapshot TEXT NOT NULL,
      provider_id TEXT, approval_url TEXT, settlement_id TEXT UNIQUE, provider_refund_id TEXT,
      customer_reference TEXT, customer_note TEXT, bank_reference TEXT, admin_note TEXT,
      expires_at INTEGER NOT NULL, created_at TEXT NOT NULL, updated_at TEXT NOT NULL
    );
    CREATE INDEX IF NOT EXISTS payment_orders_owner ON payment_orders(user_id,created_at);
    CREATE TABLE IF NOT EXISTS membership_checkout_locks (user_id TEXT PRIMARY KEY REFERENCES users(id), intent_id TEXT UNIQUE NOT NULL, expires_at INTEGER NOT NULL);
    CREATE TABLE IF NOT EXISTS payment_refund_attempts (order_id TEXT PRIMARY KEY REFERENCES payment_orders(id), receipt TEXT UNIQUE NOT NULL, created_at TEXT NOT NULL);
  `);
  if (!db.prepare("SELECT 1 FROM payment_settings WHERE id=1").get()) {
    db.prepare("INSERT INTO payment_settings VALUES (1,?)").run(
      encrypt({
        providers: {
          paypal: { enabled: false, environment: "sandbox", version: 1 },
          razorpay: { enabled: false, version: 1 },
        },
        bank: {
          enabled: false,
          version: 0,
          ...Object.fromEntries(bankFields.map((field) => [field, ""])),
        },
      }),
    );
  }
  const settings = () =>
    decrypt(
      db.prepare("SELECT payload FROM payment_settings WHERE id=1").get()
        .payload,
    );
  const rowById = (id) =>
    db.prepare("SELECT * FROM payment_orders WHERE id=?").get(id);
  const isDemoAdmin = (user) =>
    !production && demoMode && user?.email === "demo-admin@rtr.example";
  function reauthenticate(req) {
    if (isDemoAdmin(req.user)) return;
    if (
      typeof req.body?.password !== "string" ||
      !verifyPassword(req.body.password, req.user.password)
    )
      throw problem(
        "Confirm your administrator password to change payment details or reconcile funds.",
        403,
      );
  }
  function providerReady(id, config) {
    if (
      !config?.enabled ||
      !providerFields[id].every((field) => Boolean(config[field]))
    )
      return false;
    if (id === "paypal") return !production || config.environment === "live";
    return (
      /^rzp_(test|live)_[A-Za-z0-9]+$/.test(config.keyId) &&
      (!production || config.keyId.startsWith("rzp_live_"))
    );
  }
  function safeOrigin() {
    try {
      const url = new URL(publicBaseUrl);
      if (
        !/^https?:$/.test(url.protocol) ||
        url.username ||
        url.password ||
        (production && url.protocol !== "https:")
      )
        return null;
      return url.origin;
    } catch {
      return null;
    }
  }
  const methods = () => {
    const s = settings(),
      origin = safeOrigin();
    return {
      methods: [
        {
          id: "stripe",
          name: "Card / Stripe",
          available: Boolean(ctx.stripeReady),
          recurring: true,
          description:
            "Cards and supported local methods. Memberships renew automatically.",
        },
        {
          id: "paypal",
          name: "PayPal",
          available: Boolean(
            origin && providerReady("paypal", s.providers.paypal),
          ),
          recurring: false,
          description:
            "Pay in USD with PayPal. Memberships are prepaid for one fixed term and do not renew.",
        },
        {
          id: "razorpay",
          name: "Razorpay",
          available: Boolean(
            origin && providerReady("razorpay", s.providers.razorpay),
          ),
          recurring: false,
          description:
            "Pay in USD through Razorpay where supported by the seller’s account. Memberships do not renew.",
        },
        {
          id: "wire",
          name: "Bank / wire transfer",
          available: Boolean(s.bank.enabled),
          recurring: false,
          description:
            "Send USD to the seller’s bank. Access starts only after an administrator verifies cleared funds. Memberships do not renew.",
        },
      ],
      currency: "USD",
      seller: SELLER_NAME,
      demo: !production && demoMode,
    };
  };
  const locks = new Map();
  async function exclusive(key, action) {
    const previous = locks.get(key) || Promise.resolve();
    let release;
    const current = new Promise((r) => {
      release = r;
    });
    locks.set(key, current);
    await previous;
    try {
      return await action();
    } finally {
      release();
      if (locks.get(key) === current) locks.delete(key);
    }
  }
  function expire(row) {
    if (
      ["pending", "creating", "creation_failed"].includes(row.status) &&
      row.expires_at <= Date.now()
    ) {
      db.prepare(
        "UPDATE payment_orders SET status='expired',updated_at=? WHERE id=?",
      ).run(now(), row.id);
      commerce.releasePromotion?.(row.id);
      db.prepare("DELETE FROM membership_checkout_locks WHERE intent_id=?").run(
        row.id,
      );
      return rowById(row.id);
    }
    return row;
  }
  function paymentView(original, admin = false) {
    const row = expire(original),
      snapshot = decrypt(row.snapshot);
    if (production && snapshot.environment !== "live")
      throw problem(
        "This development payment is unavailable in production.",
        403,
      );
    const fulfilled = db
      .prepare("SELECT payload FROM orders WHERE id=?")
      .get(row.id);
    const order = fulfilled ? JSON.parse(fulfilled.payload) : null;
    return {
      id: row.id,
      provider: row.provider,
      status: order?.status === "refunded" ? "refunded" : row.status,
      total: row.total,
      currency: "USD",
      reference: row.id,
      expiresAt: new Date(row.expires_at).toISOString(),
      createdAt: row.created_at,
      plan: snapshot.plan || null,
      interval: snapshot.plan ? snapshot.interval : null,
      recurring: false,
      description: snapshot.plan
        ? `${plans[snapshot.plan]?.name || snapshot.plan} membership — prepaid ${snapshot.interval === "yearly" ? "year" : "month"}; no automatic renewal`
        : "Digital product purchase",
      ...(row.status === "pending" && row.approval_url
        ? { approvalUrl: row.approval_url }
        : {}),
      ...(row.provider === "wire" &&
      row.status === "pending" &&
      !admin &&
      (!production || snapshot.environment === "live")
        ? { bank: snapshot.bank }
        : {}),
      ...(row.status === "completed" ? { orderId: row.id } : {}),
      ...(order?.membershipReviewRequired
        ? { membershipReviewRequired: true }
        : {}),
      customerReference: row.customer_reference || "",
      customerNote: row.customer_note || "",
      ...(admin
        ? {
            userId: row.user_id,
            bankVersion: snapshot.bank?.version || null,
            ...(snapshot.bank
              ? {
                  bank: {
                    version: snapshot.bank.version,
                    bankName: snapshot.bank.bankName,
                    beneficiary: snapshot.bank.beneficiary,
                    accountLast4: snapshot.bank.accountNumber?.slice(-4) || "",
                    ibanLast4: snapshot.bank.iban?.slice(-4) || "",
                  },
                }
              : {}),
            bankReference: row.bank_reference || "",
            adminNote: row.admin_note || "",
          }
        : {}),
    };
  }
  const owned = (req) => {
    const row = rowById(req.params.id);
    if (!row || row.user_id !== req.user.id)
      throw problem("Payment not found.", 404);
    if (production && decrypt(row.snapshot).environment !== "live")
      throw problem(
        "This development payment is unavailable in production.",
        403,
      );
    return expire(row);
  };
  const liveVisible = (row) =>
    !production || decrypt(row.snapshot).environment === "live";
  const handler = (action) => async (req, res, next) => {
    try {
      await action(req, res);
    } catch (e) {
      if (e.status) fail(res, e.status, e.message);
      else next(e);
    }
  };
  const fetchPayment = options.paymentFetch || globalThis.fetch;
  async function request(
    provider,
    config,
    path,
    { method = "GET", body, headers = {} } = {},
  ) {
    const host =
      provider === "paypal"
        ? config.environment === "live"
          ? "https://api-m.paypal.com"
          : "https://api-m.sandbox.paypal.com"
        : "https://api.razorpay.com";
    if (!path.startsWith("/v1/") && !path.startsWith("/v2/"))
      throw problem("Invalid payment API path.", 500);
    const controller = new AbortController();
    let timer;
    try {
      return await Promise.race([
        (async () => {
          const response = await fetchPayment(host + path, {
            method,
            redirect: "error",
            signal: controller.signal,
            headers: {
              accept: "application/json",
              ...(body !== undefined
                ? { "content-type": "application/json" }
                : {}),
              ...headers,
            },
            ...(body !== undefined
              ? { body: typeof body === "string" ? body : JSON.stringify(body) }
              : {}),
          });
          const raw = await response.text();
          if (raw.length > 1024 * 1024)
            throw problem(
              "Payment provider returned an oversized response.",
              502,
            );
          let result;
          try {
            result = raw ? JSON.parse(raw) : {};
          } catch {
            throw problem(
              "Payment provider returned an invalid response.",
              502,
            );
          }
          if (!response.ok)
            throw problem(
              `The ${provider === "paypal" ? "PayPal" : "Razorpay"} request could not be completed. Check the provider dashboard before retrying.`,
              502,
            );
          return result;
        })(),
        new Promise((_, reject) => {
          timer = setTimeout(() => {
            controller.abort();
            reject(
              problem(
                "The payment provider timed out. Check payment status before retrying.",
                504,
              ),
            );
          }, 12000);
        }),
      ]);
    } catch (e) {
      if (e.status) throw e;
      throw problem(
        "The payment provider is unavailable. Check payment status before retrying.",
        502,
      );
    } finally {
      clearTimeout(timer);
    }
  }
  async function paypalToken(config) {
    const token = await request("paypal", config, "/v1/oauth2/token", {
      method: "POST",
      body: "grant_type=client_credentials",
      headers: {
        authorization: `Basic ${Buffer.from(`${config.clientId}:${config.clientSecret}`).toString("base64")}`,
        "content-type": "application/x-www-form-urlencoded",
      },
    });
    if (typeof token.access_token !== "string" || !token.access_token)
      throw problem("PayPal authentication failed.", 502);
    return token.access_token;
  }
  const razorHeaders = (config) => ({
    authorization: `Basic ${Buffer.from(`${config.keyId}:${config.keySecret}`).toString("base64")}`,
  });
  function validApproval(value, provider, config) {
    try {
      const url = new URL(value);
      const allowed =
        provider === "paypal"
          ? config.environment === "live"
            ? ["www.paypal.com", "paypal.com"]
            : ["www.sandbox.paypal.com", "sandbox.paypal.com"]
          : ["rzp.io", "rzp.co", "razorpay.com", "www.razorpay.com"];
      return url.protocol === "https:" &&
        !url.username &&
        !url.password &&
        allowed.includes(url.hostname)
        ? url.href
        : null;
    } catch {
      return null;
    }
  }
  async function createProvider(row, snapshot) {
    const config = snapshot.provider,
      origin = safeOrigin();
    let result, approvalUrl;
    if (row.provider === "paypal") {
      const token = await paypalToken(config);
      result = await request("paypal", config, "/v2/checkout/orders", {
        method: "POST",
        headers: {
          authorization: `Bearer ${token}`,
          "PayPal-Request-Id": `create-${row.id}`,
        },
        body: {
          intent: "CAPTURE",
          purchase_units: [
            {
              reference_id: row.id,
              custom_id: row.id,
              invoice_id: row.id,
              payee: { merchant_id: config.merchantId },
              amount: { currency_code: "USD", value: row.total.toFixed(2) },
              description: snapshot.plan
                ? "RTR Digital prepaid membership — no automatic renewal"
                : "RTR Digital products",
            },
          ],
          payment_source: {
            paypal: {
              experience_context: {
                brand_name: SELLER_NAME,
                user_action: "PAY_NOW",
                return_url: `${origin}/billing?payment=${row.id}&status=return`,
                cancel_url: `${origin}/billing?payment=${row.id}&status=cancel`,
              },
            },
          },
        },
      });
      approvalUrl = result.links?.find((link) =>
        ["payer-action", "approve"].includes(link.rel),
      )?.href;
    } else {
      result = await request("razorpay", config, "/v1/payment_links", {
        method: "POST",
        headers: razorHeaders(config),
        body: {
          amount: cents(row.total),
          currency: "USD",
          accept_partial: false,
          reference_id: row.id,
          description:
            "RTR Digital purchase — USD; prepaid memberships do not renew",
          expire_by: Math.floor(row.expires_at / 1000),
          notes: { rtr_payment_id: row.id },
          callback_url: `${origin}/billing?payment=${row.id}&status=return`,
          callback_method: "get",
        },
      });
      approvalUrl = result.short_url;
    }
    approvalUrl = validApproval(approvalUrl, row.provider, config);
    if (!idPattern.test(result.id || "") || !approvalUrl)
      throw problem(
        "The payment provider did not return a valid checkout link.",
        502,
      );
    db.prepare(
      "UPDATE payment_orders SET provider_id=?,approval_url=?,status='pending',updated_at=? WHERE id=?",
    ).run(result.id, approvalUrl, now(), row.id);
  }
  function ensureMembershipAvailable(user, snapshot) {
    if (!snapshot.plan) return;
    const current = visibleSubscription(user);
    if (
      current?.mode === "stripe" &&
      current.stripeSubscriptionId &&
      !["canceled", "incomplete_expired"].includes(current.status)
    )
      throw problem(
        "Resolve the existing billing subscription before purchasing a prepaid membership.",
        409,
      );
    if (activeSubscription(user) && !current?.isTrial)
      throw problem(
        "An active membership already exists. Contact support to reconcile this payment.",
        409,
      );
  }
  function complete(original, settlementId, details = {}) {
    let row = expire(rowById(original.id));
    if (row.status === "completed") return row;
    if (row.status !== "pending")
      throw problem(
        "This payment is no longer pending. Contact support if funds were sent.",
        409,
      );
    const snapshot = decrypt(row.snapshot);
    if (production && snapshot.environment !== "live")
      throw problem(
        "Development payments cannot grant production access.",
        403,
      );
    // fulfill re-reads the user and records a paid membership for review rather
    // than replacing an active membership if settlement races another checkout.
    const duplicate = db
      .prepare("SELECT id FROM payment_orders WHERE settlement_id=? AND id!=?")
      .get(settlementId, row.id);
    if (duplicate)
      throw problem("This provider payment has already been reconciled.", 409);
    db.prepare(
      "UPDATE payment_orders SET settlement_id=?,updated_at=? WHERE id=?",
    ).run(settlementId, now(), row.id);
    const mode = snapshot.environment === "live" ? row.provider : "demo";
    fulfill(
      row.user_id,
      row.id,
      snapshot.selected,
      snapshot.plan,
      snapshot.interval,
      row.total,
      mode,
      null,
      row.idempotency_key,
      null,
      {
        prepaid: Boolean(snapshot.plan),
        isPrepaid: Boolean(snapshot.plan),
        autoRenew: false,
        recurring: false,
        paymentProvider: row.provider,
        providerPaymentId: settlementId,
        paymentEnvironment: snapshot.environment,
        seller: snapshot.seller,
        ...(snapshot.plan
          ? { membershipNotice: "Prepaid fixed term; no automatic renewal" }
          : {}),
        ...details,
      },
    );
    commerce.recordPromotion?.(row.user_id, row.id, snapshot.promotionCode);
    commerce.releasePromotion?.(row.id);
    db.prepare("DELETE FROM membership_checkout_locks WHERE intent_id=?").run(
      row.id,
    );
    db.prepare(
      "UPDATE payment_orders SET status='completed',updated_at=? WHERE id=?",
    ).run(now(), row.id);
    audit(row.user_id, "payment.verified", {
      paymentId: row.id,
      provider: row.provider,
      amount: row.total,
    });
    return rowById(row.id);
  }
  function checkPayPalOrder(result, row, snapshot) {
    if (
      result.id !== row.provider_id ||
      result.intent !== "CAPTURE" ||
      result.purchase_units?.length !== 1
    )
      throw problem("PayPal returned a different order.", 409);
    const unit = result.purchase_units[0],
      captures = unit.payments?.captures;
    if (
      unit.reference_id !== row.id ||
      unit.custom_id !== row.id ||
      unit.invoice_id !== row.id ||
      unit.payee?.merchant_id !== snapshot.provider.merchantId ||
      unit.amount?.currency_code !== "USD" ||
      !exactUsd(unit.amount?.value, row.total)
    )
      throw problem(
        "PayPal payment identity, recipient, or USD amount does not match this order.",
        409,
      );
    return captures;
  }
  function checkPayPal(result, row, snapshot) {
    const captures = checkPayPalOrder(result, row, snapshot);
    if (result.status !== "COMPLETED" || captures?.length !== 1)
      throw problem("PayPal has not confirmed this payment as completed.", 409);
    const capture = captures[0];
    if (
      !idPattern.test(capture.id || "") ||
      capture.status !== "COMPLETED" ||
      capture.amount?.currency_code !== "USD" ||
      !exactUsd(capture.amount?.value, row.total) ||
      capture.final_capture !== true
    )
      throw problem(
        "PayPal has not confirmed the exact completed USD capture.",
        409,
      );
    return `paypal:${capture.id}`;
  }
  async function verifyProvider(row) {
    if (row.status === "completed") return row;
    if (row.status !== "pending" || !row.provider_id)
      throw problem("This payment is not available for verification.", 409);
    const snapshot = decrypt(row.snapshot),
      config = snapshot.provider;
    if (production && snapshot.environment !== "live")
      throw problem("Test payments cannot grant production access.", 403);
    if (row.provider === "paypal") {
      const token = await paypalToken(config),
        headers = { authorization: `Bearer ${token}` };
      let result = await request(
        "paypal",
        config,
        `/v2/checkout/orders/${encodeURIComponent(row.provider_id)}`,
        { headers },
      );
      if (result.id !== row.provider_id)
        throw problem("PayPal returned a different order.", 409);
      if (result.status === "APPROVED") {
        checkPayPalOrder(result, row, snapshot);
        // Only the authenticated owner can trigger capture; the capture response or
        // return URL never grants access. Retrieve the authoritative order again.
        await request(
          "paypal",
          config,
          `/v2/checkout/orders/${encodeURIComponent(row.provider_id)}/capture`,
          {
            method: "POST",
            body: {},
            headers: { ...headers, "PayPal-Request-Id": `capture-${row.id}` },
          },
        );
        result = await request(
          "paypal",
          config,
          `/v2/checkout/orders/${encodeURIComponent(row.provider_id)}`,
          { headers },
        );
      }
      return complete(row, checkPayPal(result, row, snapshot));
    }
    const headers = razorHeaders(config);
    const result = await request(
      "razorpay",
      config,
      `/v1/payment_links/${encodeURIComponent(row.provider_id)}`,
      { headers },
    );
    if (
      result.id !== row.provider_id ||
      result.status !== "paid" ||
      result.reference_id !== row.id ||
      result.notes?.rtr_payment_id !== row.id ||
      result.currency !== "USD" ||
      result.amount !== cents(row.total) ||
      result.amount_paid !== cents(row.total) ||
      result.accept_partial === true ||
      !Array.isArray(result.payments)
    )
      throw problem(
        "Razorpay has not confirmed the exact USD payment for this reference.",
        409,
      );
    const captures = result.payments.filter(
      (entry) => entry.status === "captured",
    );
    if (captures.length !== 1)
      throw problem(
        "Razorpay has not confirmed one captured payment for this reference.",
        409,
      );
    const linked = captures[0],
      paymentId = linked.payment_id;
    if (
      (linked.plink_id && linked.plink_id !== row.provider_id) ||
      (linked.amount !== undefined &&
        Number(linked.amount) !== cents(row.total))
    )
      throw problem(
        "Razorpay's captured payment does not match this payment link.",
        409,
      );
    if (!idPattern.test(paymentId || ""))
      throw problem("Razorpay returned an invalid payment reference.", 409);
    const payment = await request(
      "razorpay",
      config,
      `/v1/payments/${encodeURIComponent(paymentId)}`,
      { headers },
    );
    // Fetching both objects under the snapshotted account's API credentials verifies
    // payee ownership; IDs, reference, amount and capture state bind the two objects.
    if (
      payment.id !== paymentId ||
      payment.status !== "captured" ||
      payment.captured !== true ||
      payment.currency !== "USD" ||
      payment.amount !== cents(row.total) ||
      payment.amount_refunded > 0 ||
      payment.refund_status === "full" ||
      payment.refund_status === "partial" ||
      (result.order_id && payment.order_id !== result.order_id)
    )
      throw problem(
        "Razorpay has not confirmed the captured payment in this seller account.",
        409,
      );
    return complete(row, `razorpay:${paymentId}`);
  }

  app.get("/api/payments/methods", (_req, res) => res.json(methods()));
  app.get(
    "/api/admin/payments",
    requireAdmin,
    handler((req, res) => {
      const s = settings();
      const providers = [
        {
          id: "stripe",
          name: "Card / Stripe",
          enabled: Boolean(ctx.stripeReady),
          configured: Boolean(ctx.stripeReady),
          available: Boolean(ctx.stripeReady),
          environment: production ? "live" : "development",
        },
        ...Object.entries(s.providers).map(([id, value]) => ({
          id,
          name: id === "paypal" ? "PayPal" : "Razorpay",
          enabled: Boolean(value.enabled),
          configured: providerFields[id].every((field) =>
            Boolean(value[field]),
          ),
          available: Boolean(providerReady(id, value) && safeOrigin()),
          environment:
            id === "paypal"
              ? value.environment
              : value.keyId?.startsWith("rzp_live_")
                ? "live"
                : "test",
          version: value.version,
          ...Object.fromEntries(
            providerFields[id].flatMap((field) => [
              [field, field.endsWith("Secret") ? "" : mask(value[field])],
              [
                `has${field[0].toUpperCase()}${field.slice(1)}`,
                Boolean(value[field]),
              ],
            ]),
          ),
        })),
      ];
      const bank = {
        ...s.bank,
        accountNumber: mask(s.bank.accountNumber),
        iban: mask(s.bank.iban),
        routingNumber: mask(s.bank.routingNumber),
      };
      const transfers = db
        .prepare(
          "SELECT p.*,u.name AS customer_name,u.email AS customer_email FROM payment_orders p JOIN users u ON u.id=p.user_id WHERE p.provider='wire' ORDER BY p.created_at DESC LIMIT 200",
        )
        .all()
        .filter(liveVisible)
        .map((row) => ({
          ...paymentView(row, true),
          customerName: row.customer_name,
          customerEmail: row.customer_email,
        }));
      res.json({
        providers,
        bank,
        transfers,
        passwordRequired: !isDemoAdmin(req.user),
        demoReauthentication: isDemoAdmin(req.user),
      });
    }),
  );
  app.post(
    "/api/admin/payments/bank/reveal",
    requireAdmin,
    rateLimit("payments.bank.reveal", 10),
    handler((req, res) => {
      reauthenticate(req);
      audit(req.user.id, "payment.bank.revealed");
      res.json({ bank: settings().bank });
    }),
  );
  app.patch(
    "/api/admin/payments/settings",
    requireAdmin,
    rateLimit("payments.settings", 20),
    handler((req, res) => {
      reauthenticate(req);
      const s = settings(),
        input = req.body || {};
      for (const id of Object.keys(providerFields)) {
        const update = input.providers?.[id];
        if (update === undefined) continue;
        if (!update || typeof update !== "object" || Array.isArray(update))
          throw problem("Invalid provider settings.");
        if (
          update.removeFields !== undefined &&
          (!Array.isArray(update.removeFields) ||
            !update.removeFields.every((field) =>
              providerFields[id].includes(field),
            ))
        )
          throw problem("Invalid provider fields to remove.");
        const config = { ...s.providers[id] };
        if (update.enabled !== undefined) {
          if (typeof update.enabled !== "boolean")
            throw problem("Provider enabled must be true or false.");
          config.enabled = update.enabled;
        }
        if (id === "paypal" && update.environment !== undefined) {
          if (!["sandbox", "live"].includes(update.environment))
            throw problem("Choose sandbox or live PayPal.");
          config.environment = update.environment;
        }
        for (const field of providerFields[id]) {
          if (
            update[`remove${field[0].toUpperCase()}${field.slice(1)}`] ===
              true ||
            update.removeFields?.includes(field)
          ) {
            delete config[field];
            continue;
          }
          if (update[field] === undefined || update[field] === "") continue;
          if (
            typeof update[field] !== "string" ||
            update[field].length > 1000 ||
            /[\r\n\0]/.test(update[field])
          )
            throw problem("Invalid provider credential.");
          if (!update[field].trim() || update[field].includes("••••")) continue;
          config[field] = update[field].trim();
        }
        if (
          id === "razorpay" &&
          config.keyId &&
          !/^rzp_(test|live)_[A-Za-z0-9]+$/.test(config.keyId)
        )
          throw problem("Use a Razorpay test or live API key ID.");
        config.version = (config.version || 0) + 1;
        s.providers[id] = config;
      }
      if (input.bank !== undefined) {
        if (
          !input.bank ||
          typeof input.bank !== "object" ||
          Array.isArray(input.bank)
        )
          throw problem("Invalid bank details.");
        if (
          input.bank.removeFields !== undefined &&
          (!Array.isArray(input.bank.removeFields) ||
            !input.bank.removeFields.every((field) =>
              bankFields.includes(field),
            ))
        )
          throw problem("Invalid bank fields to remove.");
        const bank = { ...s.bank };
        if (input.bank.enabled !== undefined) {
          if (typeof input.bank.enabled !== "boolean")
            throw problem("Bank enabled must be true or false.");
          bank.enabled = input.bank.enabled;
        }
        for (const field of bankFields) {
          if (
            input.bank[`remove${field[0].toUpperCase()}${field.slice(1)}`] ===
              true ||
            input.bank.removeFields?.includes(field)
          ) {
            bank[field] = "";
            continue;
          }
          if (input.bank[field] === undefined) continue;
          if (
            typeof input.bank[field] !== "string" ||
            input.bank[field].length >
              (field === "instructions" ? 4000 : 500) ||
            /\0/.test(input.bank[field])
          )
            throw problem("Invalid bank details.");
          if (input.bank[field].includes("••••")) continue;
          if (
            ["accountNumber", "iban", "routingNumber"].includes(field) &&
            !input.bank[field].trim()
          )
            continue;
          bank[field] = input.bank[field].trim();
        }
        if (
          bank.enabled &&
          (!bank.beneficiary ||
            !bank.bankName ||
            (!bank.accountNumber && !bank.iban))
        )
          throw problem(
            "Enter the beneficiary, bank name and account number or IBAN before enabling bank transfers.",
          );
        bank.version = (s.bank.version || 0) + 1;
        s.bank = bank;
      }
      db.exec("BEGIN IMMEDIATE");
      try {
        if (input.bank !== undefined)
          db.prepare("INSERT INTO payment_bank_versions VALUES (?,?,?)").run(
            s.bank.version,
            encrypt(s.bank),
            now(),
          );
        db.prepare("UPDATE payment_settings SET payload=? WHERE id=1").run(
          encrypt(s),
        );
        audit(req.user.id, "payment.settings.updated", {
          providers: Object.keys(input.providers || {}),
          bankVersion: s.bank.version,
          demoReauthentication: isDemoAdmin(req.user),
        });
        db.exec("COMMIT");
      } catch (e) {
        db.exec("ROLLBACK");
        throw e;
      }
      res.json({
        success: true,
        bankVersion: s.bank.version,
        demoReauthentication: isDemoAdmin(req.user),
      });
    }),
  );
  app.post(
    "/api/payments/checkout",
    requireAuth,
    rateLimit("payments.checkout", 50),
    handler(async (req, res) => {
      const key = req.get("Idempotency-Key");
      if (!key || !/^[A-Za-z0-9_-]{8,128}$/.test(key))
        throw problem("A valid Idempotency-Key header is required.");
      const idem = `payments:${req.user.id}:${key}`;
      await exclusive(idem, async () => {
        const input = req.body || {},
          provider = input.provider,
          interval = input.interval || "monthly";
        if (!["paypal", "razorpay", "wire"].includes(provider))
          throw problem(
            "Choose PayPal, Razorpay or bank transfer. Use the card checkout for Stripe.",
          );
        if (!["monthly", "yearly"].includes(interval))
          throw problem("Choose monthly or yearly membership.");
        if (
          input.plan &&
          (typeof input.plan !== "string" || !Object.hasOwn(plans, input.plan))
        )
          throw problem("Choose a valid membership plan.");
        if (
          !Array.isArray(input.productIds || []) ||
          (input.productIds || []).length > 50 ||
          !(input.productIds || []).every(
            (id) => typeof id === "string" && id.length < 150,
          )
        )
          throw problem("Cart is invalid.");
        const ids = [...new Set(input.productIds || [])].sort(),
          plan = input.plan || null;
        if ((!plan && !ids.length) || (plan && ids.length))
          throw problem(
            "Purchase a membership separately from individual products.",
          );
        const code =
          typeof input.coupon === "string"
            ? input.coupon.trim().toUpperCase()
            : "";
        const requestHash = hash(
          JSON.stringify({
            provider,
            ids,
            plan,
            interval: plan ? interval : null,
            code,
          }),
        );
        const previous = db
          .prepare("SELECT * FROM payment_orders WHERE idempotency_key=?")
          .get(idem);
        if (previous) {
          if (!liveVisible(previous))
            throw problem(
              "This development payment is unavailable in production.",
              403,
            );
          if (previous.request_hash !== requestHash)
            throw problem(
              "This checkout key was already used for a different purchase.",
              409,
            );
          return res.json(paymentView(previous));
        }
        const s = settings();
        if (
          !(provider === "wire"
            ? s.bank.enabled
            : providerReady(provider, s.providers[provider]) && safeOrigin())
        )
          throw problem(
            "This payment method is not configured for checkout.",
            503,
          );
        const environment =
          provider === "wire"
            ? production
              ? "live"
              : "development"
            : (
                  provider === "paypal"
                    ? s.providers.paypal.environment === "live"
                    : s.providers.razorpay.keyId.startsWith("rzp_live_")
                )
              ? "live"
              : "sandbox";
        if (production && environment !== "live")
          throw problem("Test payments cannot be used in production.", 403);
        const selected = ids.map((id) =>
          product(
            db
              .prepare(
                "SELECT * FROM products WHERE id=? AND status='published'",
              )
              .get(id),
          ),
        );
        if (selected.some((p) => !p))
          throw problem("A product is no longer available.");
        if (
          environment === "live" &&
          (selected.some((p) => !liveProductAvailable(p)) ||
            (plan &&
              !products().some(
                (p) => p.subscriptionIncluded && liveProductAvailable(p),
              )))
        )
          throw problem(
            "Publish original digital files before accepting live payments.",
          );
        const snapshot = {
          selected,
          plan,
          interval,
          environment,
          provider: provider === "wire" ? null : s.providers[provider],
          bank: provider === "wire" ? s.bank : null,
          seller: commerce.sellerSnapshot?.(),
          promotionCode: code || null,
        };
        ensureMembershipAvailable(req.user, snapshot);
        for (const row of db
          .prepare(
            "SELECT * FROM payment_orders WHERE user_id=? AND status IN ('pending','creating','creation_failed')",
          )
          .all(req.user.id))
          expire(row);
        const pendingCount = db
          .prepare(
            "SELECT count(*) AS n FROM payment_orders WHERE user_id=? AND status IN ('pending','creating','creation_failed')",
          )
          .get(req.user.id).n;
        if (pendingCount >= 5)
          throw problem(
            "You already have several pending payments. Complete them or contact support.",
            409,
          );
        const subtotal = plan
          ? plans[plan][interval]
          : selected.reduce((sum, p) => sum + p.price, 0);
        const id = `P${randomUUID()}`,
          expiresAt =
            Date.now() + (provider === "wire" ? 7 * 86400000 : 30 * 60000);
        const promotion = commerce.resolvePromotion?.(req.user, {
          code,
          plan,
          selected,
          subtotal,
          reservationId: id,
        }) || { discount: 0 };
        const total = plan
          ? cents(subtotal * (1 - promotion.discount)) / 100
          : selected.reduce(
              (sum, p) => sum + cents(p.price * (1 - promotion.discount)),
              0,
            ) / 100;
        if (!Number.isFinite(total) || total <= 0 || total > 1000000)
          throw problem("This payment amount is not supported.");
        if (plan) {
          db.exec("BEGIN IMMEDIATE");
          try {
            db.prepare(
              "DELETE FROM membership_checkout_locks WHERE expires_at<=?",
            ).run(Date.now());
            if (
              db
                .prepare(
                  "SELECT 1 FROM membership_checkout_locks WHERE user_id=?",
                )
                .get(req.user.id)
            )
              throw problem(
                "A membership checkout is already pending. Complete or cancel it before starting another.",
                409,
              );
            db.prepare(
              "INSERT INTO membership_checkout_locks VALUES (?,?,?)",
            ).run(req.user.id, id, expiresAt);
            db.exec("COMMIT");
          } catch (e) {
            db.exec("ROLLBACK");
            throw e;
          }
        }
        try {
          if (provider === "wire" && commerce.reserveWirePromotion)
            commerce.reserveWirePromotion(req.user.id, id, code, expiresAt);
          else
            commerce.reservePromotion?.(
              req.user.id,
              id,
              code,
              Math.min(expiresAt, Date.now() + 3599000),
            );
          db.prepare(
            "INSERT INTO payment_orders (id,user_id,provider,status,total,idempotency_key,request_hash,snapshot,expires_at,created_at,updated_at) VALUES (?,?,?,?,?,?,?,?,?,?,?)",
          ).run(
            id,
            req.user.id,
            provider,
            provider === "wire" ? "pending" : "creating",
            total,
            idem,
            requestHash,
            encrypt(snapshot),
            expiresAt,
            now(),
            now(),
          );
        } catch (e) {
          commerce.releasePromotion?.(id);
          db.prepare(
            "DELETE FROM membership_checkout_locks WHERE intent_id=?",
          ).run(id);
          throw e;
        }
        audit(req.user.id, "payment.created", {
          paymentId: id,
          provider,
          amount: total,
          environment,
        });
        if (provider !== "wire") {
          try {
            await createProvider(rowById(id), snapshot);
          } catch (e) {
            db.prepare(
              "UPDATE payment_orders SET status='creation_failed',updated_at=? WHERE id=?",
            ).run(now(), id);
            commerce.releasePromotion?.(id);
            db.prepare(
              "DELETE FROM membership_checkout_locks WHERE intent_id=?",
            ).run(id);
            // Retain the idempotency row: a timeout can have created a remote link.
            // Automatic recreation could charge the customer twice.
            throw e;
          }
        }
        res.json(paymentView(rowById(id)));
      });
    }),
  );
  app.get(
    "/api/payments/orders",
    requireAuth,
    handler((req, res) =>
      res.json({
        payments: db
          .prepare(
            "SELECT * FROM payment_orders WHERE user_id=? ORDER BY created_at DESC LIMIT 100",
          )
          .all(req.user.id)
          .filter(liveVisible)
          .map((row) => paymentView(row)),
      }),
    ),
  );
  app.get(
    "/api/payments/orders/:id",
    requireAuth,
    handler((req, res) => res.json(paymentView(owned(req)))),
  );
  app.post(
    "/api/payments/orders/:id/verify",
    requireAuth,
    rateLimit("payments.verify", 60),
    handler(async (req, res) => {
      owned(req);
      await exclusive(req.params.id, async () => {
        const row = owned(req);
        res.json(
          paymentView(
            row.provider === "wire" || row.status === "completed"
              ? row
              : await verifyProvider(row),
          ),
        );
      });
    }),
  );
  app.post(
    "/api/payments/orders/:id/notify",
    requireAuth,
    handler((req, res) => {
      const row = owned(req),
        { reference, note = "" } = req.body || {};
      if (row.provider !== "wire" || row.status !== "pending")
        throw problem("Only a pending bank transfer can be reported.", 409);
      if (
        typeof reference !== "string" ||
        reference.trim().length < 3 ||
        reference.length > 150 ||
        typeof note !== "string" ||
        note.length > 2000
      )
        throw problem(
          "Enter the bank transfer reference and an optional short note.",
        );
      db.prepare(
        "UPDATE payment_orders SET customer_reference=?,customer_note=?,updated_at=? WHERE id=?",
      ).run(reference.trim(), note.trim(), now(), row.id);
      audit(req.user.id, "payment.wire.reported", { paymentId: row.id });
      res.json(paymentView(rowById(row.id)));
    }),
  );
  app.post(
    "/api/admin/payments/orders/:id/confirm",
    requireAdmin,
    rateLimit("payments.confirm", 30),
    handler(async (req, res) => {
      reauthenticate(req);
      await exclusive(req.params.id, async () => {
        const row = rowById(req.params.id),
          body = req.body || {};
        if (!row || row.provider !== "wire")
          throw problem("Bank transfer not found.", 404);
        if (!liveVisible(row))
          throw problem(
            "This development payment is unavailable in production.",
            403,
          );
        if (
          body.cleared !== true ||
          body.currency !== "USD" ||
          !exactAmount(body.receivedAmount, row.total)
        )
          throw problem(
            "Explicitly confirm cleared funds and the exact USD amount. Partial or other-currency receipts cannot grant access.",
          );
        if (
          typeof body.bankReference !== "string" ||
          body.bankReference.trim().length < 3 ||
          body.bankReference.length > 150
        )
          throw problem("Enter the cleared bank transaction reference.");
        const reference = body.bankReference.trim();
        if (row.status === "completed") {
          if (row.bank_reference !== reference)
            throw problem(
              "This transfer was already confirmed with another reference.",
              409,
            );
          return res.json(paymentView(row, true));
        }
        const result = complete(
          expire(row),
          `wire:${hash(reference.toUpperCase().replace(/\s+/g, ""))}`,
          { bankVersion: decrypt(row.snapshot).bank.version },
        );
        db.prepare("UPDATE payment_orders SET bank_reference=? WHERE id=?").run(
          reference,
          row.id,
        );
        audit(req.user.id, "payment.wire.confirmed", {
          paymentId: row.id,
          amount: row.total,
          demoReauthentication: isDemoAdmin(req.user),
        });
        res.json(paymentView(result, true));
      });
    }),
  );
  app.post(
    "/api/admin/payments/orders/:id/reject",
    requireAdmin,
    rateLimit("payments.reject", 30),
    handler(async (req, res) => {
      reauthenticate(req);
      await exclusive(req.params.id, async () => {
        const row = rowById(req.params.id),
          note = req.body?.note || "";
        if (!row || row.provider !== "wire")
          throw problem("Bank transfer not found.", 404);
        if (!liveVisible(row))
          throw problem(
            "This development payment is unavailable in production.",
            403,
          );
        if (!["pending", "expired", "rejected"].includes(row.status))
          throw problem("This transfer cannot be rejected.", 409);
        if (typeof note !== "string" || note.length > 2000)
          throw problem("Enter a short reconciliation note.");
        db.prepare(
          "UPDATE payment_orders SET status='rejected',admin_note=?,updated_at=? WHERE id=?",
        ).run(note.trim(), now(), row.id);
        commerce.releasePromotion?.(row.id);
        db.prepare(
          "DELETE FROM membership_checkout_locks WHERE intent_id=?",
        ).run(row.id);
        audit(req.user.id, "payment.wire.rejected", { paymentId: row.id });
        res.json(paymentView(rowById(row.id), true));
      });
    }),
  );

  // Only returns success after the provider confirms a full refund. Commerce owns
  // entitlement removal and the explicit manual wire-refund reconciliation flow.
  async function refund(order, idempotencyKey) {
    const orderId = typeof order === "string" ? order : order.id;
    return exclusive(`refund:${orderId}`, async () => {
      const row = rowById(orderId);
      if (
        !row ||
        row.status !== "completed" ||
        !["paypal", "razorpay"].includes(row.provider)
      )
        throw problem(
          "This payment requires manual refund reconciliation.",
          409,
        );
      const snapshot = decrypt(row.snapshot),
        config = snapshot.provider;
      if (production && snapshot.environment !== "live")
        throw problem(
          "Development payments cannot be refunded through production checkout.",
          403,
        );
      const paymentId = row.settlement_id?.split(":")[1];
      if (!idPattern.test(paymentId || ""))
        throw problem("Verified provider payment reference is missing.", 409);
      let result;
      if (row.provider === "paypal") {
        const token = await paypalToken(config),
          headers = { authorization: `Bearer ${token}` };
        if (row.provider_refund_id)
          result = await request(
            "paypal",
            config,
            `/v2/payments/refunds/${encodeURIComponent(row.provider_refund_id)}`,
            { headers },
          );
        else
          result = await request(
            "paypal",
            config,
            `/v2/payments/captures/${encodeURIComponent(paymentId)}/refund`,
            {
              method: "POST",
              body: {
                amount: { value: row.total.toFixed(2), currency_code: "USD" },
              },
              headers: {
                ...headers,
                "PayPal-Request-Id": `refund-${hash(String(idempotencyKey || row.id)).slice(0, 32)}`,
              },
            },
          );
        if (
          !idPattern.test(result.id || "") ||
          result.amount?.currency_code !== "USD" ||
          !exactUsd(result.amount?.value, row.total)
        )
          throw problem("PayPal did not confirm this refund amount.", 502);
        db.prepare(
          "UPDATE payment_orders SET provider_refund_id=? WHERE id=?",
        ).run(result.id, row.id);
        if (result.status !== "COMPLETED")
          return {
            pending: true,
            providerRefundId: result.id,
            message: "PayPal refund is awaiting confirmation.",
          };
      } else {
        const headers = razorHeaders(config);
        if (row.provider_refund_id)
          result = await request(
            "razorpay",
            config,
            `/v1/refunds/${encodeURIComponent(row.provider_refund_id)}`,
            { headers },
          );
        else {
          // Razorpay's refund API has no idempotency header. First locate a refund
          // by our stable receipt, including after a prior request timed out.
          const receipt = `rtr-${hash(String(idempotencyKey || row.id)).slice(0, 30)}`;
          const previous = await request(
            "razorpay",
            config,
            `/v1/payments/${encodeURIComponent(paymentId)}/refunds?count=100`,
            { headers },
          );
          result = previous.items?.find((entry) => entry.receipt === receipt);
          if (!result) {
            if (
              db
                .prepare(
                  "SELECT 1 FROM payment_refund_attempts WHERE order_id=?",
                )
                .get(row.id)
            )
              return {
                pending: true,
                message:
                  "The prior Razorpay refund attempt is awaiting reconciliation in the provider dashboard. It will not be submitted twice.",
              };
            // Persist before the remote mutation. If the response is lost, retries
            // only discover that receipt; they never send a second refund blindly.
            db.prepare(
              "INSERT INTO payment_refund_attempts VALUES (?,?,?)",
            ).run(row.id, receipt, now());
            result = await request(
              "razorpay",
              config,
              `/v1/payments/${encodeURIComponent(paymentId)}/refund`,
              {
                method: "POST",
                headers,
                body: {
                  amount: cents(row.total),
                  receipt,
                  notes: { rtr_payment_id: row.id },
                },
              },
            );
          }
        }
        if (
          !idPattern.test(result.id || "") ||
          result.payment_id !== paymentId ||
          result.amount !== cents(row.total) ||
          result.currency !== "USD"
        )
          throw problem("Razorpay did not confirm this refund amount.", 502);
        db.prepare(
          "UPDATE payment_orders SET provider_refund_id=? WHERE id=?",
        ).run(result.id, row.id);
        if (result.status !== "processed")
          return {
            pending: true,
            providerRefundId: result.id,
            message: "Razorpay refund is awaiting confirmation.",
          };
      }
      return { success: true, orderId: row.id, providerRefundId: result.id };
    });
  }
  return { methods, refund };
}
