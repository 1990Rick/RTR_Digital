import {
  randomBytes,
  randomUUID,
  createHmac,
  createCipheriv,
  createDecipheriv,
  timingSafeEqual,
} from "node:crypto";
import { existsSync, readFileSync, writeFileSync } from "node:fs";
import { resolve } from "node:path";

const base32Alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ234567";
function base32(bytes) {
  let bits = 0,
    value = 0,
    result = "";
  for (const byte of bytes) {
    value = (value << 8) | byte;
    bits += 8;
    while (bits >= 5) {
      result += base32Alphabet[(value >>> (bits - 5)) & 31];
      bits -= 5;
    }
  }
  if (bits) result += base32Alphabet[(value << (5 - bits)) & 31];
  return result;
}
function decode32(text) {
  let bits = 0,
    value = 0,
    result = [];
  for (const character of text.toUpperCase()) {
    const digit = base32Alphabet.indexOf(character);
    if (digit < 0) continue;
    value = (value << 5) | digit;
    bits += 5;
    if (bits >= 8) {
      result.push((value >>> (bits - 8)) & 255);
      bits -= 8;
    }
  }
  return Buffer.from(result);
}
export function totpCode(secret, counter = Math.floor(Date.now() / 30000)) {
  const message = Buffer.alloc(8);
  message.writeBigUInt64BE(BigInt(counter));
  const digest = createHmac("sha1", decode32(secret)).update(message).digest();
  const offset = digest[19] & 15;
  return String((digest.readUInt32BE(offset) & 0x7fffffff) % 1000000).padStart(
    6,
    "0",
  );
}
const equal = (a, b) => {
  const x = Buffer.from(a),
    y = Buffer.from(b);
  return x.length === y.length && timingSafeEqual(x, y);
};

export function registerIdentity(app, ctx) {
  const {
    db,
    dataDir,
    production,
    demoMode,
    publicBaseUrl,
    requireAuth,
    requireAdmin,
    fail,
    safeUser,
    audit,
    now,
    hash,
    passwordHash,
    verifyPassword,
    validEmail,
    rateLimit,
    setSession,
    options,
  } = ctx;
  db.exec(`
    CREATE TABLE IF NOT EXISTS account_security (user_id TEXT PRIMARY KEY REFERENCES users(id), verified_email TEXT, mfa_secret TEXT, pending_mfa TEXT, pending_mfa_until INTEGER, backup_hashes TEXT NOT NULL DEFAULT '[]', last_counter INTEGER NOT NULL DEFAULT -1, deleted_at TEXT);
    CREATE TABLE IF NOT EXISTS account_preferences (user_id TEXT PRIMARY KEY REFERENCES users(id), payload TEXT NOT NULL, updated_at TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS identity_tokens (id TEXT PRIMARY KEY, user_id TEXT NOT NULL REFERENCES users(id), purpose TEXT NOT NULL, email TEXT NOT NULL, expires_at INTEGER NOT NULL, consumed_at TEXT, attempts INTEGER NOT NULL DEFAULT 0);
    CREATE TABLE IF NOT EXISTS account_notifications (id TEXT PRIMARY KEY, user_id TEXT NOT NULL REFERENCES users(id), title TEXT NOT NULL, body TEXT NOT NULL, read_at TEXT, created_at TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS identity_mail (id TEXT PRIMARY KEY, user_id TEXT NOT NULL REFERENCES users(id), recipient TEXT NOT NULL, subject TEXT NOT NULL, body TEXT NOT NULL, status TEXT NOT NULL, created_at TEXT NOT NULL);
  `);
  const keyPath = resolve(dataDir, ".account-encryption-key");
  let key;
  if (options.identityEncryptionKey || process.env.ACCOUNT_ENCRYPTION_KEY) {
    const source =
      options.identityEncryptionKey || process.env.ACCOUNT_ENCRYPTION_KEY;
    key = Buffer.from(hash(source), "hex");
  } else {
    if (!existsSync(keyPath)) {
      try {
        writeFileSync(keyPath, randomBytes(32), { mode: 0o600, flag: "wx" });
      } catch (error) {
        if (error.code !== "EEXIST") throw error;
      }
    }
    key = readFileSync(keyPath);
    if (key.length !== 32)
      throw new Error(
        "Account encryption key is invalid. Restore the original key from backup.",
      );
  }
  function seal(text) {
    const iv = randomBytes(12),
      cipher = createCipheriv("aes-256-gcm", key, iv);
    const bytes = Buffer.concat([cipher.update(text, "utf8"), cipher.final()]);
    return Buffer.concat([iv, cipher.getAuthTag(), bytes]).toString("base64");
  }
  function open(text) {
    const bytes = Buffer.from(text, "base64"),
      decipher = createDecipheriv("aes-256-gcm", key, bytes.subarray(0, 12));
    decipher.setAuthTag(bytes.subarray(12, 28));
    return Buffer.concat([
      decipher.update(bytes.subarray(28)),
      decipher.final(),
    ]).toString("utf8");
  }
  const hasTable = (name) =>
    Boolean(
      db
        .prepare("SELECT 1 FROM sqlite_master WHERE type='table' AND name=?")
        .get(name),
    );
  const security = (id) =>
    db.prepare("SELECT * FROM account_security WHERE user_id=?").get(id) || {
      user_id: id,
      backup_hashes: "[]",
      last_counter: -1,
    };
  const ensureSecurity = (id) =>
    db
      .prepare("INSERT OR IGNORE INTO account_security (user_id) VALUES (?)")
      .run(id);
  const preferences = (id) =>
    JSON.parse(
      db
        .prepare("SELECT payload FROM account_preferences WHERE user_id=?")
        .get(id)?.payload ||
        '{"productUpdates":true,"renewalReminders":true,"newsletter":false}',
    );
  const notify = (userId, title, body) =>
    db
      .prepare("INSERT INTO account_notifications VALUES (?,?,?,?,NULL,?)")
      .run(randomUUID(), userId, title, body, now());
  const sessionHash = (req) => {
    const raw = req.headers.cookie
      ?.split(";")
      .map((v) => v.trim())
      .find((v) => v.startsWith("rtr_session="))
      ?.slice(12);
    return raw ? hash(raw) : "";
  };
  const isDemo = (user) =>
    /^demo-(admin|customer)@rtr\.example$/.test(user.email);
  let validPublicOrigin = false;
  try {
    const parsed = new URL(publicBaseUrl);
    validPublicOrigin =
      parsed.protocol === "https:" &&
      !parsed.username &&
      !parsed.password &&
      !parsed.search &&
      !parsed.hash;
  } catch {}
  const mailReady = Boolean(
    (!production || validPublicOrigin) &&
    (options.emailTransport ||
      ((options.resendApiKey || process.env.RESEND_API_KEY) &&
        (options.emailFrom || process.env.EMAIL_FROM))),
  );
  const origin = (publicBaseUrl || "http://localhost:5173").replace(/\/$/, "");
  function token(user, purpose, duration = 30 * 60000) {
    const raw = randomBytes(32).toString("hex");
    db.prepare(
      "UPDATE identity_tokens SET consumed_at=? WHERE user_id=? AND purpose=? AND consumed_at IS NULL",
    ).run(now(), user.id, purpose);
    db.prepare("INSERT INTO identity_tokens VALUES (?,?,?,?,?,NULL,0)").run(
      hash(raw),
      user.id,
      purpose,
      user.email,
      Date.now() + duration,
    );
    return raw;
  }
  async function sendMail(user, subject, body) {
    const id = randomUUID();
    db.prepare("INSERT INTO identity_mail VALUES (?,?,?,?,?,?,?)").run(
      id,
      user.id,
      user.email,
      subject,
      body,
      mailReady ? "pending" : "preview",
      now(),
    );
    if (mailReady) {
      try {
        if (options.emailTransport)
          await options.emailTransport({ to: user.email, subject, text: body });
        else {
          const response = await fetch("https://api.resend.com/emails", {
            method: "POST",
            headers: {
              Authorization: `Bearer ${options.resendApiKey || process.env.RESEND_API_KEY}`,
              "Content-Type": "application/json",
            },
            body: JSON.stringify({
              from: options.emailFrom || process.env.EMAIL_FROM,
              to: [user.email],
              subject,
              text: body,
            }),
            signal: AbortSignal.timeout(12000),
          });
          if (!response.ok)
            throw new Error("Email provider rejected delivery.");
        }
        db.prepare("UPDATE identity_mail SET status='sent' WHERE id=?").run(id);
      } catch {
        db.prepare("UPDATE identity_mail SET status='failed' WHERE id=?").run(
          id,
        );
        throw new Error(
          "Email delivery is temporarily unavailable. Please try again.",
        );
      }
    }
    return id;
  }
  function validateMfa(user, code, allowBackup = true) {
    const entry = security(user.id);
    if (!entry.mfa_secret) return true;
    const candidate = typeof code === "string" ? code.trim() : "";
    if (/^\d{6}$/.test(candidate)) {
      const counter = Math.floor(Date.now() / 30000),
        secret = open(entry.mfa_secret);
      for (const step of [0, -1, 1]) {
        const value = counter + step;
        if (
          value > entry.last_counter &&
          equal(candidate, totpCode(secret, value))
        ) {
          db.prepare(
            "UPDATE account_security SET last_counter=? WHERE user_id=?",
          ).run(value, user.id);
          return true;
        }
      }
    }
    if (allowBackup) {
      const codes = JSON.parse(entry.backup_hashes || "[]");
      const index = codes.indexOf(hash(candidate.toUpperCase()));
      if (index >= 0) {
        codes.splice(index, 1);
        db.prepare(
          "UPDATE account_security SET backup_hashes=? WHERE user_id=?",
        ).run(JSON.stringify(codes), user.id);
        return true;
      }
    }
    return false;
  }
  function reauthenticate(req, res, includeMfa = true) {
    if (
      !verifyPassword(
        req.body?.password || req.body?.currentPassword || "",
        req.user.password,
      )
    ) {
      fail(res, 403, "Confirm your current password to continue.");
      return false;
    }
    if (includeMfa && !validateMfa(req.user, req.body?.code)) {
      fail(
        res,
        403,
        "Enter a fresh authenticator code or unused recovery code.",
      );
      return false;
    }
    return true;
  }
  app.use("/api", (req, _res, next) => {
    if (req.user && security(req.user.id).deleted_at) req.user = null;
    next();
  });
  app.post("/api/auth/login", rateLimit("identity-login", 15), (req, res) => {
    const { email, password, code } = req.body || {};
    if (
      !validEmail(email) ||
      typeof password !== "string" ||
      password.length > 128
    )
      return fail(res, 400, "Enter your email address and password.");
    const user = db
      .prepare("SELECT * FROM users WHERE email=?")
      .get(email.toLowerCase());
    if (
      !user ||
      security(user.id).deleted_at ||
      (production && isDemo(user)) ||
      !verifyPassword(password, user.password)
    )
      return fail(res, 401, "Email or password is incorrect.");
    if (security(user.id).mfa_secret) {
      if (code) {
        if (!validateMfa(user, code))
          return fail(
            res,
            401,
            "Authenticator or recovery code is invalid or already used.",
          );
      } else
        return res.json({
          mfaRequired: true,
          challengeToken: token(user, "mfa-login", 5 * 60000),
        });
    }
    setSession(res, user.id);
    audit(user.id, "auth.login");
    res.json({ user: safeUser(user) });
  });
  app.post("/api/auth/mfa", rateLimit("mfa-login", 15), (req, res) => {
    const { challengeToken, code } = req.body || {};
    const entry =
      typeof challengeToken === "string" && challengeToken.length <= 128
        ? db
            .prepare(
              "SELECT * FROM identity_tokens WHERE id=? AND purpose='mfa-login' AND consumed_at IS NULL AND expires_at>?",
            )
            .get(hash(challengeToken), Date.now())
        : null;
    if (!entry || entry.attempts >= 5)
      return fail(res, 401, "This sign-in challenge expired. Sign in again.");
    db.prepare("UPDATE identity_tokens SET attempts=attempts+1 WHERE id=?").run(
      entry.id,
    );
    const user = db
      .prepare("SELECT * FROM users WHERE id=?")
      .get(entry.user_id);
    if (!user || security(user.id).deleted_at || !validateMfa(user, code))
      return fail(
        res,
        401,
        "Authenticator or recovery code is invalid or already used.",
      );
    db.prepare("UPDATE identity_tokens SET consumed_at=? WHERE id=?").run(
      now(),
      entry.id,
    );
    setSession(res, user.id);
    audit(user.id, "auth.mfa_login");
    res.json({ user: safeUser(user) });
  });
  app.get("/api/account/settings", requireAuth, (req, res) => {
    const entry = security(req.user.id),
      current = sessionHash(req);
    res.json({
      profile: {
        name: req.user.name,
        email: req.user.email,
        emailVerified: entry.verified_email === req.user.email,
        mfaEnabled: Boolean(entry.mfa_secret),
        backupCodesRemaining: JSON.parse(entry.backup_hashes || "[]").length,
      },
      preferences: preferences(req.user.id),
      sessions: db
        .prepare(
          "SELECT token,expires_at FROM sessions WHERE user_id=? AND expires_at>? ORDER BY expires_at DESC",
        )
        .all(req.user.id, Date.now())
        .map((s) => ({
          id: s.token.slice(0, 24),
          current: equal(s.token, current),
          expiresAt: new Date(s.expires_at).toISOString(),
        })),
      notifications: db
        .prepare(
          "SELECT id,title,body,read_at AS readAt,created_at AS createdAt FROM account_notifications WHERE user_id=? ORDER BY created_at DESC LIMIT 100",
        )
        .all(req.user.id),
      mail: {
        configured: mailReady,
        developmentPreview: !production,
        messages: !production
          ? db
              .prepare(
                "SELECT id,subject,status,created_at AS createdAt FROM identity_mail WHERE user_id=? ORDER BY created_at DESC LIMIT 20",
              )
              .all(req.user.id)
          : [],
      },
    });
  });
  app.patch("/api/account/profile", requireAuth, (req, res) => {
    if (isDemo(req.user))
      return fail(
        res,
        403,
        "Shared demo profiles cannot be changed. Create your own account to test profile changes.",
      );
    const { name, email } = req.body || {};
    if (
      typeof name !== "string" ||
      name.trim().length < 2 ||
      name.length > 80 ||
      !validEmail(email) ||
      /^demo-(admin|customer)@rtr\.example$/i.test(email)
    )
      return fail(res, 400, "Provide a name and valid personal email address.");
    const normalized = email.toLowerCase();
    if (normalized !== req.user.email && !reauthenticate(req, res)) return;
    if (
      db
        .prepare("SELECT 1 FROM users WHERE email=? AND id<>?")
        .get(normalized, req.user.id)
    )
      return fail(
        res,
        409,
        "That email address is already associated with an account.",
      );
    ensureSecurity(req.user.id);
    db.prepare("UPDATE users SET name=?,email=? WHERE id=?").run(
      name.trim(),
      normalized,
      req.user.id,
    );
    if (normalized !== req.user.email) {
      db.prepare(
        "UPDATE account_security SET verified_email=NULL WHERE user_id=?",
      ).run(req.user.id);
      db.prepare(
        "UPDATE identity_tokens SET consumed_at=? WHERE user_id=? AND consumed_at IS NULL",
      ).run(now(), req.user.id);
      db.prepare("DELETE FROM sessions WHERE user_id=? AND token<>?").run(
        req.user.id,
        sessionHash(req),
      );
      db.prepare("DELETE FROM newsletter WHERE email=?").run(req.user.email);
      const consent = { ...preferences(req.user.id), newsletter: false };
      db.prepare(
        "INSERT INTO account_preferences VALUES (?,?,?) ON CONFLICT(user_id) DO UPDATE SET payload=excluded.payload,updated_at=excluded.updated_at",
      ).run(req.user.id, JSON.stringify(consent), now());
    }
    audit(req.user.id, "account.profile_updated");
    notify(
      req.user.id,
      "Profile updated",
      normalized !== req.user.email
        ? "Your email changed. Verify the new email address to confirm ownership."
        : "Your profile details have been saved.",
    );
    res.json({
      user: safeUser(
        db.prepare("SELECT * FROM users WHERE id=?").get(req.user.id),
      ),
    });
  });
  app.post(
    "/api/account/password",
    requireAuth,
    rateLimit("change-password", 10),
    (req, res) => {
      if (isDemo(req.user))
        return fail(
          res,
          403,
          "Create your own account to change its password.",
        );
      if (!reauthenticate(req, res)) return;
      const value = req.body?.newPassword;
      if (typeof value !== "string" || value.length < 8 || value.length > 128)
        return fail(
          res,
          400,
          "Use a new password between 8 and 128 characters.",
        );
      db.prepare("UPDATE users SET password=? WHERE id=?").run(
        passwordHash(value),
        req.user.id,
      );
      db.prepare("DELETE FROM sessions WHERE user_id=? AND token<>?").run(
        req.user.id,
        sessionHash(req),
      );
      db.prepare(
        "UPDATE identity_tokens SET consumed_at=? WHERE user_id=? AND purpose='password-reset' AND consumed_at IS NULL",
      ).run(now(), req.user.id);
      notify(
        req.user.id,
        "Password updated",
        "Your password changed and your other sessions were signed out.",
      );
      audit(req.user.id, "account.password_changed");
      res.json({ success: true });
    },
  );
  app.post(
    "/api/auth/forgot-password",
    rateLimit("password-reset", 5),
    async (req, res) => {
      if (!mailReady && production)
        return fail(
          res,
          503,
          "Account email delivery is not configured. Contact the administrator for recovery.",
        );
      if (!validEmail(req.body?.email))
        return fail(res, 400, "Enter a valid email address.");
      const user = db
        .prepare("SELECT * FROM users WHERE email=?")
        .get(req.body.email.toLowerCase());
      if (user && !security(user.id).deleted_at && !isDemo(user)) {
        const value = token(user, "password-reset");
        try {
          await sendMail(
            user,
            "Reset your RTR Digital password",
            `A password reset was requested for your account. This link expires in 30 minutes and can be used once.\n\n${origin}/account/reset-password?token=${encodeURIComponent(value)}\n\nIf you did not request this, ignore this message.`,
          );
        } catch {
          /* Generic response prevents account enumeration. Delivery failure is recorded for the administrator. */
        }
      }
      res.json({
        success: true,
        message:
          "If this email belongs to an account, a recovery request has been recorded. Check your inbox when delivery is configured.",
        developmentPreview: !production,
      });
    },
  );
  app.post(
    "/api/auth/reset-password",
    rateLimit("apply-reset", 10),
    (req, res) => {
      const { token: value, password } = req.body || {};
      if (
        typeof value !== "string" ||
        value.length > 128 ||
        typeof password !== "string" ||
        password.length < 8 ||
        password.length > 128
      )
        return fail(
          res,
          400,
          "Provide a valid reset token and a password between 8 and 128 characters.",
        );
      const entry = db
        .prepare(
          "SELECT * FROM identity_tokens WHERE id=? AND purpose='password-reset' AND consumed_at IS NULL AND expires_at>?",
        )
        .get(hash(value), Date.now());
      const user =
        entry &&
        db.prepare("SELECT * FROM users WHERE id=?").get(entry.user_id);
      if (
        !entry ||
        !user ||
        user.email !== entry.email ||
        security(user.id).deleted_at
      )
        return fail(
          res,
          400,
          "This recovery link is invalid, expired, or already used.",
        );
      db.exec("BEGIN IMMEDIATE");
      try {
        db.prepare("UPDATE users SET password=? WHERE id=?").run(
          passwordHash(password),
          entry.user_id,
        );
        db.prepare(
          "UPDATE identity_tokens SET consumed_at=? WHERE user_id=? AND consumed_at IS NULL",
        ).run(now(), user.id);
        db.prepare("DELETE FROM sessions WHERE user_id=?").run(user.id);
        notify(
          user.id,
          "Password reset",
          "Your password was reset. All sessions have been signed out. Two-factor authentication remains enabled if you configured it.",
        );
        audit(user.id, "account.password_reset");
        db.exec("COMMIT");
      } catch (error) {
        db.exec("ROLLBACK");
        throw error;
      }
      res.json({ success: true });
    },
  );
  app.post(
    "/api/account/verification/send",
    requireAuth,
    rateLimit("verify-email", 5),
    async (req, res) => {
      if (!mailReady && production)
        return fail(
          res,
          503,
          "Email verification requires configured account email delivery.",
        );
      if (isDemo(req.user))
        return fail(
          res,
          400,
          "Verify a personal registered account instead of a shared demo identity.",
        );
      if (security(req.user.id).verified_email === req.user.email)
        return res.json({
          success: true,
          message: "Your email is already verified.",
        });
      const value = token(req.user, "email-verify", 24 * 3600000);
      try {
        await sendMail(
          req.user,
          "Verify your RTR Digital email",
          `Confirm your email address using this one-time link. It expires in 24 hours.\n\n${origin}/account/verify-email?token=${encodeURIComponent(value)}`,
        );
      } catch (error) {
        return fail(res, 503, error.message);
      }
      res.json({
        success: true,
        delivered: mailReady,
        developmentPreview: !production,
        message: mailReady
          ? "A verification email was submitted for delivery."
          : "Verification message saved to your private development mailbox. No email was sent.",
      });
    },
  );
  app.post(
    "/api/auth/verify-email",
    rateLimit("verify-token", 15),
    (req, res) => {
      const value = req.body?.token;
      const entry =
        typeof value === "string" && value.length <= 128
          ? db
              .prepare(
                "SELECT * FROM identity_tokens WHERE id=? AND purpose='email-verify' AND consumed_at IS NULL AND expires_at>?",
              )
              .get(hash(value), Date.now())
          : null;
      const user =
        entry &&
        db.prepare("SELECT * FROM users WHERE id=?").get(entry.user_id);
      if (
        !entry ||
        !user ||
        entry.email !== user.email ||
        security(user.id).deleted_at
      )
        return fail(
          res,
          400,
          "This verification link is invalid, expired, or already used.",
        );
      ensureSecurity(user.id);
      db.prepare(
        "UPDATE account_security SET verified_email=? WHERE user_id=?",
      ).run(user.email, user.id);
      db.prepare("UPDATE identity_tokens SET consumed_at=? WHERE id=?").run(
        now(),
        entry.id,
      );
      notify(
        user.id,
        "Email verified",
        "Your account email address has been confirmed.",
      );
      audit(user.id, "account.email_verified");
      res.json({ success: true });
    },
  );
  app.get("/api/account/mail/:id", requireAuth, (req, res) => {
    if (production) return fail(res, 404, "Development previews are disabled.");
    const row = db
      .prepare("SELECT * FROM identity_mail WHERE id=?")
      .get(req.params.id);
    if (!row || (row.user_id !== req.user.id && req.user.role !== "admin"))
      return fail(res, 404, "Message not found.");
    res.json({
      message: {
        id: row.id,
        subject: row.subject,
        body: row.body,
        status: row.status,
        createdAt: row.created_at,
      },
    });
  });
  app.get("/api/admin/mail", requireAdmin, (req, res) => {
    if (production) return fail(res, 404, "Development previews are disabled.");
    res.json({
      messages: db
        .prepare(
          "SELECT id,user_id AS userId,subject,status,created_at AS createdAt FROM identity_mail ORDER BY created_at DESC LIMIT 100",
        )
        .all(),
    });
  });
  app.post(
    "/api/account/mfa/setup",
    requireAuth,
    rateLimit("mfa-setup", 10),
    (req, res) => {
      if (isDemo(req.user))
        return fail(
          res,
          403,
          "Use a personal registered account for two-factor authentication.",
        );
      if (!verifyPassword(req.body?.password || "", req.user.password))
        return fail(
          res,
          403,
          "Confirm your password before configuring two-factor authentication.",
        );
      if (security(req.user.id).mfa_secret)
        return fail(res, 409, "Two-factor authentication is already enabled.");
      const secret = base32(randomBytes(20));
      ensureSecurity(req.user.id);
      db.prepare(
        "UPDATE account_security SET pending_mfa=?,pending_mfa_until=? WHERE user_id=?",
      ).run(seal(secret), Date.now() + 10 * 60000, req.user.id);
      res.json({
        secret,
        uri: `otpauth://totp/RTR%20Digital:${encodeURIComponent(req.user.email)}?secret=${secret}&issuer=RTR%20Digital&algorithm=SHA1&digits=6&period=30`,
        message:
          "Add this secret to your authenticator, then confirm a code within ten minutes.",
      });
    },
  );
  app.post(
    "/api/account/mfa/confirm",
    requireAuth,
    rateLimit("mfa-confirm", 10),
    (req, res) => {
      const entry = security(req.user.id),
        code = req.body?.code;
      if (
        !entry.pending_mfa ||
        entry.pending_mfa_until < Date.now() ||
        typeof code !== "string" ||
        !/^\d{6}$/.test(code)
      )
        return fail(
          res,
          400,
          "The authenticator setup expired or the code is invalid.",
        );
      const secret = open(entry.pending_mfa),
        counter = Math.floor(Date.now() / 30000);
      const matched = [counter, counter - 1, counter + 1].find((n) =>
        equal(code, totpCode(secret, n)),
      );
      if (matched === undefined)
        return fail(res, 400, "The authenticator code is incorrect.");
      const backupCodes = Array.from({ length: 8 }, () =>
        randomBytes(5).toString("hex").toUpperCase(),
      );
      db.prepare(
        "UPDATE account_security SET mfa_secret=pending_mfa,pending_mfa=NULL,pending_mfa_until=NULL,backup_hashes=?,last_counter=? WHERE user_id=?",
      ).run(JSON.stringify(backupCodes.map(hash)), matched, req.user.id);
      db.prepare("DELETE FROM sessions WHERE user_id=? AND token<>?").run(
        req.user.id,
        sessionHash(req),
      );
      notify(
        req.user.id,
        "Two-factor authentication enabled",
        "Authenticator verification now protects sign-in. Store your recovery codes securely; each code works once.",
      );
      audit(req.user.id, "account.mfa_enabled");
      res.json({ success: true, backupCodes });
    },
  );
  app.post(
    "/api/account/mfa/disable",
    requireAuth,
    rateLimit("mfa-disable", 10),
    (req, res) => {
      if (!reauthenticate(req, res)) return;
      ensureSecurity(req.user.id);
      db.prepare(
        "UPDATE account_security SET mfa_secret=NULL,pending_mfa=NULL,pending_mfa_until=NULL,backup_hashes='[]',last_counter=-1 WHERE user_id=?",
      ).run(req.user.id);
      notify(
        req.user.id,
        "Two-factor authentication disabled",
        "Your account now uses password-only sign-in.",
      );
      audit(req.user.id, "account.mfa_disabled");
      res.json({ success: true });
    },
  );
  app.delete("/api/account/sessions/:id", requireAuth, (req, res) => {
    if (!/^[a-f0-9]{24}$/.test(req.params.id))
      return fail(res, 400, "Invalid session reference.");
    const row = db
      .prepare(
        "SELECT token FROM sessions WHERE user_id=? AND substr(token,1,24)=?",
      )
      .get(req.user.id, req.params.id);
    if (!row) return fail(res, 404, "Session not found.");
    db.prepare("DELETE FROM sessions WHERE token=?").run(row.token);
    if (equal(row.token, sessionHash(req)))
      res.clearCookie("rtr_session", { path: "/" });
    audit(req.user.id, "account.session_revoked");
    res.json({ success: true });
  });
  app.post("/api/account/sessions/revoke-others", requireAuth, (req, res) => {
    db.prepare("DELETE FROM sessions WHERE user_id=? AND token<>?").run(
      req.user.id,
      sessionHash(req),
    );
    audit(req.user.id, "account.sessions_revoked");
    res.json({ success: true });
  });
  app.patch("/api/account/preferences", requireAuth, (req, res) => {
    const current = preferences(req.user.id),
      updated = { ...current };
    for (const name of ["productUpdates", "renewalReminders", "newsletter"]) {
      if (req.body?.[name] !== undefined && typeof req.body[name] !== "boolean")
        return fail(res, 400, "Preference values must be true or false.");
      if (req.body?.[name] !== undefined) updated[name] = req.body[name];
    }
    db.prepare(
      "INSERT INTO account_preferences VALUES (?,?,?) ON CONFLICT(user_id) DO UPDATE SET payload=excluded.payload,updated_at=excluded.updated_at",
    ).run(req.user.id, JSON.stringify(updated), now());
    if (updated.newsletter)
      db.prepare("INSERT OR IGNORE INTO newsletter VALUES (?,?)").run(
        req.user.email,
        now(),
      );
    else db.prepare("DELETE FROM newsletter WHERE email=?").run(req.user.email);
    audit(req.user.id, "account.consent_updated", updated);
    res.json({ preferences: updated });
  });
  app.patch("/api/account/notifications/:id", requireAuth, (req, res) => {
    const result = db
      .prepare(
        "UPDATE account_notifications SET read_at=? WHERE id=? AND user_id=?",
      )
      .run(now(), req.params.id, req.user.id);
    if (!result.changes) return fail(res, 404, "Notification not found.");
    res.json({ success: true });
  });
  app.post("/api/account/notifications/read-all", requireAuth, (req, res) => {
    db.prepare(
      "UPDATE account_notifications SET read_at=? WHERE user_id=? AND read_at IS NULL",
    ).run(now(), req.user.id);
    res.json({ success: true });
  });
  app.get("/api/account/export", requireAuth, (req, res) => {
    const entry = security(req.user.id);
    res.setHeader(
      "Content-Disposition",
      'attachment; filename="rtr-digital-account.json"',
    );
    res.json({
      exportedAt: now(),
      user: safeUser(req.user),
      accountSecurity: {
        emailVerified: entry.verified_email === req.user.email,
        mfaEnabled: Boolean(entry.mfa_secret),
      },
      preferences: preferences(req.user.id),
      orders: db
        .prepare("SELECT payload FROM orders WHERE user_id=?")
        .all(req.user.id)
        .map((row) => JSON.parse(row.payload)),
      wishlist: JSON.parse(
        db
          .prepare("SELECT product_ids FROM wishlists WHERE user_id=?")
          .get(req.user.id)?.product_ids || "[]",
      ),
      supportTickets: db
        .prepare(
          "SELECT id,email,subject,message,status,created_at AS createdAt FROM tickets WHERE user_id=?",
        )
        .all(req.user.id),
      reviews: db
        .prepare(
          "SELECT product_id AS productId,rating,body,created_at AS createdAt FROM reviews WHERE user_id=?",
        )
        .all(req.user.id),
      notifications: db
        .prepare(
          "SELECT title,body,read_at AS readAt,created_at AS createdAt FROM account_notifications WHERE user_id=?",
        )
        .all(req.user.id),
      mailHistory: db
        .prepare(
          "SELECT subject,status,created_at AS createdAt FROM identity_mail WHERE user_id=?",
        )
        .all(req.user.id),
      ...(hasTable("learning_progress")
        ? {
            learningProgress: db
              .prepare(
                "SELECT product_id AS productId,position,total,completed,note,updated_at AS updatedAt FROM learning_progress WHERE user_id=?",
              )
              .all(req.user.id),
          }
        : {}),
      ...(hasTable("review_reports")
        ? {
            reviewReports: db
              .prepare(
                "SELECT review_id AS reviewId,reason,status,created_at AS createdAt FROM review_reports WHERE user_id=?",
              )
              .all(req.user.id),
          }
        : {}),
    });
  });
  app.post(
    "/api/account/delete",
    requireAuth,
    rateLimit("delete-account", 3),
    async (req, res, next) => {
      if (isDemo(req.user))
        return fail(res, 403, "Shared demo accounts cannot be deleted.");
      if (req.body?.confirmation !== "DELETE")
        return fail(res, 400, "Type DELETE to confirm account removal.");
      if (!reauthenticate(req, res)) return;
      if (
        req.user.role === "admin" &&
        db
          .prepare(
            "SELECT count(*) AS count FROM users LEFT JOIN account_security ON users.id=account_security.user_id WHERE users.role='admin' AND account_security.deleted_at IS NULL AND users.email NOT IN ('demo-admin@rtr.example','demo-customer@rtr.example')",
          )
          .get().count <= 1
      )
        return fail(
          res,
          409,
          "Create another administrator before removing the final administrator account.",
        );
      const membership = ctx.subscription(req.user);
      if (
        membership?.mode === "stripe" &&
        ["active", "trialing", "past_due"].includes(membership.status)
      )
        return fail(
          res,
          409,
          "Cancel your live subscription in billing and wait for it to end before deleting your account.",
        );
      db.exec("BEGIN IMMEDIATE");
      try {
        ensureSecurity(req.user.id);
        db.prepare(
          "UPDATE users SET name=?,email=?,password=?,subscription=NULL,role=? WHERE id=?",
        ).run(
          "Deleted account",
          `deleted-${req.user.id}@removed.invalid`,
          passwordHash(randomBytes(32).toString("hex")),
          "customer",
          req.user.id,
        );
        db.prepare(
          "UPDATE account_security SET deleted_at=?,mfa_secret=NULL,pending_mfa=NULL,backup_hashes='[]',verified_email=NULL WHERE user_id=?",
        ).run(now(), req.user.id);
        for (const table of [
          "sessions",
          "identity_tokens",
          "account_preferences",
          "identity_mail",
          "account_notifications",
          "wishlists",
          "reviews",
        ])
          db.prepare(`DELETE FROM ${table} WHERE user_id=?`).run(req.user.id);
        for (const table of [
          "learning_progress",
          "product_release_notifications",
          "review_reports",
          "membership_reminders",
        ]) {
          if (hasTable(table))
            db.prepare(`DELETE FROM ${table} WHERE user_id=?`).run(req.user.id);
        }
        if (
          hasTable("studio_teams") &&
          hasTable("studio_members") &&
          hasTable("studio_invites")
        ) {
          const team = db
            .prepare("SELECT id FROM studio_teams WHERE owner_id=?")
            .get(req.user.id);
          if (team) {
            db.prepare("DELETE FROM studio_invites WHERE team_id=?").run(
              team.id,
            );
            db.prepare("DELETE FROM studio_members WHERE team_id=?").run(
              team.id,
            );
            db.prepare("DELETE FROM studio_teams WHERE id=?").run(team.id);
          }
          db.prepare("DELETE FROM studio_members WHERE user_id=?").run(
            req.user.id,
          );
          db.prepare(
            "DELETE FROM studio_invites WHERE email=? OR accepted_by=?",
          ).run(req.user.email, req.user.id);
        }
        if (hasTable("membership_events"))
          db.prepare(
            "UPDATE membership_events SET detail='Personal workspace details removed at account holder request' WHERE user_id=? AND type LIKE 'team.%'",
          ).run(req.user.id);
        db.prepare("DELETE FROM newsletter WHERE email=?").run(req.user.email);
        db.prepare(
          "UPDATE tickets SET email='removed@removed.invalid',message='Content removed at account holder request',subject='Removed support request' WHERE user_id=?",
        ).run(req.user.id);
        audit(req.user.id, "account.anonymized");
        db.exec("COMMIT");
      } catch (error) {
        db.exec("ROLLBACK");
        return next(error);
      }
      res.clearCookie("rtr_session", { path: "/" });
      res.json({
        success: true,
        message:
          "Your profile and content have been removed. An anonymized account reference and financial records are retained for legitimate accounting obligations.",
      });
    },
  );
  return { notify, sendMail, mailReady };
}
