import multer from "multer";
import express from "express";
import { registerOriginalViewing } from "./original-viewing.mjs";
import { registerResumablePublishing } from "./resumable-publishing.mjs";
import { SELLER_NAME, brandProduct } from "../brand.mjs";
import {
  createHash,
  randomUUID,
  randomBytes,
  createCipheriv,
  createDecipheriv,
} from "node:crypto";
import {
  readFileSync,
  existsSync,
  writeFileSync,
  unlinkSync,
  appendFileSync,
  createReadStream,
  mkdirSync,
  renameSync,
  statSync,
  statfsSync,
  truncateSync,
} from "node:fs";
import { basename, extname, resolve } from "node:path";

const categories = [
  "Design assets",
  "E-books",
  "Audio & music",
  "Courses",
  "Software",
  "Templates",
  "Video",
];
const digest = (bytes) => createHash("sha256").update(bytes).digest("hex");
const clean = (f) => {
  if (f?.path)
    try {
      unlinkSync(f.path);
    } catch {}
};
const byteType = (file, bytes) => {
  const ext = extname(file.originalname).toLowerCase();
  if (ext === ".pdf" && bytes.subarray(0, 5).toString() === "%PDF-")
    return { kind: "pdf", mime: "application/pdf" };
  if (
    ext === ".mp3" &&
    (bytes.subarray(0, 3).toString() === "ID3" ||
      (bytes.length > 2 && bytes[0] === 255 && (bytes[1] & 224) === 224))
  )
    return { kind: "audio", mime: "audio/mpeg" };
  if (
    ext === ".wav" &&
    bytes.subarray(0, 4).toString() === "RIFF" &&
    bytes.subarray(8, 12).toString() === "WAVE"
  )
    return { kind: "audio", mime: "audio/wav" };
  if (ext === ".ogg" && bytes.subarray(0, 4).toString() === "OggS")
    return { kind: "audio", mime: "audio/ogg" };
  if (ext === ".mp4" && bytes.subarray(4, 8).toString() === "ftyp")
    return { kind: "video", mime: "video/mp4" };
  if (
    ext === ".webm" &&
    bytes.subarray(0, 4).equals(Buffer.from([26, 69, 223, 163]))
  )
    return { kind: "video", mime: "video/webm" };
  if (ext === ".txt" && bytes.length <= 1024 * 1024 && !bytes.includes(0)) {
    const text = new TextDecoder("utf-8", { fatal: true }).decode(bytes);
    if (!/<\/?(?:script|html|iframe|svg|object|embed)\b/i.test(text))
      return { kind: "text", mime: "text/plain; charset=utf-8" };
  }
  return null;
};

export function registerPublishing(app, ctx) {
  const {
    db,
    dataDir,
    requireAuth,
    requireAdmin,
    fail,
    owns,
    product,
    products,
    audit,
    now,
    rateLimit,
  } = ctx;
  db.exec(`
    CREATE TABLE IF NOT EXISTS product_versions (id TEXT PRIMARY KEY,product_id TEXT NOT NULL REFERENCES products(id),version TEXT NOT NULL,changelog TEXT NOT NULL,file_path TEXT NOT NULL,checksum TEXT NOT NULL,bytes INTEGER NOT NULL,created_at TEXT NOT NULL,UNIQUE(product_id,version));
    CREATE TABLE IF NOT EXISTS product_previews (product_id TEXT PRIMARY KEY REFERENCES products(id),file_path TEXT NOT NULL,kind TEXT NOT NULL,mime TEXT NOT NULL,created_at TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS product_schedules (product_id TEXT PRIMARY KEY REFERENCES products(id),publish_at TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS learning_progress (user_id TEXT NOT NULL REFERENCES users(id),product_id TEXT NOT NULL REFERENCES products(id),position REAL NOT NULL DEFAULT 0,total REAL NOT NULL DEFAULT 0,completed INTEGER NOT NULL DEFAULT 0,note TEXT NOT NULL DEFAULT '',updated_at TEXT NOT NULL,PRIMARY KEY(user_id,product_id));
    CREATE TABLE IF NOT EXISTS product_license_keys (id TEXT PRIMARY KEY,product_id TEXT NOT NULL REFERENCES products(id),key_hash TEXT NOT NULL,encrypted TEXT NOT NULL,user_id TEXT,claimed_at TEXT,created_at TEXT NOT NULL,UNIQUE(product_id,key_hash));
    CREATE UNIQUE INDEX IF NOT EXISTS product_license_assignment ON product_license_keys(product_id,user_id) WHERE user_id IS NOT NULL;
    CREATE TABLE IF NOT EXISTS product_release_notifications (id TEXT PRIMARY KEY,user_id TEXT NOT NULL,product_id TEXT NOT NULL,version TEXT NOT NULL,created_at TEXT NOT NULL,read_at TEXT);
    CREATE TABLE IF NOT EXISTS review_reports (id TEXT PRIMARY KEY,review_id TEXT NOT NULL,user_id TEXT NOT NULL,reason TEXT NOT NULL,status TEXT NOT NULL DEFAULT 'open',created_at TEXT NOT NULL,UNIQUE(review_id,user_id));
    CREATE TABLE IF NOT EXISTS review_moderation (review_id TEXT PRIMARY KEY,hidden INTEGER NOT NULL DEFAULT 0,reason TEXT NOT NULL DEFAULT '',updated_at TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS product_upload_sessions (id TEXT PRIMARY KEY,product_id TEXT NOT NULL REFERENCES products(id),user_id TEXT NOT NULL REFERENCES users(id),version TEXT NOT NULL,changelog TEXT NOT NULL,filename TEXT NOT NULL,expected_bytes INTEGER NOT NULL,expected_sha256 TEXT,file_path TEXT NOT NULL,received_bytes INTEGER NOT NULL DEFAULT 0,status TEXT NOT NULL DEFAULT 'uploading',error TEXT,created_at TEXT NOT NULL,updated_at TEXT NOT NULL);
  `);
  registerOriginalViewing(app, ctx);
  const masterPath = resolve(dataDir, "license-key-master");
  if (!existsSync(masterPath))
    try {
      writeFileSync(masterPath, randomBytes(32), { flag: "wx", mode: 0o600 });
    } catch (error) {
      if (error.code !== "EEXIST") throw error;
    }
  const master = readFileSync(masterPath);
  if (master.length !== 32)
    throw new Error("License key storage is not configured correctly.");
  const encrypt = (text) => {
    const iv = randomBytes(12);
    const c = createCipheriv("aes-256-gcm", master, iv);
    const encrypted = Buffer.concat([c.update(text, "utf8"), c.final()]);
    return [
      iv.toString("hex"),
      c.getAuthTag().toString("hex"),
      encrypted.toString("hex"),
    ].join(":");
  };
  const decrypt = (text) => {
    const [iv, tag, bytes] = text.split(":");
    const d = createDecipheriv("aes-256-gcm", master, Buffer.from(iv, "hex"));
    d.setAuthTag(Buffer.from(tag, "hex"));
    return Buffer.concat([
      d.update(Buffer.from(bytes, "hex")),
      d.final(),
    ]).toString("utf8");
  };
  const filePath = (name) => resolve(dataDir, "uploads", basename(name));
  const rawProduct = (id) =>
    db.prepare("SELECT * FROM products WHERE id=?").get(id);
  const publicVersions = (id) =>
    db
      .prepare(
        "SELECT id,version,changelog,checksum,bytes,created_at AS createdAt FROM product_versions WHERE product_id=? ORDER BY rowid DESC",
      )
      .all(id);
  const publicPreview = (id) => {
    const p = db
      .prepare(
        "SELECT kind,mime,created_at AS createdAt FROM product_previews WHERE product_id=?",
      )
      .get(id);
    return p
      ? { ...p, url: `/api/products/${encodeURIComponent(id)}/preview` }
      : null;
  };
  const notifyRelease = (id, version) => {
    const audience = new Set(
      db
        .prepare("SELECT user_id FROM entitlements WHERE product_id=?")
        .all(id)
        .map((r) => r.user_id),
    );
    const row = rawProduct(id);
    if (row.status === "published" && product(row).subscriptionIncluded)
      for (const u of db
        .prepare("SELECT * FROM users WHERE subscription IS NOT NULL")
        .all())
        if (ctx.activeSubscription(u) && owns(u, id)) audience.add(u.id);
    const insert = db.prepare(
      "INSERT INTO product_release_notifications VALUES (?,?,?,?,?,NULL)",
    );
    for (const uid of audience)
      insert.run(randomUUID(), uid, id, version, now());
  };
  registerResumablePublishing(app, ctx, { notifyRelease });
  const publishDue = () => {
    const rows = db
      .prepare("SELECT product_id FROM product_schedules WHERE publish_at<=?")
      .all(now());
    for (const r of rows) {
      db.prepare("UPDATE products SET status='published' WHERE id=?").run(
        r.product_id,
      );
      db.prepare("DELETE FROM product_schedules WHERE product_id=?").run(
        r.product_id,
      );
      audit(null, "product.scheduled_published", { productId: r.product_id });
    }
  };
  app.use("/api", (req, _res, next) => {
    if (["GET", "HEAD"].includes(req.method)) publishDue();
    next();
  });
  const upload = multer({
    storage: multer.diskStorage({
      destination: resolve(dataDir, "uploads"),
      filename: (_req, file, cb) =>
        cb(
          null,
          `${randomUUID()}${extname(file.originalname)
            .toLowerCase()
            .replace(/[^.a-z0-9]/g, "")
            .slice(0, 12)}`,
        ),
    }),
    limits: {
      fileSize: 100 * 1024 * 1024,
      files: 1,
      fields: 5,
      fieldSize: 10000,
    },
  });
  const metadataPatch = (old, body) => {
    const p = brandProduct(old);
    for (const [field, min, max] of [
      ["title", 3, 120],
      ["description", 20, 5000],
      ["format", 1, 100],
    ])
      if (body[field] !== undefined) {
        if (
          typeof body[field] !== "string" ||
          body[field].trim().length < min ||
          body[field].length > max
        )
          throw new Error(`Invalid ${field}.`);
        p[field] = body[field].trim();
      }
    if (body.category !== undefined) {
      if (!categories.includes(body.category))
        throw new Error("Choose a valid digital product category.");
      p.category = body.category;
    }
    if (body.price !== undefined) {
      if (
        typeof body.price !== "number" ||
        !Number.isFinite(body.price) ||
        body.price < 0 ||
        body.price > 100000
      )
        throw new Error("Price must be between 0 and 100000.");
      p.price = Math.round(body.price * 100) / 100;
    }
    if (body.tags !== undefined) {
      if (
        !Array.isArray(body.tags) ||
        body.tags.length > 12 ||
        body.tags.some((v) => typeof v !== "string" || v.length > 50)
      )
        throw new Error("Use up to 12 tags of 50 characters each.");
      p.tags = body.tags.map((v) => v.trim()).filter(Boolean);
    }
    for (const field of ["subscriptionIncluded", "featured", "licenseRequired"])
      if (body[field] !== undefined) {
        if (typeof body[field] !== "boolean")
          throw new Error(`Invalid ${field}.`);
        p[field] = body[field];
      }
    if (body.status !== undefined) {
      if (!["draft", "published"].includes(body.status))
        throw new Error("Choose draft or published.");
      p.status = body.status;
    }
    return p;
  };
  app.get("/api/publisher/products", requireAdmin, (_req, res) =>
    res.json({ products: products(false), categories }),
  );
  app.get("/api/publisher/products/:id", requireAdmin, (req, res) => {
    const row = rawProduct(req.params.id);
    if (!row) return fail(res, 404, "Product not found.");
    const licenses = db
      .prepare(
        "SELECT count(*) AS total,sum(CASE WHEN user_id IS NOT NULL THEN 1 ELSE 0 END) AS assigned FROM product_license_keys WHERE product_id=?",
      )
      .get(row.id);
    res.json({
      product: product(row),
      versions: publicVersions(row.id),
      preview: publicPreview(row.id),
      licenses: {
        total: licenses.total,
        assigned: licenses.assigned || 0,
        available: licenses.total - (licenses.assigned || 0),
      },
      scheduledAt:
        db
          .prepare(
            "SELECT publish_at FROM product_schedules WHERE product_id=?",
          )
          .get(row.id)?.publish_at || null,
    });
  });
  app.patch("/api/publisher/products/:id", requireAdmin, (req, res) => {
    const row = rawProduct(req.params.id);
    if (!row) return fail(res, 404, "Product not found.");
    let next;
    try {
      next = metadataPatch(product(row), req.body || {});
    } catch (e) {
      return fail(res, 400, e.message);
    }
    if (
      req.body.scheduledAt !== undefined &&
      req.body.scheduledAt !== null &&
      (typeof req.body.scheduledAt !== "string" ||
        !Number.isFinite(Date.parse(req.body.scheduledAt)) ||
        Date.parse(req.body.scheduledAt) <= Date.now())
    )
      return fail(res, 400, "Choose a future publication date.");
    if (
      !next.isSample &&
      (!row.file_path || !existsSync(filePath(row.file_path))) &&
      (next.status === "published" || req.body.scheduledAt)
    )
      return fail(
        res,
        400,
        "Upload and finalize an original file before publishing or scheduling this product.",
      );
    db.exec("BEGIN IMMEDIATE");
    try {
      if (req.body.scheduledAt) {
        next.status = "draft";
        db.prepare(
          "INSERT INTO product_schedules VALUES (?,?) ON CONFLICT(product_id) DO UPDATE SET publish_at=excluded.publish_at",
        ).run(row.id, new Date(req.body.scheduledAt).toISOString());
      } else if (req.body.scheduledAt === null || req.body.status !== undefined)
        db.prepare("DELETE FROM product_schedules WHERE product_id=?").run(
          row.id,
        );
      db.prepare("UPDATE products SET payload=?,status=? WHERE id=?").run(
        JSON.stringify(next),
        next.status,
        row.id,
      );
      audit(req.user.id, "publisher.metadata_updated", { productId: row.id });
      db.exec("COMMIT");
    } catch (e) {
      db.exec("ROLLBACK");
      throw e;
    }
    res.json({ product: product(rawProduct(row.id)) });
  });
  app.post("/api/publisher/import", requireAdmin, (req, res) => {
    const incoming = req.body?.products;
    if (
      !Array.isArray(incoming) ||
      incoming.length < 1 ||
      incoming.length > 100
    )
      return fail(
        res,
        400,
        "Import between 1 and 100 existing product records.",
      );
    const updates = [];
    const seen = new Set();
    try {
      for (const item of incoming) {
        if (!item || typeof item.id !== "string" || seen.has(item.id))
          throw new Error("Each product needs a unique existing ID.");
        const row = rawProduct(item.id);
        if (!row) throw new Error(`Unknown product ID: ${item.id}`);
        seen.add(item.id);
        const update = metadataPatch(product(row), item);
        if (
          update.status === "published" &&
          !update.isSample &&
          (!row.file_path || !existsSync(filePath(row.file_path)))
        )
          throw new Error(
            "Upload and finalize an original file before publishing this product.",
          );
        updates.push(update);
      }
    } catch (e) {
      return fail(res, 400, e.message);
    }
    db.exec("BEGIN IMMEDIATE");
    try {
      for (const p of updates) {
        db.prepare("UPDATE products SET payload=?,status=? WHERE id=?").run(
          JSON.stringify(p),
          p.status,
          p.id,
        );
        if (incoming.find((item) => item.id === p.id).status !== undefined)
          db.prepare("DELETE FROM product_schedules WHERE product_id=?").run(
            p.id,
          );
      }
      audit(req.user.id, "publisher.bulk_updated", { count: updates.length });
      db.exec("COMMIT");
    } catch (e) {
      db.exec("ROLLBACK");
      throw e;
    }
    res.json({ success: true, updated: updates.length });
  });
  app.post(
    "/api/publisher/products/:id/releases",
    requireAdmin,
    upload.single("file"),
    (req, res) => {
      const row = rawProduct(req.params.id);
      const file = req.file;
      const version = req.body?.version;
      const changelog = req.body?.changelog || "";
      if (
        !row ||
        !file ||
        typeof version !== "string" ||
        !/^[A-Za-z0-9][A-Za-z0-9.+_-]{0,49}$/.test(version) ||
        typeof changelog !== "string" ||
        changelog.length > 5000
      ) {
        clean(file);
        return fail(
          res,
          400,
          "Choose a product, original file, version label, and changelog under 5000 characters.",
        );
      }
      if (
        db
          .prepare(
            "SELECT id FROM product_versions WHERE product_id=? AND version=?",
          )
          .get(row.id, version)
      ) {
        clean(file);
        return fail(res, 409, "That version already exists.");
      }
      const bytes = readFileSync(file.path),
        checksum = digest(bytes),
        id = randomUUID(),
        createdAt = now();
      const p = {
        ...product(row),
        format:
          extname(file.originalname).slice(1).toUpperCase() ||
          product(row).format,
        size: `${(file.size / 1048576).toFixed(1)} MB`,
        isSample: false,
        latestVersion: version,
        checksum,
      };
      db.exec("BEGIN IMMEDIATE");
      try {
        if (
          row.file_path &&
          !db
            .prepare(
              "SELECT id FROM product_versions WHERE product_id=? AND file_path=?",
            )
            .get(row.id, row.file_path) &&
          existsSync(filePath(row.file_path))
        ) {
          const oldBytes = readFileSync(filePath(row.file_path));
          const label =
            version === "original" ||
            db
              .prepare(
                "SELECT 1 FROM product_versions WHERE product_id=? AND version='original'",
              )
              .get(row.id)
              ? `original-${randomBytes(3).toString("hex")}`
              : "original";
          db.prepare(
            "INSERT INTO product_versions VALUES (?,?,?,?,?,?,?,?)",
          ).run(
            randomUUID(),
            row.id,
            label,
            "Original uploaded release",
            row.file_path,
            digest(oldBytes),
            oldBytes.length,
            row.created_at,
          );
        }
        db.prepare("INSERT INTO product_versions VALUES (?,?,?,?,?,?,?,?)").run(
          id,
          row.id,
          version,
          changelog,
          basename(file.path),
          checksum,
          file.size,
          createdAt,
        );
        db.prepare("UPDATE products SET payload=?,file_path=? WHERE id=?").run(
          JSON.stringify(p),
          basename(file.path),
          row.id,
        );
        notifyRelease(row.id, version);
        audit(req.user.id, "publisher.release_uploaded", {
          productId: row.id,
          version,
          checksum,
        });
        db.exec("COMMIT");
      } catch (e) {
        db.exec("ROLLBACK");
        clean(file);
        throw e;
      }
      res.status(201).json({
        version: {
          id,
          version,
          changelog,
          checksum,
          bytes: file.size,
          createdAt,
        },
      });
    },
  );
  app.get(
    "/api/products/:id/releases/:releaseId/download",
    requireAuth,
    (req, res) => {
      if (!owns(req.user, req.params.id))
        return fail(
          res,
          403,
          "Product access is required to download a release.",
        );
      const release = db
        .prepare("SELECT * FROM product_versions WHERE id=? AND product_id=?")
        .get(req.params.releaseId, req.params.id);
      if (!release || !existsSync(filePath(release.file_path)))
        return fail(res, 404, "Release file not found.");
      audit(req.user.id, "product.release_download", {
        productId: req.params.id,
        releaseId: release.id,
        version: release.version,
      });
      res.setHeader("X-Content-SHA256", release.checksum);
      res.download(
        filePath(release.file_path),
        `${req.params.id}-${release.version}${extname(release.file_path)}`,
      );
    },
  );
  app.post(
    "/api/publisher/products/:id/preview",
    requireAdmin,
    upload.single("file"),
    (req, res) => {
      const row = rawProduct(req.params.id);
      const file = req.file;
      if (!row || !file) {
        clean(file);
        return fail(res, 400, "Choose a product and preview file.");
      }
      let type;
      try {
        type = byteType(file, readFileSync(file.path));
      } catch {
        type = null;
      }
      if (!type || file.size > 50 * 1048576) {
        clean(file);
        return fail(
          res,
          400,
          "Use a genuine MP3/WAV/OGG audio, MP4/WebM video, PDF, or plain UTF-8 .txt preview (maximum 50 MB). Previews are public.",
        );
      }
      const prior = db
        .prepare("SELECT file_path FROM product_previews WHERE product_id=?")
        .get(row.id);
      db.prepare(
        "INSERT INTO product_previews VALUES (?,?,?,?,?) ON CONFLICT(product_id) DO UPDATE SET file_path=excluded.file_path,kind=excluded.kind,mime=excluded.mime,created_at=excluded.created_at",
      ).run(row.id, basename(file.path), type.kind, type.mime, now());
      if (prior) clean({ path: filePath(prior.file_path) });
      audit(req.user.id, "publisher.preview_uploaded", {
        productId: row.id,
        kind: type.kind,
      });
      res.status(201).json({ preview: publicPreview(row.id) });
    },
  );
  app.delete(
    "/api/publisher/products/:id/preview",
    requireAdmin,
    (req, res) => {
      const prior = db
        .prepare("SELECT file_path FROM product_previews WHERE product_id=?")
        .get(req.params.id);
      db.prepare("DELETE FROM product_previews WHERE product_id=?").run(
        req.params.id,
      );
      if (prior) clean({ path: filePath(prior.file_path) });
      res.json({ success: true });
    },
  );
  app.get("/api/products/:id/preview", (req, res) => {
    const row = rawProduct(req.params.id);
    const preview = db
      .prepare("SELECT * FROM product_previews WHERE product_id=?")
      .get(req.params.id);
    if (
      !row ||
      !preview ||
      !(
        row.status === "published" ||
        req.user?.role === "admin" ||
        owns(req.user, row.id)
      )
    )
      return fail(res, 404, "Preview not found.");
    res.setHeader("Content-Type", preview.mime);
    res.setHeader("X-Frame-Options", "SAMEORIGIN");
    res.setHeader(
      "Content-Disposition",
      `inline; filename="preview${extname(preview.file_path)}"`,
    );
    res.setHeader(
      "Content-Security-Policy",
      "default-src 'none'; style-src 'unsafe-inline'; frame-ancestors 'self'; sandbox",
    );
    res.setHeader("Cache-Control", "private, max-age=300");
    res.sendFile(filePath(preview.file_path));
  });
  app.get("/api/products/:id/experience", (req, res) => {
    const row = rawProduct(req.params.id);
    if (
      !row ||
      !(
        row.status === "published" ||
        req.user?.role === "admin" ||
        owns(req.user, row.id)
      )
    )
      return fail(res, 404, "Product not found.");
    const p = product(row);
    const held =
      req.user &&
      db
        .prepare(
          "SELECT id,claimed_at AS claimedAt FROM product_license_keys WHERE product_id=? AND user_id=?",
        )
        .get(row.id, req.user.id);
    res.json({
      preview: publicPreview(row.id),
      versions: publicVersions(row.id),
      canAccess: owns(req.user, row.id),
      licenseRequired: Boolean(p.licenseRequired),
      licenseAssigned: held || null,
      latestVersion: p.latestVersion || null,
      checksum: p.checksum || null,
    });
  });
  app.get("/api/products/:id/progress", requireAuth, (req, res) => {
    if (!owns(req.user, req.params.id))
      return fail(
        res,
        403,
        "Product access is required to view learning progress.",
      );
    res.json({
      progress: db
        .prepare(
          "SELECT position,total,completed,note,updated_at AS updatedAt FROM learning_progress WHERE user_id=? AND product_id=?",
        )
        .get(req.user.id, req.params.id) || {
        position: 0,
        total: 0,
        completed: 0,
        note: "",
      },
    });
  });
  app.put(
    "/api/products/:id/progress",
    requireAuth,
    rateLimit("progress", 180, 60000),
    (req, res) => {
      if (!owns(req.user, req.params.id))
        return fail(
          res,
          403,
          "Product access is required to save learning progress.",
        );
      const {
        position = 0,
        total = 0,
        completed = false,
        note = "",
      } = req.body || {};
      if (
        !Number.isFinite(position) ||
        position < 0 ||
        !Number.isFinite(total) ||
        total < 0 ||
        position > 1e9 ||
        total > 1e9 ||
        (position > total && total !== 0) ||
        typeof completed !== "boolean" ||
        typeof note !== "string" ||
        note.length > 10000
      )
        return fail(
          res,
          400,
          "Provide valid progress and notes of at most 10000 characters.",
        );
      db.prepare(
        "INSERT INTO learning_progress VALUES (?,?,?,?,?,?,?) ON CONFLICT(user_id,product_id) DO UPDATE SET position=excluded.position,total=excluded.total,completed=excluded.completed,note=excluded.note,updated_at=excluded.updated_at",
      ).run(
        req.user.id,
        req.params.id,
        position,
        total,
        completed ? 1 : 0,
        note,
        now(),
      );
      res.json({ success: true });
    },
  );
  app.get("/api/library/releases", requireAuth, (req, res) =>
    res.json({
      notifications: db
        .prepare(
          "SELECT n.id,n.product_id AS productId,p.payload,n.version,n.created_at AS createdAt,n.read_at AS readAt FROM product_release_notifications n JOIN products p ON p.id=n.product_id WHERE n.user_id=? ORDER BY n.created_at DESC LIMIT 100",
        )
        .all(req.user.id)
        .map((n) => ({
          id: n.id,
          productId: n.productId,
          title: JSON.parse(n.payload).title,
          version: n.version,
          createdAt: n.createdAt,
          readAt: n.readAt,
        })),
    }),
  );
  app.post("/api/library/releases/:id/read", requireAuth, (req, res) => {
    db.prepare(
      "UPDATE product_release_notifications SET read_at=? WHERE id=? AND user_id=?",
    ).run(now(), req.params.id, req.user.id);
    res.json({ success: true });
  });
  app.post("/api/publisher/products/:id/licenses", requireAdmin, (req, res) => {
    const row = rawProduct(req.params.id);
    if (!row) return fail(res, 404, "Product not found.");
    const raw = req.body?.keys;
    if (typeof raw !== "string" || raw.length > 80000)
      return fail(
        res,
        400,
        "Provide newline-separated license keys, maximum 500 keys.",
      );
    const keys = [
      ...new Set(
        raw
          .split(/\r?\n/)
          .map((v) => v.trim())
          .filter(Boolean),
      ),
    ];
    if (
      keys.length < 1 ||
      keys.length > 500 ||
      keys.some((k) => k.length < 5 || k.length > 200)
    )
      return fail(
        res,
        400,
        "Provide 1 to 500 keys of 5 to 200 characters each.",
      );
    let inserted = 0;
    db.exec("BEGIN IMMEDIATE");
    try {
      for (const key of keys)
        inserted += db
          .prepare(
            "INSERT OR IGNORE INTO product_license_keys VALUES (?,?,?,?,NULL,NULL,?)",
          )
          .run(randomUUID(), row.id, digest(key), encrypt(key), now()).changes;
      const p = { ...product(row), licenseRequired: true };
      db.prepare("UPDATE products SET payload=? WHERE id=?").run(
        JSON.stringify(p),
        row.id,
      );
      audit(req.user.id, "publisher.keys_imported", {
        productId: row.id,
        count: inserted,
      });
      db.exec("COMMIT");
    } catch (e) {
      db.exec("ROLLBACK");
      throw e;
    }
    res.json({
      success: true,
      imported: inserted,
      duplicates: keys.length - inserted,
    });
  });
  app.post("/api/products/:id/license", requireAuth, (req, res) => {
    if (!owns(req.user, req.params.id))
      return fail(res, 403, "Product access is required to claim a license.");
    let key = db
      .prepare(
        "SELECT * FROM product_license_keys WHERE product_id=? AND user_id=?",
      )
      .get(req.params.id, req.user.id);
    if (!key) {
      db.exec("BEGIN IMMEDIATE");
      try {
        key = db
          .prepare(
            "SELECT * FROM product_license_keys WHERE product_id=? AND user_id IS NULL ORDER BY rowid LIMIT 1",
          )
          .get(req.params.id);
        if (!key) {
          db.exec("ROLLBACK");
          return fail(
            res,
            409,
            "No license keys are available. Contact support.",
          );
        }
        key = { ...key, user_id: req.user.id, claimed_at: now() };
        db.prepare(
          "UPDATE product_license_keys SET user_id=?,claimed_at=? WHERE id=? AND user_id IS NULL",
        ).run(req.user.id, key.claimed_at, key.id);
        audit(req.user.id, "product.license_claimed", {
          productId: req.params.id,
          licenseId: key.id,
        });
        db.exec("COMMIT");
      } catch (e) {
        db.exec("ROLLBACK");
        throw e;
      }
    }
    res.json({
      key: decrypt(key.encrypted),
      licenseId: key.id,
      claimedAt: key.claimed_at,
      seller: SELLER_NAME,
      licensor: SELLER_NAME,
    });
  });
  app.get("/api/publisher/reviews", requireAdmin, (_req, res) =>
    res.json({
      reviews: db
        .prepare(
          "SELECT reviews.*,users.name,p.payload,COALESCE(m.hidden,0) AS hidden,COALESCE(m.reason,'') AS moderationReason FROM reviews JOIN users ON users.id=reviews.user_id JOIN products p ON p.id=reviews.product_id LEFT JOIN review_moderation m ON m.review_id=reviews.id ORDER BY reviews.created_at DESC LIMIT 200",
        )
        .all()
        .map((r) => ({
          id: r.id,
          productId: r.product_id,
          title: JSON.parse(r.payload).title,
          name: r.name,
          body: r.body,
          rating: r.rating,
          createdAt: r.created_at,
          hidden: Boolean(r.hidden),
          moderationReason: r.moderationReason,
        })),
      reports: db
        .prepare(
          "SELECT * FROM review_reports ORDER BY created_at DESC LIMIT 200",
        )
        .all(),
    }),
  );
  app.patch("/api/publisher/reviews/:id", requireAdmin, (req, res) => {
    if (
      typeof req.body?.hidden !== "boolean" ||
      typeof (req.body.reason || "") !== "string" ||
      (req.body.reason || "").length > 500
    )
      return fail(
        res,
        400,
        "Choose a review visibility and moderation reason.",
      );
    if (!db.prepare("SELECT id FROM reviews WHERE id=?").get(req.params.id))
      return fail(res, 404, "Review not found.");
    db.prepare(
      "INSERT INTO review_moderation VALUES (?,?,?,?) ON CONFLICT(review_id) DO UPDATE SET hidden=excluded.hidden,reason=excluded.reason,updated_at=excluded.updated_at",
    ).run(req.params.id, req.body.hidden ? 1 : 0, req.body.reason || "", now());
    audit(req.user.id, "review.moderated", {
      reviewId: req.params.id,
      hidden: req.body.hidden,
    });
    res.json({ success: true });
  });
  app.get("/api/reviews/:id", (req, res) =>
    res.json({
      reviews: db
        .prepare(
          "SELECT r.id,r.rating,r.body,r.created_at AS createdAt,u.name FROM reviews r JOIN users u ON u.id=r.user_id LEFT JOIN review_moderation m ON m.review_id=r.id WHERE r.product_id=? AND COALESCE(m.hidden,0)=0 ORDER BY r.created_at DESC",
        )
        .all(req.params.id),
    }),
  );
  app.post("/api/reviews/:id/report", requireAuth, (req, res) => {
    if (
      typeof req.body?.reason !== "string" ||
      req.body.reason.trim().length < 10 ||
      req.body.reason.length > 500
    )
      return fail(res, 400, "Give a reason between 10 and 500 characters.");
    if (!db.prepare("SELECT id FROM reviews WHERE id=?").get(req.params.id))
      return fail(res, 404, "Review not found.");
    db.prepare(
      "INSERT INTO review_reports VALUES (?,?,?,?,'open',?) ON CONFLICT(review_id,user_id) DO UPDATE SET reason=excluded.reason",
    ).run(
      randomUUID(),
      req.params.id,
      req.user.id,
      req.body.reason.trim(),
      now(),
    );
    res.json({ success: true });
  });
  app.patch("/api/publisher/reports/:id", requireAdmin, (req, res) => {
    if (!["open", "resolved"].includes(req.body?.status))
      return fail(res, 400, "Choose an open or resolved report status.");
    const result = db
      .prepare("UPDATE review_reports SET status=? WHERE id=?")
      .run(req.body.status, req.params.id);
    if (!result.changes) return fail(res, 404, "Report not found.");
    audit(req.user.id, "review.report_updated", {
      reportId: req.params.id,
      status: req.body.status,
    });
    res.json({ success: true });
  });
  return { publishDue };
}
