import { randomBytes, randomUUID } from "node:crypto";
import { statSync } from "node:fs";
import { basename, resolve } from "node:path";

const DAY = 86400000;
const isDemoIdentity = (email) =>
  /^demo-(admin|customer)@rtr\.example$/i.test(email || "");
const titleFor = {
  "trial.started": "Your seven-day creative chapter starts now",
  "trial.ended": "Your trial has ended",
  "team.created": "Your Studio workspace is ready",
  "team.joined": "Welcome to your Studio team",
  "invoice.paid": "Membership renewal confirmed",
  "invoice.payment_succeeded": "Membership renewal confirmed",
  "invoice.payment_failed": "Your membership payment needs attention",
  "invoice.payment_action_required": "A payment confirmation is required",
  "customer.subscription.updated": "Membership billing details updated",
  "customer.subscription.deleted": "Membership ended",
};

export function registerMemberships(app, ctx) {
  const {
    db,
    production,
    demoMode,
    publicBaseUrl,
    requireAuth,
    requireAdmin,
    fail,
    subscription,
    visibleSubscription,
    activeSubscription,
    safeUser,
    audit,
    now,
    hash,
    validEmail,
    rateLimit,
  } = ctx;
  db.exec(`
    CREATE TABLE IF NOT EXISTS membership_trials (user_id TEXT PRIMARY KEY, email_hash TEXT UNIQUE NOT NULL, started_at TEXT NOT NULL, expires_at TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS studio_teams (id TEXT PRIMARY KEY, owner_id TEXT NOT NULL UNIQUE REFERENCES users(id), name TEXT NOT NULL, created_at TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS studio_members (user_id TEXT PRIMARY KEY REFERENCES users(id), team_id TEXT NOT NULL REFERENCES studio_teams(id), role TEXT NOT NULL, joined_at TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS studio_invites (id TEXT PRIMARY KEY, team_id TEXT NOT NULL REFERENCES studio_teams(id), email TEXT NOT NULL, token_hash TEXT UNIQUE NOT NULL, status TEXT NOT NULL DEFAULT 'pending', expires_at TEXT NOT NULL, created_at TEXT NOT NULL, accepted_by TEXT);
    CREATE INDEX IF NOT EXISTS studio_invites_team ON studio_invites(team_id,status);
    CREATE TABLE IF NOT EXISTS membership_events (id TEXT PRIMARY KEY, user_id TEXT NOT NULL REFERENCES users(id), provider_event_id TEXT UNIQUE, type TEXT NOT NULL, title TEXT NOT NULL, detail TEXT NOT NULL, amount REAL, currency TEXT, mode TEXT NOT NULL, created_at TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS membership_reminders (id TEXT PRIMARY KEY, user_id TEXT NOT NULL REFERENCES users(id), type TEXT NOT NULL, reference TEXT NOT NULL, title TEXT NOT NULL, message TEXT NOT NULL, due_at TEXT NOT NULL, read_at TEXT, created_at TEXT NOT NULL, UNIQUE(user_id,type,reference));
  `);
  const addEvent = (
    userId,
    type,
    detail,
    { providerId = null, amount = null, currency = "USD", mode = "demo" } = {},
  ) => {
    const id = randomUUID();
    const result = db
      .prepare(
        "INSERT OR IGNORE INTO membership_events VALUES (?,?,?,?,?,?,?,?,?,?)",
      )
      .run(
        id,
        userId,
        providerId,
        type,
        titleFor[type] || type.replaceAll(".", " "),
        detail,
        amount,
        currency,
        mode,
        now(),
      );
    return result.changes ? id : null;
  };
  const addReminder = (
    user,
    type,
    reference,
    title,
    message,
    dueAt = now(),
  ) => {
    const result = db
      .prepare(
        "INSERT OR IGNORE INTO membership_reminders VALUES (?,?,?,?,?,?,?,?,?)",
      )
      .run(
        randomUUID(),
        user.id,
        type,
        reference,
        title,
        message,
        dueAt,
        null,
        now(),
      );
    if (result.changes && ctx.identity) {
      ctx.identity.notify(user.id, title, message);
      let preferences = {};
      try {
        preferences = JSON.parse(
          db
            .prepare("SELECT payload FROM account_preferences WHERE user_id=?")
            .get(user.id)?.payload || "{}",
        );
      } catch {}
      if (
        type === "payment_attention" ||
        preferences.renewalReminders !== false
      )
        Promise.resolve(ctx.identity.sendMail(user, title, message)).catch(
          () => {},
        );
    }
  };
  const teamRecord = (userId) =>
    db
      .prepare(
        "SELECT studio_teams.*,studio_members.role FROM studio_teams JOIN studio_members ON studio_teams.id=studio_members.team_id WHERE studio_members.user_id=?",
      )
      .get(userId);
  const teamActive = (team) => {
    if (!team) return false;
    const owner = db
      .prepare("SELECT * FROM users WHERE id=?")
      .get(team.owner_id);
    const s = visibleSubscription(owner);
    return Boolean(owner && activeSubscription(owner) && s?.plan === "studio");
  };
  const teamOwns = (user, productId) => {
    if (!user || !teamActive(teamRecord(user.id))) return false;
    const row = db
      .prepare("SELECT payload FROM products WHERE id=? AND status='published'")
      .get(productId);
    return Boolean(row && JSON.parse(row.payload).subscriptionIncluded);
  };
  const safeTeam = (user) => {
    const team = teamRecord(user.id);
    if (!team) return null;
    const owner = db
      .prepare("SELECT id,name,email FROM users WHERE id=?")
      .get(team.owner_id);
    const members = db
      .prepare(
        "SELECT users.id,users.name,users.email,studio_members.role,studio_members.joined_at AS joinedAt FROM studio_members JOIN users ON users.id=studio_members.user_id WHERE studio_members.team_id=? ORDER BY studio_members.joined_at",
      )
      .all(team.id);
    const reservedSeats = db
      .prepare(
        "SELECT count(*) AS n FROM studio_invites WHERE team_id=? AND status='pending' AND expires_at>?",
      )
      .get(team.id, now()).n;
    const invites =
      team.role === "owner"
        ? db
            .prepare(
              "SELECT id,email,expires_at AS expiresAt,created_at AS createdAt FROM studio_invites WHERE team_id=? AND status='pending' AND expires_at>? ORDER BY created_at",
            )
            .all(team.id, now())
        : [];
    return {
      id: team.id,
      name: team.name,
      role: team.role,
      owner,
      active: teamActive(team),
      seatLimit: 5,
      occupiedSeats: members.length,
      reservedSeats,
      members,
      invites,
    };
  };
  const requireOwner = (req, res, next) => {
    const team = teamRecord(req.user.id);
    if (!team || team.role !== "owner")
      return fail(
        res,
        403,
        "Only the workspace owner can manage Studio seats.",
      );
    req.studioTeam = team;
    next();
  };
  const scheduleReminder = (user) => {
    const s = visibleSubscription(user);
    if (
      !s ||
      !["active", "trialing"].includes(s.status) ||
      !Number.isFinite(Date.parse(s.currentPeriodEnd))
    )
      return;
    const end = Date.parse(s.currentPeriodEnd);
    const isTrial = Boolean(s.isTrial || s.interval === "trial");
    if (end <= Date.now()) {
      const title = isTrial
        ? "Your free trial has ended"
        : "Your recorded membership access period has ended";
      const message = isTrial
        ? "Your free preview has expired. It did not convert to a paid subscription or charge you. Your individual purchases remain available."
        : "Your recorded access period has ended. Check your billing status or choose a new plan to restore membership access. Your individual purchases remain available.";
      addReminder(user, "access_ended", s.currentPeriodEnd, title, message);
      if (isTrial)
        addEvent(user.id, "trial.ended", message, {
          providerId: `local-trial-expiry:${user.id}:${s.currentPeriodEnd}`,
          mode: s.mode || "demo",
        });
      return;
    }
    if (end > Date.now() + 7 * DAY) return;
    const ending = isTrial || s.cancelAtPeriodEnd || s.autoRenew === false;
    const title = isTrial
      ? "Your free trial is ending soon"
      : ending
        ? "Your membership access ends soon"
        : "Your membership renewal is coming up";
    const message = isTrial
      ? `Your free trial ends on ${new Date(end).toISOString().slice(0, 10)}. It does not automatically renew or charge you. Choose a paid plan separately if you wish to continue.`
      : ending
        ? `Your current access ends on ${new Date(end).toISOString().slice(0, 10)}. Renewal is not scheduled.`
        : `Your ${s.interval} membership is scheduled to renew on ${new Date(end).toISOString().slice(0, 10)}. You can manage or cancel renewal in your library before then.`;
    addReminder(
      user,
      isTrial ? "trial_ending" : "period_ending",
      s.currentPeriodEnd,
      title,
      message,
      new Date(Math.max(Date.now(), end - 7 * DAY)).toISOString(),
    );
  };
  const operatorTrialsEnabled =
    ctx.options.trialsEnabled === undefined
      ? process.env.TRIALS_ENABLED === "true"
      : ctx.options.trialsEnabled === true;
  const trialsAvailable = production
    ? operatorTrialsEnabled
    : demoMode || operatorTrialsEnabled;
  const realTrial = production || !demoMode;
  const originalTrialContentAvailable = () =>
    db
      .prepare(
        "SELECT payload,file_path FROM products WHERE status='published' AND file_path IS NOT NULL",
      )
      .all()
      .some((row) => {
        const item = JSON.parse(row.payload);
        if (item.isSample || !item.subscriptionIncluded) return false;
        try {
          return statSync(
            resolve(ctx.dataDir, "uploads", basename(row.file_path)),
          ).isFile();
        } catch {
          return false;
        }
      });
  const trialIssue = (user) => {
    if (!trialsAvailable)
      return {
        status: 503,
        message:
          "Free no-card trials are not enabled by the operator. No payment was taken.",
      };
    if (isDemoIdentity(user.email))
      return {
        status: 409,
        message:
          "Shared demo accounts are not eligible. Register your own account to try the free preview.",
      };
    if (activeSubscription(user))
      return {
        status: 409,
        message: "An active membership or trial already provides access.",
      };
    const current = subscription(user);
    if (
      current?.mode === "stripe" &&
      current.stripeSubscriptionId &&
      !["canceled", "incomplete_expired"].includes(current.status)
    )
      return {
        status: 409,
        message:
          "Resolve your existing membership in Stripe Billing before starting a free trial. Its billing record is still open.",
      };
    if (
      db
        .prepare(
          "SELECT user_id FROM membership_trials WHERE user_id=? OR email_hash=?",
        )
        .get(user.id, hash(user.email.toLowerCase()))
    )
      return {
        status: 409,
        message:
          "A seven-day trial is available once per account and registered email address.",
      };
    if (
      realTrial &&
      !db
        .prepare(
          "SELECT 1 FROM account_security WHERE user_id=? AND verified_email=? AND deleted_at IS NULL",
        )
        .get(user.id, user.email)
    )
      return {
        status: 403,
        message:
          "Verify your email in Account & security before starting a free trial.",
      };
    if (realTrial && !originalTrialContentAvailable())
      return {
        status: 503,
        message:
          "The operator must publish an original membership-eligible file before offering a free trial.",
      };
    return null;
  };

  app.get("/api/membership/hub", requireAuth, (req, res) => {
    scheduleReminder(req.user);
    const issue = trialIssue(req.user);
    res.json({
      subscription: visibleSubscription(req.user),
      demoMode: demoMode && !production,
      trialEligible: !issue,
      trialPolicy: {
        enabled: trialsAvailable,
        mode: realTrial ? "trial" : "demo",
        durationDays: 7,
        automaticRenewal: false,
        requiresCard: false,
        requiresVerifiedEmail: realTrial,
        requiresOriginalContent: realTrial,
      },
      trialUnavailableReason: issue?.message || null,
      team: safeTeam(req.user),
      events: db
        .prepare(
          "SELECT id,type,title,detail,amount,currency,mode,created_at AS createdAt FROM membership_events WHERE user_id=? ORDER BY created_at DESC,rowid DESC LIMIT 60",
        )
        .all(req.user.id),
      reminders: db
        .prepare(
          "SELECT id,title,message,due_at AS dueAt,read_at AS readAt FROM membership_reminders WHERE user_id=? ORDER BY created_at DESC LIMIT 30",
        )
        .all(req.user.id)
        .map((r) => ({ ...r, read: Boolean(r.readAt) })),
    });
  });
  app.post(
    "/api/membership/trial",
    requireAuth,
    rateLimit("trial", 8),
    (req, res) => {
      if (!trialsAvailable)
        return fail(
          res,
          503,
          "Free no-card trials are not enabled by the operator. No payment was taken.",
        );
      const plan = req.body?.plan || "creator";
      if (!["starter", "creator"].includes(plan))
        return fail(res, 400, "Choose Explorer or Creator for a free trial.");
      const issue = trialIssue(req.user);
      if (issue) return fail(res, issue.status, issue.message);
      const startedAt = now();
      const expiresAt = new Date(Date.now() + 7 * DAY).toISOString();
      const trial = {
        plan,
        interval: "trial",
        status: "trialing",
        currentPeriodEnd: expiresAt,
        cancelAtPeriodEnd: true,
        autoRenew: false,
        isTrial: true,
        mode: realTrial ? "trial" : "demo",
        stripeSubscriptionId: null,
      };
      db.exec("BEGIN IMMEDIATE");
      try {
        db.prepare("INSERT INTO membership_trials VALUES (?,?,?,?)").run(
          req.user.id,
          hash(req.user.email.toLowerCase()),
          startedAt,
          expiresAt,
        );
        db.prepare("UPDATE users SET subscription=? WHERE id=?").run(
          JSON.stringify(trial),
          req.user.id,
        );
        addEvent(
          req.user.id,
          "trial.started",
          "Seven days of Creator/Explorer access. No card was collected. The trial expires automatically without renewal or a charge.",
          { mode: trial.mode },
        );
        audit(req.user.id, "membership.trial_started", { plan, expiresAt });
        db.exec("COMMIT");
      } catch (error) {
        db.exec("ROLLBACK");
        throw error;
      }
      res.status(201).json({
        subscription: trial,
        user: safeUser(
          db.prepare("SELECT * FROM users WHERE id=?").get(req.user.id),
        ),
        message: realTrial
          ? "Your seven-day free trial is active. It ends automatically; no card or renewal charge."
          : "Your seven-day demo trial is active. It ends automatically; no card or renewal charge.",
      });
    },
  );
  app.post("/api/membership/trial/end", requireAuth, (req, res) => {
    const s = visibleSubscription(req.user);
    if (!s?.isTrial || s.status !== "trialing")
      return fail(res, 400, "There is no active free trial to end.");
    const updated = {
      ...s,
      status: "canceled",
      currentPeriodEnd: now(),
      cancelAtPeriodEnd: true,
      autoRenew: false,
    };
    db.prepare("UPDATE users SET subscription=? WHERE id=?").run(
      JSON.stringify(updated),
      req.user.id,
    );
    addEvent(
      req.user.id,
      "trial.ended",
      "You ended the no-card trial. No payment was taken. Your separately purchased products are still in your library.",
      { mode: s.mode },
    );
    audit(req.user.id, "membership.trial_ended");
    res.json({
      success: true,
      user: safeUser(
        db.prepare("SELECT * FROM users WHERE id=?").get(req.user.id),
      ),
      subscription: updated,
    });
  });
  app.post("/api/membership/reminders/:id/read", requireAuth, (req, res) => {
    const result = db
      .prepare(
        "UPDATE membership_reminders SET read_at=? WHERE id=? AND user_id=?",
      )
      .run(now(), req.params.id, req.user.id);
    return result.changes
      ? res.json({ success: true })
      : fail(res, 404, "Notification not found.");
  });
  app.post("/api/membership/team", requireAuth, (req, res) => {
    if (
      !activeSubscription(req.user) ||
      visibleSubscription(req.user)?.plan !== "studio"
    )
      return fail(
        res,
        403,
        "An active Studio membership is required to create a team.",
      );
    if (teamRecord(req.user.id))
      return fail(
        res,
        409,
        "You already belong to a workspace. Leave it before creating another.",
      );
    const name = req.body?.name;
    if (typeof name !== "string" || name.trim().length < 2 || name.length > 80)
      return fail(
        res,
        400,
        "Use a workspace name between 2 and 80 characters.",
      );
    const id = randomUUID();
    const createdAt = now();
    db.exec("BEGIN IMMEDIATE");
    try {
      db.prepare("INSERT INTO studio_teams VALUES (?,?,?,?)").run(
        id,
        req.user.id,
        name.trim(),
        createdAt,
      );
      db.prepare("INSERT INTO studio_members VALUES (?,?,?,?)").run(
        req.user.id,
        id,
        "owner",
        createdAt,
      );
      addEvent(
        req.user.id,
        "team.created",
        `Your Studio workspace “${name.trim()}” is ready. Five seats include the owner and pending invitations.`,
        { mode: visibleSubscription(req.user)?.mode || "demo" },
      );
      audit(req.user.id, "team.created", { teamId: id });
      db.exec("COMMIT");
    } catch (error) {
      db.exec("ROLLBACK");
      throw error;
    }
    res.status(201).json({ team: safeTeam(req.user) });
  });
  app.patch("/api/membership/team", requireAuth, requireOwner, (req, res) => {
    const name = req.body?.name;
    if (typeof name !== "string" || name.trim().length < 2 || name.length > 80)
      return fail(
        res,
        400,
        "Use a workspace name between 2 and 80 characters.",
      );
    db.prepare("UPDATE studio_teams SET name=? WHERE id=?").run(
      name.trim(),
      req.studioTeam.id,
    );
    audit(req.user.id, "team.renamed", { teamId: req.studioTeam.id });
    res.json({ team: safeTeam(req.user) });
  });
  app.post(
    "/api/membership/team/invites",
    requireAuth,
    requireOwner,
    rateLimit("team_invite", 40),
    (req, res) => {
      const team = req.studioTeam;
      if (!teamActive(team))
        return fail(
          res,
          403,
          "Restore an active Studio membership before inviting more teammates.",
        );
      const email =
        typeof req.body?.email === "string"
          ? req.body.email.trim().toLowerCase()
          : "";
      if (!validEmail(email) || isDemoIdentity(email))
        return fail(res, 400, "Invite a real, valid teammate email address.");
      if (email === req.user.email.toLowerCase())
        return fail(res, 400, "The owner already occupies a seat.");
      const existingUser = db
        .prepare("SELECT id FROM users WHERE email=?")
        .get(email);
      if (existingUser && teamRecord(existingUser.id))
        return fail(res, 409, "This email already belongs to a workspace.");
      if (
        db
          .prepare(
            "SELECT id FROM studio_invites WHERE team_id=? AND email=? AND status='pending' AND expires_at>?",
          )
          .get(team.id, email, now())
      )
        return fail(
          res,
          409,
          "A live invitation already exists. Revoke it before sending a replacement.",
        );
      const used = db
        .prepare("SELECT count(*) AS n FROM studio_members WHERE team_id=?")
        .get(team.id).n;
      const pending = db
        .prepare(
          "SELECT count(*) AS n FROM studio_invites WHERE team_id=? AND status='pending' AND expires_at>?",
        )
        .get(team.id, now()).n;
      if (used + pending >= 5)
        return fail(
          res,
          409,
          "All five Studio seats are reserved. Remove a member or pending invitation first.",
        );
      const id = randomUUID();
      const raw = randomBytes(32).toString("hex");
      const expiresAt = new Date(Date.now() + 7 * DAY).toISOString();
      db.prepare("INSERT INTO studio_invites VALUES (?,?,?,?,?,?,?,?)").run(
        id,
        team.id,
        email,
        hash(raw),
        "pending",
        expiresAt,
        now(),
        null,
      );
      audit(req.user.id, "team.invited", { teamId: team.id, email });
      res.status(201).json({
        invite: { id, email, expiresAt },
        inviteUrl: `${publicBaseUrl ? publicBaseUrl.replace(/\/$/, "") : ""}/members?invite=${raw}`,
        message:
          "Copy and privately share this single-use link. No invitation email has been sent automatically.",
      });
    },
  );
  const invitation = (token) =>
    typeof token === "string" && /^[a-f0-9]{64}$/.test(token)
      ? db
          .prepare(
            "SELECT studio_invites.*,studio_teams.name AS team_name,studio_teams.owner_id,users.name AS owner_name FROM studio_invites JOIN studio_teams ON studio_teams.id=studio_invites.team_id JOIN users ON users.id=studio_teams.owner_id WHERE studio_invites.token_hash=?",
          )
          .get(hash(token))
      : null;
  const usableInvite = (req, res) => {
    const invite = invitation(req.params.token);
    if (
      !invite ||
      invite.status !== "pending" ||
      invite.expires_at <= now() ||
      invite.email !== req.user.email.toLowerCase()
    ) {
      fail(
        res,
        404,
        "This invitation is unavailable, expired, or belongs to another email address.",
      );
      return null;
    }
    if (!teamActive({ owner_id: invite.owner_id })) {
      fail(res, 409, "The inviting Studio membership is not active.");
      return null;
    }
    return invite;
  };
  app.get("/api/membership/team/invites/:token", requireAuth, (req, res) => {
    const invite = usableInvite(req, res);
    if (!invite) return;
    res.json({
      invite: {
        email: invite.email,
        teamName: invite.team_name,
        ownerName: invite.owner_name,
        expiresAt: invite.expires_at,
      },
    });
  });
  app.post(
    "/api/membership/team/invites/:token/accept",
    requireAuth,
    (req, res) => {
      const invite = usableInvite(req, res);
      if (!invite) return;
      if (
        production &&
        !db
          .prepare(
            "SELECT 1 FROM account_security WHERE user_id=? AND verified_email=? AND deleted_at IS NULL",
          )
          .get(req.user.id, req.user.email)
      )
        return fail(
          res,
          403,
          "Verify your invited email address before joining a production workspace.",
        );
      if (teamRecord(req.user.id))
        return fail(
          res,
          409,
          "You already belong to a workspace. Leave it before accepting another invitation.",
        );
      if (
        db
          .prepare("SELECT count(*) AS n FROM studio_members WHERE team_id=?")
          .get(invite.team_id).n >= 5
      )
        return fail(
          res,
          409,
          "This workspace is full. Ask its owner to free a seat.",
        );
      db.exec("BEGIN IMMEDIATE");
      try {
        db.prepare("INSERT INTO studio_members VALUES (?,?,?,?)").run(
          req.user.id,
          invite.team_id,
          "member",
          now(),
        );
        db.prepare(
          "UPDATE studio_invites SET status='accepted',accepted_by=? WHERE id=? AND status='pending'",
        ).run(req.user.id, invite.id);
        addEvent(
          req.user.id,
          "team.joined",
          `You joined ${invite.team_name}. Included product access depends on the owner’s active Studio membership.`,
          {
            mode:
              visibleSubscription(
                db
                  .prepare("SELECT * FROM users WHERE id=?")
                  .get(invite.owner_id),
              )?.mode || "demo",
          },
        );
        audit(req.user.id, "team.joined", { teamId: invite.team_id });
        db.exec("COMMIT");
      } catch (error) {
        db.exec("ROLLBACK");
        throw error;
      }
      res.json({ success: true, team: safeTeam(req.user) });
    },
  );
  app.delete(
    "/api/membership/team/invites/:id",
    requireAuth,
    requireOwner,
    (req, res) => {
      const result = db
        .prepare(
          "UPDATE studio_invites SET status='revoked' WHERE id=? AND team_id=? AND status='pending'",
        )
        .run(req.params.id, req.studioTeam.id);
      if (!result.changes)
        return fail(res, 404, "Pending invitation not found.");
      audit(req.user.id, "team.invite_revoked", {
        teamId: req.studioTeam.id,
        inviteId: req.params.id,
      });
      res.json({ success: true });
    },
  );
  app.delete(
    "/api/membership/team/members/:id",
    requireAuth,
    requireOwner,
    (req, res) => {
      if (req.params.id === req.user.id)
        return fail(res, 400, "The workspace owner cannot be removed.");
      const result = db
        .prepare(
          "DELETE FROM studio_members WHERE user_id=? AND team_id=? AND role='member'",
        )
        .run(req.params.id, req.studioTeam.id);
      if (!result.changes) return fail(res, 404, "Teammate not found.");
      audit(req.user.id, "team.member_removed", {
        teamId: req.studioTeam.id,
        memberId: req.params.id,
      });
      res.json({ success: true });
    },
  );
  app.post("/api/membership/team/leave", requireAuth, (req, res) => {
    const team = teamRecord(req.user.id);
    if (!team) return fail(res, 404, "You are not in a workspace.");
    if (team.role === "owner")
      return fail(
        res,
        400,
        "The owner cannot leave. Remove teammates and close the workspace instead.",
      );
    db.prepare("DELETE FROM studio_members WHERE user_id=?").run(req.user.id);
    audit(req.user.id, "team.left", { teamId: team.id });
    res.json({ success: true });
  });
  app.delete("/api/membership/team", requireAuth, requireOwner, (req, res) => {
    db.exec("BEGIN IMMEDIATE");
    try {
      db.prepare(
        "UPDATE studio_invites SET status='revoked' WHERE team_id=? AND status='pending'",
      ).run(req.studioTeam.id);
      db.prepare("DELETE FROM studio_members WHERE team_id=?").run(
        req.studioTeam.id,
      );
      db.prepare("DELETE FROM studio_invites WHERE team_id=?").run(
        req.studioTeam.id,
      );
      db.prepare("DELETE FROM studio_teams WHERE id=?").run(req.studioTeam.id);
      audit(req.user.id, "team.closed", { teamId: req.studioTeam.id });
      db.exec("COMMIT");
    } catch (error) {
      db.exec("ROLLBACK");
      throw error;
    }
    res.json({ success: true });
  });
  app.post("/api/admin/billing/reminders/sweep", requireAdmin, (_req, res) => {
    const before = db
      .prepare("SELECT count(*) AS n FROM membership_reminders")
      .get().n;
    for (const user of db
      .prepare("SELECT * FROM users WHERE subscription IS NOT NULL")
      .all())
      scheduleReminder(user);
    const after = db
      .prepare("SELECT count(*) AS n FROM membership_reminders")
      .get().n;
    res.json({
      success: true,
      created: after - before,
      message:
        "In-app reminders are persistent. External email requires an email provider.",
    });
  });
  app.get("/api/admin/billing-health", requireAdmin, (_req, res) => {
    const users = db
      .prepare("SELECT * FROM users WHERE subscription IS NOT NULL")
      .all();
    let liveMrr = 0;
    let demoMrr = 0;
    let activeLive = 0;
    let activeDemo = 0;
    let activePrepaid = 0;
    let trials = 0;
    let realTrials = 0;
    let demoTrials = 0;
    let canceledLive = 0;
    let pastDueLive = 0;
    let unpricedLive = 0;
    for (const user of users) {
      const s = visibleSubscription(user);
      if (!s) continue;
      if (s.mode === "stripe" && s.status === "canceled") canceledLive++;
      if (
        s.mode === "stripe" &&
        ["past_due", "unpaid", "incomplete"].includes(s.status)
      )
        pastDueLive++;
      if (!activeSubscription(user)) continue;
      if (s.isTrial) {
        trials++;
        if (s.mode === "trial") realTrials++;
        else demoTrials++;
        continue;
      }
      if (s.isPrepaid) {
        activePrepaid++;
        continue;
      }
      const orders = db
        .prepare(
          "SELECT payload FROM orders WHERE user_id=? AND mode=? ORDER BY created_at DESC,rowid DESC",
        )
        .all(user.id, s.mode);
      const receipt = orders
        .map((o) => JSON.parse(o.payload))
        .find(
          (o) =>
            o.plan === s.plan &&
            o.interval === s.interval &&
            o.status === "completed",
        );
      if (s.mode === "stripe") {
        activeLive++;
        if (receipt)
          liveMrr +=
            (Number.isFinite(receipt.subtotal)
              ? receipt.subtotal
              : Math.max(0, receipt.total - (receipt.tax || 0))) /
            (s.interval === "yearly" ? 12 : 1);
        else unpricedLive++;
      } else {
        activeDemo++;
        if (receipt)
          demoMrr +=
            (Number.isFinite(receipt.subtotal)
              ? receipt.subtotal
              : Math.max(0, receipt.total - (receipt.tax || 0))) /
            (s.interval === "yearly" ? 12 : 1);
      }
    }
    res.json({
      liveMrr: Math.round(liveMrr * 100) / 100,
      liveArr: Math.round(liveMrr * 12 * 100) / 100,
      demoMrr: Math.round(demoMrr * 100) / 100,
      activeLiveSubscriptions: activeLive,
      activePrepaidSubscriptions: activePrepaid,
      activeDemoSubscriptions: activeDemo,
      activeTrials: trials,
      activeNoCardTrials: realTrials,
      activeDemoTrials: demoTrials,
      canceledLiveSubscriptions: canceledLive,
      pastDueLiveSubscriptions: pastDueLive,
      unpricedLiveSubscriptions: unpricedLive,
      teams: db.prepare("SELECT count(*) AS n FROM studio_teams").get().n,
      occupiedSeats: db
        .prepare("SELECT count(*) AS n FROM studio_members")
        .get().n,
      pendingInvitations: db
        .prepare(
          "SELECT count(*) AS n FROM studio_invites WHERE status='pending' AND expires_at>?",
        )
        .get(now()).n,
      mrrBasis:
        "Latest verified completed membership receipt per active subscription, excluding tax; yearly receipts divided by 12. Demo receipts are separated. Unpriced live records are excluded rather than estimated.",
      events: db
        .prepare(
          "SELECT membership_events.id,membership_events.type,membership_events.title,membership_events.detail,membership_events.amount,membership_events.mode,membership_events.created_at AS createdAt,users.email FROM membership_events JOIN users ON users.id=membership_events.user_id ORDER BY membership_events.created_at DESC LIMIT 50",
        )
        .all(),
    });
  });

  async function onBillingEvent(event) {
    if (
      !event?.id ||
      !event.type ||
      !event.data?.object ||
      !Object.hasOwn(titleFor, event.type)
    )
      return;
    const payload = event.data.object;
    const subscriptionReference = event.type.startsWith(
      "customer.subscription.",
    )
      ? payload.id
      : payload.subscription ||
        payload.parent?.subscription_details?.subscription;
    const subscriptionId =
      typeof subscriptionReference === "string"
        ? subscriptionReference
        : subscriptionReference?.id;
    if (!subscriptionId) return;
    const user = db
      .prepare(
        "SELECT * FROM users WHERE json_extract(subscription,'$.stripeSubscriptionId')=?",
      )
      .get(subscriptionId);
    if (!user) return;
    let s = subscription(user);
    if (s?.mode !== "stripe") return;
    if (
      db
        .prepare("SELECT id FROM membership_events WHERE provider_event_id=?")
        .get(event.id)
    )
      return;
    // Invoice webhooks may arrive before or without a subscription.updated delivery.
    // Refresh entitlement status from Stripe rather than deriving it from stale invoice state.
    if (event.type.startsWith("invoice.") && ctx.stripe) {
      const live = await ctx.stripe.subscriptions.retrieve(subscriptionId);
      const periodEnd =
        live.items?.data?.[0]?.current_period_end || live.current_period_end;
      if (!live.status || !Number.isFinite(periodEnd))
        throw new Error(
          "Authoritative subscription state is unavailable. Retry this billing event.",
        );
      s = {
        ...s,
        status: live.status,
        cancelAtPeriodEnd: Boolean(live.cancel_at_period_end),
        currentPeriodEnd: new Date(periodEnd * 1000).toISOString(),
      };
    }
    const amount = Number.isFinite(payload.amount_paid)
      ? payload.amount_paid / 100
      : Number.isFinite(payload.amount_due)
        ? payload.amount_due / 100
        : null;
    const isFailure = [
      "invoice.payment_failed",
      "invoice.payment_action_required",
    ].includes(event.type);
    const detail = isFailure
      ? "The payment provider reported a payment problem. Update your payment method securely in Stripe Billing. Access follows the provider’s current subscription status."
      : event.type.startsWith("invoice.")
        ? "The payment provider confirmed this billing event. Qualifying subscription-renewal receipts appear in your order history."
        : "Stripe reported a subscription lifecycle change. Current access follows the latest verified provider billing state.";
    db.exec("BEGIN IMMEDIATE");
    let added;
    try {
      db.prepare("UPDATE users SET subscription=? WHERE id=?").run(
        JSON.stringify(s),
        user.id,
      );
      added = addEvent(user.id, event.type, detail, {
        providerId: event.id,
        amount,
        currency: (payload.currency || "usd").toUpperCase(),
        mode: "stripe",
      });
      if (
        added &&
        ["invoice.paid", "invoice.payment_succeeded"].includes(event.type) &&
        payload.billing_reason === "subscription_cycle" &&
        payload.status === "paid" &&
        Number.isInteger(payload.amount_paid) &&
        payload.amount_paid >= 0 &&
        payload.currency === "usd"
      ) {
        const orderId = `INV-${payload.id}`;
        const taxCents = Array.isArray(payload.total_taxes)
          ? payload.total_taxes.reduce(
              (sum, tax) =>
                sum + (Number.isInteger(tax.amount) ? tax.amount : 0),
              0,
            )
          : Array.isArray(payload.total_tax_amounts)
            ? payload.total_tax_amounts.reduce(
                (sum, tax) =>
                  sum + (Number.isInteger(tax.amount) ? tax.amount : 0),
                0,
              )
            : 0;
        const subtotal = Number.isInteger(payload.total_excluding_tax)
          ? payload.total_excluding_tax / 100
          : Math.max(0, payload.amount_paid - taxCents) / 100;
        const order = {
          id: orderId,
          items: [],
          subtotal,
          tax: taxCents / 100,
          plan: s.plan,
          interval: s.interval,
          total: payload.amount_paid / 100,
          currency: "USD",
          status: "completed",
          mode: "stripe",
          stripeInvoiceId: payload.id,
          stripeSubscriptionId: subscriptionId,
          createdAt: now(),
          seller: ctx.sellerSnapshot(),
        };
        const result = db
          .prepare("INSERT OR IGNORE INTO orders VALUES (?,?,?,?,?,?,?)")
          .run(
            orderId,
            user.id,
            JSON.stringify(order),
            order.total,
            "stripe",
            null,
            now(),
          );
        if (result.changes)
          audit(user.id, "membership.renewal_recorded", {
            invoiceId: payload.id,
            amount: order.total,
          });
      }
      db.exec("COMMIT");
    } catch (error) {
      db.exec("ROLLBACK");
      throw error;
    }
    if (added && isFailure)
      addReminder(
        user,
        "payment_attention",
        payload.id || event.id,
        titleFor[event.type],
        detail,
      );
  }
  return { teamOwns, onBillingEvent, scheduleReminder };
}
