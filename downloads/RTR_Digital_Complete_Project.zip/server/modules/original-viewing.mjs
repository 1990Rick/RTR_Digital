import { openSync, readSync, closeSync, lstatSync } from "node:fs";
import { basename, extname, resolve } from "node:path";

const textExtensions = new Set([".txt", ".md", ".csv", ".json"]);
const unavailable =
  "This format is delivered as a download. Open it with an appropriate application after downloading from your library.";

// Inspect only a small header for binary media. Text is checked in full, bounded
// to 1 MiB; originals are never loaded wholly into memory just to stream them.
function inspectContent(path) {
  const stat = lstatSync(path);
  if (!stat.isFile()) return null;
  const extension = extname(path).toLowerCase();
  const descriptor = openSync(path, "r");
  try {
    const bytes = Buffer.alloc(Math.min(stat.size, 4096));
    const length = readSync(descriptor, bytes, 0, bytes.length, 0);
    const header = bytes.subarray(0, length);
    let type = null;
    if (extension === ".pdf" && header.subarray(0, 5).toString() === "%PDF-")
      type = { kind: "pdf", mime: "application/pdf" };
    if (
      extension === ".mp3" &&
      (header.subarray(0, 3).toString() === "ID3" ||
        (header.length > 2 && header[0] === 255 && (header[1] & 224) === 224))
    )
      type = { kind: "audio", mime: "audio/mpeg" };
    if (
      extension === ".wav" &&
      header.subarray(0, 4).toString() === "RIFF" &&
      header.subarray(8, 12).toString() === "WAVE"
    )
      type = { kind: "audio", mime: "audio/wav" };
    if (extension === ".flac" && header.subarray(0, 4).toString() === "fLaC")
      type = { kind: "audio", mime: "audio/flac" };
    if (extension === ".ogg" && header.subarray(0, 4).toString() === "OggS")
      type = { kind: "audio", mime: "audio/ogg" };
    if (
      [".mp4", ".m4a"].includes(extension) &&
      header.subarray(4, 8).toString() === "ftyp"
    )
      type =
        extension === ".m4a"
          ? { kind: "audio", mime: "audio/mp4" }
          : { kind: "video", mime: "video/mp4" };
    if (
      [".webm", ".weba"].includes(extension) &&
      header.subarray(0, 4).equals(Buffer.from([26, 69, 223, 163]))
    )
      type =
        extension === ".weba"
          ? { kind: "audio", mime: "audio/webm" }
          : { kind: "video", mime: "video/webm" };
    if (textExtensions.has(extension) && stat.size <= 1024 * 1024) {
      const content = Buffer.alloc(stat.size);
      let offset = 0;
      while (offset < content.length) {
        const count = readSync(
          descriptor,
          content,
          offset,
          content.length - offset,
          offset,
        );
        if (count === 0) break;
        offset += count;
      }
      if (offset !== stat.size || content.includes(0)) return null;
      let text;
      try {
        text = new TextDecoder("utf-8", { fatal: true }).decode(content);
      } catch {
        return null;
      }
      if (!/<\/?(?:html|script|iframe|svg|object|embed)\b/i.test(text))
        type = { kind: "text", mime: "text/plain; charset=utf-8" };
    }
    return type ? { ...type, bytes: stat.size, extension } : null;
  } finally {
    closeSync(descriptor);
  }
}

export function registerOriginalViewing(app, ctx) {
  const { db, dataDir, requireAuth, owns, fail, audit } = ctx;
  const resolveOriginal = (id) => {
    const row = db
      .prepare("SELECT id,file_path FROM products WHERE id=?")
      .get(id);
    if (!row?.file_path || typeof row.file_path !== "string") return null;
    const path = resolve(dataDir, "uploads", basename(row.file_path));
    try {
      const content = inspectContent(path);
      return content ? { ...content, path } : null;
    } catch (error) {
      if (["ENOENT", "EISDIR", "EACCES"].includes(error.code)) return null;
      throw error;
    }
  };
  app.get("/api/products/:id/content-info", requireAuth, (req, res) => {
    if (!owns(req.user, req.params.id))
      return fail(
        res,
        403,
        "Product access is required to view the original content.",
      );
    const content = resolveOriginal(req.params.id);
    if (!content) return res.json({ available: false, message: unavailable });
    res.json({
      available: true,
      kind: content.kind,
      mime: content.mime,
      url: `/api/products/${encodeURIComponent(req.params.id)}/content`,
      bytes: content.bytes,
    });
  });
  // Express handles HEAD automatically through this GET handler, and sendFile
  // performs byte-range delivery without reading the complete original file.
  app.get("/api/products/:id/content", requireAuth, (req, res, next) => {
    if (!owns(req.user, req.params.id))
      return fail(
        res,
        403,
        "Product access is required to view the original content.",
      );
    const content = resolveOriginal(req.params.id);
    if (!content) return fail(res, 415, unavailable);
    res.setHeader("Content-Type", content.mime);
    res.setHeader(
      "Content-Disposition",
      `inline; filename="digital-content${content.extension}"`,
    );
    res.setHeader("Cache-Control", "private, no-store");
    res.setHeader("X-Content-Type-Options", "nosniff");
    res.setHeader("X-Frame-Options", "SAMEORIGIN");
    res.setHeader(
      "Content-Security-Policy",
      "default-src 'none'; style-src 'unsafe-inline'; frame-ancestors 'self'; sandbox",
    );
    if (req.method !== "HEAD")
      audit(req.user.id, "product.original_viewed", {
        productId: req.params.id,
        kind: content.kind,
      });
    res.sendFile(
      content.path,
      { cacheControl: false, dotfiles: "deny" },
      (error) => {
        if (error) next(error);
      },
    );
  });
}
