import test from "node:test";
import assert from "node:assert/strict";
import { mkdtempSync, rmSync, truncateSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { createApp } from "./index.mjs";

async function fixture(t) {
  const dataDir = mkdtempSync(join(tmpdir(), "rtr-viewing-"));
  const instance = createApp({ dataDir });
  const server = instance.app.listen(0, "127.0.0.1");
  await new Promise((resolve) => server.once("listening", resolve));
  const base = `http://127.0.0.1:${server.address().port}`;
  t.after(async () => {
    await new Promise((resolve) => server.close(resolve));
    instance.close();
    rmSync(dataDir, { recursive: true, force: true });
  });
  function client() {
    let cookie = "";
    return async (
      path,
      { method = "GET", body, headers = {}, raw = false } = {},
    ) => {
      const response = await fetch(base + path, {
        method,
        headers: {
          ...(cookie ? { Cookie: cookie } : {}),
          ...(body && !(body instanceof FormData)
            ? { "Content-Type": "application/json" }
            : {}),
          ...headers,
        },
        ...(body
          ? { body: body instanceof FormData ? body : JSON.stringify(body) }
          : {}),
      });
      if (response.headers.get("set-cookie"))
        cookie = response.headers.get("set-cookie").split(";")[0];
      const text = await response.text();
      return {
        status: response.status,
        headers: response.headers,
        data: raw || !text ? text : JSON.parse(text),
      };
    };
  }
  const admin = client();
  await admin("/api/auth/demo", { method: "POST", body: { role: "admin" } });
  return { admin, client, db: instance.db, dataDir };
}
async function upload(
  admin,
  content,
  name = "original.txt",
  category = "E-books",
) {
  const body = new FormData();
  for (const [k, v] of Object.entries({
    title: `Protected ${name} product`,
    description:
      "Original licensed material for authenticated original viewing checks.",
    category,
    price: "12.50",
    status: "published",
    subscriptionIncluded: "true",
  }))
    body.set(k, v);
  body.set("file", new Blob([content]), name);
  const result = await admin("/api/admin/products", { method: "POST", body });
  assert.equal(result.status, 201);
  return result.data.product;
}
async function customer(client, email) {
  const user = client();
  assert.equal(
    (
      await user("/api/auth/register", {
        method: "POST",
        body: {
          name: "Original Reader",
          email,
          password: "meaningful-viewing-password",
        },
      })
    ).status,
    201,
  );
  return user;
}
async function buy(user, id) {
  assert.equal(
    (
      await user("/api/checkout", {
        method: "POST",
        body: { productIds: [id], mode: "demo" },
      })
    ).status,
    200,
  );
}

test("full original text is visible only to entitled accounts and stays private with range/HEAD delivery", async (t) => {
  const { admin, client } = await fixture(t);
  const text =
    "Paid original chapter: these complete bytes are not the public preview.";
  const p = await upload(admin, text);
  const guest = client();
  assert.equal((await guest(`/api/products/${p.id}/content-info`)).status, 401);
  assert.equal(
    (await guest(`/api/products/${p.id}/content`, { raw: true })).status,
    401,
  );
  const user = await customer(client, "reader-view@example.test");
  assert.equal((await user(`/api/products/${p.id}/content-info`)).status, 403);
  await buy(user, p.id);
  const info = await user(`/api/products/${p.id}/content-info`);
  assert.equal(info.status, 200);
  assert.equal(info.data.available, true);
  assert.equal(info.data.kind, "text");
  assert.equal(info.data.bytes, Buffer.byteLength(text));
  assert.equal("path" in info.data, false);
  assert.equal(JSON.stringify(info.data).includes("/uploads/"), false);
  const full = await user(info.data.url, { raw: true });
  assert.equal(full.status, 200);
  assert.equal(full.data, text);
  assert.equal(full.headers.get("cache-control"), "private, no-store");
  assert.equal(full.headers.get("x-frame-options"), "SAMEORIGIN");
  assert.equal(full.headers.get("x-content-type-options"), "nosniff");
  assert.match(
    full.headers.get("content-security-policy"),
    /frame-ancestors 'self'; sandbox/,
  );
  const range = await user(info.data.url, {
    headers: { Range: "bytes=0-12" },
    raw: true,
  });
  assert.equal(range.status, 206);
  assert.equal(range.data, text.slice(0, 13));
  assert.match(range.headers.get("content-range"), /^bytes 0-12\//);
  const head = await user(info.data.url, { method: "HEAD", raw: true });
  assert.equal(head.status, 200);
  assert.equal(head.data, "");
  assert.equal(
    Number(head.headers.get("content-length")),
    Buffer.byteLength(text),
  );
  const other = await customer(client, "other-reader@example.test");
  assert.equal((await other(info.data.url, { raw: true })).status, 403);
});

test("original viewing retains purchased draft access and expires subscription-only access", async (t) => {
  const { admin, client, db } = await fixture(t);
  const p = await upload(
    admin,
    "A book you bought remains in your personal library.",
  );
  const user = await customer(client, "purchased-draft@example.test");
  await buy(user, p.id);
  await admin(`/api/publisher/products/${p.id}`, {
    method: "PATCH",
    body: { status: "draft" },
  });
  assert.equal(
    (await user(`/api/products/${p.id}/content`, { raw: true })).status,
    200,
  );
  const subscriber = await customer(client, "sub-viewer@example.test");
  await subscriber("/api/checkout", {
    method: "POST",
    body: { plan: "creator", interval: "monthly", mode: "demo" },
  });
  assert.equal(
    (await subscriber(`/api/products/${p.id}/content-info`)).status,
    403,
  );
  await admin(`/api/publisher/products/${p.id}`, {
    method: "PATCH",
    body: { status: "published" },
  });
  assert.equal(
    (await subscriber(`/api/products/${p.id}/content-info`)).data.available,
    true,
  );
  const row = db
    .prepare("SELECT * FROM users WHERE email=?")
    .get("sub-viewer@example.test");
  const sub = JSON.parse(row.subscription);
  sub.currentPeriodEnd = new Date(Date.now() - 1000).toISOString();
  db.prepare("UPDATE users SET subscription=? WHERE id=?").run(
    JSON.stringify(sub),
    row.id,
  );
  assert.equal(
    (await subscriber(`/api/products/${p.id}/content`, { raw: true })).status,
    403,
  );
  assert.equal(
    (await user(`/api/products/${p.id}/content`, { raw: true })).status,
    200,
  );
});

test("HTML, SVG, executables, invalid signatures and oversized text remain download-only", async (t) => {
  const { admin, client } = await fixture(t);
  const user = await customer(client, "safe-formats@example.test");
  const cases = [
    ["unsafe.html", "<html><script>alert(1)</script></html>"],
    ["unsafe.svg", '<svg xmlns="http://www.w3.org/2000/svg"><script/></svg>'],
    ["software.exe", Buffer.from([77, 90, 1, 2, 3])],
    ["spoof.mp4", "<html>Not a video file</html>"],
    ["hidden.txt", "<script>alert(1)</script>"],
    ["invalid.txt", Buffer.from([255, 254, 128, 0])],
    ["large.txt", "x".repeat(1024 * 1024 + 1)],
  ];
  for (const [name, bytes] of cases) {
    const p = await upload(admin, bytes, name, "Software");
    await buy(user, p.id);
    const info = await user(`/api/products/${p.id}/content-info`);
    assert.equal(info.status, 200);
    assert.equal(info.data.available, false, name);
    assert.equal(info.data.url, undefined);
    assert.equal(
      (await user(`/api/products/${p.id}/content`, { raw: true })).status,
      415,
      name,
    );
    assert.equal(
      (await user(`/api/download/${p.id}`, { raw: true })).status,
      200,
      name,
    );
  }
});

test("validated PDF/audio/video originals stream without reading large files into memory", async (t) => {
  const { admin, client, db, dataDir } = await fixture(t);
  const user = await customer(client, "media-originals@example.test");
  const cases = [
    [
      "document.pdf",
      Buffer.from("%PDF-1.7\nA small document fixture\n%%EOF"),
      "pdf",
      "application/pdf",
    ],
    [
      "sound.wav",
      Buffer.from("RIFF0000WAVEoriginal-audio"),
      "audio",
      "audio/wav",
    ],
    [
      "movie.mp4",
      Buffer.concat([
        Buffer.from([0, 0, 0, 24]),
        Buffer.from("ftypisomoriginal-video"),
      ]),
      "video",
      "video/mp4",
    ],
  ];
  for (const [name, bytes, kind, mime] of cases) {
    const p = await upload(admin, bytes, name, "Video");
    await buy(user, p.id);
    const info = await user(`/api/products/${p.id}/content-info`);
    assert.equal(info.data.kind, kind);
    assert.equal(info.data.mime, mime);
    const range = await user(info.data.url, {
      headers: { Range: "bytes=0-7" },
      raw: true,
    });
    assert.equal(range.status, 206);
    if (name === "movie.mp4") {
      const row = db
        .prepare("SELECT file_path FROM products WHERE id=?")
        .get(p.id);
      truncateSync(join(dataDir, "uploads", row.file_path), 256 * 1024 * 1024);
      const large = await user(`/api/products/${p.id}/content-info`);
      assert.equal(large.data.bytes, 256 * 1024 * 1024);
      assert.equal(
        (
          await user(large.data.url, {
            headers: { Range: "bytes=0-7" },
            raw: true,
          })
        ).status,
        206,
      );
    }
  }
});
