import { existsSync, readFileSync } from "node:fs";
import { resolve } from "node:path";
import { SELLER_NAME } from "./brand.mjs";
const esc = (value) =>
  String(value ?? "").replace(
    /[&<>"']/g,
    (c) =>
      ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[
        c
      ],
  );
export function registerSite(
  app,
  { root, products, product, db, publicBaseUrl, production },
) {
  const canonical =
    publicBaseUrl && /^https:\/\//.test(publicBaseUrl)
      ? publicBaseUrl.replace(/\/$/, "")
      : null;
  app.get("/robots.txt", (_req, res) =>
    res
      .type("text/plain")
      .send(
        `User-agent: *\nAllow: /\nDisallow: /api/\nDisallow: /account\nDisallow: /admin\nDisallow: /publisher\nDisallow: /operations\nDisallow: /members\nDisallow: /billing\nDisallow: /library\n${canonical ? `Sitemap: ${canonical}/sitemap.xml\n` : ""}`,
      ),
  );
  app.get("/sitemap.xml", (_req, res) => {
    if (!canonical)
      return res
        .status(503)
        .type("text/plain")
        .send("Configure an HTTPS PUBLIC_URL before publishing the sitemap.");
    const paths = [
      "/",
      "/explore",
      "/membership",
      "/collections",
      "/about",
      "/support",
      ...products()
        .filter((p) => !p.isSample)
        .map((p) => `/products/${encodeURIComponent(p.id)}`),
    ];
    res
      .type("application/xml")
      .send(
        `<?xml version="1.0" encoding="UTF-8"?><urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">${paths.map((path) => `<url><loc>${esc(canonical + path)}</loc></url>`).join("")}</urlset>`,
      );
  });
  app.get("/products/:id", (req, res, next) => {
    const file = resolve(root, "dist/index.html");
    if (!existsSync(file)) return next();
    const p = product(
      db
        .prepare("SELECT * FROM products WHERE id=? AND status='published'")
        .get(req.params.id),
    );
    if (!p || (production && p.isSample))
      return res
        .status(404)
        .type("text/plain")
        .send("This digital product is not available.");
    const description = p.description.slice(0, 180);
    let html = readFileSync(file, "utf8")
      .replace(
        /<title>[\s\S]*?<\/title>/,
        `<title>${esc(p.title)} — RTR Digital</title>`,
      )
      .replace(
        /<meta\s+name="description"[\s\S]*?\/>/,
        `<meta name="description" content="${esc(description)}"/>`,
      );
    const url = canonical
      ? canonical + `/products/${encodeURIComponent(p.id)}`
      : null;
    const schema = {
      "@context": "https://schema.org",
      "@type": "Product",
      name: p.title,
      description: p.description,
      category: p.category,
      brand: { "@type": "Brand", name: SELLER_NAME },
      offers: {
        "@type": "Offer",
        priceCurrency: "USD",
        price: p.price,
        seller: { "@type": "Organization", name: SELLER_NAME },
        availability: "https://schema.org/InStock",
        ...(url ? { url } : {}),
      },
      additionalProperty: [
        { "@type": "PropertyValue", name: "Digital format", value: p.format },
      ],
    };
    html = html.replace(
      "</head>",
      `${p.isSample ? '<meta name="robots" content="noindex,nofollow"/>' : ""}${url ? `<link rel="canonical" href="${esc(url)}"/>` : ""}<meta property="og:title" content="${esc(p.title)}"/><meta property="og:description" content="${esc(description)}"/><meta property="og:type" content="product"/><script type="application/ld+json">${JSON.stringify(schema).replace(/</g, "\\u003c")}</script></head>`,
    );
    res.type("text/html").send(html);
  });
}
