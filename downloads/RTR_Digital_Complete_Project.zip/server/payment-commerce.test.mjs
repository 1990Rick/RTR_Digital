import test from "node:test";
import assert from "node:assert/strict";
import { DatabaseSync } from "node:sqlite";
import express from "express";
import { registerCommerce } from "./modules/commerce.mjs";

async function fixture(t, { production = true, payments } = {}) {
  const db = new DatabaseSync(":memory:");
  db.exec(`
    CREATE TABLE users (id TEXT PRIMARY KEY, name TEXT, email TEXT, password TEXT, role TEXT, subscription TEXT);
    CREATE TABLE orders (id TEXT PRIMARY KEY, user_id TEXT, payload TEXT, amount REAL, mode TEXT, idempotency_key TEXT, created_at TEXT);
    CREATE TABLE entitlements (user_id TEXT, product_id TEXT, mode TEXT, PRIMARY KEY(user_id,product_id));
    CREATE TABLE audit_log (action TEXT, payload TEXT, created_at TEXT);
  `);
  for (const [id, role] of [
    ["admin", "admin"],
    ["buyer", "customer"],
    ["other", "customer"],
  ])
    db.prepare("INSERT INTO users VALUES (?,?,?,?,?,NULL)").run(
      id,
      id,
      `${id}@payments.test`,
      "administrator-password",
      role,
    );
  const app = express();
  app.use(express.json());
  app.use((req, _res, next) => {
    req.user = db
      .prepare("SELECT * FROM users WHERE id=?")
      .get(req.get("x-test-user") || "buyer");
    next();
  });
  const fail = (res, status, message) => res.status(status).json({ message });
  const subscription = (user) =>
    user?.subscription ? JSON.parse(user.subscription) : null;
  const ctx = {
    db,
    production,
    demoMode: !production,
    requireAuth: (req, res, next) =>
      req.user ? next() : fail(res, 401, "Sign in."),
    requireAdmin: (req, res, next) =>
      req.user?.role === "admin"
        ? next()
        : fail(res, 403, "Administrator required."),
    fail,
    audit: (_id, action, payload = {}) =>
      db
        .prepare("INSERT INTO audit_log VALUES (?,?,?)")
        .run(action, JSON.stringify(payload), new Date().toISOString()),
    subscription,
    activeSubscription: (user) => subscription(user)?.status === "active",
    plans: { creator: { name: "Creator", monthly: 19, yearly: 190 } },
    verifyPassword: (password, stored) => password === stored,
    now: () => new Date().toISOString(),
  };
  const commerce = registerCommerce(app, ctx);
  // Payment registration occurs after commerce registration in the application.
  ctx.payments = payments;
  const server = app.listen(0, "127.0.0.1");
  await new Promise((resolve) => server.once("listening", resolve));
  t.after(async () => {
    await new Promise((resolve) => server.close(resolve));
    db.close();
  });
  const request = async (
    path,
    { user = "buyer", method = "GET", body, raw = false } = {},
  ) => {
    const response = await fetch(
      `http://127.0.0.1:${server.address().port}${path}`,
      {
        method,
        headers: {
          "x-test-user": user,
          ...(body ? { "content-type": "application/json" } : {}),
        },
        ...(body ? { body: JSON.stringify(body) } : {}),
      },
    );
    return {
      status: response.status,
      headers: response.headers,
      data: raw ? await response.text() : await response.json(),
    };
  };
  const seedOrder = (
    id,
    mode,
    { amount = 39, status = "completed", userId = "buyer", ...extra } = {},
  ) => {
    const createdAt = new Date().toISOString();
    const order = {
      id,
      mode,
      status,
      total: amount,
      items: [{ id: "kit", title: "Original kit", price: amount }],
      createdAt,
      ...extra,
    };
    db.prepare("INSERT INTO orders VALUES (?,?,?,?,?,?,?)").run(
      id,
      userId,
      JSON.stringify(order),
      amount,
      mode,
      null,
      createdAt,
    );
    for (const item of order.items)
      db.prepare(
        "INSERT INTO entitlements VALUES (?,?,?) ON CONFLICT(user_id,product_id) DO UPDATE SET mode=excluded.mode",
      ).run(userId, item.id, mode);
    return order;
  };
  const requestRefund = async (orderId) => {
    const response = await request(`/api/billing/orders/${orderId}/refunds`, {
      method: "POST",
      body: { reason: "Please refund this original purchase." },
    });
    assert.equal(response.status, 201, JSON.stringify(response.data));
    return response.data.refund.id;
  };
  const approve = (refundId, body = {}) =>
    request(`/api/admin/commerce/refunds/${refundId}/approve`, {
      user: "admin",
      method: "POST",
      body,
    });
  const order = (id) =>
    JSON.parse(
      db.prepare("SELECT payload FROM orders WHERE id=?").get(id).payload,
    );
  const entitlement = () =>
    db
      .prepare(
        "SELECT * FROM entitlements WHERE user_id='buyer' AND product_id='kit'",
      )
      .get();
  return {
    db,
    ctx,
    commerce,
    request,
    seedOrder,
    requestRefund,
    approve,
    order,
    entitlement,
  };
}

test("production receipts and order lists include every paid mode and keep customer orders private", async (t) => {
  const f = await fixture(t);
  for (const mode of [
    "stripe",
    "paypal",
    "razorpay",
    "wire",
    "demo",
    "trial",
    "unknown",
  ])
    f.seedOrder(`order_${mode}`, mode);
  const list = await f.request("/api/billing/orders");
  assert.deepEqual(list.data.orders.map((o) => o.mode).sort(), [
    "paypal",
    "razorpay",
    "stripe",
    "wire",
  ]);
  for (const mode of ["stripe", "paypal", "razorpay", "wire"]) {
    const path = `/api/billing/orders/order_${mode}/receipt`;
    const receipt = await f.request(path, { raw: true });
    assert.equal(receipt.status, 200);
    assert.match(receipt.data, /Payment receipt/);
    assert.doesNotMatch(receipt.data, /DEMONSTRATION/);
    assert.equal(receipt.headers.get("cache-control"), "private, no-store");
    assert.equal(
      (await f.request(path, { user: "other", raw: true })).status,
      404,
    );
    assert.equal(
      (
        await f.request(`/api/billing/orders/order_${mode}/refunds`, {
          user: "other",
          method: "POST",
          body: { reason: "A different customer cannot refund this." },
        })
      ).status,
      404,
    );
  }
  for (const mode of ["demo", "trial", "unknown"])
    assert.equal(
      (
        await f.request(`/api/billing/orders/order_${mode}/receipt`, {
          raw: true,
        })
      ).status,
      404,
    );
});

test("finance counts paid receipts while prepaid memberships and non-demo modes cannot inflate MRR or demo revenue", async (t) => {
  const f = await fixture(t);
  for (const [mode, amount, status] of [
    ["stripe", 10, "completed"],
    ["paypal", 20, "completed"],
    ["razorpay", 30, "refunded"],
    ["wire", 40, "completed"],
    ["demo", 7, "completed"],
    ["trial", 8, "completed"],
    ["unknown", 9, "completed"],
  ])
    f.seedOrder(`cash_${mode}`, mode, { amount, status });
  for (const [id, mode, amount, isPrepaid] of [
    ["monthly", "stripe", 19, false],
    ["annual", "stripe", 240, false],
    ["prepaid", "stripe", 100, true],
    ["paypal", "paypal", 120, true],
    ["bank", "wire", 240, true],
  ]) {
    dbMember(f.db, id, { mode, status: "active", isPrepaid });
    f.seedOrder(`member_${id}`, mode, {
      userId: id,
      amount,
      items: [],
      plan: "creator",
      interval: id === "annual" ? "yearly" : "monthly",
      isPrepaid,
    });
  }
  const finance = f.commerce.financials();
  assert.equal(finance.grossRevenue, 819);
  assert.equal(finance.refundedRevenue, 30);
  assert.equal(finance.netRevenue, 789);
  assert.equal(finance.demoTotal, 7);
  assert.equal(finance.liveMrr, 39);
  assert.equal(finance.liveArr, 468);
  assert.equal(finance.activeLiveMembers, 5);
  assert.equal(finance.activeDemoMembers, 0);
});

function dbMember(db, id, subscription) {
  db.prepare("INSERT INTO users VALUES (?,?,?,?,?,?)").run(
    id,
    id,
    `${id}@payments.test`,
    "password",
    "customer",
    JSON.stringify(subscription),
  );
}

for (const mode of ["paypal", "razorpay"]) {
  test(`${mode} refund retries preserve provider identity and access until confirmation`, async (t) => {
    let confirmed = false;
    const calls = [];
    const f = await fixture(t, {
      payments: {
        refund: async (order, idempotencyKey) => {
          calls.push({ order, idempotencyKey });
          return confirmed
            ? { success: true, providerRefundId: `${mode}_refund` }
            : {
                pending: true,
                providerRefundId: `${mode}_refund`,
                message: "Provider confirmation pending.",
              };
        },
      },
    });
    f.seedOrder("external_order", mode);
    const refundId = await f.requestRefund("external_order");
    for (let retry = 0; retry < 2; retry++) {
      const response = await f.approve(refundId);
      assert.equal(response.status, 200);
      assert.equal(response.data.pending, true);
      assert.equal(f.order("external_order").status, "completed");
      assert.ok(f.entitlement());
      const saved = f.db
        .prepare("SELECT * FROM commerce_refunds WHERE id=?")
        .get(refundId);
      assert.equal(saved.status, "processing");
      assert.equal(saved.provider_refund_id, `${mode}_refund`);
    }
    confirmed = true;
    assert.equal((await f.approve(refundId)).data.success, true);
    assert.equal(f.order("external_order").status, "refunded");
    assert.equal(f.entitlement(), undefined);
    assert.equal(calls.length, 3);
    assert.ok(
      calls.every(
        ({ order, idempotencyKey }) =>
          order.id === "external_order" &&
          order.userId === "buyer" &&
          idempotencyKey === `rtr-refund-${refundId}`,
      ),
    );
    assert.equal((await f.approve(refundId)).data.alreadyProcessed, true);
    assert.equal(calls.length, 3);
  });
}

test("an unavailable or unconfirmed external provider never falls through to a demo refund", async (t) => {
  const f = await fixture(t);
  f.seedOrder("unavailable", "paypal");
  const refundId = await f.requestRefund("unavailable");
  assert.equal((await f.approve(refundId)).status, 503);
  f.ctx.payments = { refund: async () => ({ success: false }) };
  assert.equal((await f.approve(refundId)).status, 502);
  assert.equal(f.order("unavailable").status, "completed");
  assert.ok(f.entitlement());
  assert.equal(
    f.db.prepare("SELECT status FROM commerce_refunds WHERE id=?").get(refundId)
      .status,
    "requested",
  );
});

test("sandbox gateway refunds still require provider confirmation while their receipts remain excluded from live revenue", async (t) => {
  let calls = 0;
  const f = await fixture(t, {
    production: false,
    payments: {
      refund: async () => {
        calls++;
        return { pending: true, providerRefundId: "sandbox_refund" };
      },
    },
  });
  f.seedOrder("sandbox_order", "demo", {
    paymentProvider: "paypal",
    paymentEnvironment: "sandbox",
  });
  const refundId = await f.requestRefund("sandbox_order");
  assert.equal((await f.approve(refundId)).data.pending, true);
  assert.equal(calls, 1);
  assert.equal(f.order("sandbox_order").status, "completed");
  assert.ok(f.entitlement());
  assert.equal(f.commerce.financials().grossRevenue, 0);
});

test("wire refunds require a password and explicit exact external repayment before recording a unique bank receipt", async (t) => {
  const f = await fixture(t);
  f.seedOrder("wire_order", "wire");
  const refundId = await f.requestRefund("wire_order");
  const confirmation = {
    password: "administrator-password",
    bankReference: "bank-refund-2026-42",
    refundedAmount: "39.00",
    currency: "USD",
    bankRefundConfirmed: true,
  };
  assert.equal((await f.approve(refundId)).status, 403);
  for (const [change, status] of [
    [{ password: "wrong" }, 403],
    [{ bankRefundConfirmed: false }, 400],
    [{ refundedAmount: "38.99" }, 400],
    [{ refundedAmount: "39.0001" }, 400],
    [{ currency: "INR" }, 400],
    [{ bankReference: "" }, 400],
  ]) {
    assert.equal(
      (await f.approve(refundId, { ...confirmation, ...change })).status,
      status,
    );
    assert.equal(f.order("wire_order").status, "completed");
    assert.ok(f.entitlement());
    assert.equal(
      f.db
        .prepare("SELECT status FROM commerce_refunds WHERE id=?")
        .get(refundId).status,
      "requested",
    );
  }
  assert.equal((await f.approve(refundId, confirmation)).data.success, true);
  assert.equal(f.order("wire_order").status, "refunded");
  assert.equal(f.order("wire_order").total, 39);
  assert.equal(f.entitlement(), undefined);
  const recorded = f.db
    .prepare("SELECT * FROM commerce_wire_refunds WHERE refund_id=?")
    .get(refundId);
  assert.equal(recorded.bank_reference, "BANK-REFUND-2026-42");
  assert.equal(recorded.amount_cents, 3900);
  assert.equal(recorded.currency, "USD");
  assert.equal(recorded.admin_id, "admin");
  const event = f.db
    .prepare(
      "SELECT payload FROM commerce_events WHERE type='wire.refund_confirmed'",
    )
    .get();
  assert.equal(
    JSON.parse(event.payload).bankReference,
    recorded.bank_reference,
  );
  const receipt = await f.request("/api/billing/orders/wire_order/receipt", {
    raw: true,
  });
  assert.equal(receipt.status, 200);
  assert.match(receipt.data, /refunded/);
  assert.match(receipt.data, /Total \$39\.00 USD/);
  assert.doesNotMatch(receipt.data, /DEMONSTRATION/);
  assert.equal((await f.approve(refundId)).data.alreadyProcessed, true);
  f.seedOrder("wire_order_two", "wire");
  const second = await f.requestRefund("wire_order_two");
  assert.equal(
    (
      await f.approve(second, {
        ...confirmation,
        bankReference: "bank-refund-2026-42",
      })
    ).status,
    409,
  );
  assert.equal(f.order("wire_order_two").status, "completed");
  assert.ok(f.entitlement());
});

test("refunding a wire receipt preserves an independent paid purchase in production", async (t) => {
  const f = await fixture(t);
  f.seedOrder("bank_original", "wire");
  f.seedOrder("independent_purchase", "paypal");
  const refundId = await f.requestRefund("bank_original");
  const result = await f.approve(refundId, {
    password: "administrator-password",
    bankReference: "independent-bank-refund",
    refundedAmount: 39,
    currency: "USD",
    bankRefundConfirmed: true,
  });
  assert.equal(result.data.success, true);
  assert.equal(f.entitlement().mode, "paypal");
});

test("development wire simulations use explicit manual confirmation and only the shared development admin bypasses the password", async (t) => {
  const f = await fixture(t, { production: false });
  f.db
    .prepare("UPDATE users SET email='demo-admin@rtr.example' WHERE id='admin'")
    .run();
  f.seedOrder("development_bank", "demo", {
    paymentProvider: "wire",
    paymentEnvironment: "development",
  });
  const refundId = await f.requestRefund("development_bank");
  assert.equal((await f.approve(refundId)).status, 400);
  assert.ok(f.entitlement());
  const overview = await f.request("/api/admin/commerce", { user: "admin" });
  assert.equal(overview.data.refunds[0].mode, "demo");
  assert.equal(overview.data.refunds[0].paymentProvider, "wire");
  assert.equal(
    (
      await f.approve(refundId, {
        bankReference: "development-bank-refund",
        refundedAmount: 39,
        currency: "USD",
        bankRefundConfirmed: true,
      })
    ).data.success,
    true,
  );
  assert.equal(f.entitlement(), undefined);
  assert.equal(f.commerce.financials().grossRevenue, 0);
});

test("only the server wire reservation helper can extend a promotion hold beyond one hour, up to seven days", async (t) => {
  const f = await fixture(t);
  const expiresAt = Date.now() + 7 * 86400000 - 1000;
  assert.throws(
    () =>
      f.commerce.reservePromotion("buyer", "ordinary", "WELCOME10", expiresAt),
    /expiry is invalid/,
  );
  f.commerce.reserveWirePromotion(
    "buyer",
    "bank_intent",
    "WELCOME10",
    expiresAt,
  );
  f.commerce.reserveWirePromotion(
    "buyer",
    "bank_intent",
    "WELCOME10",
    expiresAt,
  );
  assert.equal(
    f.db
      .prepare(
        "SELECT expires_at FROM commerce_reservations WHERE intent_id='bank_intent'",
      )
      .get().expires_at,
    expiresAt,
  );
  assert.throws(
    () =>
      f.commerce.reserveWirePromotion(
        "buyer",
        "too_long",
        "WELCOME10",
        Date.now() + 8 * 86400000,
      ),
    /expiry is invalid/,
  );
});
