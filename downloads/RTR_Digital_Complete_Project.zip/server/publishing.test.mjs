import test from "node:test";
import assert from "node:assert/strict";
import { createHash } from "node:crypto";
import { mkdtempSync, rmSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { createApp } from "./index.mjs";
async function fixture(t) {
  const dataDir = mkdtempSync(join(tmpdir(), "rtr-publishing-"));
  const instance = createApp({ dataDir });
  const server = instance.app.listen(0, "127.0.0.1");
  await new Promise((r) => server.once("listening", r));
  const base = `http://127.0.0.1:${server.address().port}`;
  t.after(async () => {
    await new Promise((r) => server.close(r));
    instance.close();
    rmSync(dataDir, { recursive: true, force: true });
  });
  const client = () => {
    let cookie = "";
    return async (path, method = "GET", body, raw = false) => {
      const response = await fetch(base + path, {
        method,
        headers: {
          ...(cookie ? { Cookie: cookie } : {}),
          ...(body && !(body instanceof FormData)
            ? { "Content-Type": "application/json" }
            : {}),
        },
        ...(body
          ? { body: body instanceof FormData ? body : JSON.stringify(body) }
          : {}),
      });
      if (response.headers.get("set-cookie"))
        cookie = response.headers.get("set-cookie").split(";")[0];
      return {
        status: response.status,
        data: raw ? await response.text() : await response.json(),
        headers: response.headers,
      };
    };
  };
  const admin = client();
  await admin("/api/auth/demo", "POST", { role: "admin" });
  return { admin, client, db: instance.db, base };
}
async function original(admin, title = "Original creative notes") {
  const form = new FormData();
  for (const [k, v] of Object.entries({
    title,
    description:
      "Original licensed digital content for meaningful publishing verification.",
    category: "E-books",
    price: "12.50",
    status: "published",
  }))
    form.set(k, v);
  form.set(
    "file",
    new Blob(["original bytes"], { type: "text/plain" }),
    "original.txt",
  );
  const r = await admin("/api/admin/products", "POST", form);
  assert.equal(r.status, 201);
  return r.data.product;
}
async function buyer(client, email) {
  const user = client();
  const r = await user("/api/auth/register", "POST", {
    name: "Verified Reader",
    email,
    password: "meaningful-password-2026",
  });
  assert.equal(r.status, 201);
  return user;
}

test("publisher metadata, transactional imports and scheduled visibility work", async (t) => {
  const { admin, client, db } = await fixture(t);
  const p = await original(admin);
  assert.equal((await client()(`/api/publisher/products/${p.id}`)).status, 401);
  const update = await admin(`/api/publisher/products/${p.id}`, "PATCH", {
    title: "Updated original notes",
    price: 17.25,
    tags: ["Original", "Writer"],
    featured: true,
  });
  assert.equal(update.status, 200);
  assert.equal(update.data.product.price, 17.25);
  assert.equal(
    (
      await admin("/api/publisher/import", "POST", {
        products: [
          { id: p.id, price: 99 },
          { id: "missing", price: 25 },
        ],
      })
    ).status,
    400,
  );
  assert.equal(
    (await admin(`/api/publisher/products/${p.id}`)).data.product.price,
    17.25,
  );
  assert.equal(
    (
      await admin("/api/publisher/import", "POST", {
        products: [{ id: p.id, price: 19.95 }],
      })
    ).data.updated,
    1,
  );
  assert.equal(
    (
      await admin(`/api/publisher/products/${p.id}`, "PATCH", {
        scheduledAt: new Date(Date.now() + 60000).toISOString(),
      })
    ).status,
    200,
  );
  assert.equal((await client()(`/api/products/${p.id}`)).status, 404);
  db.prepare(
    "UPDATE product_schedules SET publish_at=? WHERE product_id=?",
  ).run(new Date(Date.now() - 1000).toISOString(), p.id);
  assert.equal((await client()(`/api/products/${p.id}`)).status, 200);
});

test("versioned release preserves original file, verifies checksum and delivers latest bytes only to owners", async (t) => {
  const { admin, client, db } = await fixture(t);
  const p = await original(admin);
  const user = await buyer(client, "versions@example.test");
  await user("/api/checkout", "POST", { productIds: [p.id], mode: "demo" });
  const form = new FormData();
  const contents =
    "Version two: exact original bytes, ready for authenticated delivery.";
  form.set(
    "file",
    new Blob([contents], { type: "text/plain" }),
    "release-two.txt",
  );
  form.set("version", "2.0.0");
  form.set("changelog", "A thoughtful second edition.");
  const release = await admin(
    `/api/publisher/products/${p.id}/releases`,
    "POST",
    form,
  );
  assert.equal(release.status, 201);
  assert.equal(
    release.data.version.checksum,
    createHash("sha256").update(contents).digest("hex"),
  );
  const details = (await admin(`/api/publisher/products/${p.id}`)).data;
  assert.equal(details.versions.length, 2);
  assert.equal(details.versions[0].version, "2.0.0");
  assert.equal(
    db
      .prepare("SELECT count(*) AS n FROM product_versions WHERE product_id=?")
      .get(p.id).n,
    2,
  );
  assert.equal(
    (await client()(`/api/download/${p.id}`, "GET", undefined, true)).status,
    401,
  );
  assert.equal(
    (await user(`/api/download/${p.id}`, "GET", undefined, true)).data,
    contents,
  );
  assert.equal(
    (await user("/api/library/releases")).data.notifications[0].version,
    "2.0.0",
  );
});

test("previews validate original bytes and public visibility while learning progress stays private", async (t) => {
  const { admin, client, base } = await fixture(t);
  const p = await original(admin);
  const invalid = new FormData();
  invalid.set(
    "file",
    new Blob(["<script>alert(1)</script>"], { type: "audio/mpeg" }),
    "fake.mp3",
  );
  assert.equal(
    (await admin(`/api/publisher/products/${p.id}/preview`, "POST", invalid))
      .status,
    400,
  );
  const preview = new FormData();
  preview.set(
    "file",
    new Blob(["A genuine sample chapter."], { type: "text/plain" }),
    "chapter.txt",
  );
  assert.equal(
    (await admin(`/api/publisher/products/${p.id}/preview`, "POST", preview))
      .status,
    201,
  );
  const guest = client();
  assert.equal(
    (await guest(`/api/products/${p.id}/preview`, "GET", undefined, true)).data,
    "A genuine sample chapter.",
  );
  const range = await fetch(`${base}/api/products/${p.id}/preview`, {
    headers: { Range: "bytes=0-4" },
  });
  assert.equal(range.status, 206);
  assert.equal(await range.text(), "A gen");
  const user = await buyer(client, "progress@example.test");
  assert.equal((await user(`/api/products/${p.id}/progress`)).status, 403);
  await user("/api/checkout", "POST", { productIds: [p.id], mode: "demo" });
  assert.equal(
    (
      await user(`/api/products/${p.id}/progress`, "PUT", {
        position: 25,
        total: 100,
        completed: false,
        note: "Return to chapter two.",
      })
    ).status,
    200,
  );
  assert.equal(
    (await user(`/api/products/${p.id}/progress`)).data.progress.note,
    "Return to chapter two.",
  );
  await admin(`/api/publisher/products/${p.id}`, "PATCH", { status: "draft" });
  assert.equal(
    (await guest(`/api/products/${p.id}/preview`, "GET", undefined, true))
      .status,
    404,
  );
  assert.equal(
    (await user(`/api/products/${p.id}/preview`, "GET", undefined, true))
      .status,
    200,
  );
});

test("license inventory is encrypted and unique claims are access checked and idempotent", async (t) => {
  const { admin, client, db } = await fixture(t);
  const p = await original(admin);
  const first = await buyer(client, "license-one@example.test");
  assert.equal(
    (await first(`/api/products/${p.id}/license`, "POST")).status,
    403,
  );
  const imported = await admin(
    `/api/publisher/products/${p.id}/licenses`,
    "POST",
    { keys: "RTR-UNIQUE-ONE\nRTR-UNIQUE-TWO\nRTR-UNIQUE-ONE" },
  );
  assert.equal(imported.status, 200);
  assert.equal(imported.data.imported, 2);
  const stored = db
    .prepare("SELECT encrypted FROM product_license_keys")
    .get().encrypted;
  assert.equal(stored.includes("RTR-UNIQUE"), false);
  await first("/api/checkout", "POST", { productIds: [p.id], mode: "demo" });
  const claimed = await first(`/api/products/${p.id}/license`, "POST");
  assert.equal(claimed.status, 200);
  assert.equal(claimed.data.seller, "RTR Digital");
  assert.equal(claimed.data.licensor, "RTR Digital");
  assert.equal(
    (await first(`/api/products/${p.id}/license`, "POST")).data.key,
    claimed.data.key,
  );
  const second = await buyer(client, "license-two@example.test");
  await second("/api/checkout", "POST", { productIds: [p.id], mode: "demo" });
  const next = await second(`/api/products/${p.id}/license`, "POST");
  assert.notEqual(next.data.key, claimed.data.key);
  assert.equal(
    (await admin(`/api/publisher/products/${p.id}`)).data.licenses.available,
    0,
  );
  const third = await buyer(client, "license-three@example.test");
  await third("/api/checkout", "POST", { productIds: [p.id], mode: "demo" });
  assert.equal(
    (await third(`/api/products/${p.id}/license`, "POST")).status,
    409,
  );
});

test("review reports and staff moderation preserve records while hiding public content", async (t) => {
  const { admin, client } = await fixture(t);
  const user = await buyer(client, "reviewer-extra@example.test");
  await user("/api/checkout", "POST", {
    productIds: ["studio-brand-kit"],
    mode: "demo",
  });
  await user("/api/reviews/studio-brand-kit", "POST", {
    rating: 5,
    body: "A thoughtful original review for moderation testing.",
  });
  const list = (await user("/api/reviews/studio-brand-kit")).data.reviews;
  const id = list[0].id;
  assert.equal(
    (
      await user(`/api/reviews/${id}/report`, "POST", {
        reason: "Please review this report for moderation.",
      })
    ).status,
    200,
  );
  assert.equal(
    (await user(`/api/publisher/reviews/${id}`, "PATCH", { hidden: true }))
      .status,
    403,
  );
  assert.equal(
    (
      await admin(`/api/publisher/reviews/${id}`, "PATCH", {
        hidden: true,
        reason: "Moderation review in progress.",
      })
    ).status,
    200,
  );
  assert.equal(
    (await user("/api/reviews/studio-brand-kit")).data.reviews.length,
    0,
  );
  assert.equal(
    (await admin("/api/publisher/reviews")).data.reviews[0].hidden,
    true,
  );
});

test("release archives enforce product ownership and retain downloadable originals", async (t) => {
  const { admin, client } = await fixture(t);
  const p = await original(admin, "Archive release notes");
  const user = await buyer(client, "archive@example.test");
  await user("/api/checkout", "POST", { productIds: [p.id], mode: "demo" });
  const form = new FormData();
  form.set("file", new Blob(["new edition"]), "edition.txt");
  form.set("version", "original");
  form.set(
    "changelog",
    "A user supplied release label matching the reserved original label.",
  );
  const release = await admin(
    `/api/publisher/products/${p.id}/releases`,
    "POST",
    form,
  );
  assert.equal(release.status, 201);
  const history = (await admin(`/api/publisher/products/${p.id}`)).data
    .versions;
  assert.equal(history.length, 2);
  assert.equal(new Set(history.map((v) => v.version)).size, 2);
  const originalVersion = history.find((v) => v.version !== "original");
  const originalDownload = await user(
    `/api/products/${p.id}/releases/${originalVersion.id}/download`,
    "GET",
    undefined,
    true,
  );
  assert.equal(originalDownload.status, 200);
  assert.equal(originalDownload.data, "original bytes");
  assert.equal(
    originalDownload.headers.get("x-content-sha256"),
    createHash("sha256").update("original bytes").digest("hex"),
  );
  const other = await original(admin, "Another archive product");
  assert.equal(
    (
      await user(
        `/api/products/${other.id}/releases/${originalVersion.id}/download`,
        "GET",
        undefined,
        true,
      )
    ).status,
    403,
  );
  assert.equal(
    (
      await client()(
        `/api/products/${p.id}/releases/${originalVersion.id}/download`,
        "GET",
        undefined,
        true,
      )
    ).status,
    401,
  );
});

test("explicit draft changes cancel schedules and draft releases do not notify unrelated subscribers", async (t) => {
  const { admin, client, db } = await fixture(t);
  const p = await original(admin, "Scheduled creative edition");
  const subscriber = await buyer(client, "scheduled-reader@example.test");
  await subscriber("/api/checkout", "POST", {
    plan: "creator",
    interval: "monthly",
    mode: "demo",
  });
  assert.equal(
    (
      await admin(`/api/publisher/products/${p.id}`, "PATCH", {
        scheduledAt: [],
      })
    ).status,
    400,
  );
  await admin(`/api/publisher/products/${p.id}`, "PATCH", {
    scheduledAt: new Date(Date.now() + 60000).toISOString(),
  });
  assert.ok(
    db.prepare("SELECT 1 FROM product_schedules WHERE product_id=?").get(p.id),
  );
  await admin(`/api/publisher/products/${p.id}`, "PATCH", { status: "draft" });
  assert.equal(
    db.prepare("SELECT 1 FROM product_schedules WHERE product_id=?").get(p.id),
    undefined,
  );
  await admin(`/api/publisher/products/${p.id}`, "PATCH", {
    scheduledAt: new Date(Date.now() + 60000).toISOString(),
  });
  await admin("/api/publisher/import", "POST", {
    products: [{ id: p.id, status: "draft" }],
  });
  assert.equal(
    db.prepare("SELECT 1 FROM product_schedules WHERE product_id=?").get(p.id),
    undefined,
  );
  const file = new FormData();
  file.set("file", new Blob(["private draft edition"]), "draft.txt");
  file.set("version", "draft-2");
  file.set("changelog", "A private draft release.");
  assert.equal(
    (await admin(`/api/publisher/products/${p.id}/releases`, "POST", file))
      .status,
    201,
  );
  assert.equal(
    (await subscriber("/api/library/releases")).data.notifications.some(
      (n) => n.productId === p.id,
    ),
    false,
  );
});

test("PDF previews allow same-origin embedding and review reports can be resolved only by staff", async (t) => {
  const { admin, client } = await fixture(t);
  const p = await original(admin, "Public PDF chapter");
  const pdf = new FormData();
  pdf.set(
    "file",
    new Blob(["%PDF-1.7\n1 0 obj\n<< /Type /Catalog >>\nendobj\n%%EOF"], {
      type: "application/pdf",
    }),
    "sample.pdf",
  );
  assert.equal(
    (await admin(`/api/publisher/products/${p.id}/preview`, "POST", pdf))
      .status,
    201,
  );
  const publicPreview = await client()(
    `/api/products/${p.id}/preview`,
    "GET",
    undefined,
    true,
  );
  assert.equal(publicPreview.status, 200);
  assert.equal(publicPreview.headers.get("x-frame-options"), "SAMEORIGIN");
  assert.match(
    publicPreview.headers.get("content-security-policy"),
    /frame-ancestors 'self'/,
  );
  const user = await buyer(client, "report-resolve@example.test");
  await user("/api/checkout", "POST", { productIds: [p.id], mode: "demo" });
  await user(`/api/reviews/${p.id}`, "POST", {
    rating: 4,
    body: "A detailed review to exercise report resolution.",
  });
  const review = (await user(`/api/reviews/${p.id}`)).data.reviews[0];
  await user(`/api/reviews/${review.id}/report`, "POST", {
    reason: "Please evaluate this genuine review report.",
  });
  const report = (await admin("/api/publisher/reviews")).data.reports[0];
  assert.equal(
    (
      await user(`/api/publisher/reports/${report.id}`, "PATCH", {
        status: "resolved",
      })
    ).status,
    403,
  );
  assert.equal(
    (
      await admin(`/api/publisher/reports/${report.id}`, "PATCH", {
        status: "resolved",
      })
    ).status,
    200,
  );
  assert.equal(
    (await admin("/api/publisher/reviews")).data.reports[0].status,
    "resolved",
  );
});
