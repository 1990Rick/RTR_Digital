import test from "node:test";
import assert from "node:assert/strict";
import { mkdtempSync, rmSync, statSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { createApp } from "./index.mjs";
import { totpCode } from "./modules/identity.mjs";

const originalPassword = "a-unique-test-password";
async function fixture(t, options = {}) {
  const dataDir = mkdtempSync(join(tmpdir(), "rtr-identity-"));
  const fixture = createApp({ dataDir, ...options });
  const server = fixture.app.listen(0, "127.0.0.1");
  await new Promise((resolve) => server.once("listening", resolve));
  const base = `http://127.0.0.1:${server.address().port}`;
  t.after(async () => {
    await new Promise((resolve) => server.close(resolve));
    fixture.close();
    rmSync(dataDir, { recursive: true, force: true });
  });
  const client = () => {
    let cookie = "";
    const request = async (
      path,
      { method = "GET", body, headers = {}, raw = false } = {},
    ) => {
      const response = await fetch(`${base}${path}`, {
        method,
        headers: {
          ...(cookie ? { Cookie: cookie } : {}),
          ...(body ? { "Content-Type": "application/json" } : {}),
          ...headers,
        },
        ...(body ? { body: JSON.stringify(body) } : {}),
      });
      if (response.headers.get("set-cookie"))
        cookie = response.headers.get("set-cookie").split(";")[0];
      return {
        status: response.status,
        data: raw ? await response.text() : await response.json(),
        headers: response.headers,
      };
    };
    return { request };
  };
  const register = async (
    client,
    email = "identity@example.test",
    name = "Identity Creative",
  ) =>
    client.request("/api/auth/register", {
      method: "POST",
      body: { email, name, password: originalPassword },
    });
  return { ...fixture, client, register, dataDir };
}
const post = (body) => ({ method: "POST", body });
const patch = (body) => ({ method: "PATCH", body });
function actionToken(body) {
  return new URL(body.match(/https?:\/\/\S+/)[0]).searchParams.get("token");
}

async function latestMail(client) {
  const settings = (await client.request("/api/account/settings")).data;
  const mail = await client.request(
    `/api/account/mail/${settings.mail.messages[0].id}`,
  );
  assert.equal(mail.status, 200);
  return mail.data.message;
}

test("identity profile changes reauthenticate and invalidate other sessions; password and consent remain private", async (t) => {
  const { client, register } = await fixture(t);
  const alice = client(),
    second = client(),
    bob = client();
  await register(alice);
  await register(bob, "bob@example.test", "Bob Creative");
  await second.request(
    "/api/auth/login",
    post({ email: "identity@example.test", password: originalPassword }),
  );
  const settings = (await alice.request("/api/account/settings")).data;
  assert.equal(settings.sessions.length, 2);
  assert.equal(
    settings.sessions.filter((session) => session.current).length,
    1,
  );
  assert.match(settings.sessions[0].id, /^[a-f0-9]{24}$/);
  assert.equal(JSON.stringify(settings).includes(originalPassword), false);
  const bobSession = (await bob.request("/api/account/settings")).data
    .sessions[0].id;
  assert.equal(
    (
      await alice.request(`/api/account/sessions/${bobSession}`, {
        method: "DELETE",
      })
    ).status,
    404,
  );
  assert.equal(
    (
      await alice.request(
        "/api/account/profile",
        patch({ name: "New Name", email: "new@example.test" }),
      )
    ).status,
    403,
  );
  assert.equal(
    (
      await alice.request(
        "/api/account/preferences",
        patch({ newsletter: "yes" }),
      )
    ).status,
    400,
  );
  await alice.request(
    "/api/account/preferences",
    patch({ newsletter: true, productUpdates: false }),
  );
  const updated = await alice.request(
    "/api/account/profile",
    patch({
      name: "New Name",
      email: "new@example.test",
      password: originalPassword,
    }),
  );
  assert.equal(updated.status, 200);
  assert.equal(updated.data.user.email, "new@example.test");
  assert.equal((await second.request("/api/account/settings")).status, 401);
  const changed = await alice.request(
    "/api/account/password",
    post({
      password: originalPassword,
      newPassword: "a-different-secure-password",
    }),
  );
  assert.equal(changed.status, 200);
  const other = client();
  assert.equal(
    (
      await other.request(
        "/api/auth/login",
        post({ email: "new@example.test", password: originalPassword }),
      )
    ).status,
    401,
  );
  assert.equal(
    (
      await other.request(
        "/api/auth/login",
        post({
          email: "new@example.test",
          password: "a-different-secure-password",
        }),
      )
    ).status,
    200,
  );
  assert.equal(
    (
      await alice.request(
        "/api/account/preferences",
        patch({ newsletter: false }),
      )
    ).data.preferences.newsletter,
    false,
  );
});

test("verification tokens are owner-private, hashed, time-limited, single-use and invalidate on email change", async (t) => {
  const { client, register, db, dataDir } = await fixture(t);
  const alice = client(),
    bob = client(),
    anonymous = client();
  const user = (await register(alice)).data.user;
  await register(bob, "bob@example.test", "Bob Creative");
  const sent = await alice.request("/api/account/verification/send", post({}));
  assert.equal(sent.status, 200);
  assert.equal(sent.data.delivered, false);
  assert.equal(sent.data.developmentPreview, true);
  const mail = await latestMail(alice),
    token = actionToken(mail.body);
  assert.equal((await bob.request(`/api/account/mail/${mail.id}`)).status, 404);
  assert.equal(
    (await anonymous.request(`/api/account/mail/${mail.id}`)).status,
    401,
  );
  const tokenRow = db
    .prepare("SELECT * FROM identity_tokens WHERE user_id=?")
    .get(user.id);
  assert.notEqual(tokenRow.id, token);
  assert.equal(tokenRow.id.length, 64);
  assert.equal(
    (await anonymous.request("/api/auth/verify-email", post({ token }))).status,
    200,
  );
  assert.equal(
    (await anonymous.request("/api/auth/verify-email", post({ token }))).status,
    400,
  );
  assert.equal(
    (await alice.request("/api/account/settings")).data.profile.emailVerified,
    true,
  );
  await alice.request(
    "/api/account/profile",
    patch({
      name: "Identity Creative",
      email: "updated@example.test",
      password: originalPassword,
    }),
  );
  await alice.request("/api/account/verification/send", post({}));
  const expired = actionToken((await latestMail(alice)).body);
  db.prepare(
    "UPDATE identity_tokens SET expires_at=0 WHERE user_id=? AND consumed_at IS NULL",
  ).run(user.id);
  assert.equal(
    (
      await anonymous.request(
        "/api/auth/verify-email",
        post({ token: expired }),
      )
    ).status,
    400,
  );
  assert.equal(
    statSync(join(dataDir, ".account-encryption-key")).mode & 0o777,
    0o600,
  );
});

test("password recovery responds generically and resets once while revoking every session", async (t) => {
  const { client, register } = await fixture(t);
  const alice = client(),
    second = client(),
    anonymous = client();
  await register(alice);
  await second.request(
    "/api/auth/login",
    post({ email: "identity@example.test", password: originalPassword }),
  );
  const known = await anonymous.request(
    "/api/auth/forgot-password",
    post({ email: "identity@example.test" }),
  );
  const unknown = await anonymous.request(
    "/api/auth/forgot-password",
    post({ email: "nobody@example.test" }),
  );
  assert.equal(known.status, 200);
  assert.deepEqual(known.data, unknown.data);
  const token = actionToken((await latestMail(alice)).body);
  assert.equal(JSON.stringify(known.data).includes(token), false);
  const reset = await anonymous.request(
    "/api/auth/reset-password",
    post({ token, password: "the-recovered-password" }),
  );
  assert.equal(reset.status, 200);
  assert.equal((await alice.request("/api/account/settings")).status, 401);
  assert.equal((await second.request("/api/account/settings")).status, 401);
  assert.equal(
    (
      await anonymous.request(
        "/api/auth/reset-password",
        post({ token, password: "yet-another-password" }),
      )
    ).status,
    400,
  );
  assert.equal(
    (
      await anonymous.request(
        "/api/auth/login",
        post({ email: "identity@example.test", password: originalPassword }),
      )
    ).status,
    401,
  );
  assert.equal(
    (
      await anonymous.request(
        "/api/auth/login",
        post({
          email: "identity@example.test",
          password: "the-recovered-password",
        }),
      )
    ).status,
    200,
  );
});

test("MFA enforces a password-bound challenge, replay-resistant TOTP, single-use backup codes and private secrets", async (t) => {
  const { client, register, db } = await fixture(t);
  const owner = client(),
    visitor = client();
  const user = (await register(owner)).data.user;
  assert.equal(
    (await owner.request("/api/account/mfa/setup", post({ password: "wrong" })))
      .status,
    403,
  );
  const setup = await owner.request(
    "/api/account/mfa/setup",
    post({ password: originalPassword }),
  );
  assert.equal(setup.status, 200);
  assert.match(setup.data.secret, /^[A-Z2-7]+$/);
  const counter = Math.floor(Date.now() / 30000);
  const confirmed = await owner.request(
    "/api/account/mfa/confirm",
    post({ code: totpCode(setup.data.secret, counter) }),
  );
  assert.equal(confirmed.status, 200);
  assert.equal(confirmed.data.backupCodes.length, 8);
  const security = db
    .prepare("SELECT * FROM account_security WHERE user_id=?")
    .get(user.id);
  assert.notEqual(security.mfa_secret, setup.data.secret);
  assert.equal(
    security.backup_hashes.includes(confirmed.data.backupCodes[0]),
    false,
  );
  const settings = (await owner.request("/api/account/settings")).data;
  assert.equal(settings.profile.mfaEnabled, true);
  assert.equal(JSON.stringify(settings).includes(setup.data.secret), false);
  const challenge = await visitor.request(
    "/api/auth/login",
    post({ email: user.email, password: originalPassword }),
  );
  assert.equal(challenge.data.mfaRequired, true);
  assert.equal(challenge.headers.get("set-cookie"), null);
  assert.equal((await visitor.request("/api/account/settings")).status, 401);
  assert.equal(
    (
      await visitor.request(
        "/api/auth/mfa",
        post({
          challengeToken: challenge.data.challengeToken,
          code: totpCode(setup.data.secret, counter),
        }),
      )
    ).status,
    401,
  );
  const accepted = await visitor.request(
    "/api/auth/mfa",
    post({
      challengeToken: challenge.data.challengeToken,
      code: totpCode(setup.data.secret, counter + 1),
    }),
  );
  assert.equal(accepted.status, 200);
  assert.equal(accepted.data.user.id, user.id);
  assert.equal(
    (
      await visitor.request(
        "/api/auth/mfa",
        post({
          challengeToken: challenge.data.challengeToken,
          code: confirmed.data.backupCodes[0],
        }),
      )
    ).status,
    401,
  );
  const third = client();
  const login = await third.request(
    "/api/auth/login",
    post({ email: user.email, password: originalPassword }),
  );
  assert.equal(
    (
      await third.request(
        "/api/auth/mfa",
        post({
          challengeToken: login.data.challengeToken,
          code: confirmed.data.backupCodes[0],
        }),
      )
    ).status,
    200,
  );
  const fourth = client();
  const retry = await fourth.request(
    "/api/auth/login",
    post({ email: user.email, password: originalPassword }),
  );
  assert.equal(
    (
      await fourth.request(
        "/api/auth/mfa",
        post({
          challengeToken: retry.data.challengeToken,
          code: confirmed.data.backupCodes[0],
        }),
      )
    ).status,
    401,
  );
  assert.equal(
    (
      await owner.request(
        "/api/account/mfa/disable",
        post({
          password: originalPassword,
          code: confirmed.data.backupCodes[1],
        }),
      )
    ).status,
    200,
  );
  assert.equal(
    (
      await client().request(
        "/api/auth/login",
        post({ email: user.email, password: originalPassword }),
      )
    ).data.user.id,
    user.id,
  );
});

test("production recovery refuses missing or unsafe email origins and hides development mail", async (t) => {
  const { client, register } = await fixture(t, {
    production: true,
    emailTransport: async () => {
      throw new Error("must not send");
    },
    publicUrl: "http://unsecured.example",
  });
  const owner = client();
  await register(owner);
  assert.equal(
    (
      await owner.request(
        "/api/auth/forgot-password",
        post({ email: "identity@example.test" }),
      )
    ).status,
    503,
  );
  assert.equal(
    (await owner.request("/api/account/verification/send", post({}))).status,
    503,
  );
  assert.equal(
    (await owner.request("/api/account/settings")).data.mail.configured,
    false,
  );
  assert.equal(
    (await owner.request("/api/account/mail/does-not-exist")).status,
    404,
  );
});

test("account removal anonymizes personal data, revokes sessions and preserves financial records", async (t) => {
  const { client, register, db } = await fixture(t);
  const owner = client();
  const user = (await register(owner)).data.user;
  const purchase = await owner.request(
    "/api/checkout",
    post({ mode: "demo", productIds: ["studio-brand-kit"] }),
  );
  assert.equal(purchase.status, 200);
  await owner.request("/api/account/preferences", patch({ newsletter: true }));
  await owner.request(
    "/api/support",
    post({
      email: user.email,
      subject: "Personal question",
      message: "Please help with my personal creative account.",
    }),
  );
  const deletion = await owner.request(
    "/api/account/delete",
    post({ password: originalPassword, confirmation: "DELETE" }),
  );
  assert.equal(deletion.status, 200);
  assert.equal((await owner.request("/api/account/settings")).status, 401);
  assert.equal(
    db.prepare("SELECT email FROM users WHERE id=?").get(user.id).email,
    `deleted-${user.id}@removed.invalid`,
  );
  assert.equal(
    db.prepare("SELECT count(*) AS n FROM orders WHERE user_id=?").get(user.id)
      .n,
    1,
  );
  assert.equal(
    db
      .prepare("SELECT count(*) AS n FROM newsletter WHERE email=?")
      .get(user.email).n,
    0,
  );
  assert.equal(
    db.prepare("SELECT email,message FROM tickets WHERE user_id=?").get(user.id)
      .email,
    "removed@removed.invalid",
  );
  assert.equal(
    (
      await client().request(
        "/api/auth/login",
        post({ email: user.email, password: originalPassword }),
      )
    ).status,
    401,
  );
});

test("the last real administrator cannot be removed just because a demo administrator exists", async (t) => {
  const { client, register, db } = await fixture(t);
  const owner = client(),
    demo = client();
  const user = (await register(owner)).data.user;
  db.prepare("UPDATE users SET role='admin' WHERE id=?").run(user.id);
  await demo.request("/api/auth/demo", post({ role: "admin" }));
  const deletion = await owner.request(
    "/api/account/delete",
    post({ password: originalPassword, confirmation: "DELETE" }),
  );
  assert.equal(deletion.status, 409);
  assert.equal(
    db.prepare("SELECT role FROM users WHERE id=?").get(user.id).role,
    "admin",
  );
});

test("production email transport uses HTTPS action links without exposing its private mailbox", async (t) => {
  const messages = [];
  const { client, register } = await fixture(t, {
    production: true,
    publicUrl: "https://digital.example.test",
    emailTransport: async (message) => {
      messages.push(message);
    },
  });
  const owner = client();
  await register(owner);
  const sent = await owner.request("/api/account/verification/send", post({}));
  assert.equal(sent.status, 200);
  assert.equal(sent.data.delivered, true);
  assert.equal(messages.length, 1);
  assert.equal(messages[0].to, "identity@example.test");
  assert.match(
    messages[0].text,
    /https:\/\/digital\.example\.test\/account\/verify-email\?token=/,
  );
  const settings = (await owner.request("/api/account/settings")).data;
  assert.equal(settings.mail.configured, true);
  assert.equal(settings.mail.developmentPreview, false);
  assert.deepEqual(settings.mail.messages, []);
  const token = actionToken(messages[0].text);
  assert.equal(
    (await client().request("/api/auth/verify-email", post({ token }))).status,
    200,
  );
});

test("account exports include consent and user records while excluding authentication secrets and active action tokens", async (t) => {
  const { client, register } = await fixture(t);
  const owner = client();
  await register(owner);
  await owner.request(
    "/api/account/preferences",
    patch({ newsletter: true, renewalReminders: false }),
  );
  await owner.request("/api/account/verification/send", post({}));
  const token = actionToken((await latestMail(owner)).body);
  const exported = await owner.request("/api/account/export");
  assert.equal(exported.status, 200);
  assert.match(exported.headers.get("content-disposition"), /attachment/);
  assert.equal(exported.data.preferences.newsletter, true);
  assert.equal(exported.data.preferences.renewalReminders, false);
  assert.equal(exported.data.user.email, "identity@example.test");
  assert.equal(exported.data.accountSecurity.mfaEnabled, false);
  const json = JSON.stringify(exported.data);
  for (const secret of [
    originalPassword,
    token,
    "mfa_secret",
    "backup_hashes",
    "rtr_session",
  ])
    assert.equal(json.includes(secret), false);
  await owner.request(
    "/api/account/profile",
    patch({
      name: "Fresh Name",
      email: "fresh@example.test",
      password: originalPassword,
    }),
  );
  assert.equal(
    (await owner.request("/api/account/settings")).data.preferences.newsletter,
    false,
  );
  assert.equal(
    (await client().request("/api/auth/verify-email", post({ token }))).status,
    400,
  );
});

test("MFA challenges expire and lock after five wrong attempts without disabling MFA during password recovery", async (t) => {
  const { client, register, db } = await fixture(t);
  const owner = client(),
    anonymous = client();
  const user = (await register(owner)).data.user;
  const setup = (
    await owner.request(
      "/api/account/mfa/setup",
      post({ password: originalPassword }),
    )
  ).data;
  const confirmed = await owner.request(
    "/api/account/mfa/confirm",
    post({ code: totpCode(setup.secret) }),
  );
  assert.equal(confirmed.status, 200);
  const challenge = (
    await anonymous.request(
      "/api/auth/login",
      post({ email: user.email, password: originalPassword }),
    )
  ).data.challengeToken;
  for (let index = 0; index < 5; index++)
    assert.equal(
      (
        await anonymous.request(
          "/api/auth/mfa",
          post({ challengeToken: challenge, code: "wrong-code" }),
        )
      ).status,
      401,
    );
  assert.equal(
    (
      await anonymous.request(
        "/api/auth/mfa",
        post({
          challengeToken: challenge,
          code: confirmed.data.backupCodes[0],
        }),
      )
    ).status,
    401,
  );
  const expired = (
    await anonymous.request(
      "/api/auth/login",
      post({ email: user.email, password: originalPassword }),
    )
  ).data.challengeToken;
  db.prepare(
    "UPDATE identity_tokens SET expires_at=0 WHERE user_id=? AND purpose='mfa-login'",
  ).run(user.id);
  assert.equal(
    (
      await anonymous.request(
        "/api/auth/mfa",
        post({ challengeToken: expired, code: confirmed.data.backupCodes[0] }),
      )
    ).status,
    401,
  );
  await anonymous.request(
    "/api/auth/forgot-password",
    post({ email: user.email }),
  );
  const token = actionToken((await latestMail(owner)).body);
  await anonymous.request(
    "/api/auth/reset-password",
    post({ token, password: "new-password-with-mfa" }),
  );
  const login = await anonymous.request(
    "/api/auth/login",
    post({ email: user.email, password: "new-password-with-mfa" }),
  );
  assert.equal(login.data.mfaRequired, true);
  assert.equal(login.headers.get("set-cookie"), null);
  assert.equal(
    (
      await anonymous.request(
        "/api/auth/mfa",
        post({
          challengeToken: login.data.challengeToken,
          code: confirmed.data.backupCodes[0],
        }),
      )
    ).status,
    200,
  );
});

test("account removal closes an owned Studio workspace and removes personal learning notes and invitations", async (t) => {
  const { client, register, db } = await fixture(t);
  const owner = client(),
    member = client();
  const user = (await register(owner)).data.user;
  await register(member, "teammate@example.test", "Teammate Creative");
  await owner.request(
    "/api/checkout",
    post({ mode: "demo", plan: "studio", interval: "monthly" }),
  );
  const team = await owner.request(
    "/api/membership/team",
    post({ name: "Personal Studio" }),
  );
  assert.equal(team.status, 201);
  const invitation = await owner.request(
    "/api/membership/team/invites",
    post({ email: "teammate@example.test" }),
  );
  assert.equal(invitation.status, 201);
  const invitationToken = new URL(
    invitation.data.inviteUrl,
    "https://test.example",
  ).searchParams.get("invite");
  const accepted = await member.request(
    `/api/membership/team/invites/${invitationToken}/accept`,
    post({}),
  );
  assert.equal(accepted.status, 200);
  assert.equal(
    (await member.request("/api/download/studio-brand-kit", { raw: true }))
      .status,
    200,
  );
  db.prepare(
    "INSERT INTO learning_progress (user_id,product_id,position,total,completed,note,updated_at) VALUES (?,?,?,?,?,?,?)",
  ).run(
    user.id,
    "modern-web-masterclass",
    10,
    100,
    0,
    "Personal journal content",
    new Date().toISOString(),
  );
  const exported = await owner.request("/api/account/export");
  assert.equal(
    exported.data.learningProgress[0].note,
    "Personal journal content",
  );
  assert.equal(
    (
      await owner.request(
        "/api/account/delete",
        post({ password: originalPassword, confirmation: "DELETE" }),
      )
    ).status,
    200,
  );
  assert.equal(
    db
      .prepare("SELECT count(*) AS n FROM learning_progress WHERE user_id=?")
      .get(user.id).n,
    0,
  );
  assert.equal(
    db
      .prepare("SELECT count(*) AS n FROM studio_teams WHERE owner_id=?")
      .get(user.id).n,
    0,
  );
  assert.equal(
    db.prepare("SELECT count(*) AS n FROM studio_invites").get().n,
    0,
  );
  assert.equal(
    (await member.request("/api/download/studio-brand-kit", { raw: true }))
      .status,
    403,
  );
  assert.equal(
    db.prepare("SELECT count(*) AS n FROM orders WHERE user_id=?").get(user.id)
      .n,
    1,
  );
});
