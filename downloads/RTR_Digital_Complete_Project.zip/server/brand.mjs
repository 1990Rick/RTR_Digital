export const SELLER_NAME = "RTR Digital";

// `creator` is retained for older catalog clients; seller/licensor describe the
// storefront's commercial role without making a copyright ownership claim.
export const brandProduct = (metadata) => ({
  ...metadata,
  creator: SELLER_NAME,
  seller: SELLER_NAME,
  licensor: SELLER_NAME,
});
