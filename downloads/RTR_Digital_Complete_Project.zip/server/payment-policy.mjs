// Only server-verified providers and administrator-reconciled bank transfers
// write these modes. Customer reports and gateway redirects never do.
export const PAID_PAYMENT_MODES = Object.freeze([
  "stripe",
  "paypal",
  "razorpay",
  "wire",
]);
export const PAID_MODES_SQL = "'stripe','paypal','razorpay','wire'";
export const isPaidMode = (mode) => PAID_PAYMENT_MODES.includes(mode);
export const isPrepaidMode = (mode) =>
  ["paypal", "razorpay", "wire"].includes(mode);
