import test from "node:test";
import assert from "node:assert/strict";
import { mkdtempSync, rmSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import Stripe from "stripe";
import { createApp, nextBillingDate } from "./index.mjs";

async function fixture(t, options = {}) {
  const dataDir = mkdtempSync(join(tmpdir(), "rtr-api-"));
  const app = createApp({ dataDir, ...options });
  const listener = app.app.listen(0, "127.0.0.1");
  await new Promise((r) => listener.once("listening", r));
  const base = `http://127.0.0.1:${listener.address().port}`;
  t.after(async () => {
    await new Promise((r) => listener.close(r));
    app.close();
    rmSync(dataDir, { recursive: true, force: true });
  });
  let cookie = "";
  async function request(
    path,
    { method = "GET", body, headers = {}, raw = false } = {},
  ) {
    const response = await fetch(base + path, {
      method,
      headers: {
        ...(cookie ? { Cookie: cookie } : {}),
        ...(body && !(body instanceof FormData)
          ? { "Content-Type": "application/json" }
          : {}),
        ...headers,
      },
      ...(body
        ? { body: body instanceof FormData ? body : JSON.stringify(body) }
        : {}),
    });
    if (response.headers.get("set-cookie"))
      cookie = response.headers.get("set-cookie").split(";")[0];
    const data = raw ? await response.text() : await response.json();
    return { status: response.status, data, headers: response.headers };
  }
  return { request, base, db: app.db };
}

test("catalog is seeded, searchable, and draft products are hidden", async (t) => {
  const { request } = await fixture(t);
  const { status, data } = await request("/api/catalog");
  assert.equal(status, 200);
  assert.equal(data.products.length, 12);
  assert.equal(data.categories.length, 7);
  assert.equal(
    (await request("/api/catalog?q=ambient")).data.products.some(
      (x) => x.id === "ambient-essentials",
    ),
    true,
  );
  assert.equal(
    (await request("/api/catalog?category=E-books")).data.products.every(
      (x) => x.category === "E-books",
    ),
    true,
  );
  assert.equal((await request("/api/products/does-not-exist")).status, 404);
});

test("registration, password login, private session and role boundaries work", async (t) => {
  const { request, db } = await fixture(t);
  assert.equal((await request("/api/library")).status, 401);
  assert.equal(
    (
      await request("/api/auth/register", {
        method: "POST",
        body: {
          name: "Alex",
          email: "alex@example.com",
          password: "123",
          role: "admin",
        },
      })
    ).status,
    400,
  );
  const created = await request("/api/auth/register", {
    method: "POST",
    body: {
      name: "Alex Creative",
      email: "alex@example.com",
      password: "a-real-long-password",
      role: "admin",
    },
  });
  assert.equal(created.status, 201);
  assert.equal(created.data.user.role, "customer");
  assert.equal("password" in created.data.user, false);
  assert.match(created.headers.get("set-cookie"), /HttpOnly/);
  assert.match(created.headers.get("set-cookie"), /SameSite=Lax/);
  assert.notEqual(
    db
      .prepare("SELECT password FROM users WHERE email=?")
      .get("alex@example.com").password,
    "a-real-long-password",
  );
  assert.equal((await request("/api/admin/stats")).status, 403);
  assert.equal((await request("/api/auth/me")).data.user.name, "Alex Creative");
  await request("/api/auth/logout", { method: "POST" });
  assert.equal((await request("/api/auth/me")).data.user, null);
  assert.equal(
    (
      await request("/api/auth/login", {
        method: "POST",
        body: { email: "alex@example.com", password: "wrong-password" },
      })
    ).status,
    401,
  );
  assert.equal(
    (
      await request("/api/auth/login", {
        method: "POST",
        body: { email: "alex@example.com", password: "a-real-long-password" },
      })
    ).status,
    200,
  );
});

test("demo purchase uses trusted prices, grants downloads and is idempotent", async (t) => {
  const { request } = await fixture(t);
  await request("/api/auth/demo", {
    method: "POST",
    body: { role: "customer" },
  });
  assert.equal((await request("/api/download/studio-brand-kit")).status, 403);
  const order = await request("/api/checkout", {
    method: "POST",
    headers: { "Idempotency-Key": "unique-test-order-1" },
    body: {
      productIds: ["studio-brand-kit", "studio-brand-kit"],
      mode: "demo",
      coupon: "WELCOME10",
      total: 0.01,
    },
  });
  assert.equal(order.status, 200);
  assert.equal(order.data.total, 35.1);
  assert.equal(order.data.demo, true);
  const repeated = await request("/api/checkout", {
    method: "POST",
    headers: { "Idempotency-Key": "unique-test-order-1" },
    body: {
      productIds: ["studio-brand-kit"],
      mode: "demo",
      coupon: "WELCOME10",
    },
  });
  assert.equal(repeated.data.orderId, order.data.orderId);
  const library = (await request("/api/library")).data;
  assert.equal(library.products.length, 1);
  assert.equal(library.orders.length, 1);
  const download = await request("/api/download/studio-brand-kit", {
    raw: true,
  });
  assert.equal(download.status, 200);
  assert.match(download.data, /DEMONSTRATION DOWNLOAD/);
  assert.match(download.headers.get("content-disposition"), /attachment/);
  assert.equal((await request("/api/download/focus-deep-work")).status, 403);
  assert.equal(
    (
      await request("/api/checkout", {
        method: "POST",
        body: { productIds: ["fake"], mode: "demo" },
      })
    ).status,
    400,
  );
});

test("membership unlocks library, cancellation retains paid-period access, resume works", async (t) => {
  const { request } = await fixture(t);
  await request("/api/auth/demo", { method: "POST", body: {} });
  const checkout = await request("/api/checkout", {
    method: "POST",
    body: { plan: "creator", interval: "yearly", mode: "demo" },
  });
  assert.equal(checkout.status, 200);
  assert.equal(checkout.data.total, 180);
  assert.equal((await request("/api/library")).data.products.length, 12);
  assert.equal(
    (
      await request("/api/checkout", {
        method: "POST",
        body: { plan: "studio", mode: "demo" },
      })
    ).status,
    409,
  );
  const canceled = await request("/api/subscription/cancel", {
    method: "POST",
  });
  assert.equal(canceled.data.subscription.cancelAtPeriodEnd, true);
  assert.equal(
    (await request("/api/download/focus-deep-work", { raw: true })).status,
    200,
  );
  assert.equal(
    (await request("/api/subscription/resume", { method: "POST" })).data
      .subscription.cancelAtPeriodEnd,
    false,
  );
});

test("expired membership revokes subscription downloads without revoking purchases", async (t) => {
  const { request, db } = await fixture(t);
  const {
    data: { user },
  } = await request("/api/auth/demo", { method: "POST", body: {} });
  await request("/api/checkout", {
    method: "POST",
    body: { productIds: ["focus-deep-work"], mode: "demo" },
  });
  await request("/api/checkout", {
    method: "POST",
    body: { plan: "starter", mode: "demo" },
  });
  const s = JSON.parse(
    db.prepare("SELECT subscription FROM users WHERE id=?").get(user.id)
      .subscription,
  );
  db.prepare("UPDATE users SET subscription=? WHERE id=?").run(
    JSON.stringify({ ...s, currentPeriodEnd: "2000-01-01T00:00:00.000Z" }),
    user.id,
  );
  assert.equal((await request("/api/download/studio-brand-kit")).status, 403);
  assert.equal(
    (await request("/api/download/focus-deep-work", { raw: true })).status,
    200,
  );
  assert.equal((await request("/api/library")).data.products.length, 1);
});

test("admin can upload, publish and deliver an actual file with authentication", async (t) => {
  const { request } = await fixture(t);
  await request("/api/auth/demo", { method: "POST", body: { role: "admin" } });
  const form = new FormData();
  form.set("title", "My original digital guide");
  form.set(
    "description",
    "An original guide that demonstrates real digital uploads and delivery.",
  );
  form.set("category", "E-books");
  form.set("price", "12.50");
  form.set("subscriptionIncluded", "true");
  form.set(
    "file",
    new Blob(["Actual original content for the guide"], { type: "text/plain" }),
    "guide.txt",
  );
  const uploaded = await request("/api/admin/products", {
    method: "POST",
    body: form,
  });
  assert.equal(uploaded.status, 201);
  assert.equal(uploaded.data.product.status, "draft");
  assert.equal(uploaded.data.product.isSample, false);
  const id = uploaded.data.product.id;
  assert.equal(
    (await request("/api/catalog")).data.products.some((p) => p.id === id),
    false,
  );
  assert.equal(
    (
      await request(`/api/admin/products/${id}`, {
        method: "PATCH",
        body: { status: "published" },
      })
    ).status,
    200,
  );
  assert.equal(
    (await request("/api/catalog")).data.products.some((p) => p.id === id),
    true,
  );
  await request("/api/auth/demo", {
    method: "POST",
    body: { role: "customer" },
  });
  assert.equal((await request(`/api/download/${id}`)).status, 403);
  await request("/api/checkout", {
    method: "POST",
    body: { productIds: [id], mode: "demo" },
  });
  const delivered = await request(`/api/download/${id}`, { raw: true });
  assert.equal(delivered.data, "Actual original content for the guide");
  assert.equal((await request("/api/admin/products")).status, 403);
});

test("production has no demo login, demo payments, or fake live readiness", async (t) => {
  const { request } = await fixture(t, {
    production: true,
    demoMode: false,
    stripeKey: undefined,
  });
  assert.equal((await request("/api/config")).data.demoMode, false);
  assert.equal((await request("/api/config")).data.stripeConfigured, false);
  assert.equal(
    (
      await request("/api/auth/demo", {
        method: "POST",
        body: { role: "admin" },
      })
    ).status,
    404,
  );
  await request("/api/auth/register", {
    method: "POST",
    body: {
      name: "Production Test",
      email: "production@example.com",
      password: "safe-test-password",
    },
  });
  assert.equal(
    (
      await request("/api/checkout", {
        method: "POST",
        body: { productIds: ["studio-brand-kit"], mode: "demo" },
      })
    ).status,
    403,
  );
  assert.equal(
    (
      await request("/api/checkout", {
        method: "POST",
        body: { productIds: ["studio-brand-kit"], mode: "stripe" },
      })
    ).status,
    503,
  );
  assert.equal(
    (
      await request("/api/stripe/webhook", {
        method: "POST",
        body: { type: "checkout.session.completed" },
      })
    ).status,
    503,
  );
});

test("wishlist, support, reviews, newsletter and data export persist safely", async (t) => {
  const { request } = await fixture(t);
  await request("/api/auth/demo", {
    method: "POST",
    body: { role: "customer" },
  });
  assert.equal(
    (
      await request("/api/wishlist", {
        method: "PUT",
        body: { productIds: ["studio-brand-kit", "studio-brand-kit"] },
      })
    ).data.productIds.length,
    1,
  );
  assert.equal(
    (await request("/api/wishlist")).data.productIds[0],
    "studio-brand-kit",
  );
  assert.equal(
    (
      await request("/api/wishlist", {
        method: "PUT",
        body: { productIds: ["fake"] },
      })
    ).status,
    400,
  );
  assert.equal(
    (
      await request("/api/newsletter", {
        method: "POST",
        body: { email: "test@example.com" },
      })
    ).status,
    200,
  );
  assert.equal(
    (
      await request("/api/newsletter", {
        method: "POST",
        body: { email: "bad" },
      })
    ).status,
    400,
  );
  assert.equal(
    (
      await request("/api/support", {
        method: "POST",
        body: {
          email: "test@example.com",
          subject: "Download question",
          message: "Please help me understand the digital licensing terms.",
        },
      })
    ).status,
    201,
  );
  assert.equal(
    (
      await request("/api/reviews/studio-brand-kit", {
        method: "POST",
        body: { rating: 5, body: "A useful and thoughtful digital resource." },
      })
    ).status,
    403,
  );
  await request("/api/checkout", {
    method: "POST",
    body: { productIds: ["studio-brand-kit"], mode: "demo" },
  });
  assert.equal(
    (
      await request("/api/reviews/studio-brand-kit", {
        method: "POST",
        body: { rating: 5, body: "A useful and thoughtful digital resource." },
      })
    ).status,
    201,
  );
  assert.equal(
    (await request("/api/reviews/studio-brand-kit")).data.reviews.length,
    1,
  );
  const exported = await request("/api/account/export");
  assert.equal(exported.data.orders.length, 1);
  assert.equal("password" in exported.data.user, false);
  await request("/api/auth/demo", { method: "POST", body: { role: "admin" } });
  const stats = (await request("/api/admin/stats")).data;
  assert.equal(stats.revenue, 0);
  assert.equal(stats.demoRevenue, 39);
  assert.equal(stats.tickets.length, 1);
});

test("cross-origin mutations and malformed input are rejected", async (t) => {
  const { request } = await fixture(t);
  assert.equal(
    (
      await request("/api/auth/demo", {
        method: "POST",
        body: {},
        headers: { Origin: "https://evil.example" },
      })
    ).status,
    403,
  );
  assert.equal(
    (await request("/api/checkout", { method: "POST", body: { mode: "demo" } }))
      .status,
    401,
  );
  assert.equal((await request("/api/does-not-exist")).status, 404);
});

test("Stripe fulfillment requires a signed, paid, known checkout and is replay-safe", async (t) => {
  const webhookSecret = "whsec_local_automated_test_only";
  const { request, db } = await fixture(t, {
    stripeKey: "sk_test_local_automated_test_only",
    webhookSecret,
    publicUrl: "https://store.example",
  });
  const {
    data: { user },
  } = await request("/api/auth/demo", {
    method: "POST",
    body: { role: "customer" },
  });
  assert.equal((await request("/api/config")).data.stripeConfigured, true);
  const selected = [
    JSON.parse(
      db
        .prepare("SELECT payload FROM products WHERE id=?")
        .get("studio-brand-kit").payload,
    ),
  ];
  db.prepare("INSERT INTO checkout_intents VALUES (?,?,?,?)").run(
    "known-checkout-intent",
    user.id,
    JSON.stringify({ selected, total: 39, interval: "monthly", plan: null }),
    new Date().toISOString(),
  );
  const event = {
    id: "evt_automated_test_1",
    object: "event",
    type: "checkout.session.completed",
    data: {
      object: {
        id: "cs_automated_test_1",
        payment_status: "paid",
        currency: "usd",
        amount_total: 3900,
        metadata: { userId: user.id, intentId: "known-checkout-intent" },
      },
    },
  };
  assert.equal(
    (await request("/api/stripe/webhook", { method: "POST", body: event }))
      .status,
    400,
  );
  assert.equal((await request("/api/library")).data.products.length, 0);
  const stripe = new Stripe("sk_test_local_automated_test_only");
  const signature = stripe.webhooks.generateTestHeaderString({
    payload: JSON.stringify(event),
    secret: webhookSecret,
  });
  const fulfilled = await request("/api/stripe/webhook", {
    method: "POST",
    body: event,
    headers: { "Stripe-Signature": signature },
  });
  assert.equal(fulfilled.status, 200);
  assert.equal((await request("/api/library")).data.products.length, 1);
  assert.equal((await request("/api/library")).data.orders[0].mode, "stripe");
  assert.equal(
    (
      await request("/api/stripe/webhook", {
        method: "POST",
        body: event,
        headers: { "Stripe-Signature": signature },
      })
    ).status,
    200,
  );
  assert.equal((await request("/api/library")).data.orders.length, 1);
  const mismatch = {
    ...event,
    id: "evt_mismatch",
    data: {
      object: { ...event.data.object, id: "cs_mismatch", amount_total: 1 },
    },
  };
  const mismatchSignature = stripe.webhooks.generateTestHeaderString({
    payload: JSON.stringify(mismatch),
    secret: webhookSecret,
  });
  assert.equal(
    (
      await request("/api/stripe/webhook", {
        method: "POST",
        body: mismatch,
        headers: { "Stripe-Signature": mismatchSignature },
      })
    ).status,
    400,
  );
});

test("subscriptions cannot access drafts; purchased products survive unpublishing", async (t) => {
  const { request } = await fixture(t);
  await request("/api/auth/demo", { method: "POST", body: { role: "admin" } });
  const form = new FormData();
  form.set("title", "Unreleased original book");
  form.set(
    "description",
    "This book should stay private until the administrator publishes it.",
  );
  form.set("category", "E-books");
  form.set("price", "12.50");
  form.set(
    "file",
    new Blob(["A confidential unpublished manuscript."]),
    "manuscript.txt",
  );
  const {
    data: { product },
  } = await request("/api/admin/products", { method: "POST", body: form });
  await request("/api/auth/demo", {
    method: "POST",
    body: { role: "customer" },
  });
  await request("/api/checkout", {
    method: "POST",
    body: { plan: "creator", mode: "demo" },
  });
  assert.equal(
    (await request("/api/library")).data.products.some(
      (p) => p.id === product.id,
    ),
    false,
  );
  assert.equal((await request(`/api/download/${product.id}`)).status, 403);
  await request("/api/auth/demo", { method: "POST", body: { role: "admin" } });
  await request(`/api/admin/products/${product.id}`, {
    method: "PATCH",
    body: { status: "published" },
  });
  await request("/api/auth/demo", {
    method: "POST",
    body: { role: "customer" },
  });
  assert.equal(
    (await request("/api/library")).data.products.some(
      (p) => p.id === product.id,
    ),
    true,
  );
  await request("/api/checkout", {
    method: "POST",
    body: { productIds: [product.id], mode: "demo" },
  });
  await request("/api/auth/demo", { method: "POST", body: { role: "admin" } });
  await request(`/api/admin/products/${product.id}`, {
    method: "PATCH",
    body: { status: "draft" },
  });
  await request("/api/auth/demo", {
    method: "POST",
    body: { role: "customer" },
  });
  assert.equal(
    (await request(`/api/download/${product.id}`, { raw: true })).status,
    200,
  );
});

test("cover uploads map to frontend image field, validate bytes and protect drafts", async (t) => {
  const { request } = await fixture(t);
  await request("/api/auth/demo", { method: "POST", body: { role: "admin" } });
  const form = new FormData();
  form.set("title", "Original illustrated guide");
  form.set(
    "description",
    "A useful illustrated guide with an original cover image.",
  );
  form.set("category", "E-books");
  form.set("price", "10");
  form.set("file", new Blob(["The actual book."]), "book.txt");
  form.set(
    "cover",
    new Blob(
      [
        Buffer.from(
          "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+aR0cAAAAASUVORK5CYII=",
          "base64",
        ),
      ],
      { type: "image/png" },
    ),
    "cover.png",
  );
  const { status, data } = await request("/api/admin/products", {
    method: "POST",
    body: form,
  });
  assert.equal(status, 201);
  assert.match(data.product.image, /^\/api\/product-cover\//);
  assert.equal((await request(data.product.image, { raw: true })).status, 200);
  await request("/api/auth/demo", {
    method: "POST",
    body: { role: "customer" },
  });
  assert.equal((await request(data.product.image)).status, 404);
  await request("/api/auth/demo", { method: "POST", body: { role: "admin" } });
  form.set(
    "cover",
    new Blob(["<html><script>alert(1)</script></html>"], { type: "image/png" }),
    "forged.png",
  );
  assert.equal(
    (await request("/api/admin/products", { method: "POST", body: form }))
      .status,
    400,
  );
});

test("production does not honor demo purchases, subscriptions or administrator sessions", async (t) => {
  const { request, db } = await fixture(t, { production: true });
  const created = await request("/api/auth/register", {
    method: "POST",
    body: {
      name: "Real User",
      email: "real@example.com",
      password: "real-user-password",
    },
  });
  const id = created.data.user.id;
  db.prepare("INSERT INTO entitlements VALUES (?,?,?)").run(
    id,
    "studio-brand-kit",
    "demo",
  );
  db.prepare("UPDATE users SET subscription=? WHERE id=?").run(
    JSON.stringify({
      plan: "creator",
      interval: "yearly",
      mode: "demo",
      status: "active",
      currentPeriodEnd: "2099-01-01T00:00:00.000Z",
    }),
    id,
  );
  assert.equal((await request("/api/auth/me")).data.user.subscription, null);
  assert.equal((await request("/api/library")).data.products.length, 0);
  assert.equal((await request("/api/download/studio-brand-kit")).status, 403);
  db.prepare("UPDATE entitlements SET mode='stripe' WHERE user_id=?").run(id);
  assert.equal(
    (await request("/api/download/studio-brand-kit", { raw: true })).status,
    200,
  );
  db.prepare(
    "UPDATE users SET role='admin', email='demo-admin@rtr.example' WHERE id=?",
  ).run(id);
  assert.equal((await request("/api/auth/me")).data.user, null);
  assert.equal((await request("/api/admin/products")).status, 401);
  assert.equal(
    (
      await request("/api/auth/register", {
        method: "POST",
        body: {
          name: "Reserved User",
          email: "demo-customer@rtr.example",
          password: "a-valid-password",
        },
      })
    ).status,
    400,
  );
});

test("demo plan changes have immediate explicit test semantics and reject expired memberships", async (t) => {
  const { request, db } = await fixture(t);
  const {
    data: { user },
  } = await request("/api/auth/demo", {
    method: "POST",
    body: { role: "customer" },
  });
  assert.equal(
    (
      await request("/api/subscription/change", {
        method: "POST",
        body: { plan: "creator", interval: "yearly" },
      })
    ).status,
    400,
  );
  await request("/api/checkout", {
    method: "POST",
    body: { plan: "starter", mode: "demo" },
  });
  await request("/api/subscription/cancel", { method: "POST" });
  const changed = await request("/api/subscription/change", {
    method: "POST",
    body: { plan: "creator", interval: "yearly" },
  });
  assert.equal(changed.status, 200);
  assert.equal(changed.data.subscription.plan, "creator");
  assert.equal(changed.data.subscription.interval, "yearly");
  assert.equal(changed.data.subscription.cancelAtPeriodEnd, false);
  assert.match(changed.data.message, /No money was charged/);
  assert.ok(
    Date.parse(changed.data.subscription.currentPeriodEnd) >
      Date.now() + 360 * 86400000,
  );
  assert.equal(
    (
      await request("/api/subscription/change", {
        method: "POST",
        body: { plan: "constructor", interval: "monthly" },
      })
    ).status,
    400,
  );
  assert.equal(
    (
      await request("/api/checkout", {
        method: "POST",
        body: { plan: "__proto__", mode: "demo" },
      })
    ).status,
    400,
  );
  db.prepare("UPDATE users SET subscription=? WHERE id=?").run(
    JSON.stringify({
      ...changed.data.subscription,
      currentPeriodEnd: "2000-01-01T00:00:00Z",
    }),
    user.id,
  );
  assert.equal(
    (
      await request("/api/subscription/change", {
        method: "POST",
        body: { plan: "studio", interval: "monthly" },
      })
    ).status,
    400,
  );
});

test("calendar billing dates clamp month ends and leap years", () => {
  assert.equal(
    nextBillingDate("2026-01-31T12:00:00.000Z", "monthly"),
    "2026-02-28T12:00:00.000Z",
  );
  assert.equal(
    nextBillingDate("2024-01-31T12:00:00.000Z", "monthly"),
    "2024-02-29T12:00:00.000Z",
  );
  assert.equal(
    nextBillingDate("2024-02-29T12:00:00.000Z", "yearly"),
    "2025-02-28T12:00:00.000Z",
  );
});

test("live membership checkout, duplicate protection, billing changes and authoritative revocation", async (t) => {
  const webhookSecret = "whsec_local_live_path_test_only";
  const stripe = new Stripe("sk_test_local_live_path_test_only");
  const calls = [];
  let billingStatus = "active";
  const periodEnd = Math.floor(Date.now() / 1000) + 30 * 86400;
  const stripeClient = {
    webhooks: stripe.webhooks,
    checkout: {
      sessions: {
        create: async (input, options) => {
          calls.push({ input, options });
          return {
            id: "cs_live_path_test",
            url: "https://checkout.stripe.com/test-local",
          };
        },
      },
    },
    subscriptions: {
      retrieve: async (id) => ({
        id,
        customer: "cus_local_test",
        status: billingStatus,
        items: { data: [{ current_period_end: periodEnd }] },
        cancel_at_period_end: false,
      }),
    },
    billingPortal: {
      sessions: {
        create: async () => ({
          url: "https://billing.stripe.com/test-local-portal",
        }),
      },
    },
  };
  const { request } = await fixture(t, {
    stripeClient,
    webhookSecret,
    publicUrl: "https://store.example",
  });
  await request("/api/auth/demo", { method: "POST", body: { role: "admin" } });
  const form = new FormData();
  form.set("title", "Real membership product");
  form.set(
    "description",
    "This original digital file is an actual uploaded membership product.",
  );
  form.set("category", "E-books");
  form.set("price", "12.50");
  form.set("status", "published");
  form.set("subscriptionIncluded", "false");
  form.set(
    "file",
    new Blob(["Original subscription content."]),
    "original.txt",
  );
  const {
    data: { product },
  } = await request("/api/admin/products", { method: "POST", body: form });
  await request("/api/auth/demo", {
    method: "POST",
    body: { role: "customer" },
  });
  assert.equal(
    (
      await request("/api/checkout", {
        method: "POST",
        headers: { "Idempotency-Key": "live-test-key-1" },
        body: { plan: "creator", interval: "monthly", mode: "stripe" },
      })
    ).status,
    400,
  );
  assert.equal(
    (
      await request("/api/checkout", {
        method: "POST",
        body: { productIds: ["studio-brand-kit"], mode: "stripe" },
      })
    ).status,
    400,
  );
  await request("/api/auth/demo", { method: "POST", body: { role: "admin" } });
  await request(`/api/admin/products/${product.id}`, {
    method: "PATCH",
    body: { subscriptionIncluded: true },
  });
  await request("/api/auth/demo", {
    method: "POST",
    body: { role: "customer" },
  });
  const checkoutBody = {
    plan: "creator",
    interval: "monthly",
    mode: "stripe",
    coupon: "WELCOME10",
  };
  const checkout = await request("/api/checkout", {
    method: "POST",
    headers: { "Idempotency-Key": "live-test-key-1" },
    body: checkoutBody,
  });
  assert.equal(checkout.status, 200);
  assert.match(checkout.data.url, /^https:\/\/checkout.stripe.com/);
  assert.equal(calls[0].input.line_items[0].price_data.unit_amount, 1710);
  assert.deepEqual(calls[0].input.line_items[0].price_data.recurring, {
    interval: "month",
  });
  assert.equal(
    (await request("/api/library")).data.products.length,
    0,
    "redirect URL alone grants no access",
  );
  assert.equal(
    (
      await request("/api/checkout", {
        method: "POST",
        headers: { "Idempotency-Key": "live-test-key-1" },
        body: checkoutBody,
      })
    ).status,
    200,
  );
  assert.deepEqual(
    calls[0],
    calls[1],
    "Stripe retries have stable metadata, expiry and idempotency key",
  );
  assert.equal(
    (
      await request("/api/checkout", {
        method: "POST",
        headers: { "Idempotency-Key": "another-live-key" },
        body: { ...checkoutBody, plan: "studio" },
      })
    ).status,
    409,
  );
  const event = {
    id: "evt_live_path_paid",
    object: "event",
    type: "checkout.session.completed",
    data: {
      object: {
        id: "cs_live_path_test",
        payment_status: "paid",
        currency: "usd",
        amount_total: 1710,
        metadata: calls[0].input.metadata,
        subscription: "sub_live_path_test",
      },
    },
  };
  const signature = stripe.webhooks.generateTestHeaderString({
    payload: JSON.stringify(event),
    secret: webhookSecret,
  });
  assert.equal(
    (
      await request("/api/stripe/webhook", {
        method: "POST",
        body: event,
        headers: { "Stripe-Signature": signature },
      })
    ).status,
    200,
  );
  const library = (await request("/api/library")).data;
  assert.equal(library.products.length, 13);
  assert.equal(
    library.subscription.currentPeriodEnd,
    new Date(periodEnd * 1000).toISOString(),
  );
  const change = await request("/api/subscription/change", {
    method: "POST",
    body: { plan: "studio", interval: "yearly" },
  });
  assert.match(change.data.url, /^https:\/\/billing.stripe.com/);
  assert.equal(
    (await request("/api/library")).data.subscription.plan,
    "creator",
    "portal redirect does not pretend a plan change was applied",
  );
  billingStatus = "canceled";
  const oldEvent = {
    id: "evt_out_of_order_subscription",
    object: "event",
    type: "customer.subscription.updated",
    data: {
      object: {
        id: "sub_live_path_test",
        status: "active",
        current_period_end: periodEnd,
      },
    },
  };
  const oldSignature = stripe.webhooks.generateTestHeaderString({
    payload: JSON.stringify(oldEvent),
    secret: webhookSecret,
  });
  assert.equal(
    (
      await request("/api/stripe/webhook", {
        method: "POST",
        body: oldEvent,
        headers: { "Stripe-Signature": oldSignature },
      })
    ).status,
    200,
  );
  assert.equal(
    (await request("/api/library")).data.subscription.status,
    "canceled",
  );
  assert.equal((await request("/api/library")).data.products.length, 0);
});
