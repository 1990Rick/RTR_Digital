import test from "node:test";
import assert from "node:assert/strict";
import {
  mkdtempSync,
  rmSync,
  writeFileSync,
  symlinkSync,
  mkdirSync,
  existsSync,
} from "node:fs";
import { tmpdir } from "node:os";
import { join, resolve } from "node:path";
import { fileURLToPath } from "node:url";
import { randomUUID } from "node:crypto";
import Stripe from "stripe";
import { createApp } from "./index.mjs";
const root = fileURLToPath(new URL("..", import.meta.url));
async function fixture(t, options = {}) {
  const dir = mkdtempSync(join(tmpdir(), "rtr-platform-"));
  const app = createApp({ dataDir: dir, ...options });
  const server = app.app.listen(0, "127.0.0.1");
  await new Promise((r) => server.once("listening", r));
  const base = `http://127.0.0.1:${server.address().port}`;
  t.after(async () => {
    await new Promise((r) => server.close(r));
    app.close();
    rmSync(dir, { recursive: true, force: true });
  });
  let cookie = "";
  async function request(path, { method = "GET", body, headers = {} } = {}) {
    const response = await fetch(base + path, {
      method,
      headers: {
        ...(cookie ? { Cookie: cookie } : {}),
        ...(body === undefined ? {} : { "Content-Type": "application/json" }),
        ...headers,
      },
      ...(body === undefined ? {} : { body: JSON.stringify(body) }),
    });
    if (response.headers.get("set-cookie"))
      cookie = response.headers.get("set-cookie").split(";")[0];
    const raw = await response.text();
    let data;
    try {
      data = JSON.parse(raw);
    } catch {
      data = raw;
    }
    return { status: response.status, data, headers: response.headers };
  }
  return { ...app, request, dir };
}

test("production catalog hides illustrative stock, while administrator publishing keeps empty originals private", async (t) => {
  const f = await fixture(t, { production: true });
  assert.equal((await f.request("/api/catalog")).data.products.length, 0);
  assert.equal((await f.request("/api/products/studio-brand-kit")).status, 404);
  assert.equal((await f.request("/products/studio-brand-kit")).status, 404);
  assert.equal((await f.request("/api/config")).data.sampleCatalog, false);
});

test("database storage cannot be configured inside public web roots, even through a symlink", (t) => {
  assert.throws(
    () => createApp({ dataDir: resolve(root, "public", "private-files") }),
    /outside the public/,
  );
  assert.throws(
    () => createApp({ dataDir: resolve(root, "dist", "private-files") }),
    /outside the public/,
  );
  const dir = mkdtempSync(join(tmpdir(), "rtr-storage-"));
  t.after(() => rmSync(dir, { recursive: true, force: true }));
  const link = join(dir, "linked-public");
  symlinkSync(resolve(root, "public"), link, "dir");
  assert.throws(() => createApp({ dataDir: link }), /outside the public/);
});

test("development server refuses private database, upload, and encryption-key files", async (t) => {
  const { createServer } = await import("vite");
  const files = [`qa-${randomUUID()}.sqlite`, `qa-${randomUUID()}.sqlite-wal`];
  const dir = resolve(root, "data");
  mkdirSync(dir, { recursive: true });
  for (const name of files)
    writeFileSync(
      join(dir, name),
      "Synthetic security test. No customer data.",
    );
  const server = await createServer({
    configFile: resolve(root, "vite.config.ts"),
    logLevel: "silent",
    server: { host: "127.0.0.1", port: 0, strictPort: false, proxy: {} },
  });
  t.after(async () => {
    await server.close();
    for (const name of files) rmSync(join(dir, name), { force: true });
  });
  await server.listen();
  const base = `http://127.0.0.1:${server.httpServer.address().port}`;
  for (const name of files) {
    assert.equal((await fetch(`${base}/data/${name}`)).status, 403);
    assert.equal((await fetch(`${base}/@fs/${join(dir, name)}`)).status, 403);
  }
});

test("sitemap and product metadata use configured origin and escape untrusted catalog text", async (t) => {
  const f = await fixture(t, { publicUrl: "https://rtr.example" });
  const sitemap = await f.request("/sitemap.xml");
  assert.equal(sitemap.status, 200);
  assert.match(sitemap.data, /<loc>https:\/\/rtr.example\/membership<\/loc>/);
  assert.doesNotMatch(sitemap.data, /studio-brand-kit/);
  const noOrigin = await fixture(t);
  assert.equal((await noOrigin.request("/sitemap.xml")).status, 503);
  if (existsSync(resolve(root, "dist/index.html"))) {
    const page = await f.request("/products/studio-brand-kit");
    assert.equal(page.status, 200);
    assert.match(page.data, /application\/ld\+json/);
    assert.match(page.data, /noindex,nofollow/);
    const schema = JSON.parse(
      page.data.match(/<script type="application\/ld\+json">(.*?)<\/script>/s)[1],
    );
    assert.equal(schema.brand.name, "RTR Digital");
    assert.deepEqual(schema.offers.seller, {
      "@type": "Organization",
      name: "RTR Digital",
    });
    const row = f.db
      .prepare("SELECT payload FROM products WHERE id=?")
      .get("studio-brand-kit");
    const product = JSON.parse(row.payload);
    product.title = "Notes </script><script>alert(1)</script>";
    f.db
      .prepare("UPDATE products SET payload=? WHERE id=?")
      .run(JSON.stringify(product), "studio-brand-kit");
    const escaped = await f.request("/products/studio-brand-kit");
    assert.doesNotMatch(escaped.data, /<script>alert\(1\)<\/script>/);
    assert.match(escaped.data, /\\u003c\/script>/);
  }
});

test("signed tax-inclusive payments preserve actual paid totals, zero-price checkout is bounded to known free intents", async (t) => {
  const secret = "whsec_platform_local";
  const stripe = new Stripe("sk_test_platform_local");
  const f = await fixture(t, {
    stripeClient: stripe,
    webhookSecret: secret,
    publicUrl: "https://rtr.example",
  });
  const user = (
    await f.request("/api/auth/register", {
      method: "POST",
      body: {
        name: "Platform Buyer",
        email: "platform@example.test",
        password: "private-test-password",
      },
    })
  ).data.user;
  const selected = [
    JSON.parse(
      f.db
        .prepare("SELECT payload FROM products WHERE id=?")
        .get("focus-deep-work").payload,
    ),
  ];
  const insert = (id, payload) =>
    f.db
      .prepare("INSERT INTO checkout_intents VALUES (?,?,?,?)")
      .run(id, user.id, JSON.stringify(payload), new Date().toISOString());
  async function send(id, intent, amount, total, payment = "paid") {
    const event = {
      id,
      type: "checkout.session.completed",
      data: {
        object: {
          id: `cs_${id}`,
          payment_status: payment,
          currency: "usd",
          amount_subtotal: amount,
          amount_total: total,
          total_details: { amount_tax: total - amount },
          payment_intent: `pi_${id}`,
          metadata: { userId: user.id, intentId: intent },
        },
      },
    };
    const signature = stripe.webhooks.generateTestHeaderString({
      payload: JSON.stringify(event),
      secret,
    });
    return f.request("/api/stripe/webhook", {
      method: "POST",
      body: event,
      headers: { "Stripe-Signature": signature },
    });
  }
  insert("tax-intent", {
    selected,
    total: 19,
    interval: "monthly",
    plan: null,
    automaticTax: true,
  });
  assert.equal((await send("evt_tax", "tax-intent", 1900, 2242)).status, 200);
  const paid = (await f.request("/api/library")).data.orders[0];
  assert.equal(paid.total, 22.42);
  assert.equal(paid.subtotal, 19);
  assert.equal(paid.tax, 3.42);
  assert.equal(paid.seller.country, "IN");
  assert.equal((await send("evt_wrong", "tax-intent", 1, 2242)).status, 400);
  insert("free-intent", {
    selected,
    total: 0,
    interval: "monthly",
    plan: null,
  });
  assert.equal(
    (await send("evt_free", "free-intent", 0, 0, "no_payment_required")).status,
    200,
  );
  assert.equal(
    (await send("evt_free_wrong", "tax-intent", 0, 0, "no_payment_required"))
      .status,
    400,
  );
  assert.equal(
    (await send("evt_free_unknown", "missing", 0, 0, "no_payment_required"))
      .status,
    400,
  );
});

test("production payment readiness refuses insecure or credential-bearing public origins", async (t) => {
  for (const origin of [
    "http://store.example",
    "https://user:pass@store.example",
    "https://store.example/embedded",
    "https://store.example?token=x",
  ]) {
    const f = await fixture(t, {
      production: true,
      stripeKey: "sk_test_origin_validation",
      webhookSecret: "whsec_local",
      publicUrl: origin,
    });
    assert.equal((await f.request("/api/config")).data.stripeConfigured, false);
  }
  const valid = await fixture(t, {
    production: true,
    stripeKey: "sk_test_origin_validation",
    webhookSecret: "whsec_local",
    publicUrl: "https://store.example/",
  });
  assert.equal(
    (await valid.request("/api/config")).data.stripeConfigured,
    true,
  );
});
