import test from "node:test";
import assert from "node:assert/strict";
import { mkdtempSync, rmSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { createApp } from "./index.mjs";

const brand = "RTR Digital";
const assertBrand = (product) => {
  for (const field of ["creator", "seller", "licensor"])
    assert.equal(product[field], brand, field);
};
const overrides = {
  creator: "Outside creator",
  seller: "Outside seller",
  licensor: "Outside licensor",
};

async function fixture(t) {
  const dataDir = mkdtempSync(join(tmpdir(), "rtr-brand-"));
  let instance, server, base;
  const start = async () => {
    instance = createApp({ dataDir });
    server = instance.app.listen(0, "127.0.0.1");
    await new Promise((resolve) => server.once("listening", resolve));
    base = `http://127.0.0.1:${server.address().port}`;
  };
  const stop = async () => {
    await new Promise((resolve) => server.close(resolve));
    instance.close();
  };
  await start();
  t.after(async () => {
    await stop();
    rmSync(dataDir, { recursive: true, force: true });
  });
  const client = () => {
    let cookie = "";
    return async (path, method = "GET", body) => {
      const form = body instanceof FormData;
      const response = await fetch(base + path, {
        method,
        headers: {
          ...(cookie ? { cookie } : {}),
          ...(body === undefined || form
            ? {}
            : { "content-type": "application/json" }),
        },
        ...(body === undefined
          ? {}
          : { body: form ? body : JSON.stringify(body) }),
      });
      if (response.headers.get("set-cookie"))
        cookie = response.headers.get("set-cookie").split(";")[0];
      const text = await response.text();
      return {
        status: response.status,
        data: response.headers.get("content-type")?.includes("application/json")
          ? JSON.parse(text)
          : text,
      };
    };
  };
  const admin = client();
  assert.equal(
    (await admin("/api/auth/demo", "POST", { role: "admin" })).status,
    200,
  );
  return {
    admin,
    client,
    get db() {
      return instance.db;
    },
    restart: async () => {
      await stop();
      await start();
    },
  };
}

const metadata = {
  title: "A licensed digital original",
  description: "An original digital product licensed and sold by RTR Digital.",
  category: "E-books",
  price: 12.5,
  ...overrides,
};

async function buyer(f) {
  const request = f.client();
  assert.equal(
    (
      await request("/api/auth/register", "POST", {
        name: "Brand Buyer",
        email: "buyer@brand.test",
        password: "A-secure-brand-password-2026",
      })
    ).status,
    201,
  );
  return request;
}

test("catalog and all publishing paths keep RTR Digital as seller and licensor", async (t) => {
  const f = await fixture(t);
  const catalog = (await f.client()("/api/catalog")).data.products;
  assert.ok(catalog.length > 0);
  catalog.forEach(assertBrand);
  f.db
    .prepare("SELECT payload FROM products")
    .all()
    .forEach((row) => assertBrand(JSON.parse(row.payload)));

  const form = new FormData();
  for (const [field, value] of Object.entries({
    ...metadata,
    status: "published",
  }))
    form.set(field, String(value));
  form.set("file", new Blob(["Licensed original bytes"]), "original.txt");
  const legacy = await f.admin("/api/admin/products", "POST", form);
  assert.equal(legacy.status, 201);
  assertBrand(legacy.data.product);
  const id = legacy.data.product.id;

  const draft = await f.admin("/api/publisher/products", "POST", metadata);
  assert.equal(draft.status, 201);
  assert.equal(draft.data.product.status, "draft");
  assertBrand(draft.data.product);

  for (const path of [
    `/api/admin/products/${id}`,
    `/api/publisher/products/${id}`,
  ]) {
    const updated = await f.admin(path, "PATCH", { ...overrides, price: 18 });
    assert.equal(updated.status, 200);
    assertBrand(updated.data.product);
    assertBrand(
      JSON.parse(
        f.db.prepare("SELECT payload FROM products WHERE id=?").get(id).payload,
      ),
    );
  }
  const imported = await f.admin("/api/publisher/import", "POST", {
    products: [{ id, ...overrides, price: 19 }],
  });
  assert.equal(imported.status, 200);
  assert.equal(imported.data.updated, 1);
  assertBrand(
    JSON.parse(
      f.db.prepare("SELECT payload FROM products WHERE id=?").get(id).payload,
    ),
  );

  const stored = JSON.parse(
    f.db.prepare("SELECT payload FROM products WHERE id=?").get(id).payload,
  );
  f.db
    .prepare("UPDATE products SET payload=? WHERE id=?")
    .run(JSON.stringify({ ...stored, ...overrides }), id);
  assertBrand((await f.client()(`/api/products/${id}`)).data.product);
  assertBrand((await f.admin(`/api/publisher/products/${id}`)).data.product);
});

test("commerce ignores seller overrides while retaining editable seller details and trusted checkout snapshots", async (t) => {
  const f = await fixture(t);
  const current = JSON.parse(
    f.db.prepare("SELECT payload FROM commerce_settings WHERE id=1").get()
      .payload,
  );
  f.db
    .prepare("UPDATE commerce_settings SET payload=? WHERE id=1")
    .run(
      JSON.stringify({
        ...current,
        sellerName: "Tampered seller",
        licensor: "Tampered licensor",
      }),
    );
  const read = await f.admin("/api/admin/commerce");
  assert.equal(read.data.settings.sellerName, brand);
  assert.equal(read.data.settings.licensor, brand);
  const updated = await f.admin("/api/admin/commerce/settings", "PATCH", {
    sellerName: "Requested outside seller",
    licensor: "Requested outside licensor",
    address: "42 Digital Street, India",
    taxId: "EDITABLE-TAX-123",
    supportEmail: "support@brand.test",
  });
  assert.equal(updated.status, 200);
  assert.equal(updated.data.settings.sellerName, brand);
  assert.equal(updated.data.settings.licensor, brand);
  assert.equal(updated.data.settings.address, "42 Digital Street, India");
  assert.equal(updated.data.settings.taxId, "EDITABLE-TAX-123");
  assert.equal(updated.data.settings.supportEmail, "support@brand.test");
  const request = await buyer(f);
  const checkout = await request("/api/checkout", "POST", {
    mode: "demo",
    productIds: ["studio-brand-kit"],
  });
  assert.equal(checkout.status, 200);
  const id = checkout.data.orderId;
  const order = JSON.parse(
    f.db.prepare("SELECT payload FROM orders WHERE id=?").get(id).payload,
  );
  assert.equal(order.seller.sellerName, brand);
  assert.equal(order.seller.licensor, brand);
  const receipt = await request(`/api/billing/orders/${id}/receipt`);
  assert.equal(receipt.status, 200);
  assert.match(receipt.data, /Seller: RTR Digital/);
  assert.match(receipt.data, /Licensor: RTR Digital/);
  assert.doesNotMatch(receipt.data, /Tampered|Requested outside/);
});

test("startup normalizes existing products and settings without rewriting historical payment snapshots", async (t) => {
  const f = await fixture(t);
  const draft = await f.admin("/api/publisher/products", "POST", metadata);
  assert.equal(draft.status, 201);
  for (const id of ["studio-brand-kit", draft.data.product.id]) {
    const product = JSON.parse(
      f.db.prepare("SELECT payload FROM products WHERE id=?").get(id).payload,
    );
    f.db
      .prepare("UPDATE products SET payload=? WHERE id=?")
      .run(JSON.stringify({ ...product, ...overrides }), id);
  }
  const settings = JSON.parse(
    f.db.prepare("SELECT payload FROM commerce_settings WHERE id=1").get()
      .payload,
  );
  f.db
    .prepare("UPDATE commerce_settings SET payload=? WHERE id=1")
    .run(
      JSON.stringify({
        ...settings,
        sellerName: "Existing seller",
        licensor: "Existing licensor",
        address: "Retained address",
      }),
    );
  const request = await buyer(f);
  const checkout = await request("/api/checkout", "POST", {
    mode: "demo",
    productIds: ["studio-brand-kit"],
  });
  assert.equal(checkout.status, 200);
  const id = checkout.data.orderId;
  const row = f.db.prepare("SELECT * FROM orders WHERE id=?").get(id);
  const historical = JSON.stringify({
    ...JSON.parse(row.payload),
    seller: {
      sellerName: "Historical seller",
      licensor: "Historical licensor",
      address: "Historical address",
    },
    paymentIntent: "pi_historical_evidence",
  });
  f.db.prepare("UPDATE orders SET payload=? WHERE id=?").run(historical, id);

  await f.restart();

  for (const id of ["studio-brand-kit", draft.data.product.id])
    assertBrand(
      JSON.parse(
        f.db.prepare("SELECT payload FROM products WHERE id=?").get(id).payload,
      ),
    );
  const normalized = JSON.parse(
    f.db.prepare("SELECT payload FROM commerce_settings WHERE id=1").get()
      .payload,
  );
  assert.equal(normalized.sellerName, brand);
  assert.equal(normalized.licensor, brand);
  assert.equal(normalized.address, "Retained address");
  const preserved = f.db.prepare("SELECT * FROM orders WHERE id=?").get(id);
  assert.equal(preserved.payload, historical);
  assert.equal(preserved.amount, row.amount);
  assert.equal(preserved.mode, row.mode);
  const receipt = await request(`/api/billing/orders/${id}/receipt`);
  assert.equal(receipt.status, 200);
  assert.match(receipt.data, /Seller: Historical seller/);
  assert.match(receipt.data, /Licensor: Historical licensor/);
});
