import test from "node:test";
import assert from "node:assert/strict";
import { createHash } from "node:crypto";
import {
  appendFileSync,
  existsSync,
  mkdtempSync,
  readFileSync,
  renameSync,
  rmSync,
  symlinkSync,
  unlinkSync,
  writeFileSync,
} from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { createApp } from "./index.mjs";

const checksum = (bytes) => createHash("sha256").update(bytes).digest("hex");

async function fixture(t, settings = {}) {
  const dataDir = mkdtempSync(join(tmpdir(), "rtr-resumable-"));
  const options = {
    dataDir,
    publishingUploadChunkBytes: 8,
    publishingMaxUploadBytes: 128,
    publishingMaxReservedBytes: 384,
    ...settings,
  };
  let instance;
  let server;
  let base;
  async function start() {
    instance = createApp(options);
    server = instance.app.listen(0, "127.0.0.1");
    await new Promise((resolve) => server.once("listening", resolve));
    base = `http://127.0.0.1:${server.address().port}`;
  }
  async function stop() {
    await new Promise((resolve) => server.close(resolve));
    instance.close();
  }
  await start();
  t.after(async () => {
    await stop();
    rmSync(dataDir, { recursive: true, force: true });
  });
  const client = () => {
    let cookie = "";
    return async (path, method = "GET", body, options = {}) => {
      const binary = Buffer.isBuffer(body);
      const response = await fetch(base + path, {
        method,
        headers: {
          ...(cookie ? { Cookie: cookie } : {}),
          ...(body !== undefined && !(body instanceof FormData)
            ? {
                "Content-Type": binary
                  ? "application/octet-stream"
                  : "application/json",
              }
            : {}),
          ...options.headers,
        },
        ...(body !== undefined
          ? {
              body:
                body instanceof FormData || binary
                  ? body
                  : JSON.stringify(body),
            }
          : {}),
      });
      if (response.headers.get("set-cookie"))
        cookie = response.headers.get("set-cookie").split(";")[0];
      return {
        status: response.status,
        headers: response.headers,
        data: options.raw ? await response.text() : await response.json(),
      };
    };
  };
  const admin = client();
  assert.equal(
    (await admin("/api/auth/demo", "POST", { role: "admin" })).status,
    200,
  );
  return {
    admin,
    client,
    dataDir,
    get db() {
      return instance.db;
    },
    restart: async () => {
      await stop();
      await start();
    },
  };
}

async function original(admin) {
  const form = new FormData();
  for (const [key, value] of Object.entries({
    title: "Resumable original notes",
    description:
      "Original licensed content used to verify protected resumable publishing.",
    category: "E-books",
    price: "12.50",
    status: "published",
  }))
    form.set(key, value);
  form.set(
    "file",
    new Blob(["original bytes"], { type: "text/plain" }),
    "original.txt",
  );
  const result = await admin("/api/admin/products", "POST", form);
  assert.equal(result.status, 201);
  return result.data.product;
}

async function register(client, email) {
  const request = client();
  const result = await request("/api/auth/register", "POST", {
    name: "Resumable reader",
    email,
    password: "resumable-test-password-2026",
  });
  assert.equal(result.status, 201);
  return { request, user: result.data.user };
}

async function initialize(admin, productId, overrides = {}) {
  return admin(`/api/publisher/products/${productId}/uploads`, "POST", {
    version: "2.0.0",
    changelog: "Improved original edition.",
    filename: "release.txt",
    totalBytes: 17,
    ...overrides,
  });
}

async function chunk(request, uploadId, offset, bytes, headers = {}) {
  return request(
    `/api/publisher/uploads/${uploadId}/chunk`,
    "PUT",
    Buffer.from(bytes),
    { headers: { "Upload-Offset": String(offset), ...headers } },
  );
}

async function sendAll(admin, upload, bytes) {
  let offset = upload.receivedBytes;
  while (offset < bytes.length) {
    const response = await chunk(
      admin,
      upload.id,
      offset,
      bytes.subarray(offset, offset + upload.chunkBytes),
    );
    assert.equal(response.status, 200);
    offset = response.data.upload.receivedBytes;
  }
}

test("resumable releases survive restart, enforce sequential offsets and preserve authenticated release history", async (t) => {
  const f = await fixture(t);
  const p = await original(f.admin);
  const buyer = (await register(f.client, "resumable-buyer@example.test"))
    .request;
  assert.equal(
    (await buyer("/api/checkout", "POST", { productIds: [p.id], mode: "demo" }))
      .status,
    200,
  );
  const bytes = Buffer.from("all original release bytes");
  const capabilities = await f.admin("/api/publisher/upload-capabilities");
  assert.equal(capabilities.data.chunkBytes, 8);
  assert.equal(capabilities.data.maxBytes, 128);
  const initialized = await initialize(f.admin, p.id, {
    totalBytes: bytes.length,
    sha256: checksum(bytes).toUpperCase(),
  });
  assert.equal(initialized.status, 201);
  let upload = initialized.data.upload;
  assert.equal(upload.expectedSha256, checksum(bytes));
  assert.equal(
    (await chunk(f.admin, upload.id, 4, bytes.subarray(0, 8))).status,
    409,
  );
  assert.equal(
    (await chunk(f.admin, upload.id, 0, bytes.subarray(0, 8))).data.upload
      .receivedBytes,
    8,
  );
  assert.equal(
    (await chunk(f.admin, upload.id, 0, bytes.subarray(0, 8))).status,
    409,
  );
  assert.equal(
    (await f.admin(`/api/publisher/uploads/${upload.id}/finalize`, "POST"))
      .status,
    409,
  );
  await f.restart();
  upload = (await f.admin(`/api/publisher/uploads/${upload.id}`)).data.upload;
  assert.equal(upload.receivedBytes, 8);
  assert.equal(upload.status, "uploading");
  assert.equal(
    (await f.admin(`/api/publisher/uploads?productId=${p.id}`)).data.uploads
      .length,
    1,
  );
  await sendAll(f.admin, upload, bytes);
  const finalized = await f.admin(
    `/api/publisher/uploads/${upload.id}/finalize`,
    "POST",
  );
  assert.equal(finalized.status, 201);
  assert.equal(finalized.data.version.checksum, checksum(bytes));
  assert.equal(finalized.data.version.bytes, bytes.length);
  assert.equal(finalized.data.upload.status, "completed");
  const retry = await f.admin(
    `/api/publisher/uploads/${upload.id}/finalize`,
    "POST",
  );
  assert.equal(retry.status, 200);
  assert.equal(retry.data.version.id, finalized.data.version.id);
  assert.equal(
    (await f.admin(`/api/publisher/uploads/${upload.id}`, "DELETE")).status,
    409,
  );
  assert.equal(
    (await f.admin(`/api/publisher/uploads?productId=${p.id}`)).data.uploads
      .length,
    0,
  );
  const versions = (await f.admin(`/api/publisher/products/${p.id}`)).data
    .versions;
  assert.equal(versions.length, 2);
  const oldVersion = versions.find((version) => version.version === "original");
  assert.ok(oldVersion);
  assert.equal(oldVersion.checksum, checksum("original bytes"));
  assert.equal(
    (await buyer(`/api/download/${p.id}`, "GET", undefined, { raw: true }))
      .data,
    bytes.toString(),
  );
  assert.equal(
    (
      await buyer(
        `/api/products/${p.id}/releases/${oldVersion.id}/download`,
        "GET",
        undefined,
        { raw: true },
      )
    ).data,
    "original bytes",
  );
  assert.equal(
    (await f.client()(`/api/download/${p.id}`, "GET", undefined, { raw: true }))
      .status,
    401,
  );
  assert.equal(
    (
      await f.client()(
        `/api/products/${p.id}/releases/${oldVersion.id}/download`,
        "GET",
        undefined,
        { raw: true },
      )
    ).status,
    401,
  );
  const notifications = (await buyer("/api/library/releases")).data
    .notifications;
  assert.equal(
    notifications.filter((notification) => notification.version === "2.0.0")
      .length,
    1,
  );
  const released = f.db
    .prepare("SELECT file_path FROM products WHERE id=?")
    .get(p.id);
  assert.equal(
    readFileSync(join(f.dataDir, "uploads", released.file_path)).toString(),
    bytes.toString(),
  );
  assert.equal(
    existsSync(join(f.dataDir, "upload-sessions", `${upload.id}.part`)),
    false,
  );
});

test("every resumable endpoint requires the same administrator and cancel removes private bytes", async (t) => {
  const f = await fixture(t);
  const p = await original(f.admin);
  const second = await register(f.client, "second-upload-admin@example.test");
  const customer = await register(f.client, "upload-customer@example.test");
  f.db.prepare("UPDATE users SET role='admin' WHERE id=?").run(second.user.id);
  const initialized = await initialize(f.admin, p.id);
  assert.equal(initialized.status, 201);
  const { id } = initialized.data.upload;
  for (const [request, status] of [
    [f.client(), 401],
    [customer.request, 403],
  ]) {
    assert.equal(
      (await request("/api/publisher/upload-capabilities")).status,
      status,
    );
    assert.equal((await request("/api/publisher/uploads")).status, status);
    assert.equal((await initialize(request, p.id)).status, status);
    assert.equal(
      (await request(`/api/publisher/uploads/${id}`)).status,
      status,
    );
    assert.equal((await chunk(request, id, 0, "first")).status, status);
    assert.equal(
      (await request(`/api/publisher/uploads/${id}/finalize`, "POST")).status,
      status,
    );
    assert.equal(
      (await request(`/api/publisher/uploads/${id}`, "DELETE")).status,
      status,
    );
  }
  assert.equal(
    (await second.request("/api/publisher/uploads")).data.uploads.length,
    0,
  );
  assert.equal(
    (await second.request(`/api/publisher/uploads/${id}`)).status,
    404,
  );
  assert.equal((await chunk(second.request, id, 0, "stolen")).status, 404);
  assert.equal(
    (await second.request(`/api/publisher/uploads/${id}/finalize`, "POST"))
      .status,
    404,
  );
  assert.equal(
    (await second.request(`/api/publisher/uploads/${id}`, "DELETE")).status,
    404,
  );
  assert.equal((await chunk(f.admin, id, 0, "first")).status, 200);
  const part = join(f.dataDir, "upload-sessions", `${id}.part`);
  assert.equal(existsSync(part), true);
  assert.equal(
    (await f.admin(`/api/publisher/uploads/${id}`, "DELETE")).status,
    200,
  );
  assert.equal(existsSync(part), false);
  assert.equal(
    (await f.admin(`/api/publisher/uploads/${id}`)).data.upload.status,
    "canceled",
  );
  assert.equal((await chunk(f.admin, id, 5, "more")).status, 409);
  assert.equal(
    (await f.admin(`/api/publisher/uploads/${id}/finalize`, "POST")).status,
    409,
  );
});

test("resumable init validates byte, filename, checksum and configured reservation limits", async (t) => {
  const f = await fixture(t, { publishingMaxReservedBytes: 20 });
  const p = await original(f.admin);
  for (const invalid of [
    { totalBytes: 0 },
    { totalBytes: 129 },
    { totalBytes: 1.5 },
    { filename: "../secret.txt" },
    { filename: "a\\b.txt" },
    { filename: "a\u0000.txt" },
    { sha256: "untrusted" },
    { version: "../2" },
  ]) {
    assert.equal((await initialize(f.admin, p.id, invalid)).status, 400);
  }
  const first = await initialize(f.admin, p.id, { totalBytes: 12 });
  assert.equal(first.status, 201);
  assert.equal(
    (await initialize(f.admin, p.id, { version: "3.0.0", totalBytes: 9 }))
      .status,
    413,
  );
  assert.equal(
    (await chunk(f.admin, first.data.upload.id, 0, Buffer.alloc(9))).status,
    413,
  );
  assert.equal(
    (await chunk(f.admin, first.data.upload.id, 0, Buffer.alloc(0))).status,
    400,
  );
  assert.equal(
    (await chunk(f.admin, first.data.upload.id, 0, "12345678")).status,
    200,
  );
  assert.equal(
    (await chunk(f.admin, first.data.upload.id, 8, "12345")).status,
    400,
  );
  assert.equal(
    (await f.admin(`/api/publisher/uploads/${first.data.upload.id}`, "DELETE"))
      .status,
    200,
  );
  assert.equal(
    (await initialize(f.admin, p.id, { version: "3.0.0", totalBytes: 9 }))
      .status,
    201,
  );
});

test("three active uploads are allowed and stale uploads expire with their private bytes", async (t) => {
  const f = await fixture(t);
  const p = await original(f.admin);
  const uploads = [];
  for (let i = 0; i < 3; i++) {
    const result = await initialize(f.admin, p.id, { version: `active-${i}` });
    assert.equal(result.status, 201);
    uploads.push(result.data.upload);
  }
  assert.equal(
    (await initialize(f.admin, p.id, { version: "active-4" })).status,
    409,
  );
  f.db
    .prepare("UPDATE product_upload_sessions SET updated_at=? WHERE id=?")
    .run(new Date(Date.now() - 49 * 3600000).toISOString(), uploads[0].id);
  const active = await f.admin("/api/publisher/uploads");
  assert.equal(active.data.uploads.length, 2);
  assert.equal(
    (await f.admin(`/api/publisher/uploads/${uploads[0].id}`)).data.upload
      .status,
    "expired",
  );
  assert.equal(
    existsSync(join(f.dataDir, "upload-sessions", `${uploads[0].id}.part`)),
    false,
  );
  assert.equal(
    (await initialize(f.admin, p.id, { version: "active-4" })).status,
    201,
  );
});

test("checksum failure never changes the current release or exposes partial bytes", async (t) => {
  const f = await fixture(t);
  const p = await original(f.admin);
  const initialized = await initialize(f.admin, p.id, {
    totalBytes: 8,
    sha256: checksum("intended"),
  });
  const upload = initialized.data.upload;
  await sendAll(f.admin, upload, Buffer.from("tampered"));
  assert.equal(
    (await f.admin(`/api/publisher/uploads/${upload.id}/finalize`, "POST"))
      .status,
    422,
  );
  const status = (await f.admin(`/api/publisher/uploads/${upload.id}`)).data
    .upload;
  assert.equal(status.status, "failed");
  assert.match(status.error, /checksum/i);
  assert.equal(
    (await f.admin(`/api/publisher/products/${p.id}`)).data.versions.length,
    0,
  );
  const stored = f.db
    .prepare("SELECT file_path FROM products WHERE id=?")
    .get(p.id);
  assert.equal(
    readFileSync(join(f.dataDir, "uploads", stored.file_path)).toString(),
    "original bytes",
  );
  assert.notEqual(
    (
      await f.client()(`/uploads/${stored.file_path}`, "GET", undefined, {
        raw: true,
      })
    ).data,
    "original bytes",
  );
  assert.notEqual(
    (
      await f.client()(`/upload-sessions/${upload.id}.part`, "GET", undefined, {
        raw: true,
      })
    ).data,
    "tampered",
  );
  assert.equal(
    (await f.admin(`/api/publisher/uploads/${upload.id}`, "DELETE")).status,
    200,
  );
});

test("restart recovers an interrupted finalization and a chunk written beyond its committed offset", async (t) => {
  const f = await fixture(t);
  const p = await original(f.admin);
  const bytes = Buffer.from("one-two-three");
  const upload = (
    await initialize(f.admin, p.id, {
      totalBytes: bytes.length,
      sha256: checksum(bytes),
    })
  ).data.upload;
  assert.equal(
    (await chunk(f.admin, upload.id, 0, bytes.subarray(0, 8))).status,
    200,
  );
  appendFileSync(
    join(f.dataDir, "upload-sessions", `${upload.id}.part`),
    "uncommitted tail",
  );
  await f.restart();
  const recovered = (await f.admin(`/api/publisher/uploads/${upload.id}`)).data
    .upload;
  assert.equal(recovered.receivedBytes, 8);
  await sendAll(f.admin, recovered, bytes);
  f.db
    .prepare(
      "UPDATE product_upload_sessions SET status='finalizing' WHERE id=?",
    )
    .run(upload.id);
  await f.restart();
  assert.equal(
    (await f.admin(`/api/publisher/uploads/${upload.id}`)).data.upload.status,
    "uploading",
  );
  const released = await f.admin(
    `/api/publisher/uploads/${upload.id}/finalize`,
    "POST",
  );
  assert.equal(released.status, 201);
  assert.equal(released.data.version.checksum, checksum(bytes));
});

test("a replaced staging symlink cannot write or publish a file outside the session", async (t) => {
  const f = await fixture(t);
  const p = await original(f.admin);
  const upload = (await initialize(f.admin, p.id, { totalBytes: 8 })).data
    .upload;
  const target = join(f.dataDir, "protected-local.txt");
  const part = join(f.dataDir, "upload-sessions", `${upload.id}.part`);
  writeFileSync(target, "untouched");
  unlinkSync(part);
  symlinkSync(target, part);
  const result = await chunk(f.admin, upload.id, 0, "injected");
  assert.ok(result.status >= 400 && result.status < 500);
  assert.equal(readFileSync(target, "utf8"), "untouched");
  assert.equal(
    (await f.admin(`/api/publisher/uploads/${upload.id}/finalize`, "POST"))
      .status,
    409,
  );
  assert.equal(
    (await f.admin(`/api/publisher/uploads/${upload.id}`, "DELETE")).status,
    200,
  );
  assert.equal(readFileSync(target, "utf8"), "untouched");
});

test("restart restores bytes moved to a release destination before the database commit", async (t) => {
  const f = await fixture(t);
  const p = await original(f.admin);
  const bytes = Buffer.from("durable bytes");
  const upload = (
    await initialize(f.admin, p.id, {
      totalBytes: bytes.length,
      sha256: checksum(bytes),
    })
  ).data.upload;
  await sendAll(f.admin, upload, bytes);
  const part = join(f.dataDir, "upload-sessions", `${upload.id}.part`);
  const destination = join(f.dataDir, "uploads", `release-${upload.id}.txt`);
  f.db
    .prepare(
      "UPDATE product_upload_sessions SET status='finalizing' WHERE id=?",
    )
    .run(upload.id);
  renameSync(part, destination);
  await f.restart();
  assert.equal(existsSync(part), true);
  assert.equal(existsSync(destination), false);
  assert.equal(
    (await f.admin(`/api/publisher/uploads/${upload.id}`)).data.upload.status,
    "uploading",
  );
  const finalized = await f.admin(
    `/api/publisher/uploads/${upload.id}/finalize`,
    "POST",
  );
  assert.equal(finalized.status, 201);
  assert.equal(finalized.data.version.checksum, checksum(bytes));
  assert.equal(readFileSync(destination).toString(), bytes.toString());
});

test("a new metadata-only draft becomes purchasable only after its original is uploaded and published", async (t) => {
  const f = await fixture(t);
  const buyer = (await register(f.client, "new-original-buyer@example.test"))
    .request;
  const metadata = {
    title: "An original from the beginning",
    description:
      "A complete original digital work with a resumable release and an intentional publication step.",
    category: "E-books",
    price: 14.25,
    creator: "Original Author",
    subscriptionIncluded: false,
  };
  assert.equal(
    (await f.client()("/api/publisher/products", "POST", metadata)).status,
    401,
  );
  assert.equal(
    (await buyer("/api/publisher/products", "POST", metadata)).status,
    403,
  );
  for (const invalid of [
    { title: "" },
    { description: "too short" },
    { category: "unknown" },
    { price: -1 },
    { price: "14.25" },
    { subscriptionIncluded: "true" },
    { status: "published" },
  ]) {
    assert.equal(
      (
        await f.admin("/api/publisher/products", "POST", {
          ...metadata,
          ...invalid,
        })
      ).status,
      400,
    );
  }
  const created = await f.admin("/api/publisher/products", "POST", metadata);
  assert.equal(created.status, 201);
  const p = created.data.product;
  assert.equal(p.status, "draft");
  assert.equal(p.subscriptionIncluded, false);
  assert.equal(
    f.db.prepare("SELECT file_path FROM products WHERE id=?").get(p.id)
      .file_path,
    null,
  );
  assert.equal(
    (
      await f.admin(`/api/publisher/products/${p.id}`, "PATCH", {
        status: "published",
      })
    ).status,
    400,
  );
  assert.equal(
    (
      await f.admin(`/api/publisher/products/${p.id}`, "PATCH", {
        scheduledAt: new Date(Date.now() + 3600000).toISOString(),
      })
    ).status,
    400,
  );
  assert.equal(
    (
      await f.admin("/api/publisher/import", "POST", {
        products: [{ id: p.id, status: "published" }],
      })
    ).status,
    400,
  );
  assert.equal((await f.client()(`/api/products/${p.id}`)).status, 404);
  assert.equal(
    (await buyer("/api/checkout", "POST", { productIds: [p.id], mode: "demo" }))
      .status,
    400,
  );
  const bytes = Buffer.from("first original release: exact paid content");
  const initialized = await initialize(f.admin, p.id, {
    version: "1.0.0",
    totalBytes: bytes.length,
    sha256: checksum(bytes),
  });
  assert.equal(initialized.status, 201);
  await sendAll(f.admin, initialized.data.upload, bytes);
  const finalized = await f.admin(
    `/api/publisher/uploads/${initialized.data.upload.id}/finalize`,
    "POST",
  );
  assert.equal(finalized.status, 201);
  assert.equal(finalized.data.version.checksum, checksum(bytes));
  const details = (await f.admin(`/api/publisher/products/${p.id}`)).data;
  assert.equal(details.product.status, "draft");
  assert.equal(details.product.isSample, false);
  assert.equal(details.versions.length, 1);
  assert.equal(
    (await buyer("/api/checkout", "POST", { productIds: [p.id], mode: "demo" }))
      .status,
    400,
  );
  const published = await f.admin(`/api/publisher/products/${p.id}`, "PATCH", {
    status: "published",
  });
  assert.equal(published.status, 200);
  assert.equal(published.data.product.status, "published");
  assert.equal((await f.client()(`/api/products/${p.id}`)).status, 200);
  assert.equal(
    (await buyer("/api/checkout", "POST", { productIds: [p.id], mode: "demo" }))
      .status,
    200,
  );
  assert.equal(
    (await buyer(`/api/download/${p.id}`, "GET", undefined, { raw: true }))
      .data,
    bytes.toString(),
  );
  assert.equal(
    (
      await buyer(
        `/api/products/${p.id}/releases/${finalized.data.version.id}/download`,
        "GET",
        undefined,
        { raw: true },
      )
    ).data,
    bytes.toString(),
  );
});
