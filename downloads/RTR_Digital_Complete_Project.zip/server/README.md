# RTR Digital commerce API

Node.js 24+, Express 5, and the built-in `node:sqlite` database power the storefront. Run commands from the repository root. The application uses `data/rtr.sqlite` and `data/uploads/` by default. Keep this directory private, persistent, and backed up; it contains customer records and original digital files. Do not put it under the public document root.

## Development

```sh
npm ci
npm run dev
```

The API listens on port 3001 (override with `API_PORT`); Vite forwards `/api` requests to it. Node automatically creates the database and seeds 12 **sample** catalog entries. Sample product downloads are clearly labeled text files for testing, not the advertised full digital assets. Admin uploads are stored and delivered as their actual file contents.

RTR Digital is the sole seller and licensor. Catalog serialization, original uploads, draft creation, metadata edits/imports and commerce settings enforce this fixed identity. Startup normalizes prior catalog attribution; requests cannot introduce another seller or licensor. Legal address, tax registration, support contact and receipt prefix remain editable. Previously captured order/seller snapshots are retained as historical financial evidence.

Development demo access is enabled unless `DEMO_MODE=false`. The sign-in dialog can create a shared demo customer or demo administrator session without collecting a password. Demo checkout records a simulated order and grants development access, but never takes money. Do not expose development/demo mode as a public commerce service. `NODE_ENV=production` always disables demo access and demo payments regardless of `DEMO_MODE`. Production also refuses sessions from the shared demo accounts, demo subscriptions, and demo purchase entitlements retained in an existing development database. Real registered accounts remain usable; verified live gateway purchases, reconciled live wire purchases and eligible trusted membership access are honored in production.

Tests create isolated temporary databases and upload directories, start the actual HTTP server, exercise it with real requests, and remove the fixtures afterwards:

```sh
node --test server/*.test.mjs
```

## Production and real payments

```sh
npm ci
npm run build
NODE_ENV=production npm start
```

The API serves `dist/` when a build exists. Put it behind HTTPS and a trusted reverse proxy. Production cookies have `Secure`, `HttpOnly`, and `SameSite=Lax` enabled. Configure `PUBLIC_URL` to the final HTTPS origin, not a development port. Back up the SQLite database with a SQLite-aware backup process and the complete uploads directory; use persistent storage. The current SQLite design supports one application instance. Horizontal replicas need a shared database and object-storage implementation before scaling.

Set these values securely in the hosting environment; never commit them:

- `ADMIN_EMAIL`: administrator email for initial creation.
- `ADMIN_PASSWORD`: initial administrator password, at least 12 characters. Passwords are salted and scrypt hashed; it is only used to create the account if the email is not already registered. Remove the bootstrap password from runtime configuration after provisioning. Never create an administrator by registering through the storefront.
- `STRIPE_SECRET_KEY`: Stripe test-mode key for integration validation, then a live-mode key for launch.
- `STRIPE_WEBHOOK_SECRET`: signing secret for the webhook endpoint.
- `PUBLIC_URL`: storefront HTTPS origin.
- `DATA_DIR`: optional absolute path to persistent private storage.

Register `POST /api/stripe/webhook` with Stripe for:

- `checkout.session.completed`
- `checkout.session.async_payment_succeeded`
- `customer.subscription.updated`
- `customer.subscription.deleted`
- `checkout.session.expired`

A redirect from Stripe does not grant access. The signed webhook must match a known server-side checkout intent and the recorded amount. Paid orders and access grants are applied together in a SQLite transaction. Webhook IDs and checkout IDs prevent duplicate fulfillment. One-time product prices and product titles are snapshotted when checkout is created. Stripe subscriptions are fulfilled from paid checkout events only after their billing state is retrieved successfully from Stripe. Subsequent status events re-read the current subscription from Stripe rather than trusting potentially out-of-order event payloads. The authoritative access period and status control downloads. Live membership checkout holds a 31-minute per-account checkout lock, preventing another pending checkout for the same account; retry with the same idempotency key or complete the original session. An expired-session webhook releases the lock.

Publish original, licensed files through the administrator workspace before accepting real payments. Live checkout rejects sample products and memberships containing no original published products. The API reports live payments as configured only when the key, webhook secret, and public URL are all present; this reports configuration presence, not external Stripe connectivity. End-to-end live Stripe processing still requires a reachable HTTPS deployment and test-mode checkout verification. Configure Stripe Billing's customer portal before using `/api/billing/portal`.

Customer refund requests and administrator approve/deny actions are implemented in Billing/Commerce office. Live refunds use Stripe idempotency, retain access while confirmation is pending, and reconcile signed refund events. Provider disputes/chargebacks and statutory accounting still require the merchant's operational process. The support queue is local. Account verification/recovery and optional renewal email use a configured Resend transport; a private development mailbox is used without credentials. Support responses and marketing campaigns are not automatically sent. Configure an email delivery service and administrator notification workflow before advertising email support. Taxes, jurisdiction-specific consumer disclosures, invoicing, malware scanning/quarantine, cloud file storage/CDN, production monitoring, and disaster recovery procedures require deployment-specific integrations before commercial launch. Standard multipart uploads are capped at 100 MB (covers at 10 MB). Draft-first resumable releases support a configurable 5 GiB default maximum, bounded chunks and disk reservations; there is no claim of unlimited storage.

## Main routes

All account routes use a secure cookie session. No passwords, session tokens, private file paths, or API keys are returned by JSON APIs.

| Route                                          | Purpose                                                                        |
| ---------------------------------------------- | ------------------------------------------------------------------------------ |
| `GET /api/health`, `GET /api/config`           | Service status and public capabilities                                         |
| `GET /api/catalog?q=&category=`                | Published catalog, search, categories                                          |
| `GET /api/products/:id`                        | Published product details                                                      |
| `POST /api/auth/register`, `/login`, `/logout` | Account and session lifecycle                                                  |
| `GET /api/auth/me`                             | Current user and subscription                                                  |
| `POST /api/auth/demo`                          | Development-only customer/admin sign-in                                        |
| `GET /api/library`                             | Entitled products, orders, subscription                                        |
| `GET /api/download/:id`                        | Authenticated file delivery; purchase or active membership required            |
| `GET`, `PUT /api/wishlist`                     | Persisted favorites                                                            |
| `POST /api/checkout`                           | Server-priced demo checkout or Stripe Checkout URL                             |
| `POST /api/subscription/change`                | Immediate, uncharged demo change; live changes go to Stripe Billing for review |
| `POST /api/subscription/cancel`, `/resume`     | Schedule/undo period-end cancellation                                          |
| `POST /api/billing/portal`                     | Live Stripe customer billing portal                                            |
| `POST /api/newsletter`                         | Persisted opt-in email capture                                                 |
| `POST /api/support`                            | Persisted support ticket                                                       |
| `GET`, `POST /api/reviews/:id`                 | Read reviews; only entitled customers can write                                |
| `GET /api/account/export`                      | Account JSON download, without credentials                                     |
| `GET /api/admin/stats`, `/products`            | Administrator catalog and operational metrics                                  |
| `POST /api/admin/products`                     | Multipart file + optional cover upload, initially draft                        |
| `PATCH /api/admin/products/:id`                | Publish/unpublish, price, membership inclusion                                 |
| `PATCH /api/admin/tickets/:id`                 | Mark a support ticket open/resolved                                            |

Checkout accepts `{ productIds, mode: 'demo' | 'stripe', coupon? }` or `{ plan: 'starter' | 'creator' | 'studio', interval: 'monthly' | 'yearly', mode }`. Buy memberships separately from one-time cart items. `WELCOME10` and `RTR20` are built-in demonstration promotions; adjust the promotion configuration for real business needs. For one-time products, discounts are rounded per item in integer cents, matching Stripe line items. If applied to a membership, the discounted price is the recurring price for **every renewal**, not a first-period-only discount; there is no automatic expiration or one-use enforcement in this demonstration promotion system. Optional `Idempotency-Key` headers contain 8–128 alphanumeric, hyphen, or underscore characters and must be unique per intended order. Reusing a key returns the original completed order.

Explorer, Creator, and Studio plans cost $9/$19/$39 monthly or $84/$180/$372 yearly. All currently unlock the subscription-included catalog. Creator is a customer tier. Studio includes a five-seat customer workspace, managed through the expanded membership APIs below; it does not create seller accounts. License/support/team descriptions must reflect RTR Digital's actual policy. Canceled memberships retain access until `currentPeriodEnd`. Expired or non-active subscriptions lose membership-only downloads. Individually purchased products remain available. Demo plan changes apply immediately without a charge, start a fresh calendar billing period today, and clear scheduled cancellation. Monthly and yearly dates clamp correctly to the last valid day in short months and non-leap years. Live plan changes redirect to Stripe's customer portal, where available changes and proration must be configured and reviewed; the local plan changes only after verified billing events. Unpublished drafts never become accessible through a membership; an existing individual purchase retains its original access even when the product is later unpublished.

Upload multipart fields: `title`, `description`, `category`, `price`, `subscriptionIncluded`, `file`, optional `cover` and `status`. Seller/licensor attribution is always RTR Digital; the legacy `creator` field cannot override it. Allowed categories are returned by the catalog API. Cover images must have valid PNG/JPEG/WebP signatures and matching filename extensions. Product files are private and delivered through authenticated downloads or supported inline original viewing. Publish/unpublish preserves existing order records and purchased entitlements. Uploaded executables are not automatically malware-scanned; deploy an appropriate quarantine/scanning pipeline before selling software.

## Expanded account, membership, publishing and commerce APIs

These modules are registered before the original endpoints and share the same authenticated user, transaction database and entitlement checks.

| Routes                                                                                    | Capability                                                                                             |
| ----------------------------------------------------------------------------------------- | ------------------------------------------------------------------------------------------------------ |
| `GET /api/account/settings`, `PATCH /api/account/profile`                                 | Profile, verified-email status, preferences, sessions and owner-private development mail               |
| `POST /api/account/password`, `/api/auth/forgot-password`, `/api/auth/reset-password`     | Reauthenticated password changes and single-use expiring recovery                                      |
| `POST /api/account/verification/send`, `/api/auth/verify-email`                           | Email ownership confirmation                                                                           |
| `/api/account/mfa/*`, `POST /api/auth/mfa`                                                | Authenticator enrollment, challenge completion, one-use recovery codes and disable controls            |
| `/api/account/sessions/*`, `/api/account/preferences`, `/api/account/notifications/*`     | Session revocation, timestamped consent, persisted notices                                             |
| `DELETE /api/account`                                                                     | Reauthenticated anonymization/removal with financial-record retention and owned-team closure           |
| `GET /api/membership/hub`, `POST /api/membership/trial`, `/api/membership/trial/end`      | Trial eligibility, activity, expiry and nonrenewing no-card access                                     |
| `/api/membership/team/*`, `/api/admin/billing-health`                                     | Five-seat Studio workspaces, secure invitations, access revocation and live/demo/trial billing metrics |
| `/api/publisher/products`, `/api/publisher/products/:id`                                  | Draft-first creation and full metadata editing                                                         |
| `POST /api/publisher/import`, `/api/publisher/products/:id/releases`                      | Transactional existing-record imports and versioned file releases                                      |
| `/api/publisher/uploads/*`, `POST /api/publisher/products/:id/uploads`                    | Persistent resumable releases; offset validation, capacity checks, SHA-256 and crash recovery          |
| `/api/publisher/products/:id/preview`, `/api/products/:id/preview`                        | Separately designated public media samples                                                             |
| `/api/products/:id/content-info`, `/api/products/:id/content`                             | Authenticated full-original viewing with range/HEAD support; unsupported formats remain downloads      |
| `/api/products/:id/experience`, `/api/products/:id/progress`                              | Versions, checksums, course/media bookmarks, completion and private notes                              |
| `/api/publisher/products/:id/licenses`, `/api/products/:id/license`                       | Encrypted administrator key inventory and unique entitled-user assignments                             |
| `/api/publisher/reviews/*`, `/api/reviews/:id/report`                                     | Review moderation and reports                                                                          |
| `POST /api/checkout/quote`, `/api/admin/commerce/promotions/*`                            | Trusted dynamic promotions with dates/scopes/limits and concurrent reservations                        |
| `/api/billing/orders/*`, `/api/admin/commerce/refunds/*`                                  | Private payment receipts and actual refund decisions/reconciliation                                    |
| `/api/admin/commerce`, `/api/admin/commerce/settings`, `/api/admin/commerce/export/:type` | Financial activity, immutable seller snapshots, India/global USD settings and operational CSV exports  |
| `/robots.txt`, `/sitemap.xml`, `/products/:id`                                            | Origin-aware discovery and escaped structured product metadata; production hides illustrative samples  |

API handlers validate the relevant shapes; consult the corresponding module source for exact request fields. A printable payment receipt does not imply a statutory GST/export invoice.

### Additional payment providers and wire reconciliation

`server/modules/payments.mjs` adds PayPal Orders v2, Razorpay hosted payment links and manual USD wire reconciliation. `GET /api/payments/methods` returns available methods without account details. `GET /api/admin/payments` returns masked configuration and the private bank queue; `PATCH /api/admin/payments/settings` requires administrator password reauthentication (shared development demo excepted). Secrets are write-only, blank preserves stored credentials, and explicit remove flags remove them. `POST /api/admin/payments/bank/reveal` requires reauthentication and audits the reveal. Encrypted settings and per-order account snapshots use `data/.payment-encryption-key`.

`POST /api/payments/checkout` accepts provider, product IDs or plan/interval, coupon and a required Idempotency-Key. The stored USD quote and original provider/bank configuration control fulfillment. `GET /api/payments/orders` and `GET /api/payments/orders/:id` are owner-private. `POST /api/payments/orders/:id/verify` retrieves authoritative provider state; PayPal capture is server-side and checked before and after capture. `POST /api/payments/orders/:id/notify` records a customer's wire reference without granting access.

`POST /api/admin/payments/orders/:id/confirm` requires a password, exact receivedAmount, currency USD, unique bankReference and `cleared: true`. Rejection uses the sibling `/reject` endpoint with password and note. Wire orders reserve their immutable instructions for seven days. Expired or ambiguous payments do not grant access. Provider calls are bounded, use fixed HTTPS API hosts and retain an uncertain creation's idempotency record. Account changes affect new orders; pending verification/refunds use original encrypted credentials. Sandbox/development orders fulfill in demo mode and cannot become valid production entitlements.

Stripe is the recurring provider; PayPal/Razorpay/wire memberships are prepaid fixed terms with no automatic renewal or free plan-change extension. Verified external paid modes are included in production delivery, receipts and financial totals. Prepaid terms are excluded from MRR. PayPal/Razorpay refunds delegate to original provider records and preserve access while pending. Wire approvals record an already-cleared bank repayment using `bankRefundConfirmed`, refundedAmount, USD currency, unique bankReference and administrator password; they do not transfer bank funds. An uncertain Razorpay refund attempt requires provider reconciliation rather than blind resubmission.

Provider merchant onboarding, gateway payout-bank verification, actual international USD eligibility and external settlement remain account operations. See [payment guide](../docs/PAYMENTS_GUIDE.md) for setup and supported boundaries.

### Production no-card trials

Production trials are disabled unless `TRIALS_ENABLED=true`. When enabled, a verified account and original published membership content are required. The seven-day trial is nonrenewing, never collects a card and cannot replace an unresolved Stripe subscription. Paid conversion requires explicit hosted checkout and signed fulfillment. Trial access and demo activity are excluded from live MRR.

### Email and encryption keys

`RESEND_API_KEY`, a verified `EMAIL_FROM`, and HTTPS `PUBLIC_URL` enable real account email. Values belong in the deployment secret store, never source files. Development mail previews require the owning authenticated user or administrator and are unavailable in production. Configured transport presence is not proof of external delivery.

Back up `data/.account-encryption-key`, `data/license-key-master` and `data/.payment-encryption-key` along with the SQLite database and original/versioned uploads. An optional `ACCOUNT_ENCRYPTION_KEY` must be chosen before initial MFA enrollment and kept stable; do not switch key sources without migrating existing encrypted records. The server rejects public/dist data directories and development denies serving private files.

### India and international USD sales

The seller and licensor is RTR Digital, the business country is India and prices are USD. Set actual business address, tax and contact details in Commerce office. Enable `STRIPE_AUTOMATIC_TAX=true` only with the merchant's tax registrations and appropriate provider configuration; webhook fulfillment validates pretax totals and preserves the actual tax-inclusive charge. Merchant eligibility, cross-border settlement, GST/export documentation, final policies and jurisdiction-specific accounting require operator verification.
