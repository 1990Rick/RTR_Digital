import { registerSite } from "./site.mjs";
import { registerIdentity } from "./modules/identity.mjs";
import { registerMemberships } from "./modules/memberships.mjs";
import { registerPublishing } from "./modules/publishing.mjs";
import { registerCommerce } from "./modules/commerce.mjs";
import { registerPayments } from "./modules/payments.mjs";
import {
  isPaidMode,
  isPrepaidMode,
  PAID_MODES_SQL,
} from "./payment-policy.mjs";
import { SELLER_NAME, brandProduct } from "./brand.mjs";
import express from "express";
import multer from "multer";
import Stripe from "stripe";
import { DatabaseSync } from "node:sqlite";
import {
  randomBytes,
  randomUUID,
  scryptSync,
  timingSafeEqual,
  createHash,
} from "node:crypto";
import {
  mkdirSync,
  readFileSync,
  existsSync,
  unlinkSync,
  realpathSync,
} from "node:fs";
import { resolve, dirname, basename, extname } from "node:path";
import { fileURLToPath } from "node:url";

const root = resolve(dirname(fileURLToPath(import.meta.url)), "..");
export const plans = {
  starter: { name: "Explorer", monthly: 9, yearly: 84 },
  creator: { name: "Creator", monthly: 19, yearly: 180 },
  studio: { name: "Studio", monthly: 39, yearly: 372 },
};
const categories = [
  "Design assets",
  "E-books",
  "Audio & music",
  "Courses",
  "Software",
  "Templates",
  "Video",
];
const hash = (value) => createHash("sha256").update(value).digest("hex");
const now = () => new Date().toISOString();
const passwordHash = (password) => {
  const salt = randomBytes(16).toString("hex");
  return `${salt}:${scryptSync(password, salt, 64).toString("hex")}`;
};
const verifyPassword = (password, stored) => {
  try {
    const [salt, key] = stored.split(":");
    return timingSafeEqual(
      scryptSync(password, salt, 64),
      Buffer.from(key, "hex"),
    );
  } catch {
    return false;
  }
};
export function nextBillingDate(from, interval) {
  const end = new Date(from);
  const day = end.getUTCDate();
  end.setUTCDate(1);
  if (interval === "yearly") end.setUTCFullYear(end.getUTCFullYear() + 1);
  else end.setUTCMonth(end.getUTCMonth() + 1);
  const lastDay = new Date(
    Date.UTC(end.getUTCFullYear(), end.getUTCMonth() + 1, 0),
  ).getUTCDate();
  end.setUTCDate(Math.min(day, lastDay));
  return end.toISOString();
}
const demoEmail = (email) =>
  ["demo-admin@rtr.example", "demo-customer@rtr.example"].includes(email);
const fail = (res, status, message) =>
  res.status(status).json({ error: message });
const validEmail = (email) =>
  typeof email === "string" &&
  email.length <= 254 &&
  /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);

export function createApp(options = {}) {
  const production =
    options.production ?? process.env.NODE_ENV === "production";
  const demoMode =
    options.demoMode ?? (!production && process.env.DEMO_MODE !== "false");
  const dataDir = resolve(
    options.dataDir || process.env.DATA_DIR || resolve(root, "data"),
  );
  const webRoots = [resolve(root, "public"), resolve(root, "dist")];
  const under = (file, parent) =>
    file === parent || file.startsWith(`${parent}/`);
  if (webRoots.some((web) => under(dataDir, web)))
    throw new Error(
      "DATA_DIR must stay outside the public and dist web roots.",
    );
  mkdirSync(dataDir, { recursive: true, mode: 0o700 });
  const realData = realpathSync(dataDir);
  if (
    webRoots.some((web) =>
      under(realData, existsSync(web) ? realpathSync(web) : web),
    )
  )
    throw new Error(
      "DATA_DIR must stay outside the public and dist web roots.",
    );
  mkdirSync(resolve(dataDir, "uploads"), { recursive: true, mode: 0o700 });
  const db = new DatabaseSync(resolve(dataDir, "rtr.sqlite"));
  db.exec(`PRAGMA journal_mode=WAL; PRAGMA foreign_keys=ON;
    CREATE TABLE IF NOT EXISTS users (id TEXT PRIMARY KEY, name TEXT NOT NULL, email TEXT UNIQUE NOT NULL, password TEXT NOT NULL, role TEXT NOT NULL DEFAULT 'customer', subscription TEXT, created_at TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS sessions (token TEXT PRIMARY KEY, user_id TEXT NOT NULL REFERENCES users(id), expires_at INTEGER NOT NULL);
    CREATE TABLE IF NOT EXISTS products (id TEXT PRIMARY KEY, payload TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'published', file_path TEXT, cover_path TEXT, created_at TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS orders (id TEXT PRIMARY KEY, user_id TEXT NOT NULL REFERENCES users(id), payload TEXT NOT NULL, amount REAL NOT NULL, mode TEXT NOT NULL, idempotency_key TEXT UNIQUE, created_at TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS entitlements (user_id TEXT NOT NULL REFERENCES users(id), product_id TEXT NOT NULL REFERENCES products(id), mode TEXT NOT NULL DEFAULT 'demo', PRIMARY KEY(user_id, product_id));
    CREATE TABLE IF NOT EXISTS wishlists (user_id TEXT PRIMARY KEY REFERENCES users(id), product_ids TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS newsletter (email TEXT PRIMARY KEY, created_at TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS tickets (id TEXT PRIMARY KEY, user_id TEXT, email TEXT NOT NULL, subject TEXT NOT NULL, message TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'open', created_at TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS reviews (id TEXT PRIMARY KEY, user_id TEXT NOT NULL REFERENCES users(id), product_id TEXT NOT NULL REFERENCES products(id), rating INTEGER NOT NULL, body TEXT NOT NULL, created_at TEXT NOT NULL, UNIQUE(user_id, product_id));
    CREATE TABLE IF NOT EXISTS membership_checkout_locks (user_id TEXT PRIMARY KEY REFERENCES users(id), intent_id TEXT NOT NULL, expires_at INTEGER NOT NULL);
    CREATE TABLE IF NOT EXISTS checkout_intents (id TEXT PRIMARY KEY, user_id TEXT NOT NULL REFERENCES users(id), payload TEXT NOT NULL, created_at TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS webhook_events (id TEXT PRIMARY KEY, created_at TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS audit_log (id TEXT PRIMARY KEY, user_id TEXT, action TEXT NOT NULL, payload TEXT, created_at TEXT NOT NULL);
  `);
  if (
    !db
      .prepare("PRAGMA table_info(entitlements)")
      .all()
      .some((column) => column.name === "mode")
  ) {
    db.exec(
      "ALTER TABLE entitlements ADD COLUMN mode TEXT NOT NULL DEFAULT 'demo'; UPDATE entitlements SET mode='stripe' WHERE EXISTS (SELECT 1 FROM orders, json_each(orders.payload, '$.items') item WHERE orders.user_id=entitlements.user_id AND orders.mode='stripe' AND json_extract(item.value, '$.id')=entitlements.product_id);",
    );
  }
  const seed = JSON.parse(
    readFileSync(resolve(root, "shared/catalog.json"), "utf8"),
  );
  const insertProduct = db.prepare(
    "INSERT OR IGNORE INTO products (id,payload,created_at) VALUES (?,?,?)",
  );
  for (const p of seed)
    insertProduct.run(
      p.id,
      JSON.stringify(
        brandProduct({ ...p, status: "published", isSample: true }),
      ),
      now(),
    );
  // Existing catalogs predate the sole seller policy. Normalize only mutable
  // product metadata; orders and payment evidence retain their original data.
  const updateProductBrand = db.prepare(
    "UPDATE products SET payload=? WHERE id=?",
  );
  for (const row of db.prepare("SELECT id,payload FROM products").all()) {
    const metadata = JSON.parse(row.payload);
    if (
      metadata.creator !== SELLER_NAME ||
      metadata.seller !== SELLER_NAME ||
      metadata.licensor !== SELLER_NAME
    )
      updateProductBrand.run(JSON.stringify(brandProduct(metadata)), row.id);
  }
  if (
    process.env.ADMIN_EMAIL &&
    process.env.ADMIN_PASSWORD &&
    !db
      .prepare("SELECT id FROM users WHERE email=?")
      .get(process.env.ADMIN_EMAIL.toLowerCase())
  ) {
    if (
      !validEmail(process.env.ADMIN_EMAIL) ||
      demoEmail(process.env.ADMIN_EMAIL.toLowerCase())
    )
      throw new Error("ADMIN_EMAIL must be a valid, non-demo email address.");
    if (process.env.ADMIN_PASSWORD.length < 12)
      throw new Error("ADMIN_PASSWORD must contain at least 12 characters.");
    db.prepare(
      "INSERT INTO users (id,name,email,password,role,created_at) VALUES (?,?,?,?,?,?)",
    ).run(
      randomUUID(),
      "RTR Administrator",
      process.env.ADMIN_EMAIL.toLowerCase(),
      passwordHash(process.env.ADMIN_PASSWORD),
      "admin",
      now(),
    );
  }
  const app = express();
  app.disable("x-powered-by");
  if (production) app.set("trust proxy", 1);
  const stripeKey = options.stripeKey ?? process.env.STRIPE_SECRET_KEY;
  const stripe =
    options.stripeClient ?? (stripeKey ? new Stripe(stripeKey) : null);
  const webhookSecret =
    options.webhookSecret ?? process.env.STRIPE_WEBHOOK_SECRET;
  const publicBaseUrl = options.publicUrl ?? process.env.PUBLIC_URL;
  const validPaymentOrigin = (() => {
    try {
      const url = new URL(publicBaseUrl);
      return (
        !url.username &&
        !url.password &&
        !url.search &&
        !url.hash &&
        url.pathname === "/" &&
        (url.protocol === "https:" || (!production && url.protocol === "http:"))
      );
    } catch {
      return false;
    }
  })();
  const stripeReady = Boolean(stripe && webhookSecret && validPaymentOrigin);
  const audit = (uid, action, payload = {}) =>
    db
      .prepare("INSERT INTO audit_log VALUES (?,?,?,?,?)")
      .run(randomUUID(), uid, action, JSON.stringify(payload), now());
  const subscription = (user) => {
    try {
      return user?.subscription ? JSON.parse(user.subscription) : null;
    } catch {
      return null;
    }
  };
  const visibleSubscription = (user) => {
    const s = subscription(user);
    return production &&
      !isPaidMode(s?.mode) &&
      !(s?.mode === "trial" && s?.isTrial === true)
      ? null
      : s;
  };
  const activeSubscription = (user) => {
    const s = visibleSubscription(user);
    return (
      s &&
      ["active", "trialing"].includes(s.status) &&
      Date.parse(s.currentPeriodEnd) > Date.now()
    );
  };
  const safeUser = (user) =>
    user
      ? {
          id: user.id,
          name: user.name,
          email: user.email,
          role: user.role,
          subscription: visibleSubscription(user),
        }
      : null;
  const product = (row) => {
    if (!row) return null;
    const p = brandProduct(JSON.parse(row.payload));
    const moderated = Boolean(
      db
        .prepare(
          "SELECT 1 FROM sqlite_master WHERE type='table' AND name='review_moderation'",
        )
        .get(),
    );
    const ratings = moderated
      ? db
          .prepare(
            "SELECT COUNT(*) AS count,AVG(r.rating) AS average FROM reviews r LEFT JOIN review_moderation m ON m.review_id=r.id WHERE r.product_id=? AND COALESCE(m.hidden,0)=0",
          )
          .get(row.id)
      : db
          .prepare(
            "SELECT COUNT(*) AS count,AVG(rating) AS average FROM reviews WHERE product_id=?",
          )
          .get(row.id);
    return {
      ...p,
      status: row.status,
      ratingIsSample: !ratings.count && Boolean(p.isSample),
      ...(ratings.count
        ? {
            rating: Math.round(ratings.average * 10) / 10,
            reviewCount: ratings.count,
          }
        : {}),
      ...(row.cover_path
        ? {
            image: `/api/product-cover/${row.id}`,
            cover: `/api/product-cover/${row.id}`,
          }
        : {}),
    };
  };
  const products = (publishedOnly = true) =>
    db
      .prepare(
        `SELECT * FROM products ${publishedOnly ? "WHERE status='published'" : ""} ORDER BY created_at ASC, rowid ASC`,
      )
      .all()
      .map(product)
      .filter((p) => !publishedOnly || !production || !p.isSample);
  let teamOwns = () => false;
  const owns = (user, id) => {
    if (!user) return false;
    const entitlement = db
      .prepare("SELECT mode FROM entitlements WHERE user_id=? AND product_id=?")
      .get(user.id, id);
    if (entitlement && (!production || isPaidMode(entitlement.mode)))
      return true;
    const row = db
      .prepare("SELECT * FROM products WHERE id=? AND status='published'")
      .get(id);
    return Boolean(
      row &&
      product(row).subscriptionIncluded &&
      (activeSubscription(user) || teamOwns(user, id)),
    );
  };
  const liveProductAvailable = (p) => {
    const row = db
      .prepare(
        "SELECT file_path FROM products WHERE id=? AND status='published'",
      )
      .get(p.id);
    return (
      !p.isSample &&
      row?.file_path &&
      existsSync(resolve(dataDir, "uploads", basename(row.file_path)))
    );
  };
  function setSession(res, userId) {
    const token = randomBytes(32).toString("hex");
    db.prepare("DELETE FROM sessions WHERE expires_at < ?").run(Date.now());
    db.prepare("INSERT INTO sessions VALUES (?,?,?)").run(
      hash(token),
      userId,
      Date.now() + 30 * 86400000,
    );
    res.cookie("rtr_session", token, {
      httpOnly: true,
      secure: production,
      sameSite: "lax",
      maxAge: 30 * 86400000,
      path: "/",
    });
  }
  app.use((req, res, next) => {
    res.setHeader("X-Content-Type-Options", "nosniff");
    res.setHeader("Referrer-Policy", "strict-origin-when-cross-origin");
    res.setHeader("X-Frame-Options", "DENY");
    res.setHeader(
      "Permissions-Policy",
      "camera=(), microphone=(), geolocation=()",
    );
    if (req.path.startsWith("/api/"))
      res.setHeader("Cache-Control", "no-store");
    next();
  });

  function fulfill(
    userId,
    orderId,
    selected,
    plan,
    interval,
    amount,
    mode,
    stripeSubscriptionId = null,
    idemKey = null,
    stripeState = null,
    billingDetails = null,
  ) {
    if (db.prepare("SELECT id FROM orders WHERE id=?").get(orderId)) return;
    const prepaid = Boolean(
      plan && (isPrepaidMode(mode) || billingDetails?.isPrepaid),
    );
    const latestUser = plan
      ? db.prepare("SELECT * FROM users WHERE id=?").get(userId)
      : null;
    const previousMembership = latestUser ? subscription(latestUser) : null;
    const membershipReviewRequired = Boolean(
      plan &&
      activeSubscription(latestUser) &&
      !previousMembership?.isTrial &&
      !(
        stripeSubscriptionId &&
        previousMembership?.stripeSubscriptionId === stripeSubscriptionId
      ) &&
      previousMembership?.paymentOrderId !== orderId,
    );
    db.exec("BEGIN IMMEDIATE");
    try {
      const record = {
        id: orderId,
        items: selected.map((p) => ({
          id: p.id,
          title: p.title,
          price: p.price,
        })),
        plan: plan || null,
        interval: interval || null,
        total: amount,
        currency: "USD",
        status: "completed",
        mode,
        createdAt: now(),
        seller: commerceModule.sellerSnapshot?.(),
        ...(prepaid ? { isPrepaid: true, autoRenew: false } : {}),
        ...(billingDetails || {}),
        ...(membershipReviewRequired ? { membershipReviewRequired: true } : {}),
      };
      db.prepare("INSERT INTO orders VALUES (?,?,?,?,?,?,?)").run(
        orderId,
        userId,
        JSON.stringify(record),
        amount,
        mode,
        idemKey,
        now(),
      );
      const grant = db.prepare(
        `INSERT INTO entitlements (user_id,product_id,mode) VALUES (?,?,?) ON CONFLICT(user_id,product_id) DO UPDATE SET mode=CASE WHEN entitlements.mode IN (${PAID_MODES_SQL}) THEN entitlements.mode WHEN excluded.mode IN (${PAID_MODES_SQL}) THEN excluded.mode ELSE entitlements.mode END`,
      );
      for (const p of selected) grant.run(userId, p.id, mode);
      if (plan && !membershipReviewRequired) {
        const periodEnd =
          stripeState?.currentPeriodEnd ||
          nextBillingDate(new Date(), interval);
        db.prepare("UPDATE users SET subscription=? WHERE id=?").run(
          JSON.stringify({
            plan,
            interval,
            status: stripeState?.status || "active",
            currentPeriodEnd: periodEnd,
            cancelAtPeriodEnd:
              prepaid || stripeState?.cancelAtPeriodEnd || false,
            mode,
            stripeSubscriptionId,
            ...(prepaid
              ? { isPrepaid: true, autoRenew: false, paymentOrderId: orderId }
              : {}),
            ...(stripeState
              ? {
                  stripePriceId: stripeState.stripePriceId,
                  recurringAmount: stripeState.recurringAmount,
                }
              : {}),
          }),
          userId,
        );
      }
      audit(userId, "checkout.completed", { orderId, mode, amount });
      if (membershipReviewRequired)
        audit(userId, "payment.membership_review_required", {
          orderId,
          mode,
          existingPlan: previousMembership?.plan,
        });
      db.exec("COMMIT");
    } catch (error) {
      db.exec("ROLLBACK");
      throw error;
    }
  }
  app.post(
    "/api/stripe/webhook",
    express.raw({ type: "application/json", limit: "1mb" }),
    async (req, res, next) => {
      if (!stripe || !webhookSecret)
        return fail(res, 503, "Stripe webhooks are not configured.");
      let event;
      try {
        event = stripe.webhooks.constructEvent(
          req.body,
          req.headers["stripe-signature"],
          webhookSecret,
        );
      } catch {
        return fail(res, 400, "Invalid webhook signature.");
      }
      if (db.prepare("SELECT id FROM webhook_events WHERE id=?").get(event.id))
        return res.json({ received: true });
      try {
        if (
          [
            "checkout.session.completed",
            "checkout.session.async_payment_succeeded",
          ].includes(event.type)
        ) {
          const session = event.data.object;
          if (
            ["paid", "no_payment_required"].includes(session.payment_status) &&
            session.metadata?.userId &&
            db
              .prepare("SELECT id FROM users WHERE id=?")
              .get(session.metadata.userId)
          ) {
            const intent = db
              .prepare(
                "SELECT * FROM checkout_intents WHERE id=? AND user_id=?",
              )
              .get(session.metadata.intentId || "", session.metadata.userId);
            if (!intent)
              return fail(res, 400, "Checkout intent was not found.");
            const snapshot = JSON.parse(intent.payload);
            if (
              session.payment_status === "no_payment_required" &&
              snapshot.total !== 0
            )
              return fail(
                res,
                400,
                "A paid order cannot be fulfilled without verified payment.",
              );
            if (
              (snapshot.automaticTax
                ? session.amount_subtotal
                : session.amount_total) !== Math.round(snapshot.total * 100)
            )
              return fail(
                res,
                400,
                "Checkout amount did not match the recorded order.",
              );
            if (session.currency !== "usd")
              return fail(
                res,
                400,
                "Checkout currency did not match the recorded order.",
              );
            let stripeState = null;
            if (snapshot.plan) {
              if (!session.subscription)
                return fail(
                  res,
                  400,
                  "Subscription checkout is missing its billing record.",
                );
              const live = await stripe.subscriptions.retrieve(
                session.subscription,
              );
              const periodEnd =
                live.items?.data?.[0]?.current_period_end ||
                live.current_period_end;
              if (!Number.isFinite(periodEnd) || !live.status)
                return fail(
                  res,
                  503,
                  "Subscription billing state is unavailable; retry fulfillment.",
                );
              stripeState = {
                stripePriceId: live.items?.data?.[0]?.price?.id || null,
                recurringAmount: Number.isFinite(
                  live.items?.data?.[0]?.price?.unit_amount,
                )
                  ? live.items.data[0].price.unit_amount / 100
                  : snapshot.total,
                status: live.status,
                currentPeriodEnd: new Date(periodEnd * 1000).toISOString(),
                cancelAtPeriodEnd: Boolean(live.cancel_at_period_end),
              };
            }
            const paidTotal = snapshot.automaticTax
              ? session.amount_total / 100
              : snapshot.total;
            fulfill(
              session.metadata.userId,
              session.id,
              snapshot.selected,
              snapshot.plan,
              snapshot.interval,
              paidTotal,
              "stripe",
              session.subscription || null,
              snapshot.idempotencyKey || null,
              stripeState,
              {
                subtotal: snapshot.total,
                tax: (session.total_details?.amount_tax || 0) / 100,
              },
            );
            commerceModule.recordPromotion?.(
              session.metadata.userId,
              session.id,
              snapshot.promotionCode || null,
              session.metadata.intentId,
            );
            commerceModule.recordPayment?.(session.id, session);
            if (snapshot.plan)
              db.prepare(
                "DELETE FROM membership_checkout_locks WHERE user_id=? AND intent_id=?",
              ).run(session.metadata.userId, session.metadata.intentId);
          }
        }
        if (
          [
            "customer.subscription.updated",
            "customer.subscription.deleted",
          ].includes(event.type)
        ) {
          const live = await stripe.subscriptions.retrieve(
            event.data.object.id,
          );
          for (const user of db
            .prepare("SELECT * FROM users WHERE subscription IS NOT NULL")
            .all()) {
            const existing = subscription(user);
            if (existing?.stripeSubscriptionId === live.id) {
              const periodEnd =
                live.items?.data?.[0]?.current_period_end ||
                live.current_period_end;
              const itemPrice = live.items?.data?.[0]?.price;
              let mappedPlan = null;
              for (const candidate of Object.keys(plans))
                for (const cycle of ["monthly", "yearly"])
                  if (
                    process.env[
                      `STRIPE_PRICE_${candidate.toUpperCase()}_${cycle.toUpperCase()}`
                    ] === itemPrice?.id &&
                    itemPrice?.id
                  )
                    mappedPlan = { plan: candidate, interval: cycle };
              const priceChanged = Boolean(
                existing.stripePriceId &&
                itemPrice?.id &&
                existing.stripePriceId !== itemPrice.id,
              );
              const cycle =
                itemPrice?.recurring?.interval === "year"
                  ? "yearly"
                  : itemPrice?.recurring?.interval === "month"
                    ? "monthly"
                    : existing.interval;
              const mapping =
                (mappedPlan
                  ? { ...mappedPlan, priceMappingRequired: false }
                  : null) ||
                (priceChanged
                  ? {
                      plan: "starter",
                      interval: cycle,
                      priceMappingRequired: true,
                    }
                  : { interval: cycle });
              if (priceChanged && !mappedPlan)
                identityModule.notify?.(
                  user.id,
                  "Billing plan needs review",
                  "Your provider changed to an unrecognized price. Personal library access continues; team privileges require administrator price mapping.",
                );
              db.prepare("UPDATE users SET subscription=? WHERE id=?").run(
                JSON.stringify({
                  ...existing,
                  ...mapping,
                  ...(Number.isFinite(itemPrice?.unit_amount)
                    ? { recurringAmount: itemPrice.unit_amount / 100 }
                    : {}),
                  ...(itemPrice?.id ? { stripePriceId: itemPrice.id } : {}),
                  status: live.status,
                  cancelAtPeriodEnd: Boolean(live.cancel_at_period_end),
                  ...(periodEnd
                    ? {
                        currentPeriodEnd: new Date(
                          periodEnd * 1000,
                        ).toISOString(),
                      }
                    : {}),
                }),
                user.id,
              );
            }
          }
        }
        if (
          event.type === "checkout.session.expired" &&
          event.data.object.metadata?.userId
        )
          db.prepare(
            "DELETE FROM membership_checkout_locks WHERE user_id=? AND intent_id=?",
          ).run(
            event.data.object.metadata.userId,
            event.data.object.metadata.intentId || "",
          );
        if (membershipModule.onBillingEvent)
          await membershipModule.onBillingEvent(event);
        if (commerceModule.onBillingEvent)
          await commerceModule.onBillingEvent(event);
        db.prepare("INSERT OR IGNORE INTO webhook_events VALUES (?,?)").run(
          event.id,
          now(),
        );
        res.json({ received: true });
      } catch (error) {
        next(error);
      }
    },
  );
  app.use(express.json({ limit: "1mb" }));
  app.use("/api", (req, res, next) => {
    if (
      ["POST", "PUT", "PATCH", "DELETE"].includes(req.method) &&
      req.headers.origin
    ) {
      const expected = new Set(
        [
          publicBaseUrl,
          !production && "http://localhost:5173",
          !production && "http://127.0.0.1:5173",
          !production && "http://localhost:3001",
          !production && "http://127.0.0.1:3001",
        ].filter(Boolean),
      );
      const hostOrigin = `${req.protocol}://${req.get("host")}`;
      expected.add(hostOrigin);
      if (!expected.has(req.headers.origin))
        return fail(res, 403, "Request origin is not allowed.");
    }
    const cookie = req.headers.cookie
      ?.split(";")
      .map((x) => x.trim())
      .find((x) => x.startsWith("rtr_session="))
      ?.slice(12);
    req.user = cookie
      ? db
          .prepare(
            "SELECT users.* FROM users JOIN sessions ON users.id=sessions.user_id WHERE sessions.token=? AND sessions.expires_at>?",
          )
          .get(hash(cookie), Date.now())
      : null;
    if (production && req.user && demoEmail(req.user.email)) req.user = null;
    next();
  });
  const requireAuth = (req, res, next) =>
    req.user ? next() : fail(res, 401, "Sign in to continue.");
  const requireAdmin = (req, res, next) =>
    req.user?.role === "admin"
      ? next()
      : fail(res, req.user ? 403 : 401, "Administrator access required.");
  const limits = new Map();
  const rateLimit =
    (key, count = 10, window = 600000) =>
    (req, res, next) => {
      const id = `${key}:${req.ip}`;
      const entry = limits.get(id);
      const time = Date.now();
      if (!entry || entry.end < time)
        limits.set(id, { count: 1, end: time + window });
      else if (entry.count >= count) {
        res.setHeader(
          "Retry-After",
          String(Math.ceil((entry.end - time) / 1000)),
        );
        return fail(
          res,
          429,
          "Too many attempts. Please try again in a few minutes.",
        );
      } else entry.count++;
      if (limits.size > 10000)
        for (const [k, v] of limits) if (v.end < time) limits.delete(k);
      next();
    };
  const moduleContext = {
    db,
    dataDir,
    root,
    production,
    demoMode,
    stripe,
    stripeReady,
    publicBaseUrl,
    requireAuth,
    requireAdmin,
    fail,
    safeUser,
    subscription,
    visibleSubscription,
    activeSubscription,
    owns,
    product,
    products,
    audit,
    plans,
    now,
    hash,
    passwordHash,
    verifyPassword,
    rateLimit,
    setSession,
    validEmail,
    nextBillingDate,
    fulfill,
    liveProductAvailable,
    sellerSnapshot: () => commerceModule.sellerSnapshot(),
    options,
  };
  const identityModule = registerIdentity(app, moduleContext);
  moduleContext.identity = identityModule;
  const membershipModule = registerMemberships(app, moduleContext);
  if (membershipModule.teamOwns) teamOwns = membershipModule.teamOwns;
  registerPublishing(app, moduleContext);
  const commerceModule = registerCommerce(app, moduleContext);
  moduleContext.commerce = commerceModule;
  const paymentsModule = registerPayments(app, moduleContext);
  moduleContext.payments = paymentsModule;
  app.get("/api/health", (_req, res) =>
    res.json({ status: "ok", service: "RTR Digital", demoMode }),
  );
  app.get("/api/config", (_req, res) =>
    res.json({
      demoMode,
      stripeConfigured: stripeReady,
      paymentMethods: paymentsModule.methods().methods,
      plans,
      currency: "USD",
      maxUploadBytes: 100 * 1024 * 1024,
      sampleCatalog: !production,
      country: "IN",
    }),
  );
  app.get("/api/catalog", (req, res) => {
    let list = products();
    if (typeof req.query.q === "string") {
      const q = req.query.q.toLowerCase().slice(0, 200);
      list = list.filter((p) =>
        `${p.title} ${p.creator} ${p.description} ${p.tags.join(" ")}`
          .toLowerCase()
          .includes(q),
      );
    }
    if (req.query.category && req.query.category !== "All")
      list = list.filter((p) => p.category === req.query.category);
    res.json({ products: list, categories });
  });
  app.get("/api/products/:id", (req, res) => {
    const p = product(
      db
        .prepare("SELECT * FROM products WHERE id=? AND status='published'")
        .get(req.params.id),
    );
    return p && (!production || !p.isSample)
      ? res.json({ product: p })
      : fail(res, 404, "Product not found.");
  });
  app.get("/api/auth/me", (req, res) => res.json({ user: safeUser(req.user) }));
  app.post("/api/auth/register", rateLimit("register", 12), (req, res) => {
    const { name, email, password } = req.body || {};
    if (typeof name !== "string" || name.trim().length < 2 || name.length > 80)
      return fail(res, 400, "Enter a name between 2 and 80 characters.");
    if (!validEmail(email) || demoEmail(email.toLowerCase()))
      return fail(res, 400, "Enter a valid personal email address.");
    if (
      typeof password !== "string" ||
      password.length < 8 ||
      password.length > 128
    )
      return fail(res, 400, "Use a password between 8 and 128 characters.");
    if (
      db.prepare("SELECT id FROM users WHERE email=?").get(email.toLowerCase())
    )
      return fail(res, 409, "An account already exists with this email.");
    const id = randomUUID();
    db.prepare(
      "INSERT INTO users (id,name,email,password,created_at) VALUES (?,?,?,?,?)",
    ).run(id, name.trim(), email.toLowerCase(), passwordHash(password), now());
    setSession(res, id);
    audit(id, "auth.register");
    res.status(201).json({
      user: safeUser(db.prepare("SELECT * FROM users WHERE id=?").get(id)),
    });
  });
  app.post("/api/auth/login", rateLimit("login", 15), (req, res) => {
    const { email, password } = req.body || {};
    if (
      !validEmail(email) ||
      typeof password !== "string" ||
      password.length > 128
    )
      return fail(res, 400, "Enter your email address and password.");
    const user = db
      .prepare("SELECT * FROM users WHERE email=?")
      .get(email.toLowerCase());
    if (
      !user ||
      (production && demoEmail(user.email)) ||
      !verifyPassword(password, user.password)
    )
      return fail(res, 401, "Email or password is incorrect.");
    setSession(res, user.id);
    audit(user.id, "auth.login");
    res.json({ user: safeUser(user) });
  });
  app.post("/api/auth/demo", rateLimit("demo", 50), (req, res) => {
    if (!demoMode) return fail(res, 404, "Demo access is disabled.");
    const role = req.body?.role === "admin" ? "admin" : "customer";
    const email = `demo-${role}@rtr.example`;
    let user = db.prepare("SELECT * FROM users WHERE email=?").get(email);
    if (!user) {
      const id = randomUUID();
      db.prepare(
        "INSERT INTO users (id,name,email,password,role,created_at) VALUES (?,?,?,?,?,?)",
      ).run(
        id,
        role === "admin" ? "RTR Administrator" : "Alex Creative",
        email,
        passwordHash(randomBytes(48).toString("hex")),
        role,
        now(),
      );
      user = db.prepare("SELECT * FROM users WHERE id=?").get(id);
    }
    setSession(res, user.id);
    res.json({ user: safeUser(user), demo: true });
  });
  app.post("/api/auth/logout", (req, res) => {
    const cookie = req.headers.cookie
      ?.split(";")
      .map((x) => x.trim())
      .find((x) => x.startsWith("rtr_session="))
      ?.slice(12);
    if (cookie)
      db.prepare("DELETE FROM sessions WHERE token=?").run(hash(cookie));
    res.clearCookie("rtr_session", {
      httpOnly: true,
      secure: production,
      sameSite: "lax",
      path: "/",
    });
    res.json({ success: true });
  });
  app.get("/api/library", requireAuth, (req, res) =>
    res.json({
      products: products(false).filter((p) => owns(req.user, p.id)),
      orders: db
        .prepare(
          "SELECT payload FROM orders WHERE user_id=? ORDER BY created_at DESC",
        )
        .all(req.user.id)
        .map((row) => JSON.parse(row.payload)),
      subscription: visibleSubscription(req.user),
    }),
  );
  app.get("/api/wishlist", requireAuth, (req, res) =>
    res.json({
      productIds: JSON.parse(
        db
          .prepare("SELECT product_ids FROM wishlists WHERE user_id=?")
          .get(req.user.id)?.product_ids || "[]",
      ).filter((id) =>
        db
          .prepare("SELECT 1 FROM products WHERE id=? AND status='published'")
          .get(id),
      ),
    }),
  );
  app.put("/api/wishlist", requireAuth, (req, res) => {
    if (
      !Array.isArray(req.body?.productIds) ||
      req.body.productIds.length > 100 ||
      !req.body.productIds.every(
        (id) =>
          typeof id === "string" &&
          db
            .prepare(
              "SELECT id FROM products WHERE id=? AND status='published'",
            )
            .get(id),
      )
    )
      return fail(res, 400, "Provide up to 100 valid product IDs.");
    const ids = [...new Set(req.body.productIds)];
    db.prepare(
      "INSERT INTO wishlists VALUES (?,?) ON CONFLICT(user_id) DO UPDATE SET product_ids=excluded.product_ids",
    ).run(req.user.id, JSON.stringify(ids));
    res.json({ productIds: ids });
  });
  app.post(
    "/api/checkout",
    requireAuth,
    rateLimit("checkout", 50),
    async (req, res, next) => {
      try {
        const {
          plan,
          coupon,
          mode,
          interval = "monthly",
          productIds = [],
        } = req.body || {};
        if (!["demo", "stripe"].includes(mode))
          return fail(res, 400, "Select a checkout payment mode.");
        if (mode === "demo" && !demoMode)
          return fail(res, 403, "Demo checkout is disabled.");
        if (mode === "stripe" && !stripeReady)
          return fail(
            res,
            503,
            "Live payments require Stripe keys, a webhook secret, and PUBLIC_URL. No payment was taken.",
          );
        const suppliedIdem = req.get("Idempotency-Key");
        if (suppliedIdem && !/^[A-Za-z0-9_-]{8,128}$/.test(suppliedIdem))
          return fail(res, 400, "Invalid idempotency key.");
        const idemKey = suppliedIdem ? `${req.user.id}:${suppliedIdem}` : null;
        if (idemKey) {
          const previous = db
            .prepare("SELECT id,payload FROM orders WHERE idempotency_key=?")
            .get(idemKey);
          if (previous)
            return res.json({
              success: true,
              orderId: previous.id,
              order: JSON.parse(previous.payload),
              demo: mode === "demo",
            });
        }
        if (plan && (typeof plan !== "string" || !Object.hasOwn(plans, plan)))
          return fail(res, 400, "Choose a valid membership plan.");
        if (!["monthly", "yearly"].includes(interval))
          return fail(res, 400, "Choose monthly or yearly billing.");
        if (
          !Array.isArray(productIds) ||
          productIds.length > 50 ||
          !productIds.every((id) => typeof id === "string")
        )
          return fail(res, 400, "Cart is invalid.");
        const ids = [...new Set(productIds)];
        const selected = ids.map((id) =>
          product(
            db
              .prepare(
                "SELECT * FROM products WHERE id=? AND status='published'",
              )
              .get(id),
          ),
        );
        if (selected.some((p) => !p))
          return fail(res, 400, "A product is no longer available.");
        if (!plan && selected.length === 0)
          return fail(res, 400, "Your cart is empty.");
        if (plan && ids.length)
          return fail(
            res,
            400,
            "Purchase a membership separately from individual products.",
          );
        if (
          plan &&
          visibleSubscription(req.user)?.mode === "stripe" &&
          visibleSubscription(req.user)?.stripeSubscriptionId &&
          !["canceled", "incomplete_expired"].includes(
            visibleSubscription(req.user).status,
          )
        )
          return fail(
            res,
            409,
            "A billing subscription already exists. Use your billing portal to resolve payment or change plans.",
          );
        if (
          plan &&
          activeSubscription(req.user) &&
          !visibleSubscription(req.user)?.isTrial
        )
          return fail(
            res,
            409,
            "You already have an active membership. Manage it in your library.",
          );
        if (mode === "stripe" && selected.some((p) => !liveProductAvailable(p)))
          return fail(
            res,
            400,
            "Sample products are demonstration content. Publish your own files before accepting live payments.",
          );
        if (
          mode === "stripe" &&
          plan &&
          !products().some(
            (p) => p.subscriptionIncluded && liveProductAvailable(p),
          )
        )
          return fail(
            res,
            400,
            "Publish your own digital products before selling a live membership.",
          );
        const code =
          typeof coupon === "string" ? coupon.trim().toUpperCase() : "";
        const subtotal = plan
          ? plans[plan][interval]
          : selected.reduce((sum, p) => sum + p.price, 0);
        let promotion;
        try {
          promotion = commerceModule.resolvePromotion
            ? commerceModule.resolvePromotion(req.user, {
                code,
                plan,
                selected,
                subtotal,
                reservationId: idemKey ? hash(`checkout:${idemKey}`) : null,
              })
            : {
                discount:
                  code === "RTR20" ? 0.2 : code === "WELCOME10" ? 0.1 : 0,
              };
        } catch (error) {
          return fail(res, error.status || 400, error.message);
        }
        const discount = promotion.discount;
        const total = plan
          ? Math.round(subtotal * (1 - discount) * 100) / 100
          : selected.reduce(
              (sum, p) => sum + Math.round(p.price * (1 - discount) * 100),
              0,
            ) / 100;
        if (mode === "demo") {
          const orderId = `RTR-${randomBytes(4).toString("hex").toUpperCase()}`;
          fulfill(
            req.user.id,
            orderId,
            selected,
            plan,
            interval,
            total,
            "demo",
            null,
            idemKey,
          );
          commerceModule.recordPromotion?.(req.user.id, orderId, code || null);
          return res.json({
            success: true,
            orderId,
            total,
            subtotal,
            discount: Math.round(subtotal * discount * 100) / 100,
            demo: true,
            message: "Demo order complete. No money was charged.",
            user: safeUser(
              db.prepare("SELECT * FROM users WHERE id=?").get(req.user.id),
            ),
          });
        }
        const publicUrl = publicBaseUrl.replace(/\/$/, "");
        const intentId = idemKey ? hash(`checkout:${idemKey}`) : randomUUID();
        const taxOptions = commerceModule.stripeTaxOptions?.() || {};
        const snapshot = JSON.stringify({
          selected,
          plan: plan || null,
          interval,
          total,
          idempotencyKey: idemKey,
          promotionCode: code || null,
          automaticTax: Boolean(taxOptions.automatic_tax?.enabled),
        });
        const previousIntent = db
          .prepare("SELECT payload FROM checkout_intents WHERE id=?")
          .get(intentId);
        if (previousIntent && previousIntent.payload !== snapshot)
          return fail(
            res,
            409,
            "This checkout key was already used for a different order.",
          );
        db.prepare(
          "INSERT OR IGNORE INTO checkout_intents VALUES (?,?,?,?)",
        ).run(intentId, req.user.id, snapshot, now());
        let expiresAt = Math.floor(Date.now() / 1000) + 1860;
        if (plan) {
          const lock = db
            .prepare("SELECT * FROM membership_checkout_locks WHERE user_id=?")
            .get(req.user.id);
          if (
            lock &&
            lock.expires_at > Date.now() &&
            lock.intent_id !== intentId
          )
            return fail(
              res,
              409,
              "A membership checkout is already in progress. Complete or resolve the pending payment before starting another.",
            );
          if (
            lock &&
            lock.expires_at > Date.now() &&
            lock.intent_id === intentId
          )
            expiresAt = Math.floor(lock.expires_at / 1000);
          db.prepare(
            "INSERT INTO membership_checkout_locks VALUES (?,?,?) ON CONFLICT(user_id) DO UPDATE SET intent_id=excluded.intent_id,expires_at=excluded.expires_at",
          ).run(req.user.id, intentId, expiresAt * 1000);
        }
        const line_items = plan
          ? [
              {
                price_data: {
                  currency: "usd",
                  unit_amount: Math.round(total * 100),
                  recurring: {
                    interval: interval === "yearly" ? "year" : "month",
                  },
                  product_data: {
                    name: `RTR Digital ${plans[plan].name} membership`,
                  },
                },
                quantity: 1,
              },
            ]
          : selected.map((p) => ({
              price_data: {
                currency: "usd",
                unit_amount: Math.round(p.price * (1 - discount) * 100),
                product_data: { name: p.title },
              },
              quantity: 1,
            }));
        if (code)
          commerceModule.reservePromotion?.(
            req.user.id,
            intentId,
            code,
            expiresAt * 1000,
          );
        let session;
        try {
          session = await stripe.checkout.sessions.create(
            {
              mode: plan ? "subscription" : "payment",
              line_items,
              ...taxOptions,
              ...(plan || code ? { expires_at: expiresAt } : {}),
              customer_email: req.user.email,
              success_url: `${publicUrl}/?checkout=success&session_id={CHECKOUT_SESSION_ID}`,
              cancel_url: `${publicUrl}/?checkout=cancelled`,
              metadata: {
                userId: req.user.id,
                intentId,
                plan: plan || "",
                interval,
              },
              ...(plan
                ? {
                    subscription_data: {
                      metadata: { userId: req.user.id, plan, interval },
                    },
                  }
                : {}),
            },
            suppliedIdem
              ? { idempotencyKey: `${req.user.id}-${suppliedIdem}` }
              : {},
          );
        } catch (error) {
          commerceModule.releasePromotion?.(intentId);
          if (plan)
            db.prepare(
              "DELETE FROM membership_checkout_locks WHERE user_id=? AND intent_id=?",
            ).run(req.user.id, intentId);
          throw error;
        }
        res.json({ url: session.url, sessionId: session.id });
      } catch (error) {
        next(error);
      }
    },
  );
  app.get("/api/download/:id", requireAuth, (req, res) => {
    const row = db
      .prepare("SELECT * FROM products WHERE id=?")
      .get(req.params.id);
    if (!row) return fail(res, 404, "Product not found.");
    if (!owns(req.user, row.id))
      return fail(
        res,
        403,
        "Purchase this product or start a membership to download it.",
      );
    audit(req.user.id, "product.download", { productId: row.id });
    if (row.file_path)
      return res.download(
        resolve(dataDir, "uploads", basename(row.file_path)),
        `${row.id}${extname(row.file_path)}`,
      );
    const p = product(row);
    res.setHeader(
      "Content-Disposition",
      `attachment; filename="${p.id}-sample.txt"`,
    );
    res
      .type("text/plain")
      .send(
        `RTR DIGITAL — DEMONSTRATION DOWNLOAD\n\n${p.title}\nSold and licensed by ${SELLER_NAME}\n\n${p.description}\n\nThis is a sample product supplied with the RTR Digital development storefront. It demonstrates authenticated digital delivery and is not the full advertised product. Replace sample catalog entries with your original, licensed digital files in the administrator workspace before launching.\n\nOrder access: ${req.user.email}\nLicense: ${activeSubscription(req.user) ? `${subscription(req.user).plan} membership access, valid while subscription is active` : "Individual demo purchase, perpetual access"}\n\nThank you for exploring RTR Digital.\n`,
      );
  });
  async function updateCancellation(req, res, cancel) {
    const current = subscription(req.user);
    if (!current || !activeSubscription(req.user))
      return fail(res, 400, "There is no active membership to manage.");
    if (current.isTrial)
      return fail(
        res,
        400,
        "This preview never renews automatically. End it from the membership hub.",
      );
    if (current.isPrepaid)
      return fail(
        res,
        400,
        "This prepaid membership expires automatically. It has no recurring charge to cancel or resume.",
      );
    if (current.mode === "stripe") {
      if (!stripe || !current.stripeSubscriptionId)
        return fail(res, 503, "Billing is temporarily unavailable.");
      await stripe.subscriptions.update(current.stripeSubscriptionId, {
        cancel_at_period_end: cancel,
      });
    }
    const updated = { ...current, cancelAtPeriodEnd: cancel };
    db.prepare("UPDATE users SET subscription=? WHERE id=?").run(
      JSON.stringify(updated),
      req.user.id,
    );
    audit(
      req.user.id,
      cancel ? "subscription.cancel_scheduled" : "subscription.resumed",
    );
    res.json({
      subscription: updated,
      user: safeUser(
        db.prepare("SELECT * FROM users WHERE id=?").get(req.user.id),
      ),
    });
  }
  app.post("/api/subscription/cancel", requireAuth, async (req, res, next) => {
    try {
      await updateCancellation(req, res, true);
    } catch (e) {
      next(e);
    }
  });
  app.post("/api/subscription/resume", requireAuth, async (req, res, next) => {
    try {
      await updateCancellation(req, res, false);
    } catch (e) {
      next(e);
    }
  });
  app.post("/api/subscription/change", requireAuth, async (req, res, next) => {
    try {
      const current = visibleSubscription(req.user);
      const { plan, interval } = req.body || {};
      if (
        typeof plan !== "string" ||
        !Object.hasOwn(plans, plan) ||
        !["monthly", "yearly"].includes(interval)
      )
        return fail(res, 400, "Choose a valid plan and billing interval.");
      if (!current || !activeSubscription(req.user))
        return fail(
          res,
          400,
          "An active membership is required to change plans.",
        );
      if (current.isTrial)
        return fail(
          res,
          400,
          "Preview plans cannot be extended or changed. Choose a paid plan through checkout to convert.",
        );
      if (current.isPrepaid)
        return fail(
          res,
          400,
          "A prepaid membership keeps its purchased plan until expiry. Purchase a new term after it ends.",
        );
      if (current.mode === "stripe") {
        if (!stripe || !current.stripeSubscriptionId || !publicBaseUrl)
          return fail(res, 503, "Live billing is temporarily unavailable.");
        const live = await stripe.subscriptions.retrieve(
          current.stripeSubscriptionId,
        );
        const session = await stripe.billingPortal.sessions.create({
          customer:
            typeof live.customer === "string"
              ? live.customer
              : live.customer.id,
          return_url: publicBaseUrl,
        });
        return res.json({
          url: session.url,
          message:
            "Review plan changes, availability, and any prorated charges in Stripe Billing.",
        });
      }
      if (current.plan === plan && current.interval === interval)
        return fail(
          res,
          400,
          "You are already on this plan and billing interval.",
        );
      const updated = {
        ...current,
        plan,
        interval,
        currentPeriodEnd: nextBillingDate(new Date(), interval),
        cancelAtPeriodEnd: false,
      };
      db.prepare("UPDATE users SET subscription=? WHERE id=?").run(
        JSON.stringify(updated),
        req.user.id,
      );
      audit(req.user.id, "subscription.demo_plan_changed", {
        from: current.plan,
        plan,
        interval,
      });
      res.json({
        subscription: updated,
        user: safeUser(
          db.prepare("SELECT * FROM users WHERE id=?").get(req.user.id),
        ),
        message:
          "Demo plan changed immediately. A new test billing period starts today. No money was charged.",
      });
    } catch (error) {
      next(error);
    }
  });
  app.post("/api/billing/portal", requireAuth, async (req, res, next) => {
    try {
      const current = subscription(req.user);
      if (
        !stripe ||
        current?.mode !== "stripe" ||
        !current.stripeSubscriptionId
      )
        return fail(res, 400, "A live Stripe subscription is required.");
      const sub = await stripe.subscriptions.retrieve(
        current.stripeSubscriptionId,
      );
      const session = await stripe.billingPortal.sessions.create({
        customer:
          typeof sub.customer === "string" ? sub.customer : sub.customer.id,
        return_url: publicBaseUrl,
      });
      res.json({ url: session.url });
    } catch (e) {
      next(e);
    }
  });
  app.post("/api/newsletter", rateLimit("newsletter", 12), (req, res) => {
    if (!validEmail(req.body?.email))
      return fail(res, 400, "Enter a valid email address.");
    db.prepare("INSERT OR IGNORE INTO newsletter VALUES (?,?)").run(
      req.body.email.toLowerCase(),
      now(),
    );
    res.json({
      success: true,
      message: "You are on the list. Welcome to the creative side.",
    });
  });
  app.post("/api/support", rateLimit("support", 10), (req, res) => {
    const { email, subject, message } = req.body || {};
    if (
      !validEmail(email) ||
      typeof subject !== "string" ||
      subject.trim().length < 3 ||
      subject.length > 150 ||
      typeof message !== "string" ||
      message.trim().length < 10 ||
      message.length > 5000
    )
      return fail(
        res,
        400,
        "Provide an email, subject, and message of at least 10 characters.",
      );
    const id = `TKT-${randomBytes(4).toString("hex").toUpperCase()}`;
    db.prepare(
      "INSERT INTO tickets (id,user_id,email,subject,message,created_at) VALUES (?,?,?,?,?,?)",
    ).run(
      id,
      req.user?.id || null,
      email.toLowerCase(),
      subject.trim(),
      message.trim(),
      now(),
    );
    res.status(201).json({
      success: true,
      ticketId: id,
      message:
        "Your message has been saved. An administrator can review it in the workspace.",
    });
  });
  app.get("/api/reviews/:id", (req, res) =>
    res.json({
      reviews: db
        .prepare(
          "SELECT reviews.id,reviews.rating,reviews.body,reviews.created_at AS createdAt,users.name FROM reviews JOIN users ON users.id=reviews.user_id WHERE product_id=? ORDER BY reviews.created_at DESC",
        )
        .all(req.params.id),
    }),
  );
  app.post("/api/reviews/:id", requireAuth, (req, res) => {
    if (!owns(req.user, req.params.id))
      return fail(res, 403, "Reviews are available to verified customers.");
    const { rating, body } = req.body || {};
    if (
      !Number.isInteger(rating) ||
      rating < 1 ||
      rating > 5 ||
      typeof body !== "string" ||
      body.trim().length < 10 ||
      body.length > 2000
    )
      return fail(
        res,
        400,
        "Give a rating from 1 to 5 and a review of at least 10 characters.",
      );
    db.prepare(
      "INSERT INTO reviews VALUES (?,?,?,?,?,?) ON CONFLICT(user_id,product_id) DO UPDATE SET rating=excluded.rating,body=excluded.body,created_at=excluded.created_at",
    ).run(randomUUID(), req.user.id, req.params.id, rating, body.trim(), now());
    res.status(201).json({ success: true });
  });
  app.get("/api/admin/stats", requireAdmin, (_req, res) => {
    const orderRows = db
      .prepare(
        "SELECT payload,amount,mode FROM orders ORDER BY created_at DESC",
      )
      .all();
    const users = db.prepare("SELECT * FROM users").all();
    const allProducts = products(false);
    res.json({
      revenue: orderRows
        .filter(
          (x) =>
            isPaidMode(x.mode) && JSON.parse(x.payload).status !== "refunded",
        )
        .reduce((n, x) => n + x.amount, 0),
      demoRevenue: orderRows
        .filter(
          (x) =>
            x.mode === "demo" && JSON.parse(x.payload).status !== "refunded",
        )
        .reduce((n, x) => n + x.amount, 0),
      orders: orderRows.length,
      subscribers: users.filter(activeSubscription).length,
      products: allProducts.length,
      customers: users.filter((x) => x.role === "customer").length,
      recentOrders: orderRows.slice(0, 20).map((x) => JSON.parse(x.payload)),
      newsletterSubscribers: db
        .prepare("SELECT count(*) AS n FROM newsletter")
        .get().n,
      tickets: db
        .prepare("SELECT * FROM tickets ORDER BY created_at DESC LIMIT 50")
        .all(),
      recentActivity: db
        .prepare(
          "SELECT action,payload,created_at AS createdAt FROM audit_log ORDER BY created_at DESC LIMIT 20",
        )
        .all(),
    });
  });
  app.get("/api/admin/products", requireAdmin, (_req, res) =>
    res.json({ products: products(false), categories }),
  );
  const upload = multer({
    storage: multer.diskStorage({
      destination: resolve(dataDir, "uploads"),
      filename: (_req, file, cb) =>
        cb(
          null,
          `${randomUUID()}${extname(file.originalname)
            .toLowerCase()
            .replace(/[^.a-z0-9]/g, "")
            .slice(0, 12)}`,
        ),
    }),
    limits: {
      fileSize: 100 * 1024 * 1024,
      files: 2,
      fields: 16,
      fieldSize: 20000,
    },
    fileFilter: (_req, file, cb) => {
      if (
        file.fieldname === "cover" &&
        (!["image/jpeg", "image/png", "image/webp"].includes(file.mimetype) ||
          ![".jpg", ".jpeg", ".png", ".webp"].includes(
            extname(file.originalname).toLowerCase(),
          ))
      )
        return cb(new Error("Cover must be a JPEG, PNG, or WebP image."));
      cb(null, true);
    },
  });
  app.post(
    "/api/admin/products",
    requireAdmin,
    upload.fields([
      { name: "file", maxCount: 1 },
      { name: "cover", maxCount: 1 },
    ]),
    (req, res) => {
      const files = req.files || {};
      const cleanup = () =>
        Object.values(files)
          .flat()
          .forEach((f) => {
            try {
              unlinkSync(f.path);
            } catch {}
          });
      const { title, description, category, price } = req.body || {};
      const amount = Number(price);
      if (
        typeof title !== "string" ||
        title.trim().length < 3 ||
        title.length > 120 ||
        typeof description !== "string" ||
        description.trim().length < 20 ||
        description.length > 5000 ||
        !categories.includes(category) ||
        !Number.isFinite(amount) ||
        amount < 0 ||
        amount > 100000 ||
        !files.file?.[0]
      ) {
        cleanup();
        return fail(
          res,
          400,
          "Provide a title, description (20+ characters), category, valid price, and digital product file.",
        );
      }
      const id = `${
        title
          .toLowerCase()
          .replace(/[^a-z0-9]+/g, "-")
          .replace(/^-|-$/g, "")
          .slice(0, 60) || "product"
      }-${randomBytes(3).toString("hex")}`;
      const f = files.file[0];
      if (files.cover?.[0]) {
        const cover = files.cover[0];
        const bytes = readFileSync(cover.path);
        const png =
          bytes.length > 8 &&
          bytes
            .subarray(0, 8)
            .equals(Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]));
        const jpg =
          bytes.length > 3 &&
          bytes[0] === 255 &&
          bytes[1] === 216 &&
          bytes[2] === 255;
        const webp =
          bytes.length > 12 &&
          bytes.subarray(0, 4).toString() === "RIFF" &&
          bytes.subarray(8, 12).toString() === "WEBP";
        const extension = extname(cover.path).toLowerCase();
        if (
          cover.size > 10 * 1024 * 1024 ||
          !(
            (png && extension === ".png") ||
            (jpg && [".jpg", ".jpeg"].includes(extension)) ||
            (webp && extension === ".webp")
          )
        ) {
          cleanup();
          return fail(
            res,
            400,
            "Upload a valid JPEG, PNG, or WebP cover smaller than 10 MB.",
          );
        }
      }
      const p = brandProduct({
        id,
        title: title.trim(),
        description: description.trim(),
        category,
        price: Math.round(amount * 100) / 100,
        originalPrice: Math.round(amount * 100) / 100,
        rating: 0,
        reviewCount: 0,
        format: (
          extname(f.originalname).slice(1) || "Digital file"
        ).toUpperCase(),
        size: `${(f.size / (1024 * 1024)).toFixed(1)} MB`,
        accent: "#e7dff4",
        art:
          {
            "E-books": "book",
            "Audio & music": "audio",
            Software: "code",
            Video: "film",
            Courses: "course",
            Templates: "dashboard",
          }[category] || "studio",
        tags: ["New release"],
        featured: false,
        subscriptionIncluded: req.body.subscriptionIncluded !== "false",
        downloads: 0,
        isSample: false,
        status: req.body.status === "published" ? "published" : "draft",
      });
      db.prepare("INSERT INTO products VALUES (?,?,?,?,?,?)").run(
        id,
        JSON.stringify(p),
        p.status,
        basename(f.path),
        files.cover?.[0] ? basename(files.cover[0].path) : null,
        now(),
      );
      audit(req.user.id, "product.uploaded", {
        productId: id,
        status: p.status,
      });
      res.status(201).json({
        success: true,
        product: product(
          db.prepare("SELECT * FROM products WHERE id=?").get(id),
        ),
      });
    },
  );
  app.patch("/api/admin/products/:id", requireAdmin, (req, res) => {
    const row = db
      .prepare("SELECT * FROM products WHERE id=?")
      .get(req.params.id);
    if (!row) return fail(res, 404, "Product not found.");
    const p = brandProduct(JSON.parse(row.payload));
    if (req.body.status && !["draft", "published"].includes(req.body.status))
      return fail(res, 400, "Choose draft or published status.");
    const status = req.body.status || row.status;
    if (
      status === "published" &&
      !p.isSample &&
      (!row.file_path ||
        !existsSync(resolve(dataDir, "uploads", basename(row.file_path))))
    )
      return fail(
        res,
        400,
        "Upload and finalize an original file before publishing this product.",
      );
    if (req.body.price !== undefined) {
      const n = Number(req.body.price);
      if (!Number.isFinite(n) || n < 0 || n > 100000)
        return fail(res, 400, "Invalid price.");
      p.price = Math.round(n * 100) / 100;
    }
    if (typeof req.body.subscriptionIncluded === "boolean")
      p.subscriptionIncluded = req.body.subscriptionIncluded;
    db.prepare("UPDATE products SET payload=?,status=? WHERE id=?").run(
      JSON.stringify({ ...p, status }),
      status,
      row.id,
    );
    if (
      req.body.status &&
      db
        .prepare(
          "SELECT 1 FROM sqlite_master WHERE type='table' AND name='product_schedules'",
        )
        .get()
    )
      db.prepare("DELETE FROM product_schedules WHERE product_id=?").run(
        row.id,
      );
    audit(req.user.id, "product.updated", { productId: row.id, status });
    res.json({
      product: product(
        db.prepare("SELECT * FROM products WHERE id=?").get(row.id),
      ),
    });
  });
  app.get("/api/product-cover/:id", (req, res) => {
    const row = db
      .prepare("SELECT id,status,cover_path FROM products WHERE id=?")
      .get(req.params.id);
    if (
      !row?.cover_path ||
      !(
        row.status === "published" ||
        req.user?.role === "admin" ||
        owns(req.user, row.id)
      )
    )
      return fail(res, 404, "Cover not found.");
    res.setHeader(
      "Cache-Control",
      row.status === "published" ? "public, max-age=3600" : "private, no-store",
    );
    res.sendFile(resolve(dataDir, "uploads", basename(row.cover_path)));
  });
  app.patch("/api/admin/tickets/:id", requireAdmin, (req, res) => {
    if (!["open", "resolved"].includes(req.body?.status))
      return fail(res, 400, "Invalid ticket status.");
    const result = db
      .prepare("UPDATE tickets SET status=? WHERE id=?")
      .run(req.body.status, req.params.id);
    return result.changes
      ? res.json({ success: true })
      : fail(res, 404, "Ticket not found.");
  });
  app.get("/api/account/export", requireAuth, (req, res) => {
    res.setHeader(
      "Content-Disposition",
      'attachment; filename="rtr-digital-account.json"',
    );
    res.json({
      user: safeUser(req.user),
      orders: db
        .prepare("SELECT payload FROM orders WHERE user_id=?")
        .all(req.user.id)
        .map((x) => JSON.parse(x.payload)),
      wishlist: JSON.parse(
        db
          .prepare("SELECT product_ids FROM wishlists WHERE user_id=?")
          .get(req.user.id)?.product_ids || "[]",
      ),
      supportTickets: db
        .prepare(
          "SELECT id,email,subject,message,status,created_at FROM tickets WHERE user_id=?",
        )
        .all(req.user.id),
    });
  });
  app.use("/api", (_req, res) => fail(res, 404, "API endpoint not found."));
  registerSite(app, { root, products, product, db, publicBaseUrl, production });
  const dist = resolve(root, "dist");
  if (existsSync(dist)) {
    app.use(express.static(dist));
    app.get("/{*path}", (_req, res) =>
      res.sendFile(resolve(dist, "index.html")),
    );
  }
  app.use((error, _req, res, _next) => {
    if (error instanceof multer.MulterError)
      return fail(
        res,
        400,
        error.code === "LIMIT_FILE_SIZE"
          ? "Each uploaded file must be 100 MB or smaller."
          : "Upload could not be accepted. Check file and field limits.",
      );
    if (error.type === "entity.parse.failed")
      return fail(res, 400, "Request contains invalid JSON.");
    if (error.type === "entity.too.large")
      return fail(res, 413, "Request is too large.");
    if (error.message?.startsWith("Cover must"))
      return fail(res, 400, error.message);
    console.error("RTR API error:", error.code || error.type || error.name);
    fail(res, 500, "Something went wrong. Please try again.");
  });
  return { app, db, close: () => db.close() };
}

if (
  process.argv[1] &&
  resolve(process.argv[1]) === fileURLToPath(import.meta.url)
) {
  const { app } = createApp();
  const port = Number(process.env.API_PORT || process.env.PORT || 3001);
  app.listen(port, "0.0.0.0", () =>
    console.log(
      `RTR Digital API listening on port ${port}. ${process.env.NODE_ENV === "production" ? "Production mode." : "Development demo mode — no real charges."}`,
    ),
  );
}
