import test from "node:test";
import assert from "node:assert/strict";
import { mkdirSync, mkdtempSync, rmSync, writeFileSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import Stripe from "stripe";
import { createApp } from "./index.mjs";

const PASSWORD = "a-strong-test-password";
async function fixture(t, options = {}) {
  const dataDir = mkdtempSync(join(tmpdir(), "rtr-membership-"));
  const instance = createApp({ dataDir, ...options });
  const server = instance.app.listen(0, "127.0.0.1");
  await new Promise((resolve) => server.once("listening", resolve));
  const base = `http://127.0.0.1:${server.address().port}`;
  t.after(async () => {
    await new Promise((resolve) => server.close(resolve));
    instance.close();
    rmSync(dataDir, { recursive: true, force: true });
  });
  const session = () => {
    let cookie = "";
    const request = async (path, method = "GET", body, headers = {}) => {
      const response = await fetch(base + path, {
        method,
        headers: {
          ...(cookie ? { Cookie: cookie } : {}),
          ...(body === undefined ? {} : { "Content-Type": "application/json" }),
          ...headers,
        },
        ...(body === undefined ? {} : { body: JSON.stringify(body) }),
      });
      if (response.headers.get("set-cookie"))
        cookie = response.headers.get("set-cookie").split(";")[0];
      const text = await response.text();
      let data;
      try {
        data = JSON.parse(text);
      } catch {
        data = text;
      }
      return { status: response.status, data, headers: response.headers };
    };
    return {
      request,
      async register(email, name = "Creative Member") {
        const result = await request("/api/auth/register", "POST", {
          name,
          email,
          password: PASSWORD,
        });
        assert.equal(result.status, 201, JSON.stringify(result.data));
        return result.data.user;
      },
    };
  };
  return { ...instance, base, session, dataDir };
}
const post = (client, path, body) => client.request(path, "POST", body);
const setSubscription = (db, id, changes = {}) => {
  const current = JSON.parse(
    db.prepare("SELECT subscription FROM users WHERE id=?").get(id)
      .subscription || "{}",
  );
  db.prepare("UPDATE users SET subscription=? WHERE id=?").run(
    JSON.stringify({
      plan: "studio",
      interval: "monthly",
      status: "active",
      mode: "demo",
      currentPeriodEnd: new Date(Date.now() + 30 * 86400000).toISOString(),
      ...current,
      ...changes,
    }),
    id,
  );
};

// These exercise account/database state and the actual HTTP authorization paths,
// rather than merely verifying that the new routes return a successful status.
test("free preview is once per account/email, grants timed access, and never records a charge", async (t) => {
  const { session, db } = await fixture(t);
  const customer = session();
  const user = await customer.register("trial@example.test");
  assert.equal(
    (await customer.request("/api/membership/hub")).data.trialEligible,
    true,
  );
  assert.equal(
    (await post(customer, "/api/membership/trial", { plan: "studio" })).status,
    400,
  );
  const trial = await post(customer, "/api/membership/trial", {
    plan: "creator",
  });
  assert.equal(trial.status, 201);
  assert.equal(trial.data.subscription.status, "trialing");
  assert.equal(trial.data.subscription.autoRenew, false);
  assert.equal(trial.data.subscription.cancelAtPeriodEnd, true);
  assert.ok(
    Date.parse(trial.data.subscription.currentPeriodEnd) >
      Date.now() + 6.99 * 86400000,
  );
  assert.equal(
    (await customer.request("/api/library")).data.products.length,
    12,
  );
  assert.equal(db.prepare("SELECT count(*) AS n FROM orders").get().n, 0);
  const hub = await customer.request("/api/membership/hub");
  assert.equal(hub.data.trialEligible, false);
  assert.equal(hub.data.events[0].type, "trial.started");
  assert.equal((await post(customer, "/api/membership/trial")).status, 409);
  assert.equal((await post(customer, "/api/membership/trial/end")).status, 200);
  assert.equal(
    (await customer.request("/api/library")).data.products.length,
    0,
  );
  assert.equal((await post(customer, "/api/membership/trial")).status, 409);
  // Retaining the original email hash prevents deletion/email-change signup cycling.
  db.prepare("UPDATE users SET email=? WHERE id=?").run(
    "changed-trial@example.test",
    user.id,
  );
  const replacement = session();
  await replacement.register("trial@example.test");
  assert.equal((await post(replacement, "/api/membership/trial")).status, 409);
  assert.equal((await post(customer, "/api/membership/trial")).status, 409);
});

test("expired trials lose downloads and remain ineligible; shared and production identities cannot claim previews", async (t) => {
  const { session, db } = await fixture(t);
  const customer = session();
  const user = await customer.register("expired-trial@example.test");
  await post(customer, "/api/membership/trial", { plan: "starter" });
  setSubscription(db, user.id, {
    currentPeriodEnd: new Date(Date.now() - 1000).toISOString(),
  });
  assert.equal(
    (await customer.request("/api/download/focus-deep-work")).status,
    403,
  );
  assert.equal(
    (await customer.request("/api/membership/hub")).data.trialEligible,
    false,
  );
  const shared = session();
  await post(shared, "/api/auth/demo", { role: "customer" });
  assert.equal((await post(shared, "/api/membership/trial")).status, 409);
  const production = await fixture(t, {
    production: true,
    trialsEnabled: false,
  });
  const real = production.session();
  const liveUser = await real.register("production-trial@example.test");
  setSubscription(production.db, liveUser.id, {
    status: "trialing",
    isTrial: true,
  });
  assert.equal((await post(real, "/api/membership/trial")).status, 503);
  assert.equal((await real.request("/api/library")).data.products.length, 0);
  assert.equal(
    (await real.request("/api/membership/hub")).data.subscription,
    null,
  );
});

test("Studio reservations enforce five total seats and private invites are email-bound, expiring and single-use", async (t) => {
  const { session, db } = await fixture(t);
  const owner = session();
  const ownerUser = await owner.register("owner@example.test", "Studio Owner");
  assert.equal(
    (await post(owner, "/api/membership/team", { name: "The Studio" })).status,
    403,
  );
  await post(owner, "/api/checkout", { plan: "studio", mode: "demo" });
  const team = await post(owner, "/api/membership/team", {
    name: "The Studio",
  });
  assert.equal(team.status, 201);
  assert.equal(team.data.team.members.length, 1);
  assert.equal(team.data.team.seatLimit, 5);
  assert.equal(
    (await post(owner, "/api/membership/team", { name: "Second Studio" }))
      .status,
    409,
  );
  assert.equal(
    (
      await post(owner, "/api/membership/team/invites", {
        email: ownerUser.email,
      })
    ).status,
    400,
  );
  const invitations = [];
  for (let index = 0; index < 4; index++) {
    const invite = await post(owner, "/api/membership/team/invites", {
      email: `member-${index}@example.test`,
    });
    assert.equal(invite.status, 201);
    invitations.push(invite.data);
  }
  assert.equal(
    (
      await post(owner, "/api/membership/team/invites", {
        email: "overflow@example.test",
      })
    ).status,
    409,
  );
  assert.equal(
    (
      await post(owner, "/api/membership/team/invites", {
        email: "member-0@example.test",
      })
    ).status,
    409,
  );
  const token = new URL(
    invitations[0].inviteUrl,
    "https://store.example",
  ).searchParams.get("invite");
  assert.match(token, /^[a-f0-9]{64}$/);
  const stored = db
    .prepare("SELECT * FROM studio_invites WHERE id=?")
    .get(invitations[0].invite.id);
  assert.notEqual(stored.token_hash, token);
  assert.equal(stored.token_hash.length, 64);
  const outsider = session();
  await outsider.register("outsider@example.test");
  assert.equal(
    (await outsider.request(`/api/membership/team/invites/${token}`)).status,
    404,
  );
  assert.equal(
    (await post(outsider, `/api/membership/team/invites/${token}/accept`))
      .status,
    404,
  );
  const member = session();
  const memberUser = await member.register("member-0@example.test");
  assert.equal(
    (await member.request(`/api/membership/team/invites/${token}`)).data.invite
      .teamName,
    "The Studio",
  );
  const joined = await post(
    member,
    `/api/membership/team/invites/${token}/accept`,
    { role: "owner" },
  );
  assert.equal(joined.status, 200);
  assert.equal(joined.data.team.role, "member");
  assert.equal(
    (await member.request("/api/auth/me")).data.user.role,
    "customer",
  );
  assert.equal((await member.request("/api/admin/stats")).status, 403);
  assert.equal(
    (
      await post(member, "/api/membership/team/invites", {
        email: "attacker@example.test",
      })
    ).status,
    403,
  );
  assert.equal(
    (await post(member, `/api/membership/team/invites/${token}/accept`)).status,
    404,
  );
  assert.equal((await member.request("/api/library")).data.products.length, 12);
  const privateView = (await member.request("/api/membership/hub")).data.team;
  assert.equal(privateView.invites.length, 0);
  assert.equal(privateView.occupiedSeats + privateView.reservedSeats, 5);
  db.prepare("UPDATE studio_invites SET expires_at=? WHERE id=?").run(
    new Date(Date.now() - 1000).toISOString(),
    invitations[1].invite.id,
  );
  const expired = session();
  await expired.register("member-1@example.test");
  const expiredToken = new URL(
    invitations[1].inviteUrl,
    "https://store.example",
  ).searchParams.get("invite");
  assert.equal(
    (await post(expired, `/api/membership/team/invites/${expiredToken}/accept`))
      .status,
    404,
  );
  assert.equal(
    (
      await post(owner, "/api/membership/team/invites", {
        email: "replacement@example.test",
      })
    ).status,
    201,
  );
  assert.equal(
    memberUser.id,
    joined.data.team.members.find((item) => item.role === "member").id,
  );
});

test("removing members, revoking invitations and owner expiry revoke shared access without removing personal purchases", async (t) => {
  const { session, db } = await fixture(t);
  const owner = session();
  const ownerUser = await owner.register("revocation-owner@example.test");
  await post(owner, "/api/checkout", { plan: "studio", mode: "demo" });
  await post(owner, "/api/membership/team", { name: "Access Lab" });
  const member = session();
  const memberUser = await member.register("revocation-member@example.test");
  const invited = await post(owner, "/api/membership/team/invites", {
    email: memberUser.email,
  });
  const token = new URL(
    invited.data.inviteUrl,
    "https://store.example",
  ).searchParams.get("invite");
  await post(member, `/api/membership/team/invites/${token}/accept`);
  await post(member, "/api/checkout", {
    productIds: ["focus-deep-work"],
    mode: "demo",
  });
  db.prepare(
    "UPDATE products SET status='draft' WHERE id='studio-brand-kit'",
  ).run();
  assert.equal(
    (await member.request("/api/download/studio-brand-kit")).status,
    403,
  );
  assert.equal((await member.request("/api/library")).data.products.length, 11);
  setSubscription(db, ownerUser.id, {
    currentPeriodEnd: new Date(Date.now() - 1000).toISOString(),
  });
  assert.equal(
    (await member.request("/api/membership/hub")).data.team.active,
    false,
  );
  assert.deepEqual(
    (await member.request("/api/library")).data.products.map((item) => item.id),
    ["focus-deep-work"],
  );
  setSubscription(db, ownerUser.id, {
    currentPeriodEnd: new Date(Date.now() + 86400000).toISOString(),
    plan: "creator",
  });
  assert.equal(
    (await member.request("/api/download/ambient-essentials")).status,
    403,
  );
  setSubscription(db, ownerUser.id, { plan: "studio" });
  assert.equal(
    (await member.request("/api/download/ambient-essentials")).status,
    200,
  );
  assert.equal(
    (
      await owner.request(
        `/api/membership/team/members/${ownerUser.id}`,
        "DELETE",
      )
    ).status,
    400,
  );
  assert.equal(
    (await member.request("/api/membership/team", "DELETE")).status,
    403,
  );
  assert.equal(
    (
      await owner.request(
        `/api/membership/team/members/${memberUser.id}`,
        "DELETE",
      )
    ).status,
    200,
  );
  assert.deepEqual(
    (await member.request("/api/library")).data.products.map((item) => item.id),
    ["focus-deep-work"],
  );
  assert.equal((await member.request("/api/membership/hub")).data.team, null);
  const pending = await post(owner, "/api/membership/team/invites", {
    email: memberUser.email,
  });
  assert.equal(
    (
      await owner.request(
        `/api/membership/team/invites/${pending.data.invite.id}`,
        "DELETE",
      )
    ).status,
    200,
  );
  const revokedToken = new URL(
    pending.data.inviteUrl,
    "https://store.example",
  ).searchParams.get("invite");
  assert.equal(
    (await post(member, `/api/membership/team/invites/${revokedToken}/accept`))
      .status,
    404,
  );
  assert.equal(
    (await owner.request("/api/membership/team", "DELETE")).status,
    200,
  );
  assert.equal(db.prepare("SELECT count(*) AS n FROM studio_teams").get().n, 0);
  assert.equal((await owner.request("/api/library")).data.products.length, 11);
});

test("production Studio invitation acceptance requires verified email ownership", async (t) => {
  const { session, db } = await fixture(t, { production: true });
  const owner = session();
  const ownerUser = await owner.register("live-owner@example.test");
  setSubscription(db, ownerUser.id, {
    mode: "stripe",
    stripeSubscriptionId: "sub_live_owner",
  });
  assert.equal(
    (await post(owner, "/api/membership/team", { name: "Live Studio" })).status,
    201,
  );
  assert.equal(
    (await owner.request("/api/membership/hub")).data.events[0].mode,
    "stripe",
  );
  const member = session();
  const memberUser = await member.register("live-member@example.test");
  const invited = await post(owner, "/api/membership/team/invites", {
    email: memberUser.email,
  });
  const token = new URL(
    invited.data.inviteUrl,
    "https://store.example",
  ).searchParams.get("invite");
  assert.equal(
    (await post(member, `/api/membership/team/invites/${token}/accept`)).status,
    403,
  );
  db.prepare(
    "INSERT INTO account_security (user_id,verified_email) VALUES (?,?) ON CONFLICT(user_id) DO UPDATE SET verified_email=excluded.verified_email",
  ).run(memberUser.id, memberUser.email);
  assert.equal(
    (await post(member, `/api/membership/team/invites/${token}/accept`)).status,
    200,
  );
  assert.equal((await member.request("/api/library")).data.products.length, 12);
  assert.equal(
    (await member.request("/api/membership/hub")).data.events[0].mode,
    "stripe",
  );
});

test("renewal reminders are deduplicated, private, and persisted in account notifications", async (t) => {
  const { session, db } = await fixture(t);
  const customer = session();
  const user = await customer.register("reminder@example.test");
  await post(customer, "/api/checkout", { plan: "creator", mode: "demo" });
  setSubscription(db, user.id, {
    currentPeriodEnd: new Date(Date.now() + 3 * 86400000).toISOString(),
  });
  const first = await customer.request("/api/membership/hub");
  assert.equal(first.data.reminders.length, 1);
  const reminder = first.data.reminders[0];
  await customer.request("/api/membership/hub");
  assert.equal(
    db
      .prepare("SELECT count(*) AS n FROM membership_reminders WHERE user_id=?")
      .get(user.id).n,
    1,
  );
  assert.equal(
    db
      .prepare(
        "SELECT count(*) AS n FROM account_notifications WHERE user_id=?",
      )
      .get(user.id).n,
    1,
  );
  const outsider = session();
  await outsider.register("reminder-outsider@example.test");
  assert.equal(
    (await post(outsider, `/api/membership/reminders/${reminder.id}/read`))
      .status,
    404,
  );
  assert.equal(
    (await post(customer, `/api/membership/reminders/${reminder.id}/read`))
      .status,
    200,
  );
  assert.equal(
    (await customer.request("/api/membership/hub")).data.reminders[0].read,
    true,
  );
});

test("signed billing events refresh authoritative access, preserve one renewal receipt and exclude tax from MRR", async (t) => {
  const sdk = new Stripe("sk_test_local_only");
  const secret = "whsec_local_membership_events";
  let liveStatus = "active";
  const future = Math.floor((Date.now() + 31 * 86400000) / 1000);
  const stripeClient = {
    webhooks: sdk.webhooks,
    subscriptions: {
      retrieve: async (id) => ({
        id,
        status: liveStatus,
        current_period_end: future,
        cancel_at_period_end: false,
      }),
    },
  };
  const { session, db, base } = await fixture(t, {
    stripeClient,
    webhookSecret: secret,
    publicUrl: "https://store.example",
  });
  const customer = session();
  const user = await customer.register("billing-events@example.test");
  setSubscription(db, user.id, {
    plan: "creator",
    mode: "stripe",
    stripeSubscriptionId: "sub_billing_events",
  });
  const admin = session();
  await post(admin, "/api/auth/demo", { role: "admin" });
  const send = async (event) => {
    const payload = JSON.stringify(event);
    const signature = sdk.webhooks.generateTestHeaderString({
      payload,
      secret,
    });
    const result = await fetch(`${base}/api/stripe/webhook`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "stripe-signature": signature,
      },
      body: payload,
    });
    return { status: result.status, data: await result.json() };
  };
  const invoice = {
    id: "in_renewal_01",
    subscription: "sub_billing_events",
    billing_reason: "subscription_cycle",
    status: "paid",
    amount_paid: 2242,
    total_excluding_tax: 1900,
    total_tax_amounts: [{ amount: 342 }],
    currency: "usd",
  };
  const event = {
    id: "evt_membership_paid",
    type: "invoice.paid",
    data: { object: invoice },
  };
  assert.equal((await send(event)).status, 200);
  assert.equal((await send(event)).status, 200);
  assert.equal(
    db
      .prepare("SELECT count(*) AS n FROM orders WHERE id='INV-in_renewal_01'")
      .get().n,
    1,
  );
  const saved = JSON.parse(
    db.prepare("SELECT payload FROM orders WHERE id='INV-in_renewal_01'").get()
      .payload,
  );
  assert.equal(saved.total, 22.42);
  assert.equal(saved.subtotal, 19);
  assert.equal(saved.tax, 3.42);
  assert.equal(saved.seller.sellerName, "RTR Digital");
  assert.equal(saved.seller.licensor, "RTR Digital");
  const sellerSnapshot = { ...saved.seller };
  const updateSeller = await admin.request(
    "/api/admin/commerce/settings",
    "PATCH",
    { sellerName: "Other seller", address: "Changed after renewal" },
  );
  assert.equal(updateSeller.status, 200);
  assert.equal(updateSeller.data.settings.sellerName, "RTR Digital");
  const receipt = await customer.request(
    "/api/billing/orders/INV-in_renewal_01/receipt",
  );
  assert.equal(receipt.status, 200);
  assert.match(receipt.data, /Seller: RTR Digital/);
  assert.match(receipt.data, /Licensor: RTR Digital/);
  assert.doesNotMatch(receipt.data, /Changed after renewal/);
  const health = await admin.request("/api/admin/billing-health");
  assert.equal(health.data.liveMrr, 19);
  assert.equal(health.data.liveArr, 228);
  assert.equal(health.data.demoMrr, 0);
  assert.equal(
    (await customer.request("/api/membership/hub")).data.events.length,
    1,
  );
  assert.equal(
    (
      await send({
        ...event,
        id: "evt_membership_succeeded",
        type: "invoice.payment_succeeded",
      })
    ).status,
    200,
  );
  assert.equal(
    db
      .prepare("SELECT count(*) AS n FROM orders WHERE id='INV-in_renewal_01'")
      .get().n,
    1,
  );
  assert.deepEqual(
    JSON.parse(
      db
        .prepare("SELECT payload FROM orders WHERE id='INV-in_renewal_01'")
        .get().payload,
    ).seller,
    sellerSnapshot,
  );
  assert.equal(
    db
      .prepare(
        "SELECT count(*) AS n FROM audit_log WHERE action='membership.renewal_recorded'",
      )
      .get().n,
    1,
  );
  liveStatus = "past_due";
  const failed = {
    id: "evt_membership_failed",
    type: "invoice.payment_failed",
    data: {
      object: {
        id: "in_failed_02",
        subscription: "sub_billing_events",
        status: "open",
        amount_due: 1900,
        currency: "usd",
      },
    },
  };
  assert.equal((await send(failed)).status, 200);
  assert.equal(
    (await customer.request("/api/download/focus-deep-work")).status,
    403,
  );
  assert.equal(
    (await customer.request("/api/membership/hub")).data.reminders.length,
    1,
  );
  const failedHealth = await admin.request("/api/admin/billing-health");
  assert.equal(failedHealth.data.pastDueLiveSubscriptions, 1);
  assert.equal(failedHealth.data.liveMrr, 0);
  const unsigned = await fetch(`${base}/api/stripe/webhook`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(event),
  });
  assert.equal(unsigned.status, 400);
});

test("a free preview cannot extend itself through plan changes but can convert through explicit checkout", async (t) => {
  const { session } = await fixture(t);
  const customer = session();
  await customer.register("trial-conversion@example.test");
  const trial = await post(customer, "/api/membership/trial", {
    plan: "creator",
  });
  assert.equal(trial.status, 201);
  assert.equal(
    (
      await post(customer, "/api/subscription/change", {
        plan: "studio",
        interval: "yearly",
      })
    ).status,
    400,
  );
  assert.equal((await post(customer, "/api/subscription/resume")).status, 400);
  assert.equal((await post(customer, "/api/subscription/cancel")).status, 400);
  assert.equal(
    (await customer.request("/api/membership/hub")).data.subscription
      .currentPeriodEnd,
    trial.data.subscription.currentPeriodEnd,
  );
  const checkout = await post(customer, "/api/checkout", {
    plan: "studio",
    interval: "monthly",
    mode: "demo",
  });
  assert.equal(checkout.status, 200);
  assert.equal(checkout.data.user.subscription.status, "active");
  assert.equal(Boolean(checkout.data.user.subscription.isTrial), false);
  assert.equal(checkout.data.user.subscription.plan, "studio");
  assert.equal((await customer.request("/api/library")).data.orders.length, 1);
  assert.equal(
    (await customer.request("/api/membership/hub")).data.trialEligible,
    false,
  );
});

test("optional renewal emails honor preferences while in-app expiry reminders remain available", async (t) => {
  const deliveries = [];
  const { session, db } = await fixture(t, {
    emailTransport: async (mail) => {
      deliveries.push(mail);
    },
  });
  const customer = session();
  const user = await customer.register("reminder-preferences@example.test");
  await post(customer, "/api/checkout", { plan: "creator", mode: "demo" });
  db.prepare("INSERT INTO account_preferences VALUES (?,?,?)").run(
    user.id,
    JSON.stringify({ renewalReminders: false }),
    new Date().toISOString(),
  );
  setSubscription(db, user.id, {
    currentPeriodEnd: new Date(Date.now() + 3 * 86400000).toISOString(),
  });
  assert.equal(
    (await customer.request("/api/membership/hub")).data.reminders.length,
    1,
  );
  assert.equal(deliveries.length, 0);
  db.prepare("UPDATE account_preferences SET payload=? WHERE user_id=?").run(
    JSON.stringify({ renewalReminders: true }),
    user.id,
  );
  setSubscription(db, user.id, {
    currentPeriodEnd: new Date(Date.now() + 4 * 86400000).toISOString(),
  });
  assert.equal(
    (await customer.request("/api/membership/hub")).data.reminders.length,
    2,
  );
  assert.equal(deliveries.length, 1);
  await customer.request("/api/membership/hub");
  assert.equal(deliveries.length, 1);
  setSubscription(db, user.id, {
    currentPeriodEnd: new Date(Date.now() - 1000).toISOString(),
  });
  const expired = await customer.request("/api/membership/hub");
  assert.equal(
    expired.data.reminders[0].title,
    "Your recorded membership access period has ended",
  );
});

test("production trials default off, honor the environment opt-in, and allow an explicit operator override", async (t) => {
  const previous = process.env.TRIALS_ENABLED;
  try {
    delete process.env.TRIALS_ENABLED;
    const disabled = await fixture(t, { production: true, demoMode: true });
    const customer = disabled.session();
    await customer.register("default-disabled@example.test");
    const hub = (await customer.request("/api/membership/hub")).data;
    assert.equal(hub.trialEligible, false);
    assert.equal(hub.trialPolicy.enabled, false);
    assert.equal(hub.trialPolicy.mode, "trial");
    assert.equal((await post(customer, "/api/membership/trial")).status, 503);
    assert.equal(
      disabled.db.prepare("SELECT count(*) AS n FROM membership_trials").get()
        .n,
      0,
    );

    process.env.TRIALS_ENABLED = "true";
    const enabled = await fixture(t, { production: true });
    const enabledCustomer = enabled.session();
    await enabledCustomer.register("environment-enabled@example.test");
    assert.equal(
      (await enabledCustomer.request("/api/membership/hub")).data.trialPolicy
        .enabled,
      true,
    );

    const overridden = await fixture(t, {
      production: true,
      trialsEnabled: false,
    });
    const overriddenCustomer = overridden.session();
    await overriddenCustomer.register("operator-disabled@example.test");
    assert.equal(
      (await overriddenCustomer.request("/api/membership/hub")).data.trialPolicy
        .enabled,
      false,
    );
  } finally {
    if (previous === undefined) delete process.env.TRIALS_ENABLED;
    else process.env.TRIALS_ENABLED = previous;
  }
});

test("opt-in production trial requires the current verified email and an original published downloadable membership file", async (t) => {
  const { session, db, dataDir } = await fixture(t, {
    production: true,
    trialsEnabled: true,
    stripeKey: "",
  });
  const customer = session();
  const user = await customer.register("real-trial@example.test");
  const policy = (await customer.request("/api/membership/hub")).data
    .trialPolicy;
  assert.deepEqual(policy, {
    enabled: true,
    mode: "trial",
    durationDays: 7,
    automaticRenewal: false,
    requiresCard: false,
    requiresVerifiedEmail: true,
    requiresOriginalContent: true,
  });
  assert.equal((await post(customer, "/api/membership/trial")).status, 403);
  db.prepare(
    "INSERT INTO account_security (user_id,verified_email) VALUES (?,?)",
  ).run(user.id, "previous-address@example.test");
  assert.equal((await post(customer, "/api/membership/trial")).status, 403);
  db.prepare(
    "UPDATE account_security SET verified_email=? WHERE user_id=?",
  ).run(user.email, user.id);
  assert.equal((await post(customer, "/api/membership/trial")).status, 503);

  const sample = JSON.parse(
    db.prepare("SELECT payload FROM products WHERE id='focus-deep-work'").get()
      .payload,
  );
  const original = {
    ...sample,
    id: "original-trial-guide",
    isSample: false,
    title: "Original creator guide",
    subscriptionIncluded: true,
  };
  const saveProduct = ({
    status = "published",
    filePath = "trial-original.txt",
    payload = {},
  } = {}) => {
    db.prepare(
      "INSERT INTO products (id,payload,status,file_path,created_at) VALUES (?,?,?,?,?) ON CONFLICT(id) DO UPDATE SET payload=excluded.payload,status=excluded.status,file_path=excluded.file_path",
    ).run(
      original.id,
      JSON.stringify({ ...original, ...payload }),
      status,
      filePath,
      new Date().toISOString(),
    );
  };
  writeFileSync(
    join(dataDir, "uploads", "trial-original.txt"),
    "An original guide supplied by the operator.",
  );
  mkdirSync(join(dataDir, "uploads", "not-a-file"));
  for (const invalid of [
    { payload: { isSample: true } },
    { status: "draft" },
    { payload: { subscriptionIncluded: false } },
    { filePath: "missing-original.txt" },
    { filePath: "not-a-file" },
  ]) {
    saveProduct(invalid);
    const hub = (await customer.request("/api/membership/hub")).data;
    assert.equal(hub.trialEligible, false, JSON.stringify(invalid));
    assert.match(
      hub.trialUnavailableReason,
      /original membership-eligible file/,
    );
  }
  saveProduct();
  assert.equal(
    (await customer.request("/api/membership/hub")).data.trialEligible,
    true,
  );
  const result = await post(customer, "/api/membership/trial", {
    plan: "creator",
  });
  assert.equal(result.status, 201, JSON.stringify(result.data));
  const trial = result.data.subscription;
  assert.equal(trial.mode, "trial");
  assert.equal(trial.isTrial, true);
  assert.equal(trial.status, "trialing");
  assert.equal(trial.interval, "trial");
  assert.equal(trial.stripeSubscriptionId, null);
  assert.equal(trial.autoRenew, false);
  assert.equal(trial.cancelAtPeriodEnd, true);
  assert.ok(
    Math.abs(Date.parse(trial.currentPeriodEnd) - Date.now() - 7 * 86400000) <
      5000,
  );
  assert.equal(
    (await customer.request("/api/auth/me")).data.user.subscription.mode,
    "trial",
  );
  assert.equal(
    (await customer.request(`/api/download/${original.id}`)).data,
    "An original guide supplied by the operator.",
  );
  assert.ok(
    (await customer.request("/api/library")).data.products.some(
      (item) => item.id === original.id,
    ),
  );
  assert.equal(
    db.prepare("SELECT count(*) AS n FROM orders WHERE user_id=?").get(user.id)
      .n,
    0,
  );
  assert.equal(
    db
      .prepare("SELECT count(*) AS n FROM checkout_intents WHERE user_id=?")
      .get(user.id).n,
    0,
  );
  assert.equal(
    (
      await post(customer, "/api/subscription/change", {
        plan: "studio",
        interval: "yearly",
      })
    ).status,
    400,
  );
  assert.equal((await post(customer, "/api/subscription/resume")).status, 400);
  assert.equal((await post(customer, "/api/subscription/cancel")).status, 400);
  assert.equal((await post(customer, "/api/membership/trial")).status, 409);
  const activeHub = (await customer.request("/api/membership/hub")).data;
  assert.equal(activeHub.subscription.currentPeriodEnd, trial.currentPeriodEnd);
  assert.equal(activeHub.events[0].mode, "trial");
  assert.match(
    activeHub.reminders[0].message,
    /does not automatically renew or charge/,
  );
  const admin = session();
  const adminUser = await admin.register("trial-metrics-admin@example.test");
  db.prepare("UPDATE users SET role='admin' WHERE id=?").run(adminUser.id);
  const health = (await admin.request("/api/admin/billing-health")).data;
  assert.equal(health.activeTrials, 1);
  assert.equal(health.activeNoCardTrials, 1);
  assert.equal(health.activeDemoTrials, 0);
  assert.equal(health.activeLiveSubscriptions, 0);
  assert.equal(health.liveMrr, 0);
  assert.equal(health.demoMrr, 0);

  // Paid purchases survive expiry; preview access ends without a provider charge.
  db.prepare(
    "INSERT INTO entitlements (user_id,product_id,mode) VALUES (?,?,'stripe')",
  ).run(user.id, "focus-deep-work");
  setSubscription(db, user.id, {
    currentPeriodEnd: new Date(Date.now() - 1000).toISOString(),
  });
  assert.equal(
    (await customer.request(`/api/download/${original.id}`)).status,
    403,
  );
  assert.deepEqual(
    (await customer.request("/api/library")).data.products.map(
      (item) => item.id,
    ),
    ["focus-deep-work"],
  );
  const expiredHub = (await customer.request("/api/membership/hub")).data;
  assert.equal(expiredHub.trialEligible, false);
  assert.equal(expiredHub.events[0].type, "trial.ended");
  assert.equal(expiredHub.events[0].mode, "trial");
  await customer.request("/api/membership/hub");
  assert.equal(
    db
      .prepare(
        "SELECT count(*) AS n FROM membership_events WHERE user_id=? AND type='trial.ended'",
      )
      .get(user.id).n,
    1,
  );
  assert.equal((await post(customer, "/api/membership/trial")).status, 409);
});

test("a no-card trial never replaces an outstanding provider billing record", async (t) => {
  const { session, db, dataDir } = await fixture(t, {
    production: true,
    trialsEnabled: true,
  });
  const customer = session();
  const user = await customer.register("outstanding-billing@example.test");
  db.prepare(
    "INSERT INTO account_security (user_id,verified_email) VALUES (?,?)",
  ).run(user.id, user.email);
  const row = db
    .prepare("SELECT payload FROM products WHERE id='focus-deep-work'")
    .get();
  db.prepare(
    "UPDATE products SET payload=?,file_path=? WHERE id='focus-deep-work'",
  ).run(
    JSON.stringify({ ...JSON.parse(row.payload), isSample: false }),
    "billing-guide.txt",
  );
  writeFileSync(
    join(dataDir, "uploads", "billing-guide.txt"),
    "Original guide.",
  );
  for (const status of [
    "past_due",
    "unpaid",
    "incomplete",
    "paused",
    "active",
    "trialing",
  ]) {
    setSubscription(db, user.id, {
      mode: "stripe",
      stripeSubscriptionId: "sub_still_billable",
      status,
    });
    assert.equal(
      (await post(customer, "/api/membership/trial")).status,
      409,
      status,
    );
    assert.equal(
      (await customer.request("/api/membership/hub")).data.trialEligible,
      false,
    );
    const saved = JSON.parse(
      db.prepare("SELECT subscription FROM users WHERE id=?").get(user.id)
        .subscription,
    );
    assert.equal(saved.stripeSubscriptionId, "sub_still_billable");
    assert.equal(saved.status, status);
  }
  assert.equal(
    db
      .prepare("SELECT count(*) AS n FROM membership_trials WHERE user_id=?")
      .get(user.id).n,
    0,
  );
  for (const status of ["canceled", "incomplete_expired"]) {
    setSubscription(db, user.id, {
      mode: "stripe",
      stripeSubscriptionId: "sub_closed_billing",
      status,
    });
    assert.equal(
      (await customer.request("/api/membership/hub")).data.trialEligible,
      true,
      status,
    );
  }
  assert.equal((await post(customer, "/api/membership/trial")).status, 201);
});

test("production trial conversion requires an explicit USD checkout and a signed provider confirmation", async (t) => {
  const sdk = new Stripe("sk_test_local_only");
  const secret = "whsec_trial_conversion_local_only";
  const checkoutCalls = [];
  const stripeClient = {
    webhooks: sdk.webhooks,
    checkout: {
      sessions: {
        create: async (options) => {
          checkoutCalls.push(options);
          return {
            id: "cs_trial_conversion",
            url: "https://checkout.example.test/trial-conversion",
          };
        },
      },
    },
    subscriptions: {
      retrieve: async (id) => ({
        id,
        status: "active",
        current_period_end: Math.floor((Date.now() + 30 * 86400000) / 1000),
        cancel_at_period_end: false,
      }),
    },
  };
  const { session, db, dataDir, base } = await fixture(t, {
    production: true,
    trialsEnabled: true,
    stripeClient,
    webhookSecret: secret,
    publicUrl: "https://store.example.test",
    emailTransport: async () => {},
  });
  const customer = session();
  const user = await customer.register("paid-conversion@example.test");
  db.prepare(
    "INSERT INTO account_security (user_id,verified_email) VALUES (?,?)",
  ).run(user.id, user.email);
  const row = db
    .prepare("SELECT payload FROM products WHERE id='focus-deep-work'")
    .get();
  db.prepare(
    "UPDATE products SET payload=?,file_path=? WHERE id='focus-deep-work'",
  ).run(
    JSON.stringify({ ...JSON.parse(row.payload), isSample: false }),
    "real-guide.txt",
  );
  writeFileSync(join(dataDir, "uploads", "real-guide.txt"), "Original guide.");
  assert.equal(
    (await post(customer, "/api/membership/trial", { plan: "creator" })).status,
    201,
  );
  assert.equal(checkoutCalls.length, 0);
  const checkout = await post(customer, "/api/checkout", {
    plan: "creator",
    interval: "monthly",
    mode: "stripe",
  });
  assert.equal(checkout.status, 200, JSON.stringify(checkout.data));
  assert.equal(checkoutCalls.length, 1);
  const requested = checkoutCalls[0];
  assert.equal(requested.mode, "subscription");
  assert.equal(requested.line_items[0].price_data.currency, "usd");
  assert.equal(requested.line_items[0].price_data.unit_amount, 1900);
  assert.equal(
    (await customer.request("/api/membership/hub")).data.subscription.mode,
    "trial",
  );
  assert.equal(
    db.prepare("SELECT count(*) AS n FROM orders WHERE user_id=?").get(user.id)
      .n,
    0,
  );
  const payload = JSON.stringify({
    id: "evt_explicit_trial_conversion",
    type: "checkout.session.completed",
    data: {
      object: {
        id: "cs_trial_conversion",
        payment_status: "paid",
        amount_total: 1900,
        currency: "usd",
        subscription: "sub_paid_conversion",
        metadata: requested.metadata,
      },
    },
  });
  const response = await fetch(`${base}/api/stripe/webhook`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "stripe-signature": sdk.webhooks.generateTestHeaderString({
        payload,
        secret,
      }),
    },
    body: payload,
  });
  assert.equal(response.status, 200, await response.text());
  const hub = (await customer.request("/api/membership/hub")).data;
  assert.equal(hub.subscription.mode, "stripe");
  assert.equal(hub.subscription.status, "active");
  assert.equal(Boolean(hub.subscription.isTrial), false);
  assert.equal(hub.subscription.stripeSubscriptionId, "sub_paid_conversion");
  assert.equal(hub.trialEligible, false);
  assert.equal(
    db
      .prepare(
        "SELECT count(*) AS n FROM orders WHERE user_id=? AND mode='stripe'",
      )
      .get(user.id).n,
    1,
  );
});
