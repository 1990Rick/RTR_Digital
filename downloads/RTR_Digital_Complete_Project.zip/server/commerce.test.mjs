import test from "node:test";
import assert from "node:assert/strict";
import { mkdtempSync, rmSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { randomUUID } from "node:crypto";
import Stripe from "stripe";
import { createApp } from "./index.mjs";
import { registerCommerce } from "./modules/commerce.mjs";

async function fixture(t, options = {}) {
  const dataDir = mkdtempSync(join(tmpdir(), "rtr-commerce-"));
  const f = createApp({ dataDir, ...options });
  const server = f.app.listen(0, "127.0.0.1");
  await new Promise((r) => server.once("listening", r));
  const base = `http://127.0.0.1:${server.address().port}`;
  t.after(async () => {
    await new Promise((r) => server.close(r));
    f.close();
    rmSync(dataDir, { recursive: true, force: true });
  });
  const client = () => {
    let cookie = "";
    return async (
      path,
      { method = "GET", body, headers = {}, raw = false } = {},
    ) => {
      const r = await fetch(base + path, {
        method,
        headers: {
          ...(cookie ? { cookie } : {}),
          ...(body && !(body instanceof FormData)
            ? { "content-type": "application/json" }
            : {}),
          ...headers,
        },
        ...(body
          ? { body: body instanceof FormData ? body : JSON.stringify(body) }
          : {}),
      });
      if (r.headers.get("set-cookie"))
        cookie = r.headers.get("set-cookie").split(";")[0];
      return {
        status: r.status,
        data: raw ? await r.text() : await r.json(),
        headers: r.headers,
      };
    };
  };
  const admin = client(),
    buyer = client(),
    other = client();
  await admin("/api/auth/demo", { method: "POST", body: { role: "admin" } });
  for (const [request, email] of [
    [buyer, "buyer@commerce.test"],
    [other, "other@commerce.test"],
  ]) {
    const r = await request("/api/auth/register", {
      method: "POST",
      body: { name: "Creative Buyer", email, password: "A-secure-password-26" },
    });
    assert.equal(r.status, 201);
  }
  return { ...f, base, client, admin, buyer, other };
}
const post = (body, headers = {}) => ({ method: "POST", body, headers });
async function buy(buyer, more = {}) {
  const r = await buyer(
    "/api/checkout",
    post({ mode: "demo", productIds: ["studio-brand-kit"], ...more }),
  );
  assert.equal(r.status, 200, JSON.stringify(r.data));
  return r.data.orderId;
}

test("commerce promotions validate scope, dates, limits, trusted cents, and idempotent redemption", async (t) => {
  const { admin, buyer, other, db } = await fixture(t);
  assert.equal((await buyer("/api/admin/commerce")).status, 403);
  assert.equal(
    (
      await buyer(
        "/api/admin/commerce/promotions",
        post({ code: "ILLEGAL", percent: 90 }),
      )
    ).status,
    403,
  );
  const created = await admin(
    "/api/admin/commerce/promotions",
    post({
      code: "ONCE25",
      percent: 25,
      scope: "products",
      maxUses: 1,
      perUser: 1,
      minSpend: 20,
    }),
  );
  assert.equal(created.status, 201);
  const quote = await buyer(
    "/api/checkout/quote",
    post({ productIds: ["studio-brand-kit"], coupon: "once25" }),
  );
  assert.equal(quote.status, 200);
  assert.equal(quote.data.total, 29.25);
  assert.equal(quote.data.discount, 9.75);
  assert.equal(quote.data.currency, "USD");
  assert.equal(
    (
      await buyer(
        "/api/checkout/quote",
        post({ plan: "creator", coupon: "ONCE25" }),
      )
    ).status,
    400,
  );
  const key = "promotion-order-123";
  const first = await buyer("/api/checkout", {
    ...post({
      mode: "demo",
      productIds: ["studio-brand-kit"],
      coupon: "ONCE25",
    }),
    headers: { "Idempotency-Key": key },
  });
  assert.equal(first.status, 200);
  const retry = await buyer("/api/checkout", {
    ...post({
      mode: "demo",
      productIds: ["studio-brand-kit"],
      coupon: "ONCE25",
    }),
    headers: { "Idempotency-Key": key },
  });
  assert.equal(retry.data.orderId, first.data.orderId);
  assert.equal(
    db.prepare("SELECT count(*) n FROM commerce_redemptions").get().n,
    1,
  );
  assert.equal(
    (
      await other(
        "/api/checkout/quote",
        post({ productIds: ["studio-brand-kit"], coupon: "ONCE25" }),
      )
    ).status,
    409,
  );
  await admin(
    "/api/admin/commerce/promotions",
    post({ code: "EXPIRED", percent: 10, endsAt: "2020-01-01" }),
  );
  assert.equal(
    (
      await buyer(
        "/api/checkout/quote",
        post({ productIds: ["studio-brand-kit"], coupon: "EXPIRED" }),
      )
    ).status,
    400,
  );
  assert.equal(
    (await buyer("/api/checkout/quote", post({ plan: ["creator"] }))).status,
    400,
  );
  const toggle = await admin(
    `/api/admin/commerce/promotions/${created.data.promotion.id}`,
    { method: "PATCH", body: { enabled: false } },
  );
  assert.equal(toggle.status, 200);
});

test("demo refunds preserve independent purchases, revoke last grant, and cannot cross account boundaries", async (t) => {
  const { admin, buyer, other, db } = await fixture(t);
  const one = await buy(buyer);
  const two = await buy(buyer);
  assert.equal((await other(`/api/billing/orders/${one}/receipt`)).status, 404);
  assert.equal(
    (
      await other(
        `/api/billing/orders/${one}/refunds`,
        post({ reason: "Please refund this unauthorized request." }),
      )
    ).status,
    404,
  );
  const first = await buyer(
    `/api/billing/orders/${one}/refunds`,
    post({ reason: "This original purchase needs a refund." }),
  );
  assert.equal(first.status, 201);
  assert.equal(
    (
      await buyer(
        `/api/billing/orders/${one}/refunds`,
        post({ reason: "A duplicate refund request should be idempotent." }),
      )
    ).data.refund.id,
    first.data.refund.id,
  );
  assert.equal(
    (
      await buyer(
        `/api/admin/commerce/refunds/${first.data.refund.id}/approve`,
        post({}),
      )
    ).status,
    403,
  );
  assert.equal(
    (
      await admin(
        `/api/admin/commerce/refunds/${first.data.refund.id}/approve`,
        post({}),
      )
    ).status,
    200,
  );
  assert.equal(
    (await buyer("/api/download/studio-brand-kit", { raw: true })).status,
    200,
  );
  const second = await buyer(
    `/api/billing/orders/${two}/refunds`,
    post({ reason: "Refund my second purchase as well." }),
  );
  await admin(
    `/api/admin/commerce/refunds/${second.data.refund.id}/approve`,
    post({}),
  );
  assert.equal(
    (await buyer("/api/download/studio-brand-kit", { raw: true })).status,
    403,
  );
  assert.equal(
    (
      await admin(
        `/api/admin/commerce/refunds/${second.data.refund.id}/approve`,
        post({}),
      )
    ).data.alreadyProcessed,
    true,
  );
  assert.equal(
    db
      .prepare(
        "SELECT COUNT(*) n FROM commerce_refunds WHERE status='approved'",
      )
      .get().n,
    2,
  );
  const office = await admin("/api/admin/commerce");
  assert.equal(office.data.finance.grossRevenue, 0);
  assert.equal(office.data.finance.demoTotal, 0);
  assert.equal(office.data.settings.country, "IN");
});

test("receipts escape seller address, expose actual tax totals, and customer orders remain private", async (t) => {
  const { admin, buyer, db } = await fixture(t);
  await admin("/api/admin/commerce/settings", {
    method: "PATCH",
    body: {
      sellerName: "Other Seller",
      address: "India <script>alert(1)</script>",
      taxId: "",
      supportEmail: "help@example.test",
    },
  });
  const id = await buy(buyer);
  await admin("/api/admin/commerce/settings", {
    method: "PATCH",
    body: { sellerName: "Later Seller Name", address: "Later address" },
  });
  const order = db.prepare("SELECT payload FROM orders WHERE id=?").get(id);
  const data = {
    ...JSON.parse(order.payload),
    subtotal: 35.1,
    tax: 2.1,
    total: 37.2,
  };
  db.prepare("UPDATE orders SET payload=?,amount=? WHERE id=?").run(
    JSON.stringify(data),
    data.total,
    id,
  );
  const receipt = await buyer(`/api/billing/orders/${id}/receipt`, {
    raw: true,
  });
  assert.equal(receipt.status, 200);
  assert.match(receipt.data, /&lt;script&gt;/);
  assert.doesNotMatch(receipt.data, /<script>/);
  assert.doesNotMatch(receipt.data, /Later Seller Name/);
  assert.doesNotMatch(receipt.data, /Later address/);
  assert.match(receipt.data, /Seller: RTR Digital/);
  assert.match(receipt.data, /Licensor: RTR Digital/);
  assert.match(receipt.data, /\$37\.20/);
  assert.match(receipt.data, /Tax collected: \$2\.10/);
  assert.match(receipt.data, /not a tax invoice/);
  assert.match(
    receipt.headers.get("content-security-policy"),
    /default-src 'none'/,
  );
  const records = await buyer("/api/billing/orders");
  assert.equal(records.data.orders.length, 1);
  assert.equal(
    records.data.orders[0].receiptUrl,
    `/api/billing/orders/${id}/receipt`,
  );
  assert.equal(
    (await buyer("/api/admin/commerce/export/orders", { raw: true })).status,
    403,
  );
  const csv = await admin("/api/admin/commerce/export/orders", { raw: true });
  assert.equal(csv.status, 200);
  assert.match(csv.data, /Total USD/);
  assert.match(csv.headers.get("content-disposition"), /rtr-orders\.csv/);
});

test("pending Stripe refunds never revoke access until provider confirmation; failure stays retryable", async (t) => {
  let providerState = "pending",
    created = 0;
  const stripeClient = {
    refunds: {
      create: async () => {
        created++;
        return { id: "re_pending", status: "pending" };
      },
      retrieve: async () => ({ id: "re_pending", status: providerState }),
    },
  };
  const { admin, buyer, db } = await fixture(t, { stripeClient });
  const user = db
    .prepare("SELECT * FROM users WHERE email='buyer@commerce.test'")
    .get();
  const id = "cs_test_pending_refund",
    stamp = new Date().toISOString();
  const payload = {
    id,
    items: [{ id: "studio-brand-kit", title: "Original kit", price: 39 }],
    plan: null,
    total: 39,
    status: "completed",
    mode: "stripe",
    createdAt: stamp,
  };
  db.prepare("INSERT INTO orders VALUES (?,?,?,?,?,?,?)").run(
    id,
    user.id,
    JSON.stringify(payload),
    39,
    "stripe",
    null,
    stamp,
  );
  db.prepare("INSERT INTO entitlements VALUES (?,?,?)").run(
    user.id,
    "studio-brand-kit",
    "stripe",
  );
  db.prepare("INSERT INTO commerce_payments VALUES (?,?,?,?,?)").run(
    id,
    "pi_pending",
    null,
    id,
    stamp,
  );
  const request = await buyer(
    `/api/billing/orders/${id}/refunds`,
    post({ reason: "Please reverse my original test payment." }),
  );
  const route = `/api/admin/commerce/refunds/${request.data.refund.id}/approve`;
  assert.equal((await admin(route, post({}))).data.pending, true);
  assert.equal((await admin(route, post({}))).data.pending, true);
  assert.equal(created, 1);
  assert.equal(
    (await buyer("/api/download/studio-brand-kit", { raw: true })).status,
    200,
  );
  providerState = "succeeded";
  assert.equal((await admin(route, post({}))).data.success, true);
  assert.equal(created, 1);
  assert.equal(
    (await buyer("/api/download/studio-brand-kit", { raw: true })).status,
    403,
  );
});

test("partial provider refund events do not revoke the original product entitlement", async (t) => {
  const stripe = new Stripe("sk_test_unused");
  const webhookSecret = "whsec_commerce_testing";
  const { buyer, db, base } = await fixture(t, {
    stripeClient: { webhooks: stripe.webhooks },
    webhookSecret,
  });
  const user = db
    .prepare("SELECT * FROM users WHERE email='buyer@commerce.test'")
    .get();
  const id = "cs_original_full",
    stamp = new Date().toISOString();
  db.prepare("INSERT INTO orders VALUES (?,?,?,?,?,?,?)").run(
    id,
    user.id,
    JSON.stringify({
      id,
      items: [{ id: "studio-brand-kit", price: 39 }],
      total: 39,
      status: "completed",
      mode: "stripe",
    }),
    39,
    "stripe",
    null,
    stamp,
  );
  db.prepare("INSERT INTO entitlements VALUES (?,?,?)").run(
    user.id,
    "studio-brand-kit",
    "stripe",
  );
  db.prepare("INSERT INTO commerce_payments VALUES (?,?,?,?,?)").run(
    id,
    "pi_partial",
    null,
    id,
    stamp,
  );
  const event = {
    id: "evt_partial",
    type: "refund.updated",
    data: {
      object: {
        id: "re_partial",
        status: "succeeded",
        payment_intent: "pi_partial",
        amount: 500,
      },
    },
  };
  const payload = JSON.stringify(event);
  const signature = stripe.webhooks.generateTestHeaderString({
    payload,
    secret: webhookSecret,
  });
  const response = await fetch(`${base}/api/stripe/webhook`, {
    method: "POST",
    headers: {
      "content-type": "application/json",
      "stripe-signature": signature,
    },
    body: payload,
  });
  assert.equal(response.status, 200);
  assert.equal(
    (await buyer("/api/download/studio-brand-kit", { raw: true })).status,
    200,
  );
  assert.equal(
    db.prepare("SELECT count(*) n FROM commerce_refunds").get().n,
    0,
  );
});

test("promotion reservations enforce concurrent limits, allow same-intent retries, and consume exact holds", async (t) => {
  const { admin, buyer, db } = await fixture(t);
  await admin(
    "/api/admin/commerce/promotions",
    post({ code: "HELD10", percent: 10, maxUses: 1, perUser: 1 }),
  );
  const buyerUser = db
    .prepare("SELECT * FROM users WHERE email='buyer@commerce.test'")
    .get();
  const otherUser = db
    .prepare("SELECT * FROM users WHERE email='other@commerce.test'")
    .get();
  const noop = () => {};
  const helpers = registerCommerce(
    { get: noop, post: noop, patch: noop },
    { db, now: () => new Date().toISOString() },
  );
  helpers.reservePromotion(buyerUser.id, "intent_one", "HELD10");
  helpers.reservePromotion(buyerUser.id, "intent_one", "HELD10");
  assert.throws(
    () => helpers.reservePromotion(otherUser.id, "intent_two", "HELD10"),
    /redemption limit/,
  );
  assert.equal(
    helpers.resolvePromotion(buyerUser, {
      code: "HELD10",
      selected: [{}],
      subtotal: 39,
      reservationId: "intent_one",
    }).discount,
    0.1,
  );
  assert.throws(
    () =>
      helpers.resolvePromotion(otherUser, {
        code: "HELD10",
        selected: [{}],
        subtotal: 39,
      }),
    /redemption limit/,
  );
  helpers.releasePromotion("intent_one");
  helpers.reservePromotion(otherUser.id, "intent_two", "HELD10");
  db.prepare(
    "UPDATE commerce_reservations SET expires_at=? WHERE intent_id=?",
  ).run(Date.now() - 1, "intent_two");
  helpers.reservePromotion(buyerUser.id, "intent_three", "HELD10");
  const id = await buy(buyer);
  helpers.recordPromotion(buyerUser.id, id, "HELD10", "intent_three");
  assert.equal(
    db.prepare("SELECT count(*) n FROM commerce_reservations").get().n,
    0,
  );
  assert.throws(
    () => helpers.reservePromotion(otherUser.id, "intent_four", "HELD10"),
    /redemption limit/,
  );
});

test("membership refund retries cancellation without issuing a second provider refund", async (t) => {
  let cancelReady = false,
    created = 0,
    cancelAttempts = 0;
  const stripeClient = {
    refunds: {
      create: async () => {
        created++;
        return { id: "re_membership", status: "succeeded" };
      },
    },
    subscriptions: {
      retrieve: async () => ({ status: "active" }),
      cancel: async () => {
        cancelAttempts++;
        if (!cancelReady) throw new Error("Temporary provider failure");
        return { status: "canceled" };
      },
    },
  };
  const { admin, buyer, db } = await fixture(t, { stripeClient });
  const user = db
    .prepare("SELECT * FROM users WHERE email='buyer@commerce.test'")
    .get();
  const id = "cs_membership_refund",
    stamp = new Date().toISOString();
  db.prepare("INSERT INTO orders VALUES (?,?,?,?,?,?,?)").run(
    id,
    user.id,
    JSON.stringify({
      id,
      items: [],
      plan: "creator",
      interval: "monthly",
      total: 19,
      status: "completed",
      mode: "stripe",
      createdAt: stamp,
    }),
    19,
    "stripe",
    null,
    stamp,
  );
  db.prepare("UPDATE users SET subscription=? WHERE id=?").run(
    JSON.stringify({
      plan: "creator",
      interval: "monthly",
      mode: "stripe",
      status: "active",
      currentPeriodEnd: new Date(Date.now() + 86400000).toISOString(),
      stripeSubscriptionId: "sub_refund",
    }),
    user.id,
  );
  db.prepare("INSERT INTO commerce_payments VALUES (?,?,?,?,?)").run(
    id,
    "pi_membership",
    "sub_refund",
    id,
    stamp,
  );
  const request = await buyer(
    `/api/billing/orders/${id}/refunds`,
    post({ reason: "Please refund this membership purchase." }),
  );
  const route = `/api/admin/commerce/refunds/${request.data.refund.id}/approve`;
  assert.equal((await admin(route, post({}))).data.pending, true);
  assert.equal(created, 1);
  cancelReady = true;
  assert.equal((await admin(route, post({}))).data.success, true);
  assert.equal(created, 1);
  assert.equal(cancelAttempts, 2);
  assert.equal(
    JSON.parse(
      db.prepare("SELECT subscription FROM users WHERE id=?").get(user.id)
        .subscription,
    ).status,
    "canceled",
  );
  assert.equal(
    (await buyer("/api/download/studio-brand-kit", { raw: true })).status,
    403,
  );
});
