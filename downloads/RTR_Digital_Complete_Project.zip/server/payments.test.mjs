import test from "node:test";
import assert from "node:assert/strict";
import {
  mkdtempSync,
  readFileSync,
  readdirSync,
  rmSync,
  statSync,
  writeFileSync,
} from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { createApp } from "./index.mjs";

const PASSWORD = "A-secure-password-26";
const ACCOUNT = "1234567890123456";
const bank = {
  enabled: true,
  beneficiary: "RTR Digital",
  bankName: "Example Bank",
  accountNumber: ACCOUNT,
  swift: "EXAMINBBXXX",
  ifsc: "EXAM0000123",
  bankAddress: "Mumbai, India",
  instructions:
    "Use the checkout reference. Access starts after cleared USD funds are confirmed.",
};

function httpClient(base) {
  let cookie = "";
  return async (path, { method = "GET", body, headers = {} } = {}) => {
    const response = await fetch(base + path, {
      method,
      headers: {
        ...(cookie ? { Cookie: cookie } : {}),
        ...(body === undefined ? {} : { "Content-Type": "application/json" }),
        ...headers,
      },
      ...(body === undefined ? {} : { body: JSON.stringify(body) }),
    });
    if (response.headers.get("set-cookie"))
      cookie = response.headers.get("set-cookie").split(";")[0];
    const raw = await response.text();
    let data;
    try {
      data = JSON.parse(raw);
    } catch {
      data = raw;
    }
    return { status: response.status, data, headers: response.headers };
  };
}

async function fixture(t, options = {}) {
  const dataDir = mkdtempSync(join(tmpdir(), "rtr-payments-"));
  const instance = createApp({
    dataDir,
    publicUrl: "https://store.example",
    ...options,
  });
  const server = instance.app.listen(0, "127.0.0.1");
  await new Promise((resolve) => server.once("listening", resolve));
  const base = `http://127.0.0.1:${server.address().port}`;
  t.after(async () => {
    await new Promise((resolve) => server.close(resolve));
    instance.close();
    rmSync(dataDir, { recursive: true, force: true });
  });
  const client = () => httpClient(base);
  const admin = client(),
    buyer = client(),
    other = client(),
    anonymous = client();
  const users = {};
  for (const [name, request] of Object.entries({ admin, buyer, other })) {
    const registered = await request(
      "/api/auth/register",
      post({
        name: `Payment ${name}`,
        email: `${name}@payment.test`,
        password: PASSWORD,
      }),
    );
    assert.equal(registered.status, 201, JSON.stringify(registered.data));
    users[name] = registered.data.user;
  }
  instance.db
    .prepare("UPDATE users SET role='admin' WHERE id=?")
    .run(users.admin.id);
  const row = instance.db
    .prepare("SELECT payload FROM products WHERE id='studio-brand-kit'")
    .get();
  instance.db
    .prepare(
      "UPDATE products SET payload=?,file_path=? WHERE id='studio-brand-kit'",
    )
    .run(
      JSON.stringify({ ...JSON.parse(row.payload), isSample: false }),
      "payment-original.txt",
    );
  writeFileSync(
    join(dataDir, "uploads", "payment-original.txt"),
    "RTR payment test original file",
  );
  return { ...instance, dataDir, admin, buyer, other, anonymous, users };
}
const post = (body, headers = {}) => ({ method: "POST", body, headers });
const patch = (body) => ({ method: "PATCH", body });
const checkout = (request, provider, key, more = {}) =>
  request(
    "/api/payments/checkout",
    post(
      { provider, productIds: ["studio-brand-kit"], ...more },
      { "Idempotency-Key": key },
    ),
  );
const configure = (admin, settings) =>
  admin(
    "/api/admin/payments/settings",
    patch({ password: PASSWORD, ...settings }),
  );
const json = (data, status = 200) =>
  new Response(JSON.stringify(data), {
    status,
    headers: { "Content-Type": "application/json" },
  });
const noGrant = (db, userId) => {
  assert.equal(
    db
      .prepare("SELECT COUNT(*) AS n FROM entitlements WHERE user_id=?")
      .get(userId).n,
    0,
  );
  assert.equal(
    db.prepare("SELECT COUNT(*) AS n FROM orders WHERE user_id=?").get(userId)
      .n,
    0,
  );
};

async function withRestartedApp(dataDir, options, action) {
  const instance = createApp({
    dataDir,
    publicUrl: "https://store.example",
    ...options,
  });
  const server = instance.app.listen(0, "127.0.0.1");
  await new Promise((resolve) => server.once("listening", resolve));
  try {
    return await action({
      ...instance,
      client: () => httpClient(`http://127.0.0.1:${server.address().port}`),
    });
  } finally {
    await new Promise((resolve) => server.close(resolve));
    instance.close();
  }
}

// These assertions exercise persistent state and ownership boundaries through HTTP.
test("payment settings require reauthentication, encrypt secrets, and expose only masked configuration", async (t) => {
  const { admin, buyer, anonymous, dataDir } = await fixture(t);
  assert.equal((await buyer("/api/admin/payments")).status, 403);
  assert.equal((await anonymous("/api/admin/payments")).status, 401);
  const denied = await admin(
    "/api/admin/payments/settings",
    patch({ password: "wrong-password", bank }),
  );
  assert.equal(denied.status, 403);
  const result = await configure(admin, {
    bank: {
      ...bank,
      iban: "GB82WEST12345698765432",
      routingNumber: "110000000",
    },
    providers: {
      paypal: {
        enabled: true,
        environment: "sandbox",
        clientId: "paypal-client-id",
        clientSecret: "paypal-secret-value",
        merchantId: "RTRMERCHANT123",
      },
      razorpay: {
        enabled: true,
        keyId: "rzp_test_ABC123",
        keySecret: "razorpay-secret-value",
      },
    },
  });
  assert.equal(result.status, 200, JSON.stringify(result.data));
  const masked = await admin("/api/admin/payments");
  assert.equal(masked.status, 200);
  assert.equal(masked.data.bank.enabled, true);
  assert.equal(
    masked.data.providers.find((provider) => provider.id === "stripe")
      .configured,
    false,
  );
  assert.notEqual(masked.data.bank.accountNumber, ACCOUNT);
  for (const secret of [
    ACCOUNT,
    "paypal-secret-value",
    "razorpay-secret-value",
  ])
    assert.equal(JSON.stringify(masked.data).includes(secret), false);
  const publicMethods = await anonymous("/api/payments/methods");
  assert.equal(publicMethods.status, 200);
  assert.ok(
    publicMethods.data.methods.some(
      (method) => method.id === "wire" && method.available,
    ),
  );
  assert.equal(
    JSON.stringify(publicMethods.data).includes("Example Bank"),
    false,
  );
  assert.equal(JSON.stringify(publicMethods.data).includes(ACCOUNT), false);
  const unauthenticatedReveal = await admin(
    "/api/admin/payments/bank?reveal=true",
  );
  assert.equal(
    JSON.stringify(unauthenticatedReveal.data).includes(ACCOUNT),
    false,
  );
  const key = join(dataDir, ".payment-encryption-key");
  assert.equal(statSync(key).mode & 0o077, 0);
  for (const filename of readdirSync(dataDir).filter((name) =>
    name.startsWith("rtr.sqlite"),
  )) {
    const bytes = readFileSync(join(dataDir, filename));
    for (const secret of [
      ACCOUNT,
      "paypal-secret-value",
      "razorpay-secret-value",
    ])
      assert.equal(
        bytes.includes(Buffer.from(secret)),
        false,
        `${filename} exposed ${secret}`,
      );
  }
  const blankSecrets = await configure(admin, {
    bank: { accountNumber: "", iban: " ", routingNumber: "" },
    providers: { paypal: { clientSecret: " " }, razorpay: { keySecret: "" } },
  });
  assert.equal(blankSecrets.status, 200, JSON.stringify(blankSecrets.data));
  const preserved = await admin("/api/admin/payments");
  const providers = Object.fromEntries(
    preserved.data.providers.map((provider) => [provider.id, provider]),
  );
  assert.equal(providers.paypal.configured, true);
  assert.equal(providers.razorpay.configured, true);
  const originalKey = readFileSync(key);
  const reopened = createApp({ dataDir, publicUrl: "https://store.example" });
  const restartedServer = reopened.app.listen(0, "127.0.0.1");
  await new Promise((resolve) => restartedServer.once("listening", resolve));
  try {
    const restartedMethods = await fetch(
      `http://127.0.0.1:${restartedServer.address().port}/api/payments/methods`,
    ).then((response) => response.json());
    assert.equal(
      restartedMethods.methods.find((method) => method.id === "wire").available,
      true,
    );
    assert.equal(
      restartedMethods.methods.find((method) => method.id === "paypal")
        .available,
      true,
    );
    assert.deepEqual(readFileSync(key), originalKey);
  } finally {
    await new Promise((resolve) => restartedServer.close(resolve));
    reopened.close();
  }
  const deniedReveal = await admin(
    "/api/admin/payments/bank/reveal",
    post({ password: "incorrect" }),
  );
  assert.equal(deniedReveal.status, 403);
  const revealed = await admin(
    "/api/admin/payments/bank/reveal",
    post({ password: PASSWORD }),
  );
  assert.equal(revealed.status, 200);
  assert.equal(revealed.data.bank.accountNumber, ACCOUNT);
  assert.equal(revealed.data.bank.iban, "GB82WEST12345698765432");
  assert.equal(revealed.data.bank.routingNumber, "110000000");
  assert.equal(
    (
      await configure(admin, {
        bank: { removeAccountNumber: true, removeRoutingNumber: true },
      })
    ).status,
    200,
  );
  const removedBank = (
    await admin("/api/admin/payments/bank/reveal", post({ password: PASSWORD }))
  ).data.bank;
  assert.equal(removedBank.accountNumber, "");
  assert.equal(removedBank.routingNumber, "");
  assert.equal(removedBank.iban, "GB82WEST12345698765432");
  assert.equal(
    (
      await configure(admin, {
        providers: {
          paypal: { removeClientSecret: true },
          razorpay: { removeKeySecret: true },
        },
      })
    ).status,
    200,
  );
  const removed = (await admin("/api/admin/payments")).data.providers;
  assert.equal(
    removed.find((provider) => provider.id === "paypal").configured,
    false,
  );
  assert.equal(
    removed.find((provider) => provider.id === "razorpay").configured,
    false,
  );
});

test("wire checkout isolates owners, keeps bank snapshots, and grants only after exact cleared-funds confirmation", async (t) => {
  const { admin, buyer, other, anonymous, db, users } = await fixture(t);
  assert.equal((await configure(admin, { bank })).status, 200);
  const missingIdem = await buyer(
    "/api/payments/checkout",
    post({ provider: "wire", productIds: ["studio-brand-kit"] }),
  );
  assert.equal(missingIdem.status, 400);
  const pending = await checkout(buyer, "wire", "wire-checkout-0001");
  assert.equal(pending.status, 200, JSON.stringify(pending.data));
  assert.equal(pending.data.status, "pending");
  assert.equal(pending.data.total, 39);
  assert.equal(pending.data.currency, "USD");
  assert.equal(pending.data.bank.accountNumber, ACCOUNT);
  noGrant(db, users.buyer.id);
  const repeated = await checkout(buyer, "wire", "wire-checkout-0001");
  assert.equal(repeated.data.id, pending.data.id);
  const conflict = await checkout(buyer, "wire", "wire-checkout-0001", {
    plan: "creator",
    productIds: [],
  });
  assert.equal(conflict.status, 409);
  assert.equal(
    (await other(`/api/payments/orders/${pending.data.id}`)).status,
    404,
  );
  assert.equal(
    (await anonymous(`/api/payments/orders/${pending.data.id}`)).status,
    401,
  );
  assert.equal(
    (
      await other(
        `/api/payments/orders/${pending.data.id}/notify`,
        post({ reference: "FORGED" }),
      )
    ).status,
    404,
  );
  const notice = await buyer(
    `/api/payments/orders/${pending.data.id}/notify`,
    post({ reference: "BUYER-BANK-123", note: "Transferred from my bank." }),
  );
  assert.equal(notice.status, 200, JSON.stringify(notice.data));
  noGrant(db, users.buyer.id);
  assert.equal(
    (await buyer(`/api/payments/orders/${pending.data.id}/verify`, post({})))
      .status,
    200,
  );
  noGrant(db, users.buyer.id);
  assert.equal(
    (
      await configure(admin, {
        bank: {
          ...bank,
          accountNumber: "9999888877776666",
          instructions: "Updated transfer instructions",
        },
      })
    ).status,
    200,
  );
  const original = await buyer(`/api/payments/orders/${pending.data.id}`);
  assert.equal(original.data.bank.accountNumber, ACCOUNT);
  const next = await checkout(other, "wire", "wire-checkout-0002");
  assert.equal(next.data.bank.accountNumber, "9999888877776666");
  assert.notEqual(next.data.bank.version, original.data.bank.version);
  assert.equal(
    (
      await buyer(
        `/api/admin/payments/orders/${pending.data.id}/confirm`,
        post({
          password: PASSWORD,
          receivedAmount: 39,
          currency: "USD",
          bankReference: "BANK-001",
          cleared: true,
        }),
      )
    ).status,
    403,
  );
  const confirm = (changes = {}) =>
    admin(
      `/api/admin/payments/orders/${pending.data.id}/confirm`,
      post({
        password: PASSWORD,
        receivedAmount: 39,
        currency: "USD",
        bankReference: "BANK-001",
        cleared: true,
        ...changes,
      }),
    );
  assert.equal((await confirm({ password: "wrong-password" })).status, 403);
  assert.equal((await confirm({ receivedAmount: 38.99 })).status, 400);
  assert.equal((await confirm({ cleared: false })).status, 400);
  assert.equal((await confirm({ currency: "INR" })).status, 400);
  noGrant(db, users.buyer.id);
  const completed = await confirm();
  assert.equal(completed.status, 200, JSON.stringify(completed.data));
  assert.equal(completed.data.status, "completed");
  assert.equal(
    db
      .prepare("SELECT COUNT(*) AS n FROM orders WHERE user_id=?")
      .get(users.buyer.id).n,
    1,
  );
  assert.equal(
    db
      .prepare("SELECT mode FROM entitlements WHERE user_id=?")
      .get(users.buyer.id).mode,
    "demo",
  );
  const storedPayment = JSON.parse(
    db.prepare("SELECT payload FROM orders WHERE id=?").get(pending.data.id)
      .payload,
  );
  assert.equal(storedPayment.paymentProvider, "wire");
  assert.equal(storedPayment.paymentEnvironment, "development");
  const replay = await confirm();
  assert.equal(replay.status, 200, JSON.stringify(replay.data));
  assert.equal(
    db
      .prepare("SELECT COUNT(*) AS n FROM orders WHERE user_id=?")
      .get(users.buyer.id).n,
    1,
  );
  const reusedTransfer = await admin(
    `/api/admin/payments/orders/${next.data.id}/confirm`,
    post({
      password: PASSWORD,
      receivedAmount: 39,
      currency: "USD",
      bankReference: "BANK-001",
      cleared: true,
    }),
  );
  assert.equal(reusedTransfer.status, 409, JSON.stringify(reusedTransfer.data));
  noGrant(db, users.other.id);
});

function paypalMock() {
  const state = { calls: [], unit: null, completed: false, mismatch: null };
  const paymentFetch = async (input, init = {}) => {
    const url = new URL(input);
    state.calls.push({
      url: url.href,
      method: init.method || "GET",
      headers: init.headers,
    });
    assert.equal(url.origin, "https://api-m.sandbox.paypal.com");
    if (url.pathname === "/v1/oauth2/token") {
      assert.equal(
        new Headers(init.headers).get("Authorization"),
        `Basic ${Buffer.from("paypal-client-id:paypal-secret-value").toString("base64")}`,
      );
      return json({
        access_token: "test-paypal-token",
        token_type: "Bearer",
        expires_in: 300,
      });
    }
    if (url.pathname === "/v2/checkout/orders" && init.method === "POST") {
      const body = JSON.parse(init.body);
      state.unit = body.purchase_units[0];
      return json(
        {
          id: "5O190127TN364715T",
          status: "CREATED",
          purchase_units: [
            { ...state.unit, payee: { merchant_id: "RTRMERCHANT123" } },
          ],
          links: [
            {
              rel: "approve",
              href: "https://www.sandbox.paypal.com/checkoutnow?token=5O190127TN364715T",
            },
          ],
        },
        201,
      );
    }
    if (url.pathname === "/v2/checkout/orders/5O190127TN364715T/capture")
      state.completed = true;
    if (url.pathname.startsWith("/v2/checkout/orders/5O190127TN364715T")) {
      const amount = {
        currency_code: state.mismatch === "currency" ? "INR" : "USD",
        value: state.mismatch === "amount" ? "38.99" : state.unit.amount.value,
      };
      return json({
        id: "5O190127TN364715T",
        intent: "CAPTURE",
        status: state.completed ? "COMPLETED" : "APPROVED",
        purchase_units: [
          {
            ...state.unit,
            amount,
            payee: {
              merchant_id:
                state.mismatch === "payee" ? "WRONGMERCHANT" : "RTRMERCHANT123",
            },
            payments: state.completed
              ? {
                  captures: [
                    {
                      id: "3C679366HH908993F",
                      status: "COMPLETED",
                      amount,
                      final_capture: true,
                    },
                  ],
                }
              : {},
          },
        ],
      });
    }
    throw new Error(`Unexpected payment request ${url}`);
  };
  return { state, paymentFetch };
}

test("PayPal uses server-authoritative capture, credential snapshots, exact USD amount, and owner-only verification", async (t) => {
  const { state, paymentFetch } = paypalMock();
  const { admin, buyer, other, db, users } = await fixture(t, { paymentFetch });
  assert.equal(
    (
      await configure(admin, {
        providers: {
          paypal: {
            enabled: true,
            environment: "sandbox",
            clientId: "paypal-client-id",
            clientSecret: "paypal-secret-value",
            merchantId: "RTRMERCHANT123",
          },
        },
      })
    ).status,
    200,
  );
  const [pending, concurrent] = await Promise.all([
    checkout(buyer, "paypal", "paypal-checkout-0001"),
    checkout(buyer, "paypal", "paypal-checkout-0001"),
  ]);
  assert.equal(concurrent.status, 200, JSON.stringify(concurrent.data));
  assert.equal(concurrent.data.id, pending.data.id);
  assert.equal(pending.status, 200, JSON.stringify(pending.data));
  assert.match(
    pending.data.approvalUrl,
    /^https:\/\/www\.sandbox\.paypal\.com\//,
  );
  noGrant(db, users.buyer.id);
  const callsBefore = state.calls.length;
  assert.equal(
    (await other(`/api/payments/orders/${pending.data.id}/verify`, post({})))
      .status,
    404,
  );
  assert.equal(state.calls.length, callsBefore);
  assert.equal(
    (await checkout(buyer, "paypal", "paypal-checkout-0001")).data.id,
    pending.data.id,
  );
  assert.equal(
    state.calls.filter((call) => call.url.endsWith("/v2/checkout/orders"))
      .length,
    1,
  );
  // A later account edit must not switch a pending order's expected payee.
  assert.equal(
    (
      await configure(admin, {
        providers: {
          paypal: {
            merchantId: "NEWPAYEEMERCHANT",
            clientSecret: "changed-provider-secret",
          },
        },
      })
    ).status,
    200,
  );
  state.mismatch = "amount";
  const badAmount = await buyer(
    `/api/payments/orders/${pending.data.id}/verify`,
    post({}),
  );
  assert.ok(
    [400, 409, 502].includes(badAmount.status),
    JSON.stringify(badAmount),
  );
  noGrant(db, users.buyer.id);
  state.mismatch = "currency";
  const wrongCurrency = await buyer(
    `/api/payments/orders/${pending.data.id}/verify`,
    post({}),
  );
  assert.ok(
    [400, 409, 502].includes(wrongCurrency.status),
    JSON.stringify(wrongCurrency),
  );
  noGrant(db, users.buyer.id);
  state.mismatch = "payee";
  const wrongPayee = await buyer(
    `/api/payments/orders/${pending.data.id}/verify`,
    post({}),
  );
  assert.ok(
    [400, 409, 502].includes(wrongPayee.status),
    JSON.stringify(wrongPayee),
  );
  noGrant(db, users.buyer.id);
  assert.equal(
    state.calls.filter((call) => call.url.endsWith("/capture")).length,
    0,
    "Do not capture an approved order with the wrong amount, currency or payee",
  );
  state.mismatch = null;
  const [verified, replayed] = await Promise.all([
    buyer(`/api/payments/orders/${pending.data.id}/verify`, post({})),
    buyer(`/api/payments/orders/${pending.data.id}/verify`, post({})),
  ]);
  assert.equal(replayed.status, 200, JSON.stringify(replayed.data));
  assert.equal(
    state.calls.filter((call) => call.url.endsWith("/capture")).length,
    1,
  );
  assert.equal(verified.status, 200, JSON.stringify(verified.data));
  assert.equal(verified.data.status, "completed");
  assert.equal(
    db
      .prepare("SELECT mode FROM entitlements WHERE user_id=?")
      .get(users.buyer.id).mode,
    "demo",
  );
  const storedPayment = JSON.parse(
    db.prepare("SELECT payload FROM orders WHERE id=?").get(pending.data.id)
      .payload,
  );
  assert.equal(storedPayment.paymentProvider, "paypal");
  assert.equal(storedPayment.paymentEnvironment, "sandbox");
  assert.equal(
    (await buyer(`/api/payments/orders/${pending.data.id}/verify`, post({})))
      .status,
    200,
  );
  assert.equal(
    db
      .prepare("SELECT COUNT(*) AS n FROM orders WHERE user_id=?")
      .get(users.buyer.id).n,
    1,
  );
});

function razorpayMock() {
  const state = { calls: [], link: null, paid: false, mismatch: null };
  const paymentFetch = async (input, init = {}) => {
    const url = new URL(input);
    state.calls.push({
      url: url.href,
      method: init.method || "GET",
      headers: init.headers,
    });
    assert.equal(url.origin, "https://api.razorpay.com");
    assert.equal(
      new Headers(init.headers).get("Authorization"),
      `Basic ${Buffer.from("rzp_test_ABC123:razorpay-secret-value").toString("base64")}`,
    );
    if (url.pathname === "/v1/payment_links" && init.method === "POST") {
      state.link = JSON.parse(init.body);
      return json(
        {
          ...state.link,
          id: "plink_TEST123456",
          short_url: "https://rzp.io/i/test-rtr",
          status: "created",
          amount_paid: 0,
          payments: [],
        },
        201,
      );
    }
    if (url.pathname === "/v1/payment_links/plink_TEST123456")
      return json({
        ...state.link,
        id: "plink_TEST123456",
        status: state.paid ? "paid" : "created",
        order_id: "order_TEST123456",
        amount_paid: state.paid ? state.link.amount : 0,
        currency: state.mismatch === "currency" ? "INR" : "USD",
        reference_id:
          state.mismatch === "reference"
            ? "UNRELATED"
            : state.link.reference_id,
        payments: state.paid
          ? [
              {
                payment_id: "pay_TEST123456",
                amount: state.link.amount,
                method: "card",
                status: "captured",
              },
            ]
          : [],
      });
    if (url.pathname === "/v1/payments/pay_TEST123456")
      return json({
        id: "pay_TEST123456",
        entity: "payment",
        status: "captured",
        captured: true,
        amount:
          state.mismatch === "amount"
            ? state.link.amount - 1
            : state.link.amount,
        currency: "USD",
        notes: state.link.notes,
        order_id: "order_TEST123456",
      });
    throw new Error(`Unexpected payment request ${url}`);
  };
  return { state, paymentFetch };
}

test("Razorpay verifies paid links and captured USD payments without trusting browser data", async (t) => {
  const { state, paymentFetch } = razorpayMock();
  const { admin, buyer, db, users } = await fixture(t, { paymentFetch });
  assert.equal(
    (
      await configure(admin, {
        providers: {
          razorpay: {
            enabled: true,
            keyId: "rzp_test_ABC123",
            keySecret: "razorpay-secret-value",
          },
        },
      })
    ).status,
    200,
  );
  const pending = await checkout(buyer, "razorpay", "razorpay-checkout-0001");
  assert.equal(pending.status, 200, JSON.stringify(pending.data));
  noGrant(db, users.buyer.id);
  assert.equal(
    (
      await buyer(
        `/api/payments/orders/${pending.data.id}/verify`,
        post({ status: "paid", amount: 39 }),
      )
    ).status,
    409,
  );
  noGrant(db, users.buyer.id);
  assert.equal(
    (
      await configure(admin, {
        providers: {
          razorpay: {
            keyId: "rzp_test_CHANGED",
            keySecret: "changed-provider-secret",
          },
        },
      })
    ).status,
    200,
  );
  state.paid = true;
  state.mismatch = "reference";
  const unrelated = await buyer(
    `/api/payments/orders/${pending.data.id}/verify`,
    post({}),
  );
  assert.ok(
    [400, 409, 502].includes(unrelated.status),
    JSON.stringify(unrelated),
  );
  noGrant(db, users.buyer.id);
  state.mismatch = "amount";
  const wrongAmount = await buyer(
    `/api/payments/orders/${pending.data.id}/verify`,
    post({}),
  );
  assert.ok(
    [400, 409, 502].includes(wrongAmount.status),
    JSON.stringify(wrongAmount),
  );
  noGrant(db, users.buyer.id);
  state.mismatch = null;
  const verified = await buyer(
    `/api/payments/orders/${pending.data.id}/verify`,
    post({}),
  );
  assert.equal(verified.status, 200, JSON.stringify(verified.data));
  assert.equal(verified.data.status, "completed");
  assert.equal(
    db
      .prepare("SELECT mode FROM entitlements WHERE user_id=?")
      .get(users.buyer.id).mode,
    "demo",
  );
  const storedPayment = JSON.parse(
    db.prepare("SELECT payload FROM orders WHERE id=?").get(pending.data.id)
      .payload,
  );
  assert.equal(storedPayment.paymentProvider, "razorpay");
  assert.equal(storedPayment.paymentEnvironment, "sandbox");
});

test("expired and rejected wire payments cannot be reconciled or expose transfer instructions", async (t) => {
  const { admin, buyer, db, users } = await fixture(t);
  assert.equal((await configure(admin, { bank })).status, 200);
  const expired = await checkout(buyer, "wire", "expired-wire-0001");
  assert.equal(expired.status, 200, JSON.stringify(expired.data));
  db.prepare("UPDATE payment_orders SET expires_at=? WHERE id=?").run(
    Date.now() - 1000,
    expired.data.id,
  );
  const shown = await buyer(`/api/payments/orders/${expired.data.id}`);
  assert.equal(shown.data.status, "expired");
  assert.equal(shown.data.bank, undefined);
  assert.equal(
    (
      await buyer(
        `/api/payments/orders/${expired.data.id}/notify`,
        post({ reference: "LATE-TRANSFER" }),
      )
    ).status,
    409,
  );
  const confirm = (id) =>
    admin(
      `/api/admin/payments/orders/${id}/confirm`,
      post({
        password: PASSWORD,
        receivedAmount: 39,
        currency: "USD",
        bankReference: "LATE-001",
        cleared: true,
      }),
    );
  assert.equal((await confirm(expired.data.id)).status, 409);
  noGrant(db, users.buyer.id);
  const pending = await checkout(buyer, "wire", "rejected-wire-0001");
  assert.equal(pending.status, 200, JSON.stringify(pending.data));
  assert.equal(
    (
      await admin(
        `/api/admin/payments/orders/${pending.data.id}/reject`,
        post({ note: "No funds received" }),
      )
    ).status,
    403,
  );
  const rejected = await admin(
    `/api/admin/payments/orders/${pending.data.id}/reject`,
    post({ password: PASSWORD, note: "No funds received" }),
  );
  assert.equal(rejected.status, 200, JSON.stringify(rejected.data));
  assert.equal(rejected.data.status, "rejected");
  assert.equal(
    (await buyer(`/api/payments/orders/${pending.data.id}`)).data.bank,
    undefined,
  );
  assert.equal((await confirm(pending.data.id)).status, 409);
  noGrant(db, users.buyer.id);
});

test("production disables PayPal sandbox and Razorpay test credentials before calling providers", async (t) => {
  let calls = 0;
  const { admin, buyer, anonymous, db, users } = await fixture(t, {
    production: true,
    demoMode: false,
    paymentFetch: async () => {
      calls++;
      throw new Error("Test providers must never be called in production");
    },
  });
  const configured = await configure(admin, {
    providers: {
      paypal: {
        enabled: true,
        environment: "sandbox",
        clientId: "paypal-client-id",
        clientSecret: "paypal-secret-value",
        merchantId: "RTRMERCHANT123",
      },
      razorpay: {
        enabled: true,
        keyId: "rzp_test_ABC123",
        keySecret: "razorpay-secret-value",
      },
    },
  });
  assert.equal(configured.status, 200, JSON.stringify(configured.data));
  const methods = (await anonymous("/api/payments/methods")).data.methods;
  for (const provider of ["paypal", "razorpay"]) {
    assert.equal(
      methods.find((method) => method.id === provider).available,
      false,
    );
    const result = await checkout(
      buyer,
      provider,
      `production-${provider}-0001`,
    );
    assert.ok([403, 503].includes(result.status), JSON.stringify(result.data));
  }
  assert.equal(calls, 0);
  noGrant(db, users.buyer.id);
});

test("reconciled USD wire membership grants one prepaid term with no automatic renewal", async (t) => {
  const { admin, buyer, db, users } = await fixture(t, {
    production: true,
    demoMode: false,
  });
  assert.equal((await configure(admin, { bank })).status, 200);
  const pending = await checkout(buyer, "wire", "prepaid-membership-0001", {
    productIds: [],
    plan: "creator",
    interval: "yearly",
  });
  assert.equal(pending.status, 200, JSON.stringify(pending.data));
  assert.equal(pending.data.total, 180);
  assert.equal(pending.data.recurring, false);
  assert.match(pending.data.description, /no automatic renewal/i);
  assert.equal((await buyer("/api/download/studio-brand-kit")).status, 403);
  noGrant(db, users.buyer.id);
  const confirmed = await admin(
    `/api/admin/payments/orders/${pending.data.id}/confirm`,
    post({
      password: PASSWORD,
      bankReference: "PREPAID-USD-001",
      receivedAmount: 180,
      currency: "USD",
      cleared: true,
    }),
  );
  assert.equal(confirmed.status, 200, JSON.stringify(confirmed.data));
  const me = (await buyer("/api/auth/me")).data.user;
  assert.equal(me.subscription.plan, "creator");
  assert.equal(me.subscription.interval, "yearly");
  assert.equal(me.subscription.mode, "wire");
  assert.equal(me.subscription.isPrepaid, true);
  assert.equal(me.subscription.autoRenew, false);
  assert.equal(me.subscription.cancelAtPeriodEnd, true);
  assert.equal(me.subscription.stripeSubscriptionId, null);
  const daysRemaining =
    (Date.parse(me.subscription.currentPeriodEnd) - Date.now()) / 86400000;
  assert.ok(daysRemaining > 364 && daysRemaining < 367);
  const order = JSON.parse(
    db.prepare("SELECT payload FROM orders WHERE id=?").get(pending.data.id)
      .payload,
  );
  assert.equal(order.isPrepaid, true);
  assert.equal(order.autoRenew, false);
  assert.equal(order.recurring, false);
  assert.equal(order.seller.sellerName, "RTR Digital");
  assert.equal(order.seller.licensor, "RTR Digital");
  assert.equal((await buyer("/api/download/studio-brand-kit")).status, 200);
  assert.equal((await buyer("/api/subscription/resume", post({}))).status, 400);
  assert.equal(
    (await buyer(`/api/payments/orders/${pending.data.id}`)).data.bank,
    undefined,
  );
});

test("restarting in production hides sandbox and development payments and never upgrades their access", async (t) => {
  const { paymentFetch } = paypalMock();
  const { admin, buyer, other, dataDir, db, users } = await fixture(t, {
    paymentFetch,
  });
  assert.equal(
    (
      await configure(admin, {
        bank,
        providers: {
          paypal: {
            enabled: true,
            environment: "sandbox",
            clientId: "paypal-client-id",
            clientSecret: "paypal-secret-value",
            merchantId: "RTRMERCHANT123",
          },
        },
      })
    ).status,
    200,
  );
  const sandbox = await checkout(buyer, "paypal", "sandbox-restart-0001");
  assert.equal(
    (await buyer(`/api/payments/orders/${sandbox.data.id}/verify`, post({})))
      .status,
    200,
  );
  const wire = await checkout(buyer, "wire", "dev-wire-restart-0001");
  const membership = await checkout(other, "wire", "dev-plan-restart-0001", {
    productIds: [],
    plan: "creator",
  });
  assert.equal(
    (
      await admin(
        `/api/admin/payments/orders/${membership.data.id}/confirm`,
        post({
          password: PASSWORD,
          bankReference: "DEV-MEMBERSHIP-001",
          receivedAmount: membership.data.total,
          currency: "USD",
          cleared: true,
        }),
      )
    ).status,
    200,
  );
  assert.equal(
    db
      .prepare("SELECT mode FROM entitlements WHERE user_id=?")
      .get(users.buyer.id).mode,
    "demo",
  );
  assert.equal(
    JSON.parse(
      db
        .prepare("SELECT subscription FROM users WHERE id=?")
        .get(users.other.id).subscription,
    ).mode,
    "demo",
  );
  await withRestartedApp(
    dataDir,
    {
      production: true,
      demoMode: false,
      paymentFetch: async () => {
        throw new Error("Do not call sandbox providers from production");
      },
    },
    async ({ client }) => {
      const prodBuyer = client(),
        prodAdmin = client(),
        prodOther = client();
      for (const [name, request] of [
        ["buyer", prodBuyer],
        ["admin", prodAdmin],
        ["other", prodOther],
      ])
        assert.equal(
          (
            await request(
              "/api/auth/login",
              post({ email: `${name}@payment.test`, password: PASSWORD }),
            )
          ).status,
          200,
        );
      assert.deepEqual(
        (await prodBuyer("/api/payments/orders")).data.payments,
        [],
      );
      assert.deepEqual(
        (await prodOther("/api/payments/orders")).data.payments,
        [],
      );
      assert.deepEqual(
        (await prodAdmin("/api/admin/payments")).data.transfers,
        [],
      );
      for (const id of [sandbox.data.id, wire.data.id]) {
        assert.equal(
          (await prodBuyer(`/api/payments/orders/${id}`)).status,
          403,
        );
        assert.equal(
          (await prodBuyer(`/api/payments/orders/${id}/verify`, post({})))
            .status,
          403,
        );
      }
      assert.equal(
        (await checkout(prodBuyer, "paypal", "sandbox-restart-0001")).status,
        403,
      );
      assert.equal(
        (await checkout(prodBuyer, "wire", "dev-wire-restart-0001")).status,
        403,
      );
      assert.equal(
        (
          await prodAdmin(
            `/api/admin/payments/orders/${wire.data.id}/confirm`,
            post({
              password: PASSWORD,
              bankReference: "DO-NOT-UPGRADE",
              receivedAmount: wire.data.total,
              currency: "USD",
              cleared: true,
            }),
          )
        ).status,
        403,
      );
      assert.equal(
        (await prodBuyer("/api/download/studio-brand-kit")).status,
        403,
      );
      assert.equal(
        (await prodOther("/api/auth/me")).data.user.subscription,
        null,
      );
      assert.equal(
        (await prodOther("/api/download/studio-brand-kit")).status,
        403,
      );
    },
  );
});

test("membership checkout locks serialize purchases and settlement preserves a membership activated meanwhile", async (t) => {
  const { admin, buyer, db, users } = await fixture(t, {
    production: true,
    demoMode: false,
  });
  assert.equal((await configure(admin, { bank })).status, 200);
  const attempts = await Promise.all([
    checkout(buyer, "wire", "membership-race-0001", {
      productIds: [],
      plan: "creator",
    }),
    checkout(buyer, "wire", "membership-race-0002", {
      productIds: [],
      plan: "creator",
    }),
  ]);
  assert.deepEqual(
    attempts.map((attempt) => attempt.status).sort(),
    [200, 409],
  );
  const pending = attempts.find((attempt) => attempt.status === 200).data;
  const existing = {
    plan: "studio",
    interval: "yearly",
    status: "active",
    mode: "stripe",
    stripeSubscriptionId: "sub_existing_123",
    currentPeriodEnd: new Date(Date.now() + 86400000 * 100).toISOString(),
  };
  db.prepare("UPDATE users SET subscription=? WHERE id=?").run(
    JSON.stringify(existing),
    users.buyer.id,
  );
  const confirmed = await admin(
    `/api/admin/payments/orders/${pending.id}/confirm`,
    post({
      password: PASSWORD,
      bankReference: "MEMBERSHIP-RACE-001",
      receivedAmount: pending.total,
      currency: "USD",
      cleared: true,
    }),
  );
  assert.equal(confirmed.status, 200, JSON.stringify(confirmed.data));
  assert.equal(confirmed.data.status, "completed");
  assert.equal(confirmed.data.membershipReviewRequired, true);
  assert.deepEqual(
    JSON.parse(
      db
        .prepare("SELECT subscription FROM users WHERE id=?")
        .get(users.buyer.id).subscription,
    ),
    existing,
  );
  assert.equal(
    db
      .prepare(
        "SELECT COUNT(*) AS n FROM membership_checkout_locks WHERE user_id=?",
      )
      .get(users.buyer.id).n,
    0,
  );
  assert.equal(
    db
      .prepare("SELECT COUNT(*) AS n FROM orders WHERE user_id=?")
      .get(users.buyer.id).n,
    1,
  );
});

test("pending PayPal refunds survive restart and revoke access only after provider confirmation", async (t) => {
  const paypal = paypalMock();
  const refundState = { status: "PENDING", posts: 0, gets: 0 };
  const paymentFetch = async (input, init) => {
    const path = new URL(input).pathname;
    if (path === "/v2/payments/captures/3C679366HH908993F/refund") {
      refundState.posts++;
      assert.equal(init.method, "POST");
      assert.equal(JSON.parse(init.body).amount.value, "39.00");
      return json(
        {
          id: "refund_PAYPAL123",
          status: refundState.status,
          amount: { value: "39.00", currency_code: "USD" },
        },
        201,
      );
    }
    if (path === "/v2/payments/refunds/refund_PAYPAL123") {
      refundState.gets++;
      return json({
        id: "refund_PAYPAL123",
        status: refundState.status,
        amount: { value: "39.00", currency_code: "USD" },
      });
    }
    return paypal.paymentFetch(input, init);
  };
  const { admin, buyer, db, dataDir, users } = await fixture(t, {
    paymentFetch,
  });
  assert.equal(
    (
      await configure(admin, {
        providers: {
          paypal: {
            enabled: true,
            environment: "sandbox",
            clientId: "paypal-client-id",
            clientSecret: "paypal-secret-value",
            merchantId: "RTRMERCHANT123",
          },
        },
      })
    ).status,
    200,
  );
  const payment = await checkout(buyer, "paypal", "paypal-refund-0001");
  assert.equal(
    (await buyer(`/api/payments/orders/${payment.data.id}/verify`, post({})))
      .status,
    200,
  );
  const requested = await buyer(
    `/api/billing/orders/${payment.data.id}/refunds`,
    post({ reason: "Please refund this test purchase." }),
  );
  assert.equal(requested.status, 201, JSON.stringify(requested.data));
  const refundPath = `/api/admin/commerce/refunds/${requested.data.refund.id}/approve`;
  const pending = await admin(refundPath, post({}));
  assert.equal(pending.status, 200, JSON.stringify(pending.data));
  assert.equal(pending.data.pending, true);
  assert.equal(
    db
      .prepare("SELECT provider_refund_id FROM payment_orders WHERE id=?")
      .get(payment.data.id).provider_refund_id,
    "refund_PAYPAL123",
  );
  assert.equal(
    db
      .prepare("SELECT COUNT(*) AS n FROM entitlements WHERE user_id=?")
      .get(users.buyer.id).n,
    1,
  );
  refundState.status = "COMPLETED";
  await withRestartedApp(
    dataDir,
    { paymentFetch },
    async ({ client, db: restartedDb }) => {
      const restartedAdmin = client();
      assert.equal(
        (
          await restartedAdmin(
            "/api/auth/login",
            post({ email: "admin@payment.test", password: PASSWORD }),
          )
        ).status,
        200,
      );
      const completed = await restartedAdmin(refundPath, post({}));
      assert.equal(completed.status, 200, JSON.stringify(completed.data));
      assert.equal(completed.data.pending, undefined);
      assert.equal(
        JSON.parse(
          restartedDb
            .prepare("SELECT payload FROM orders WHERE id=?")
            .get(payment.data.id).payload,
        ).status,
        "refunded",
      );
      assert.equal(
        restartedDb
          .prepare("SELECT COUNT(*) AS n FROM entitlements WHERE user_id=?")
          .get(users.buyer.id).n,
        0,
      );
    },
  );
  assert.equal(refundState.posts, 1);
  assert.equal(refundState.gets, 1);
});

test("a lost Razorpay refund response never causes a second refund, including after restart", async (t) => {
  const razorpay = razorpayMock();
  const refundState = { posts: 0, result: null, visible: false };
  const paymentFetch = async (input, init) => {
    const path = new URL(input).pathname;
    if (path === "/v1/payments/pay_TEST123456/refunds")
      return json({
        entity: "collection",
        count: refundState.visible ? 1 : 0,
        items: refundState.visible ? [refundState.result] : [],
      });
    if (path === "/v1/payments/pay_TEST123456/refund") {
      refundState.posts++;
      const body = JSON.parse(init.body);
      refundState.result = {
        id: "rfnd_TEST123456",
        payment_id: "pay_TEST123456",
        status: "processed",
        amount: body.amount,
        currency: "USD",
        receipt: body.receipt,
      };
      throw new Error(
        "The provider processed the refund but its response was lost",
      );
    }
    return razorpay.paymentFetch(input, init);
  };
  const { admin, buyer, db, dataDir, users } = await fixture(t, {
    paymentFetch,
  });
  assert.equal(
    (
      await configure(admin, {
        providers: {
          razorpay: {
            enabled: true,
            keyId: "rzp_test_ABC123",
            keySecret: "razorpay-secret-value",
          },
        },
      })
    ).status,
    200,
  );
  const payment = await checkout(buyer, "razorpay", "razorpay-refund-0001");
  razorpay.state.paid = true;
  assert.equal(
    (await buyer(`/api/payments/orders/${payment.data.id}/verify`, post({})))
      .status,
    200,
  );
  const requested = await buyer(
    `/api/billing/orders/${payment.data.id}/refunds`,
    post({ reason: "Please refund this test purchase." }),
  );
  assert.equal(requested.status, 201, JSON.stringify(requested.data));
  const refundPath = `/api/admin/commerce/refunds/${requested.data.refund.id}/approve`;
  assert.equal((await admin(refundPath, post({}))).status, 502);
  assert.equal(
    db
      .prepare(
        "SELECT COUNT(*) AS n FROM payment_refund_attempts WHERE order_id=?",
      )
      .get(payment.data.id).n,
    1,
  );
  assert.equal(
    db
      .prepare("SELECT COUNT(*) AS n FROM entitlements WHERE user_id=?")
      .get(users.buyer.id).n,
    1,
  );
  await withRestartedApp(
    dataDir,
    { paymentFetch },
    async ({ client, db: restartedDb }) => {
      const restartedAdmin = client();
      assert.equal(
        (
          await restartedAdmin(
            "/api/auth/login",
            post({ email: "admin@payment.test", password: PASSWORD }),
          )
        ).status,
        200,
      );
      const unknown = await restartedAdmin(refundPath, post({}));
      assert.equal(unknown.status, 200, JSON.stringify(unknown.data));
      assert.equal(unknown.data.pending, true);
      assert.equal(refundState.posts, 1);
      assert.equal(
        restartedDb
          .prepare("SELECT COUNT(*) AS n FROM entitlements WHERE user_id=?")
          .get(users.buyer.id).n,
        1,
      );
      refundState.visible = true;
      const confirmed = await restartedAdmin(refundPath, post({}));
      assert.equal(confirmed.status, 200, JSON.stringify(confirmed.data));
      assert.equal(
        JSON.parse(
          restartedDb
            .prepare("SELECT payload FROM orders WHERE id=?")
            .get(payment.data.id).payload,
        ).status,
        "refunded",
      );
      assert.equal(
        restartedDb
          .prepare("SELECT COUNT(*) AS n FROM entitlements WHERE user_id=?")
          .get(users.buyer.id).n,
        0,
      );
    },
  );
  assert.equal(refundState.posts, 1);
});

test("payment checkout, verification, and credential changes enforce request quotas", async (t) => {
  const { admin, buyer, db, users } = await fixture(t);
  const checkouts = await Promise.all(
    Array.from({ length: 51 }, (_, i) =>
      checkout(
        buyer,
        "invalid-provider",
        `quota-checkout-${String(i).padStart(4, "0")}`,
      ),
    ),
  );
  assert.equal(
    checkouts.filter((response) => response.status === 400).length,
    50,
  );
  const limited = checkouts.find((response) => response.status === 429);
  assert.ok(limited);
  assert.ok(Number(limited.headers.get("Retry-After")) > 0);
  const verifications = await Promise.all(
    Array.from({ length: 61 }, () =>
      buyer("/api/payments/orders/missing/verify", post({})),
    ),
  );
  assert.equal(
    verifications.filter((response) => response.status === 404).length,
    60,
  );
  assert.equal(
    verifications.filter((response) => response.status === 429).length,
    1,
  );
  const settings = await Promise.all(
    Array.from({ length: 21 }, () =>
      admin("/api/admin/payments/settings", patch({ password: "incorrect" })),
    ),
  );
  assert.equal(
    settings.filter((response) => response.status === 403).length,
    20,
  );
  assert.equal(
    settings.filter((response) => response.status === 429).length,
    1,
  );
  noGrant(db, users.buyer.id);
});
