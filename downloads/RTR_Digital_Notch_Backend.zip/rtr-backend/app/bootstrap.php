<?php
declare(strict_types=1);
ini_set('display_errors', '0');
ini_set('log_errors', '1');

define('RTR_BACKEND_ROOT', dirname(__DIR__));
define('RTR_PRIVATE', getenv('RTR_PRIVATE_DIR') ?: RTR_BACKEND_ROOT . '/private');

final class RtrHttpError extends RuntimeException {
    public int $status;
    public function __construct(int $status, string $message) {
        parent::__construct($message); $this->status = $status;
    }
}
function rtr_fail(int $status, string $message): never { throw new RtrHttpError($status, $message); }
function rtr_config(): array {
    static $config;
    if (isset($config)) return $config;
    $file = RTR_PRIVATE . '/config.php';
    $config = is_file($file) ? require $file : [];
    if (!is_array($config)) rtr_fail(503, 'The private backend configuration is invalid.');
    if (getenv('RTR_ENV') === 'development' || getenv('APP_ENV') === 'development') $config['environment'] = 'development';
    return $config;
}
function rtr_configured(): bool {
    $token = (string)(rtr_config()['setup_token'] ?? '');
    return strlen($token) >= 32 && !str_contains($token, 'REPLACE-');
}
function rtr_installed(): bool { return is_file(RTR_PRIVATE . '/auth.json'); }
function rtr_https(): bool {
    if (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') return true;
    return !empty(rtr_config()['trust_proxy_https']) &&
        strtolower((string)($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '')) === 'https';
}
function rtr_require_https(): void {
    if ((rtr_config()['environment'] ?? 'production') !== 'development' && !rtr_https())
        rtr_fail(426, 'Open the backend using HTTPS. Plain HTTP is only enabled by the explicit development configuration.');
}
function rtr_private_dir(): void {
    if (!is_dir(RTR_PRIVATE) && !mkdir(RTR_PRIVATE, 0700, true)) rtr_fail(503, 'Private storage is unavailable.');
    if (!is_writable(RTR_PRIVATE)) rtr_fail(503, 'The private backend directory must be writable by PHP.');
}
function rtr_headers(bool $admin = false): void {
    header('X-Content-Type-Options: nosniff');
    header('Referrer-Policy: same-origin');
    header('X-Frame-Options: DENY');
    if ($admin) {
        header('Cache-Control: no-store, private');
        header("Content-Security-Policy: default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; connect-src 'self'; frame-ancestors 'none'; base-uri 'self'; form-action 'self'");
    }
}
function rtr_json(array $payload, int $status = 200): never {
    http_response_code($status); header('Content-Type: application/json; charset=utf-8');
    echo json_encode($payload, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR); exit;
}
function rtr_run(callable $fn): never {
    try { $fn(); } catch (RtrHttpError $e) { rtr_json(['error' => $e->getMessage()], $e->status); }
    catch (Throwable $e) { error_log('RTR backend failure: ' . get_class($e)); rtr_json(['error' => 'The request could not be completed. Check the private server configuration and try again.'], 500); }
    exit;
}
function rtr_input(int $max = 300000): array {
    if ((int)($_SERVER['CONTENT_LENGTH'] ?? 0) > $max) rtr_fail(413, 'This request is too large.');
    $raw = file_get_contents('php://input', false, null, 0, $max + 1);
    if ($raw === false || strlen($raw) > $max) rtr_fail(413, 'This request is too large.');
    try { $data = json_decode($raw, true, 48, JSON_THROW_ON_ERROR); }
    catch (JsonException $e) { rtr_fail(400, 'Send a valid JSON object.'); }
    if (!is_array($data) || array_is_list($data)) rtr_fail(400, 'Send a JSON object.');
    return $data;
}
function rtr_method(string $method): void {
    if (($_SERVER['REQUEST_METHOD'] ?? '') !== $method) {
        header('Allow: ' . $method); rtr_fail(405, 'This method is not supported.');
    }
}
function rtr_origin(): string {
    return (rtr_https() ? 'https://' : 'http://') . strtolower((string)($_SERVER['HTTP_HOST'] ?? ''));
}
function rtr_same_origin(): void {
    $origin = $_SERVER['HTTP_ORIGIN'] ?? '';
    if (!$origin && !empty($_SERVER['HTTP_REFERER'])) {
        $p = parse_url($_SERVER['HTTP_REFERER']);
        if (is_array($p) && isset($p['scheme'], $p['host']))
            $origin = $p['scheme'] . '://' . $p['host'] . (isset($p['port']) ? ':' . $p['port'] : '');
    }
    $incoming = strtolower(rtrim($origin, '/'));
    $public = parse_url((string)(rtr_config()['public_url'] ?? ''));
    $configured = is_array($public) && isset($public['scheme'], $public['host'])
        ? strtolower($public['scheme'] . '://' . $public['host'] . (isset($public['port']) ? ':' . $public['port'] : '')) : '';
    $developmentAlias = false;
    if ((rtr_config()['environment'] ?? '') === 'development' && is_array($public)) {
        $parsed = parse_url($incoming); $loopback = ['localhost', '127.0.0.1', '[::1]', '::1'];
        $developmentAlias = is_array($parsed) && in_array(strtolower((string)($public['host'] ?? '')), $loopback, true) &&
            in_array(strtolower((string)($parsed['host'] ?? '')), $loopback, true) &&
            ($parsed['scheme'] ?? '') === ($public['scheme'] ?? '') &&
            ($parsed['port'] ?? 80) === ($public['port'] ?? 80);
    }
    if (!$origin || (!hash_equals(rtr_origin(), $incoming) && (!$configured || !hash_equals($configured, $incoming)) && !$developmentAlias))
        rtr_fail(403, 'This action must be submitted from the same website.');
}
function rtr_read(string $name, mixed $default = []): mixed {
    $file = RTR_PRIVATE . '/' . $name . '.json';
    if (!is_file($file)) return $default;
    $lock = fopen(RTR_PRIVATE . '/' . $name . '.lock', 'c');
    if (!$lock || !flock($lock, LOCK_SH)) rtr_fail(503, 'Private storage is busy.');
    try {
        $raw = file_get_contents($file);
        if ($raw === false) rtr_fail(503, 'Private storage could not be read.');
        return json_decode($raw, true, 64, JSON_THROW_ON_ERROR);
    } finally { flock($lock, LOCK_UN); fclose($lock); }
}
function rtr_transaction(string $name, mixed $default, callable $edit): mixed {
    rtr_private_dir(); $lockPath = RTR_PRIVATE . '/' . $name . '.lock';
    $lock = fopen($lockPath, 'c');
    if (!$lock || !flock($lock, LOCK_EX)) rtr_fail(503, 'Private storage is busy.');
    @chmod($lockPath, 0600);
    try {
        $file = RTR_PRIVATE . '/' . $name . '.json';
        $value = is_file($file) ? json_decode((string)file_get_contents($file), true, 64, JSON_THROW_ON_ERROR) : $default;
        $result = $edit($value);
        $tmp = RTR_PRIVATE . '/.' . $name . '-' . bin2hex(random_bytes(8)) . '.tmp';
        $encoded = json_encode($result, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR);
        if (file_put_contents($tmp, $encoded, LOCK_EX) !== strlen($encoded)) { @unlink($tmp); rtr_fail(503, 'Private storage could not be written completely.'); }
        @chmod($tmp, 0600);
        if (!rename($tmp, $file)) { @unlink($tmp); rtr_fail(503, 'The update could not be saved atomically.'); }
        return $result;
    } finally { flock($lock, LOCK_UN); fclose($lock); }
}
function rtr_seed(): array {
    $paths = [RTR_BACKEND_ROOT . '/seed/editorial-content.json', dirname(RTR_BACKEND_ROOT) . '/shared/editorial-content.json'];
    foreach ($paths as $p) if (is_file($p)) {
        $seed = json_decode((string)file_get_contents($p), true, 64, JSON_THROW_ON_ERROR);
        if (is_array($seed)) return $seed;
    }
    rtr_fail(503, 'The editorial seed is missing. Upload the complete backend package.');
}
function rtr_content(): array {
    $stored = rtr_read('content', null);
    return is_array($stored) ? $stored : ['revision' => 0, 'updatedAt' => null, 'content' => rtr_seed()];
}
function rtr_rate(string $group, int $limit, int $seconds): void {
    if (!rtr_configured()) rtr_fail(503, 'The private backend has not been configured yet.');
    $key = hash_hmac('sha256', (string)($_SERVER['REMOTE_ADDR'] ?? 'unknown'), (string)rtr_config()['setup_token']);
    $now = time();
    rtr_transaction('rate-' . $group, [], function ($rows) use ($key, $limit, $seconds, $now) {
        $rows = is_array($rows) ? $rows : [];
        foreach ($rows as $ip => $hits) {
            $rows[$ip] = array_values(array_filter((array)$hits, fn($n) => is_int($n) && $n > $now - $seconds));
            if (!$rows[$ip]) unset($rows[$ip]);
        }
        if (count($rows[$key] ?? []) >= $limit) { header('Retry-After: ' . $seconds); rtr_fail(429, 'Too many attempts. Please wait before trying again.'); }
        if (count($rows) > 10000) rtr_fail(503, 'Please try again later.');
        $rows[$key][] = $now; return $rows;
    });
}
function rtr_session(): void {
    rtr_require_https(); rtr_private_dir();
    if (session_status() === PHP_SESSION_ACTIVE) return;
    $sessions = RTR_PRIVATE . '/sessions';
    if (!is_dir($sessions)) mkdir($sessions, 0700, true);
    session_save_path($sessions); session_name('rtr_editorial_admin');
    ini_set('session.use_strict_mode', '1'); ini_set('session.use_only_cookies', '1');
    session_set_cookie_params(['lifetime' => 0, 'path' => '/admin', 'secure' => rtr_https(), 'httponly' => true, 'samesite' => 'Strict']);
    session_start();
    if (isset($_SESSION['last_seen']) && ($_SESSION['last_seen'] < time() - 1800 || ($_SESSION['created'] ?? 0) < time() - 43200)) {
        $_SESSION = []; session_regenerate_id(true);
    }
    if (!isset($_SESSION['created'])) $_SESSION['created'] = time();
    $_SESSION['last_seen'] = time();
    if (empty($_SESSION['csrf'])) $_SESSION['csrf'] = bin2hex(random_bytes(32));
}
function rtr_csrf(): void {
    rtr_same_origin();
    $token = (string)($_SERVER['HTTP_X_CSRF_TOKEN'] ?? '');
    if (!$token || !hash_equals((string)($_SESSION['csrf'] ?? ''), $token)) rtr_fail(403, 'The security token is missing or expired. Reload this page.');
}
function rtr_admin(): array {
    rtr_session(); $auth = rtr_read('auth', null);
    if (!$auth || !isset($_SESSION['admin']) || !hash_equals((string)$auth['email'], (string)$_SESSION['admin']) ||
        ($_SESSION['auth_version'] ?? 0) !== ($auth['version'] ?? 1))
        rtr_fail(401, 'Sign in to the private administrator backend.');
    return $auth;
}
function rtr_plain(mixed $value, int $max = 5000, bool $required = false): string {
    if (!is_string($value)) rtr_fail(422, 'Content fields must contain plain text.');
    $value = trim($value);
    if (strlen($value) > $max || ($required && $value === '')) rtr_fail(422, 'One of the content fields is empty or too long.');
    if (preg_match('/<\/?[a-z][^>]*>/i', $value) || preg_match('/[\x00-\x08\x0B\x0C\x0E-\x1F]/', $value))
        rtr_fail(422, 'HTML and control characters are not accepted in editorial text.');
    return $value;
}
function rtr_validate_content(mixed $candidate): array {
    $seed = rtr_seed();
    if (!is_array($candidate)) rtr_fail(422, 'Send the complete editorial content object.');
    $immutable = ['id', 'path', 'slug', 'theme', 'art', 'image', 'category', 'name'];
    $walk = function ($value, $model, string $key = '') use (&$walk, $immutable) {
        if (is_array($model)) {
            if (!is_array($value) || array_keys($value) !== array_keys($model)) rtr_fail(422, 'Keep the existing content fields and record order.');
            $out = []; foreach ($model as $k => $v) $out[$k] = $walk($value[$k], $v, (string)$k); return $out;
        }
        if (in_array($key, $immutable, true)) {
            if ($value !== $model) rtr_fail(422, 'Content identities, routes, artwork and categories cannot be changed in this editor.');
            return $model;
        }
        if (is_string($model)) {
            if ($key === 'accent' && (!is_string($value) || !preg_match('/^#[0-9a-fA-F]{6}$/', $value))) rtr_fail(422, 'Accent colors must be six-digit hex colors.');
            $max = in_array($key, ['title', 'label', 'name', 'emphasis', 'eyebrow', 'tagline', 'topic', 'format'], true) ? 200 : 10000;
            return rtr_plain($value, $max, $model !== '');
        }
        if (is_int($model)) { if (!is_int($value) || $value < 0 || $value > 10000) rtr_fail(422, 'Numeric content fields are outside their allowed range.'); return $value; }
        if (is_bool($model)) { if (!is_bool($value)) rtr_fail(422, 'A content switch has an invalid value.'); return $value; }
        if ($value !== $model) rtr_fail(422, 'A content field has an unsupported value.');
        return $model;
    };
    return $walk($candidate, $seed);
}
