<?php
// Copy to config.php INSIDE the private rtr-backend/private directory.
// Replace setup_token with a NEW random secret of at least 32 characters.
// Never upload this private directory into public_html.
return [
    'environment' => 'production',
    'setup_token' => 'REPLACE-WITH-YOUR-OWN-32-OR-MORE-CHARACTER-RANDOM-SECRET',
    'public_url' => 'https://your-real-domain.example',
    // Leave false unless PHP is behind a reverse proxy you explicitly trust.
    'trust_proxy_https' => false,
];
