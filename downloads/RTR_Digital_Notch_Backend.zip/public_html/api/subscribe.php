<?php
require dirname(__DIR__) . '/rtr-bootstrap.php';
rtr_headers(); header('Cache-Control: no-store');
rtr_run(function () {
    rtr_method('POST'); rtr_require_https(); rtr_same_origin(); rtr_rate('subscribe', 10, 3600);
    $input = rtr_input(12000); $email = strtolower(trim((string)($input['email'] ?? '')));
    if (strlen($email) > 254 || !filter_var($email, FILTER_VALIDATE_EMAIL)) rtr_fail(422, 'Enter a valid email address.');
    if (($input['consent'] ?? null) !== true) rtr_fail(422, 'Please consent to the newsletter subscription request.');
    if (!empty($input['website'])) rtr_json(['ok' => true, 'message' => 'Your subscription request has been saved.']);
    $topics = $input['topics'] ?? [];
    if (!is_array($topics) || count($topics) > 9) rtr_fail(422, 'Choose valid newsletter topics.');
    $allowed = ['academics','crime-thrillers','fiction','non-fiction','literature','magazines','newsletters','all','weekly','monthly'];
    foreach ($topics as $topic) if (!is_string($topic) || !in_array($topic, $allowed, true)) rtr_fail(422, 'Choose valid newsletter topics.');
    $topics = array_values(array_unique($topics));
    rtr_transaction('subscribers', [], function ($rows) use ($email, $topics) {
        $rows = is_array($rows) ? $rows : []; $key = hash('sha256', $email);
        if (!isset($rows[$key]) && count($rows) >= 20000) rtr_fail(503, 'Subscriptions are temporarily unavailable. Please try again later.');
        if (!isset($rows[$key])) $rows[$key] = ['email' => $email, 'topics' => $topics, 'consent' => true,
            'createdAt' => gmdate('c'), 'status' => 'requested', 'source' => 'RTR Digital website'];
        return $rows;
    });
    rtr_json(['ok' => true, 'message' => 'Your subscription request has been saved. Email delivery will begin when RTR Digital enables its mailing service.']);
});
