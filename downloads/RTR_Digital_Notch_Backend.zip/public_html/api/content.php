<?php
require dirname(__DIR__) . '/rtr-bootstrap.php';
rtr_headers();
rtr_run(function () {
    rtr_method('GET'); $result = rtr_content();
    $etag = '"rtr-' . hash('sha256', json_encode($result)) . '"';
    header('Cache-Control: public, max-age=0, must-revalidate'); header('ETag: ' . $etag);
    if (($_SERVER['HTTP_IF_NONE_MATCH'] ?? '') === $etag) { http_response_code(304); exit; }
    rtr_json($result);
});
