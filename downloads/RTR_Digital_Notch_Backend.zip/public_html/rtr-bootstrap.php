<?php
declare(strict_types=1);
// Public bridge only: the PHP application, configuration and data stay OUTSIDE public_html.
$rtrCandidates = [getenv('RTR_BACKEND_PATH') ?: '', dirname(__DIR__) . '/rtr-backend', dirname(__DIR__)];
foreach ($rtrCandidates as $rtrPath) {
    if ($rtrPath && is_file($rtrPath . '/app/bootstrap.php')) {
        require_once $rtrPath . '/app/bootstrap.php'; return;
    }
}
http_response_code(503); header('Content-Type: application/json; charset=utf-8');
echo json_encode(['error' => 'The private RTR backend folder could not be located. Complete the hosting installation.']); exit;
