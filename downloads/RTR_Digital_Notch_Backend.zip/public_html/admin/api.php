<?php
require dirname(__DIR__) . '/rtr-bootstrap.php';
rtr_headers(true);
rtr_run(function () {
    rtr_session(); $action = (string)($_GET['action'] ?? 'session');
    if ($action === 'session') {
        rtr_method('GET'); $auth = rtr_read('auth', null);
        $signed = $auth && isset($_SESSION['admin']) && hash_equals($auth['email'], $_SESSION['admin']) &&
            ($_SESSION['auth_version'] ?? 0) === ($auth['version'] ?? 1);
        rtr_json(['configured' => rtr_configured(), 'installed' => rtr_installed(),
            'user' => $signed ? ['email' => $auth['email']] : null, 'csrf' => $_SESSION['csrf']]);
    }
    if ($action === 'install') {
        rtr_method('POST'); rtr_csrf(); rtr_rate('install', 5, 3600); $input = rtr_input(8000);
        if (rtr_installed()) rtr_fail(409, 'Setup is already complete. Sign in using your administrator account.');
        if (!hash_equals((string)rtr_config()['setup_token'], (string)($input['token'] ?? ''))) rtr_fail(403, 'The private setup token is incorrect.');
        $email = strtolower(trim((string)($input['email'] ?? ''))); $password = (string)($input['password'] ?? '');
        if (!filter_var($email, FILTER_VALIDATE_EMAIL) || strlen($email) > 254) rtr_fail(422, 'Enter a valid administrator email address.');
        if (strlen($password) < 12 || strlen($password) > 72) rtr_fail(422, 'Use an administrator password containing 12–72 bytes.');
        rtr_transaction('auth', null, function ($current) use ($email, $password) {
            if ($current) rtr_fail(409, 'Setup is already complete.');
            return ['email' => $email, 'passwordHash' => password_hash($password, PASSWORD_DEFAULT), 'createdAt' => gmdate('c'), 'version' => 1];
        });
        $_SESSION = []; session_regenerate_id(true);
        rtr_json(['ok' => true, 'message' => 'Your private administrator account is ready. Sign in to continue.']);
    }
    if ($action === 'login') {
        rtr_method('POST'); rtr_csrf(); rtr_rate('login', 10, 900); $input = rtr_input(8000); $auth = rtr_read('auth', null);
        $email = strtolower(trim((string)($input['email'] ?? ''))); $password = (string)($input['password'] ?? '');
        if (!$auth || strlen($password) > 72 || !password_verify($password, $auth['passwordHash']) || !hash_equals($auth['email'], $email))
            rtr_fail(401, 'The email address or password is incorrect.');
        session_regenerate_id(true); $_SESSION = ['admin' => $auth['email'], 'auth_version' => $auth['version'] ?? 1,
            'created' => time(), 'last_seen' => time(), 'csrf' => bin2hex(random_bytes(32))];
        rtr_json(['ok' => true]);
    }
    $auth = rtr_admin();
    if ($action === 'content') {
        if (($_SERVER['REQUEST_METHOD'] ?? '') === 'GET') rtr_json(rtr_content());
        rtr_method('POST'); rtr_csrf(); $input = rtr_input();
        $validated = rtr_validate_content($input['content'] ?? null);
        if (!is_int($input['revision'] ?? null)) rtr_fail(422, 'A valid content revision is required.');
        $result = rtr_transaction('content', rtr_content(), function ($current) use ($validated, $input) {
            if ($input['revision'] !== ($current['revision'] ?? 0)) rtr_fail(409, 'This content changed in another session. Reload it before saving again.');
            return ['revision' => $current['revision'] + 1, 'updatedAt' => gmdate('c'), 'content' => $validated];
        });
        rtr_json(['ok' => true, 'revision' => $result['revision'], 'updatedAt' => $result['updatedAt']]);
    }
    if ($action === 'subscribers') {
        rtr_method('GET'); rtr_json(['subscribers' => array_values(rtr_read('subscribers', []))]);
    }
    if ($action === 'export') {
        rtr_method('POST'); rtr_csrf();
        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename="rtr-newsletter-requests.csv"');
        $out = fopen('php://output', 'w');
        fputcsv($out, ['Email', 'Topics', 'Consent', 'Requested at UTC', 'Status'], ',', '"', '');
        $safe = fn($v) => preg_match('/^[\s]*[=+@\-]/u', (string)$v) ? "'" . $v : $v;
        foreach (rtr_read('subscribers', []) as $row)
            fputcsv($out, array_map($safe, [$row['email'], implode('; ', $row['topics']), 'yes', $row['createdAt'], $row['status']]), ',', '"', '');
        fclose($out); exit;
    }
    if ($action === 'delete-subscriber') {
        rtr_method('POST'); rtr_csrf(); $input = rtr_input(2000);
        $email = strtolower(trim((string)($input['email'] ?? '')));
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) rtr_fail(422, 'Enter a valid subscriber email address.');
        rtr_transaction('subscribers', [], function ($rows) use ($email) { unset($rows[hash('sha256', $email)]); return $rows; });
        rtr_json(['ok' => true]);
    }
    if ($action === 'password') {
        rtr_method('POST'); rtr_csrf(); rtr_rate('password', 5, 900); $input = rtr_input(8000);
        if (!password_verify((string)($input['currentPassword'] ?? ''), $auth['passwordHash'])) rtr_fail(403, 'Your current password is incorrect.');
        $password = (string)($input['password'] ?? '');
        if (strlen($password) < 12 || strlen($password) > 72) rtr_fail(422, 'Use a new password containing 12–72 bytes.');
        $updated = rtr_transaction('auth', null, function ($current) use ($auth, $password) {
            if (!$current || $current['passwordHash'] !== $auth['passwordHash']) rtr_fail(409, 'Your account changed. Sign in again.');
            $current['passwordHash'] = password_hash($password, PASSWORD_DEFAULT); $current['version'] = ($current['version'] ?? 1) + 1; return $current;
        });
        session_regenerate_id(true); $_SESSION['auth_version'] = $updated['version'];
        rtr_json(['ok' => true, 'message' => 'Password changed. Other administrator sessions must sign in again.']);
    }
    if ($action === 'logout') {
        rtr_method('POST'); rtr_csrf(); $_SESSION = [];
        $params = session_get_cookie_params(); setcookie(session_name(), '', ['expires' => time()-3600, 'path' => $params['path'],
            'secure' => $params['secure'], 'httponly' => true, 'samesite' => 'Strict']); session_destroy(); rtr_json(['ok' => true]);
    }
    rtr_fail(404, 'This administrator action does not exist.');
});
