<?php
require dirname(__DIR__) . '/rtr-bootstrap.php';
rtr_headers(true);
$rtrError = '';
try { rtr_session(); } catch (RtrHttpError $e) { http_response_code($e->status); $rtrError = $e->getMessage(); }
catch (Throwable $e) { http_response_code(503); $rtrError = 'The private backend configuration could not be loaded. Ask the hosting operator to inspect the private PHP configuration.'; }
function h(string $s): string { return htmlspecialchars($s, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'); }
?><!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
  <meta name="robots" content="noindex,nofollow,noarchive">
  <title>RTR Digital — Private Editorial Backend</title>
  <link rel="icon" href="assets/favicon.svg" type="image/svg+xml">
  <link rel="stylesheet" href="assets/admin.css">
</head>
<body>
<a class="skip" href="#workspace">Skip to workspace</a>
<div class="backend-shell">
  <aside class="sidebar">
    <a class="brand" href="./" aria-label="RTR Digital backend"><span class="brand-mark">R</span><span>RTR<span class="brand-small">DIGITAL</span></span></a>
    <p class="sidebar-kicker">THE OTHER SIDE OF THE STORY.</p>
    <h1>Your editorial<br><em>control room.</em></h1>
    <p class="sidebar-intro">A private space for the words, ideas and reading experiences that make RTR Digital yours.</p>
    <nav id="private-nav" aria-label="Backend workspaces" hidden>
      <button type="button" data-tab="content" class="nav-item is-active">01 <span>Editorial content</span><b class="arrow" aria-hidden="true"></b></button>
      <button type="button" data-tab="subscribers" class="nav-item">02 <span>Newsletter requests</span><b class="arrow" aria-hidden="true"></b></button>
      <button type="button" data-tab="account" class="nav-item">03 <span>Account & security</span><b class="arrow" aria-hidden="true"></b></button>
    </nav>
    <div class="sidebar-foot"><span class="status-dot"></span>SEPARATE BACKEND · PRIVATE ACCESS<p>The public website contains no administrator navigation.</p></div>
  </aside>
  <main id="workspace" class="workspace" tabindex="-1">
    <header class="topbar"><span>RTR DIGITAL / EDITORIAL BACKEND</span><div id="session-tools" hidden><span id="user-email"></span><button type="button" id="logout" class="text-button">Sign out <span class="arrow" aria-hidden="true"></span></button></div></header>
    <div id="notice" role="status" aria-live="polite"></div>
    <?php if ($rtrError): ?><section class="auth-card"><p class="eyebrow">CONNECTION REQUIRED</p><h2>Use a secure<br><em>connection.</em></h2><p><?= h($rtrError) ?></p></section><?php else: ?>
    <section id="loading" class="auth-card"><p class="eyebrow">PRIVATE EDITORIAL WORKSPACE</p><h2>Opening your<br><em>next chapter.</em></h2><p>Checking your secure session…</p></section>
    <section id="configuration" class="auth-card" hidden><p class="eyebrow">ONE PRIVATE STEP FIRST</p><h2>Make this<br><em>workspace yours.</em></h2><p>Upload the complete private backend folder outside <code>public_html</code>. Copy <code>private/config.example.php</code> to <code>private/config.php</code> and replace the setup-token placeholder with your own random secret of at least 32 characters.</p><p>Set your real HTTPS domain and leave production mode enabled. Then reload this page to create the administrator account. No shared login or default password is supplied.</p><button type="button" class="primary" id="reload">Check configuration <span class="arrow" aria-hidden="true"></span></button></section>
    <section id="install" class="auth-card" hidden><p class="eyebrow">FIRST-TIME SETUP</p><h2>The beginning<br>of <em>something good.</em></h2><p>Create your private administrator account. You will need the setup token saved in your private configuration file.</p><form id="install-form"><label>Private setup token<input name="token" type="password" required autocomplete="off"></label><label>Administrator email<input name="email" type="email" required maxlength="254" autocomplete="username"></label><label>Choose a password<input name="password" type="password" required minlength="12" maxlength="72" autocomplete="new-password"><small>Use 12–72 ASCII characters and keep it in your password manager.</small></label><button class="primary" type="submit">Create administrator <span class="arrow" aria-hidden="true"></span></button></form><p class="fine">Setup locks after the first account is created. This screen does not create a public customer account.</p></section>
    <section id="login" class="auth-card" hidden><p class="eyebrow">FOR YOUR EYES ONLY</p><h2>Welcome<br><em>back, editor.</em></h2><p>Sign in to manage your editorial pages and newsletter requests.</p><form id="login-form"><label>Email address<input type="email" name="email" required maxlength="254" autocomplete="username"></label><label>Password<input type="password" name="password" required maxlength="72" autocomplete="current-password"></label><button class="primary" type="submit">Enter your workspace <span class="arrow" aria-hidden="true"></span></button></form><p class="fine">Access is private. Contact your hosting operator if you need to recover the administrator account.</p></section>
    <section id="content-panel" class="panel" hidden>
      <div class="panel-heading"><div><p class="eyebrow">THE WORDS ARE YOURS</p><h2>Shape the <em>story.</em></h2><p>Edit the public copy, then publish it in one considered update.</p></div><div class="heading-actions"><span id="revision" class="pill"></span><button class="secondary" id="reload-content" type="button">Reload</button><button class="primary" id="save-content" type="button" disabled>Publish changes <span class="arrow" aria-hidden="true"></span></button></div></div>
      <div class="editor-summary" id="editor-summary"></div>
      <div class="editor-layout"><div class="record-picker"><label for="record-type">WHAT WOULD YOU LIKE TO EDIT?</label><select id="record-type"><option value="site">Brand & global copy</option><option value="pages">The nine pages</option><option value="entries">Reading selections</option></select><div id="record-list" class="record-list"></div></div><form id="editor-form" class="editor-form"></form></div>
      <p class="fine">Content is plain text. Routes, record identities and artwork remain stable. Layout and visual design live in the separate frontend source.</p>
    </section>
    <section id="subscribers-panel" class="panel" hidden><div class="panel-heading"><div><p class="eyebrow">A MORE THOUGHTFUL INBOX</p><h2>Curious minds,<br><em>staying in touch.</em></h2><p>Consented newsletter requests captured by your website. No email is sent by this backend.</p></div><button type="button" class="primary" id="export-subscribers">Download CSV <span class="arrow" aria-hidden="true"></span></button></div><div id="subscriber-list"></div><p class="fine">Connect an authorized mailing service separately before sending newsletters. Honor consent and removal requests. CSV exports contain personal information; keep them private.</p></section>
    <section id="account-panel" class="panel" hidden><p class="eyebrow">KEEP YOUR SPACE PRIVATE</p><h2>A little care.<br><em>A stronger account.</em></h2><div class="account-grid"><form id="password-form" class="white-card"><h3>Change your password</h3><label>Current password<input name="currentPassword" type="password" required autocomplete="current-password" maxlength="72"></label><label>New password<input name="password" type="password" required minlength="12" maxlength="72" autocomplete="new-password"><small>Use 12–72 ASCII characters.</small></label><button class="primary" type="submit">Update password <span class="arrow" aria-hidden="true"></span></button></form><div class="white-card"><p class="eyebrow">A NOTE ON YOUR BACKEND</p><h3>Private by design.</h3><p>Your content, account hash and subscriber requests are stored outside the public website folder. Back up the complete private backend directory through your hosting account.</p><p>Sessions expire after 30 minutes of inactivity or 12 hours overall. Changing your password signs out other backend sessions.</p><p>This editorial backend manages the current nine-page website. Digital commerce, payment credentials and customer libraries belong to the separately retained commerce services.</p></div></div></section>
    <?php endif; ?>
    <footer class="workspace-footer"><span>RTR DIGITAL</span><span>Independent minds. Extraordinary worlds.</span><span>PRIVATE BACKEND</span></footer>
  </main>
</div>
<?php if (!$rtrError): ?><script src="assets/admin.js" defer></script><?php endif; ?>
</body></html>
