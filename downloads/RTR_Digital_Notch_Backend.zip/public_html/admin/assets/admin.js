(() => {
  'use strict';
  const $ = (id) => document.getElementById(id);
  const state = { csrf: '', user: null, content: null, revision: 0, dirty: false, kind: 'site', record: 0, saving: false };
  const sections = ['loading', 'configuration', 'install', 'login', 'content-panel', 'subscribers-panel', 'account-panel'];
  const immutable = new Set(['id', 'path', 'slug', 'theme', 'art', 'image', 'category', 'name']);
  const notice = (text, error = false) => { $('notice').textContent = text; $('notice').className = text ? `notice-shown${error ? ' notice-error' : ''}` : ''; };
  const label = (key) => key.replace(/([A-Z])/g, ' $1').replace(/[-_]/g, ' ').replace(/^./, (s) => s.toUpperCase());
  const show = (id) => sections.forEach((key) => { if ($(key)) $(key).hidden = key !== id; });
  async function request(action, method = 'GET', body) {
    const response = await fetch(`api.php?action=${encodeURIComponent(action)}`, { method, credentials: 'same-origin',
      headers: method === 'GET' ? {} : { 'Content-Type': 'application/json', 'X-CSRF-Token': state.csrf },
      ...(body ? { body: JSON.stringify(body) } : {}) });
    const payload = await response.json();
    if (!response.ok) throw new Error(payload.error || 'The request could not be completed.');
    return payload;
  }
  async function session() {
    const data = await request('session'); state.csrf = data.csrf; state.user = data.user;
    $('private-nav').hidden = !data.user; $('session-tools').hidden = !data.user;
    if (!data.configured) { show('configuration'); return; }
    if (!data.installed) { show('install'); return; }
    if (!data.user) { state.content = null; state.dirty = false; show('login'); return; }
    $('user-email').textContent = data.user.email; await loadContent(); tab('content');
  }
  function records(kind) {
    if (kind === 'site') return [{ key: null, value: state.content.site || state.content.global || state.content }];
    const source = state.content[kind] || [];
    return Array.isArray(source) ? source.map((value, key) => ({ key, value })) : Object.entries(source).map(([key, value]) => ({ key, value }));
  }
  function dirty(value) { state.dirty = value; $('save-content').disabled = !value || state.saving; $('revision').textContent = value ? 'Unsaved changes' : `Revision ${state.revision}`; }
  function selected() { return records(state.kind)[state.record] || records(state.kind)[0]; }
  function recordTitle(item) { return item?.value?.label || item?.value?.title || item?.value?.name || (state.kind === 'site' ? 'The RTR Digital identity' : String(item?.key || 'Record')); }
  function make(tag, text, className) { const el = document.createElement(tag); if (text !== undefined) el.textContent = text; if (className) el.className = className; return el; }
  function renderPicker() {
    const list = $('record-list'); list.replaceChildren();
    records(state.kind).forEach((record, index) => {
      const b = make('button', recordTitle(record), `record-button${index === state.record ? ' selected' : ''}`);
      b.type = 'button'; b.setAttribute('aria-pressed', String(index === state.record));
      const sub = record.value?.path || record.value?.id || (state.kind === 'site' ? 'Public brand & editorial copy' : 'Editorial record');
      b.append(make('small', sub)); b.addEventListener('click', () => { state.record = index; renderPicker(); renderEditor(); }); list.append(b);
    });
  }
  function renderFields(value, parent, path = []) {
    for (const [key, current] of Object.entries(value)) {
      const next = [...path, key]; const fieldLabel = /^\d+$/.test(key) ? `Paragraph ${Number(key)+1}` : label(key);
      if (immutable.has(key)) {
        const p = make('p', undefined, 'readonly-field'); p.append(make('strong', fieldLabel + ': '), document.createTextNode(String(current))); parent.append(p); continue;
      }
      if (current !== null && typeof current === 'object') {
        const fieldset = make('fieldset'); fieldset.append(make('legend', fieldLabel)); renderFields(current, fieldset, next); parent.append(fieldset); continue;
      }
      if (typeof current !== 'string' && typeof current !== 'number' && typeof current !== 'boolean') continue;
      const wrapper = make('label', fieldLabel); let input;
      if (typeof current === 'boolean') { input = make('input'); input.type = 'checkbox'; input.checked = current; }
      else if (typeof current === 'number') { input = make('input'); input.type = 'number'; input.min = '0'; input.max = '10000'; input.step = '1'; input.value = String(current); }
      else if (current.length > 140 || /description|excerpt|text|body|manifesto|paragraph/i.test(key) || Array.isArray(value)) {
        input = make('textarea'); input.value = current; input.maxLength = 10000; input.rows = current.length > 500 ? 8 : 4;
      } else { input = make('input'); input.type = 'text'; input.value = current; input.maxLength = 10000; }
      input.addEventListener('input', () => {
        let target = selected().value; for (const part of next.slice(0,-1)) target = target[part];
        target[next[next.length-1]] = typeof current === 'boolean' ? input.checked : typeof current === 'number' ? Number(input.value) : input.value; dirty(true);
      });
      wrapper.append(input); parent.append(wrapper);
    }
  }
  function renderEditor() {
    const record = selected(); const form = $('editor-form'); form.replaceChildren(); if (!record) return;
    form.append(make('h3', recordTitle(record)), make('p', 'Edit the words below. Your update appears on the public website after you publish and refresh it.', 'record-context'));
    renderFields(record.value, form); form.addEventListener('submit', (e) => e.preventDefault(), { once: true });
  }
  async function loadContent() {
    const data = await request('content'); state.content = data.content; state.revision = data.revision; state.record = 0; dirty(false);
    const summary = $('editor-summary'); summary.replaceChildren();
    [[records('pages').length, 'Editorial pages'], [records('entries').length, 'Reading selections'], [state.revision, 'Published revisions']].forEach(([num, text]) => {
      const stat = make('div', undefined, 'summary-stat'); stat.append(make('strong', String(num)), make('span', text)); summary.append(stat);
    });
    renderPicker(); renderEditor();
  }
  async function tab(id) {
    show(`${id}-panel`); document.querySelectorAll('[data-tab]').forEach((b) => b.classList.toggle('is-active', b.dataset.tab === id));
    if (id === 'subscribers') await loadSubscribers();
  }
  async function loadSubscribers() {
    const data = await request('subscribers'); const target = $('subscriber-list'); target.replaceChildren();
    if (!data.subscribers.length) {
      const empty = make('div', undefined, 'empty-state'); empty.append(make('h3', 'Every conversation starts somewhere.'), make('p', 'When readers submit a consented newsletter request, it will appear here. The website does not send an email or start a campaign automatically.')); target.append(empty); return;
    }
    const info = make('p', `${data.subscribers.length} subscription request${data.subscribers.length === 1 ? '' : 's'} stored privately.${data.subscribers.length > 200 ? ' Showing the first 200; CSV includes all requests.' : ''}`); target.append(info);
    const wrap = make('div', undefined, 'subscriber-table-wrap'); const table = make('table', undefined, 'subscriber-table'); const head = make('thead'); const hrow = make('tr');
    ['Email address', 'Interests', 'Requested', 'Status', ''].forEach((t) => { const th = make('th', t); th.scope = 'col'; hrow.append(th); }); head.append(hrow); table.append(head); const body = make('tbody');
    data.subscribers.slice(0,200).forEach((row) => {
      const tr = make('tr'); [row.email, row.topics.join(', ') || 'General updates', new Date(row.createdAt).toLocaleDateString(), row.status].forEach((t) => tr.append(make('td', t)));
      const td = make('td'); const remove = make('button', 'Remove', 'text-button'); remove.type = 'button'; remove.setAttribute('aria-label', `Remove newsletter request for ${row.email}`);
      remove.addEventListener('click', async () => {
        if (!window.confirm(`Remove ${row.email} from the stored newsletter requests? This also removes their recorded consent from this backend.`)) return;
        try { await request('delete-subscriber', 'POST', { email: row.email }); notice('The newsletter request has been removed.'); await loadSubscribers(); } catch (e) { notice(e.message, true); }
      }); td.append(remove); tr.append(td); body.append(tr);
    }); table.append(body); wrap.append(table); target.append(wrap);
  }
  function formAction(formId, action, success) {
    $(formId).addEventListener('submit', async (event) => {
      event.preventDefault(); const form = event.currentTarget; const button = form.querySelector('button[type=submit]'); button.disabled = true;
      try { const result = await request(action, 'POST', Object.fromEntries(new FormData(form))); form.reset(); notice(result.message || success); if (action !== 'password') await session(); }
      catch (error) { notice(error.message, true); } finally { button.disabled = false; }
    });
  }
  formAction('install-form', 'install', 'Your private account is ready. Sign in to continue.');
  formAction('login-form', 'login', 'You are signed in to the private backend.');
  formAction('password-form', 'password', 'Your password was updated.');
  $('record-type').addEventListener('change', (event) => { state.kind = event.target.value; state.record = 0; renderPicker(); renderEditor(); });
  document.querySelectorAll('[data-tab]').forEach((button) => button.addEventListener('click', () => tab(button.dataset.tab).catch((e) => notice(e.message, true))));
  $('reload').addEventListener('click', () => session().catch((e) => notice(e.message, true)));
  $('reload-content').addEventListener('click', async () => { if (state.dirty && !window.confirm('Discard your unpublished changes and reload the saved content?')) return; try { await loadContent(); notice('The saved editorial content has been reloaded.'); } catch (e) { notice(e.message, true); } });
  $('save-content').addEventListener('click', async () => {
    state.saving = true; $('save-content').disabled = true; document.querySelectorAll('#editor-form input,#editor-form textarea,#record-type,#record-list button').forEach((i) => { i.disabled = true; });
    try { const result = await request('content', 'POST', { content: state.content, revision: state.revision }); state.revision = result.revision; dirty(false); const total = document.querySelectorAll('#editor-summary .summary-stat strong')[2]; if (total) total.textContent = String(state.revision); notice('Your editorial changes are published. Refresh the public website to see them.'); }
    catch (error) { notice(error.message, true); }
    finally { state.saving = false; document.querySelectorAll('#editor-form input,#editor-form textarea,#record-type,#record-list button').forEach((i) => { i.disabled = false; }); $('save-content').disabled = !state.dirty; }
  });
  $('logout').addEventListener('click', async () => { if (state.dirty && !window.confirm('Sign out without publishing your current edits?')) return; try { await request('logout', 'POST', {}); state.dirty = false; await session(); notice('You are signed out.'); } catch (e) { notice(e.message, true); } });
  $('export-subscribers').addEventListener('click', async () => {
    try {
      const response = await fetch('api.php?action=export', { method: 'POST', credentials: 'same-origin', headers: { 'X-CSRF-Token': state.csrf } });
      if (!response.ok) { const data = await response.json(); throw new Error(data.error || 'Export could not be prepared.'); }
      const blob = await response.blob(); const url = URL.createObjectURL(blob); const a = make('a'); a.href = url; a.download = 'rtr-newsletter-requests.csv'; document.body.append(a); a.click(); a.remove(); setTimeout(() => URL.revokeObjectURL(url), 1000);
      notice('Your CSV export is ready. Keep subscriber information private.');
    } catch (error) { notice(error.message, true); }
  });
  window.addEventListener('beforeunload', (e) => { if (state.dirty) { e.preventDefault(); e.returnValue = ''; } });
  session().catch((error) => { show('login'); notice(error.message, true); });
})();
