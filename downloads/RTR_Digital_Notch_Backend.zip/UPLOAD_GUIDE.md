# RTR Digital Notch — upload and launch guide

This guide applies to the new editorial website with nine public pages: **RTR's Notch**, **About**, **Academics**, **Crime Thrillers/Novels**, **Fiction**, **Non-Fiction**, **Literature**, **Magazines**, and **Newsletters**. The public frontend and the content-administration backend are separate deliveries. This edition provides sample editorial content, reading interactions and newsletter-interest capture; it does not activate the earlier digital-commerce checkout.

## 1. Choose a compatible hosting plan

Use Linux web hosting that provides PHP **8.2 or newer**, HTTPS, PHP sessions, JSON, hashing, writable private storage and Apache/LiteSpeed rewrite rules. The backend uses native PHP and private JSON files, so you do not need Node.js, Composer, MySQL or SQLite on the host for this phase.

Both GoDaddy Linux/cPanel hosting and Hostinger PHP web-hosting plans can be suitable when the chosen plan supplies these capabilities. Confirm the actual plan rather than relying on its brand name. Windows/ASP-only hosting, static-only hosting and a plan that prevents private storage outside the public web directory need a different deployment arrangement. This guide has not purchased or logged into your provider account.

The recommended first deployment uses the root of one domain, such as `https://your-real-domain.com/`. Replace every example domain and account path with your own values. Do not use `.example` addresses as live domains.

## 2. Understand the delivered files

| Download | What it contains | Where it belongs |
| --- | --- | --- |
| `RTR_Digital_Notch_Frontend.zip` | Compiled public pages, CSS, JavaScript, images and `.htaccess` | Extract its contents directly into your domain's `public_html`. |
| `RTR_Digital_Notch_Backend.zip` | `public_html/api`, `public_html/admin`, a small public PHP bridge, and `rtr-backend` private application files | Extract at the parent of `public_html`, preserving both sibling directories. |
| `RTR_Digital_Notch_Complete_Source.zip` | Editable new frontend/backend source and the separately preserved previous commerce source | Keep on your computer or in a private source repository; do not upload it into the public website. |
| `RTR_Digital_Notch_Hosting_Package.zip` | The frontend and backend upload trees together, plus these instructions | Extract on your computer first, then follow the directory mapping below. |
| `RTR_Digital_Notch_Upload_Guide.pdf` | The readable version of this guide | Keep beside your browser while uploading. |

You can use the two individual ZIPs or the combined package. Do not upload both repeatedly into nested directories. The complete-source ZIP is for development; it is not the ready-to-serve web folder.

The intended hosting layout is:

```text
YOUR_ACCOUNT_OR_DOMAIN_HOME/
├── public_html/
│   ├── index.html
│   ├── .htaccess
│   ├── assets/
│   ├── images/
│   ├── api/
│   │   ├── content.php
│   │   └── subscribe.php
│   ├── admin/
│   │   └── index.php
│   └── rtr-bootstrap.php
└── rtr-backend/
    ├── app/
    ├── private/
    │   ├── config.example.php
    │   └── config.php       [you create this privately]
    └── seed/
        └── editorial-content.json
```

`public_html` is the public document root. Files in it can potentially be requested by a browser. `rtr-backend/private` is outside that root and contains the configuration and persistent records. Never move `private` under `assets`, `images`, `api`, or any other publicly served directory.

The public PHP bridge looks for the private backend in the sibling `rtr-backend` directory. A host-specific `RTR_BACKEND_PATH` environment setting can override that location when necessary. Use an absolute filesystem path, not an HTTPS URL. If your account does not let you create the sibling directory, use the host's supported SFTP/SSH access or ask it for the correct private location before continuing.

## 3. Prepare the domain, HTTPS and a backup

1. Sign in to your hosting and domain accounts through their official dashboards. Enable their account security controls and retain the recovery information privately.
2. Add the domain to the hosting account if it is not already assigned. Identify the actual document root. A second domain may have its own folder rather than the account's first `public_html`.
3. Point the domain's website DNS records to the assigned hosting service using that host's current instructions. Preserve existing business-email MX/TXT records unless a reviewed migration requires changing them.
4. Activate the host's SSL/TLS certificate for the exact domain. Wait until `https://YOUR-DOMAIN/` opens without a certificate warning.
5. Decide whether the main address includes `www`. Use one final HTTPS origin consistently in redirects and backend configuration. A domain and its `www` form are different hostnames until configured.
6. If a website already exists, use the host's backup tool and download a protected copy before replacing files. Record the original document-root path and any redirects or mail-related settings.
7. Prefer a separate staging domain or subdomain for the first installation. Give staging its own private backend directory, configuration and records. Do not point two installations at the same writable private data.

Do not test administrator credentials over a page that shows an HTTPS warning. The production backend expects HTTPS; a connection that merely uses an IP address usually does not match the domain's certificate.

## 4. Upload on GoDaddy Linux/cPanel hosting

GoDaddy labels can change, but the technical destination remains your domain's actual document root and its private sibling folder.

1. Sign in to GoDaddy and open **My Products** or the account's product list.
2. Find your Linux Web Hosting product, select **Manage**, and open **cPanel Admin**.
3. In cPanel, use its PHP-version control to select PHP 8.2 or newer for the intended domain. The exact control may be called **Select PHP Version** or **MultiPHP Manager** depending on the plan. Confirm PHP sessions and JSON support.
4. Open **File Manager**. Locate the domain's `public_html` or assigned document root. Turn on **Show Hidden Files** in File Manager settings so `.htaccess` is visible.
5. If replacing an old website, preserve its files in your backup first. Do not delete unrelated mail folders, account configuration, or another domain's site.
6. Upload `RTR_Digital_Notch_Frontend.zip` into the document root. Use **Extract** there. After extraction, `index.html` and `.htaccess` must sit directly in `public_html`, with `assets` and `images` beside them. There should not be an extra `frontend` folder between the document root and `index.html`.
7. Move one directory up to the parent of `public_html`. Upload `RTR_Digital_Notch_Backend.zip` and extract it there. Its `public_html` contents merge with the existing public folder, while `rtr-backend` becomes a sibling. Check the layout before extracting if your domain uses a differently named document root.
8. If the document root has another name, manually copy the archive's `public_html` contents into that actual root and place `rtr-backend` immediately beside it. Keep `app`, `private` and `seed` together inside `rtr-backend`.
9. Confirm the public `api/content.php`, `api/subscribe.php`, `admin/index.php` and `rtr-bootstrap.php` files exist.
10. Delete uploaded ZIP files from the public directory after extraction. Downloadable source ZIPs should not remain available from your live site's public folder.
11. Complete the private configuration and administrator setup in sections 6 and 7 below before relying on the backend.

If extraction produced `public_html/public_html/api`, the archive was extracted one directory too deep. Move the inner folder's contents to the actual document root; do not rewrite API URLs just to accommodate the mistaken nesting.

## 5. Upload on Hostinger hPanel

1. Sign in to Hostinger and open **Websites**.
2. Find the intended domain and open **Dashboard** or **Manage**.
3. Find **PHP Configuration** under its advanced/runtime settings and select PHP 8.2 or newer. Apply the change and confirm it affects this domain.
4. Open **Files → File Manager**. Choose the relevant site's files. Identify the domain's actual `public_html` directory and the folder immediately above it.
5. Enable the display of hidden files so you can confirm `.htaccess` after extraction.
6. Upload the frontend ZIP into `public_html` and extract it. `index.html`, `.htaccess`, `assets` and `images` must be at that public root, not inside an extra extraction folder.
7. Navigate to the parent of this domain's `public_html`, then extract the backend ZIP there. The archive's public files belong inside that domain's public root; its `rtr-backend` folder belongs beside the public root.
8. Some Hostinger account layouts use a path resembling `domains/YOUR-DOMAIN/public_html`. In that arrangement the matching private folder is `domains/YOUR-DOMAIN/rtr-backend`. Use your actual path, not this literal example.
9. If File Manager exposes only `public_html`, use the plan's supported file-transfer/SSH route to reach the domain home or ask support how to create a private sibling directory. Do not publish the private backend inside `public_html` as a shortcut.
10. Verify the final directory tree, remove public ZIP files, and continue with configuration below.

A cached Hostinger landing page can persist briefly after upload. Confirm the correct domain/document root first, then use a private browser window and the host's cache-clear control if needed. Re-uploading the project to several unrelated folders makes diagnosis harder.

## 6. Create the private production configuration

No working administrator password or shared installation token is supplied. You must create your own unique setup token privately before opening the installer.

1. In File Manager, open `rtr-backend/private` outside the public web root.
2. Copy `config.example.php` to a new file named exactly `config.php` in that same private folder. Keep the example file as a reference.
3. Open `config.php` in the host's plain-text code editor. Preserve the PHP syntax and the setting names from the supplied template.
4. Set `environment` to `production` for the live site.
5. Replace the `setup_token` placeholder with a new random secret of at least 32 characters from your password manager. Use a long random combination of letters and numbers to keep quoting simple. Do not reuse your email password or post this token in a support screenshot.
6. Set `public_url` to the exact final HTTPS origin, for example `https://YOUR-REAL-DOMAIN.com`. Do not add `/admin`, a query string, a username/password, or an API path.
7. Keep `trust_proxy_https` set to `false` unless you have verified that a trusted reverse proxy handles HTTPS and safely supplies the relevant forwarded protocol header. Enabling it blindly can cause the backend to trust client-supplied headers.
8. Save the file. Reopen it privately to confirm the filename and values, without exposing the token to a public page or screenshot.
9. Ensure PHP can write to `rtr-backend/private`. On typical shared hosting, PHP runs as your account user. Use owner-only private directory permissions such as `700` and private configuration/data-file permissions such as `600` where the account permits them. Public files normally use `644` and public directories `755`.
10. Do not use `777` to fix a permissions error. Check file ownership and the host's PHP execution identity instead. Retain the private setup token after installation: the backend also uses it to protect rate-limit identifiers. It is not a disposable password-reset switch.

The exact template in your delivered backend remains authoritative if a later release adds optional settings. Do not replace the complete file with a shortened example that discards required fields. A secret changed after installation is not automatically a password-reset operation.

## 7. Create and use the separate administrator account

1. Open `https://YOUR-REAL-DOMAIN/admin/` directly in your browser. There is intentionally no administrator link or demonstration-admin button in the public navigation.
2. On an uninitialized installation, the administrator setup screen appears. Enter the unique setup token you just saved privately.
3. Enter an email address you control and create a unique administrator password using 12–72 ASCII characters. Store the account in your password manager.
4. Submit the setup form once and wait for its success result. Setup records are saved privately; completing setup locks the installation workflow.
5. Sign in through the administrator login screen with your new credentials. A public visitor opening `/admin/` receives the login screen, not publishing controls.
6. Open **Editorial content** and inspect **The nine pages** in its record selector. Change a small item of demonstration text, choose **Publish changes**, then open the corresponding public page in another tab and refresh.
7. Check the saved result. The frontend has bundled sample content for its initial display; a successful API response supplies your saved content. A change in the admin editor should appear after the public page reloads with the working API.
8. Use **Reading selections** to edit story/excerpt records, or **Brand & global copy** to update the supported site-wide wording. Keep text plain; this backend does not accept arbitrary HTML, scripts or a visual page-builder layout.
9. Open **Newsletter requests** after performing a controlled newsletter test. **Download CSV** saves the consented request records. Use the individual **Remove** control for a deletion request, and honor the confirmation prompt. Export only to a protected location and treat subscriber email addresses as private personal data.
10. Use **Account & security** for a supported password change; supply the current password and your new unique password. Use **Sign out** when finished, particularly on a shared computer. Opening the public homepage is not a logout action.

The backend is for content management and newsletter-interest records in this edition. It does not provide the old Node commerce panel, payment account connections or an upload-and-sell library through this PHP administration screen. Those earlier services remain separately preserved for the future commerce phase.

## 8. Check all nine public pages

Use the visible public navigation and confirm each requested page opens. Then refresh the browser on the page's own address. This second step checks the host's rewrite configuration, which ordinary client-side navigation alone does not establish.

| Page | What to check |
| --- | --- |
| RTR's Notch | Hero artwork, featured-item navigation, reading controls and category links. |
| About | Editorial introduction and responsive manifesto/story sections. |
| Academics | Subject choices, sample academic content and reading preview. |
| Crime Thrillers/Novels | Dark editorial treatment, genre/content filtering and reading preview. |
| Fiction | Fiction selection, preview and saved-reading interaction. |
| Non-Fiction | Topic selection, sorting and nonfiction sample content. |
| Literature | Literary text, excerpt viewing and navigation. |
| Magazines | Issue/pick interactions and magazine content previews. |
| Newsletters | Email entry, topic choices, explicit consent and real backend submission feedback. |

Also test the mobile menu, keyboard access, search, close controls, saved-reading persistence after refresh, and reduced-motion behavior. Sample editorial titles and excerpts are demonstration content for replacement, not claims of a paid catalog already supplied by third-party publishers.

## 9. Verify the newsletter flow honestly

1. Open Newsletters on the live HTTPS site.
2. Enter an inbox you control, select the intended topics and actively choose the consent checkbox.
3. Submit once. Read the result. A successful result means the request was stored by this backend; it does not mean a campaign or confirmation email was sent.
4. Sign in separately to the administrator area and confirm the test address and topic selection appear.
5. Test a missing/invalid email and a submission without consent. The backend should reject invalid input rather than silently adding it.
6. Keep subscriber exports private. The export workflow protects spreadsheet cells against formula interpretation, but that does not make the personal information public.
7. Before you begin sending newsletters, connect and configure your chosen email delivery/consent-management service as a later integration. This edition does not pretend that a collected address has been double-opted-in or that a message was delivered.

Avoid repeated rapid submissions while testing; rate limits protect the form. If a submission is rejected for excessive attempts, wait for the applicable limit window instead of switching off the protection.

## 10. Run and edit the new frontend locally

Node.js is a development/build tool for the public frontend. It is not required on the shared host after you upload its compiled output. PHP is required locally if you want to test the content backend and newsletter storage rather than only the visual frontend.

Do not double-click the compiled `index.html` to run the site locally. Browser `file://` module restrictions and the absent PHP server can break that approach. Use `npm run dev` from the complete source, or upload the compiled files as documented.

1. Extract `RTR_Digital_Notch_Complete_Source.zip` on your own computer.
2. Open the `RTR_Digital_Notch_Source` folder in a code editor. Confirm the top level contains `package.json`, `frontend`, `backend`, `shared` and `scripts`.
3. Install a current supported Node runtime for this project; the existing project tooling targets Node 24 LTS. Open a fresh terminal and confirm `node --version`.
4. From the source root, run `npm ci`. On PowerShell systems where `npm.ps1` is blocked, use `npm.cmd ci` instead of weakening the machine's execution policy.
5. Run `npm run dev` to start both the separate PHP backend and the new public frontend. Open the printed public address, normally `http://localhost:5173`. Use `npm.cmd run dev` in PowerShell when needed. Keep this terminal running. If you only want the visual frontend without PHP, use `npm run dev:frontend` instead.
6. The backend helper uses PHP on your machine or its documented Docker fallback, listens on port 3002, and creates a private development configuration only when one is absent. Read the generated setup token privately in `backend/private/config.php`, open `http://localhost:3002/admin/`, and create your own local owner account. This is separate from the public frontend. For manually controlled separate terminals, use `npm run dev:backend` in one and `npm run dev:frontend` in another instead of the combined command; do not start a second backend on the occupied port.
7. Edit the new public code under `frontend/src`. Do not edit the preserved `legacy-commerce/src` when you intend to change this editorial website.
8. Use `shared/editorial-content.json` for the initial bundled sample copy. Existing backend-saved content can override that seed, so use the administrator editor to update an already installed site's content.
9. Run `npm run build` to rebuild the frontend before upload. Source `.tsx` files are not runnable replacements for the compiled `assets` files on a PHP host. The new public output is `dist/frontend`.
10. Run `node scripts/package-notch.mjs` after building to create the new upload ZIPs under `deliverables`. Keep live private configuration and data outside the source repository. The PDF is included in the combined package when present; the Markdown upload instructions are always included.
11. Upload the updated frontend files to the same public root, preserve the API/admin folders, and check the changed public pages after clearing stale cache if necessary. Stop each local development terminal with Ctrl+C when finished.

Code changes and content changes are different operations. An admin save does not need a Node build. A CSS or React source change needs a frontend rebuild. A backend PHP code update does not require you to replace the private customer/subscriber records.

## 11. Back up and update safely

1. Back up your current public release and the entire private backend directory before making a substantive update. Keep the backup outside `public_html` and retain an encrypted/off-server copy.
2. Preserve `rtr-backend/private/config.php` and the complete persistent private record set. A fresh source ZIP does not contain your installed administrator credentials or saved subscribers.
3. Pause administrator edits and newsletter submissions during a filesystem backup or ask your operator to use the host's consistent snapshot procedure. Copying several writable files at arbitrary moments is not an assured consistent snapshot.
4. Restore first into a separate staging directory with a separate domain/private path. Do not overwrite the only live copy to discover whether a backup works.
5. For a frontend-only update, replace the compiled public frontend files while preserving `api`, `admin`, `rtr-bootstrap.php` and the private sibling backend.
6. For a backend update, review the release instructions and replace only application/public PHP code and intentional seed changes. Preserve `private/config.php` and installed data. Do not extract a fresh template over a live private directory without reviewing the operation.
7. Confirm login, a content edit, a public page refresh and a controlled newsletter submission after the update. Keep your previous tested release available for a considered rollback.

Do not publish backups, raw subscriber exports, setup tokens or source archives in the website's public downloads. A website source release and a private business-data backup are different deliverables.

## 12. Troubleshooting by symptom

### The host's default page still appears

Check that the domain points to the intended account and that `index.html` is in the real document root. Look for an old `index.php` or provider landing page that takes precedence. Preserve the old file before removing or renaming it. Then clear the host/browser cache and test privately.

### Navigation works, but refreshing About or another page returns 404

Confirm `.htaccess` was extracted at the same level as `index.html`; hidden files are easy to miss. Check that Apache/LiteSpeed rewrite rules are supported/enabled for the plan. Do not rewrite `/api` or `/admin` to the React page.

### The visual pages work, but saved admin content or newsletter submission fails

Open `https://YOUR-DOMAIN/api/content.php` directly. A working endpoint returns JSON with a `content` field, not the React HTML page or a PHP source download. Confirm PHP is enabled, the public bridge exists, and the private backend is at the expected sibling path. Check the host's PHP error log privately for the actual cause.

### PHP source text downloads instead of executing

Stop the launch and correct the hosting/PHP-handler configuration. Do not put secrets into public PHP files to work around it. This application requires a PHP-capable plan for its backend.

### Administrator setup says the token is invalid

Check the private `config.php` exists in the selected backend path and that its token is a fresh secret at least 32 characters long. Do not leave the template's `REPLACE-*` marker. The token typed in the installer must match the private value exactly. A completed installation is intentionally not an open setup form.

### Login or a save fails after moving from staging to production

Check the exact HTTPS origin, `public_url`, cookies and the installation's chosen private path. Use a private browser window to rule out a stale session. Save requests require the session's current CSRF protection; do not disable it to suppress a deployment error.

### The backend reports that it cannot save

Check that the private directory belongs to the hosting account's PHP user and is writable. Read the specific error and inspect storage quota/free space. Fix ownership/path configuration rather than setting the whole website to `777`.

### The administrator password is lost

Ask your authorized hosting operator to make a complete protected backend backup first. The owner-recovery helper is a server-CLI program under `rtr-backend/bin/recover-admin.php`; it is deliberately not a public reset URL. From the private `rtr-backend` directory, run `php bin/recover-admin.php --confirm-owner-recovery`, then enter the new 12–72-character password at its prompt. Do not put a real password into a command line or a support ticket. The helper preserves content/subscribers and invalidates older sessions. If the plan does not provide PHP CLI/SSH access, arrange recovery through the hosting operator; do not move this helper into `public_html` or delete the private records.

### CSS or images are missing

Confirm `assets` and `images` were extracted beside `index.html` and that case-sensitive filenames match. Use a domain-root deployment as documented. Deploying the build inside an extra subdirectory requires a deliberate base-path and routing build; moving files alone does not configure that.

### Someone can see the administrator login URL

The administrator login screen is a separate protected entry point at `/admin/`. Its existence is not permission to view or edit content. Public navigation contains no admin controls, and unauthenticated administrative changes must fail. Keep a strong private administrator password and use HTTPS.

## 13. Final launch checklist

1. All nine requested public pages open and refresh correctly on the chosen HTTPS domain.
2. Public navigation contains the editorial pages, search and reading interactions, with no administrator/demo controls.
3. A private-window visit to `/admin/` requires setup/login rather than exposing editing controls.
4. Your unique administrator account works, the installer is locked after setup, and logout ends the session.
5. A deliberate content edit appears publicly after refresh, and an unauthenticated visitor cannot make edits.
6. A controlled newsletter submission is stored; invalid input and missing consent are rejected.
7. The final HTTPS origin and private backend filesystem path are correct.
8. Source archives, setup tokens and private records are absent from public directories.
9. You have a current protected backup and have identified how to restore it into staging.
10. Sample text has been reviewed for your intended public preview. No payment, inventory, campaign delivery or third-party publishing claims are implied by the demonstration content.
