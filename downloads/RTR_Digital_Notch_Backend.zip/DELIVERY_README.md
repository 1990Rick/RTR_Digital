# RTR Digital Notch — what this delivery is

This release replaces the public experience for the current editorial phase. It has nine pages requested by the owner: RTR's Notch, About, Academics, Crime Thrillers/Novels, Fiction, Non-Fiction, Literature, Magazines and Newsletters.

The **frontend** is the compiled public React website. It contains editorial presentation, navigation, search, sample reading previews and locally saved reading selections. It has no administrator workspace, shared demo sign-in, merchant controls or embedded content-management screen.

The **backend** is a separate PHP 8.2+ content-management application. Its public API and password-protected `/admin/` entry point are uploaded separately; its configuration, credentials and persistent records stay outside the public document root. It stores page/story edits and explicit newsletter-interest submissions. It does not send a marketing campaign or imply verified email delivery.

The **previous Node/SQLite digital-commerce application** is preserved in the complete source download under `legacy-commerce/`. It is a separate application with its original runtime requirements. It is not silently deployed into a PHP-only shared plan, and its checkout/admin UI is not part of the new public website. Later commerce integration must deliberately connect the new public design to the appropriate commerce services.

Use `RTR_Digital_Notch_Hosting_Package.zip` for the combined upload trees, or use the clearly separated frontend/backend ZIPs. Follow `NOTCH_HOSTING_GUIDE.md` or its PDF version for the exact directory layout and setup. Do not upload the complete-source ZIP as your live document root.

No real domain account, hosting purchase, bank account, live merchant charge or email campaign has been provisioned by preparing this delivery. GoDaddy and Hostinger compatibility refers to plans meeting the PHP/private-storage/HTTPS requirements in the upload guide; it does not mean every product sold under those brands supports this backend.

Sample editorial text and conceptual artwork are supplied for design and interaction review. The owner can replace the text later through the separated content backend and make structural design changes in `frontend/src`. No paid third-party book inventory or publisher relationship is represented by the sample titles.
