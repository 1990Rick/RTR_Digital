# RTR Digital Notch artwork

Original generated artwork for the nine-page RTR Digital editorial website. These are conceptual book and paper still lifes, not photographs of products currently offered for sale. No real people, brand marks, lettering, or third-party product covers appear.

## Shared style specification

Editorial still-life photograph with surreal sculptural objects, soft directional late-afternoon light from upper left, warm ivory #f7f4ec and ink #20231f with vermilion #d7472f accents, close three-quarter camera, restrained analog grain and warm desaturated grade, matte textured paper and plaster background, no people, no text, no lettering, no logos, no watermark.

This exact paragraph prefixed every generation prompt. Per-section subject descriptions supplied the blue, charcoal, peach, sage, ivory and red variations.

## Ready-to-use assets

| Filename | Exact pixels | Measured bytes | Alt text |
| --- | --- | --- | --- |
| `rtr-digital-notch-hero.webp` | 1920 × 1080 | 187438 | Unlettered books and open pages beside a cream arch and vermilion sun disk in a warm sculptural still life. |
| `rtr-digital-notch-academics.webp` | 800 × 600 | 46120 | A periwinkle book beside ivory stairs, a brass sphere and folded paper in warm afternoon light. |
| `rtr-digital-notch-crime.webp` | 800 × 600 | 51104 | A charcoal book beneath dark architectural arches with a red moon and softly folded ivory paper. |
| `rtr-digital-notch-fiction.webp` | 800 × 600 | 50190 | A peach book on a stone plinth beneath floating curved paper and a suspended vermilion sphere. |
| `rtr-digital-notch-nonfiction.webp` | 800 × 600 | 58084 | A sage book, dark stone and sculptural paper aperture crossed by a narrow vermilion ribbon. |
| `rtr-digital-notch-literature.webp` | 800 × 600 | 43624 | Open ivory pages and a curling black ribbon framed by a cream arch and a small red sphere. |
| `rtr-digital-notch-magazines.webp` | 800 × 600 | 52178 | Blank red and ivory magazines stacked beneath an upright black disk and a small cream cylinder. |

All final assets are RGB WebP, converted with Pillow using quality 86 and method 6. Exact-size fitting uses Lanczos resampling. The original generated PNGs remain unchanged in the generation workspace; final WebP files are the deployable assets. The hero was generated at 1672 × 941 before exact 16:9 sizing, and each section artwork at 1448 × 1086 before exact 4:3 sizing.

## Subject prompts

Each paragraph below follows the shared style specification above.

### Hero

Create a high-end editorial website hero picture, wide landscape 16:9 composition. A compact sculptural arrangement occupies the right two thirds: three tactile unlettered linen-bound books, one vermilion red, one deep forest green, one warm ivory; a cream open book with delicate paper pages gently fanning, a large vermilion sun disk behind a matte cream architectural arch, one small charcoal sphere and low plaster plinth. Restful gallery quality with refined soft long shadows and tangible paper fibers, a literary world of curiosity and imagination. Left one third is clean warm ivory negative space. No typography anywhere. Target 1920 by 1080 pixels.

### Academics

A fine art still life for the Academics section: an unlettered periwinkle blue hardback book standing beside elegant geometric stair steps made of ivory paper, a thin brass sphere and one folded graph-like paper plane with no actual writing. Calm scholarly curiosity, restrained periwinkle accents. Centered compact composition on warm ivory with room around every edge. Target 800 by 600 pixels.

### Crime

A fine art atmospheric still life for the Crime Thrillers and Novels section: a mysterious unlettered matte charcoal book emerging from layered dark charcoal architectural arches, a small vermilion moon disk, folded ivory paper and one elongated hard shadow. No people, no weapons, no violence, just literary suspense. Predominantly deep charcoal background, discreet red accent, centered compact composition. Target 800 by 600 pixels.

### Fiction

A fine art still life for the Fiction section: an unlettered soft peach hardback book resting on a sculptural plinth, a suspended ivory paper arch with curled pages and a warm vermilion sphere suspended nearby, surreal literary imagination. Delicate peach and warm cream background, compact centered composition with open margins. Target 800 by 600 pixels.

### Non-fiction

A fine art still life for the Non-Fiction section: a beautiful unlettered deep sage green hardback book, smooth natural dark stone, upright sculptural paper rectangle with a circular aperture and one narrow vermilion ribbon. Grounded tactile objects and quiet discovery, pale sage and ivory setting, compact centered composition with open margins. Target 800 by 600 pixels.

### Literature

A poetic fine art still life for the Literature section: layered delicate warm ivory paper folds like an open book in motion, an elegant black ink-colored silk ribbon curling through the air, one small vermilion sphere, large subtle architectural ivory arch. Airy monochromatic cream background, deep black accent, meditative and timeless, compact centered composition with generous margins. Target 800 by 600 pixels.

### Magazines

A confident fine art still life for the Magazines section: a sculptural stack of blank vermilion and ivory editorial magazines, clean layered paper edges, one large matte black circle standing upright and a small ivory cylinder. Graphic angular composition, pale warm ivory background, striking red and black contrast, no printed text whatsoever. Compact centered composition with margins. Target 800 by 600 pixels.
